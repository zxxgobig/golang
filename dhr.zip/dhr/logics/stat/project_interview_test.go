package stat

import (
	"reflect"
	"testing"

	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

// go test -run Test_leaderShipStyleFreqHandler -v
func Test_leaderShipStyleFreqHandler(t *testing.T) {
	type args struct {
		axesV1 []*pb.Axis
	}
	tests := []struct {
		name string
		args args
		want []*DimensionFreq
	}{
		// TODO: Add test cases.
		{
			name: "",
			args: args{axesV1: []*pb.Axis{
				{
					Id:        1,
					Frequency: 1,
					StaffId:   8874,
				},
				{
					Id:        2,
					Frequency: 3,
					StaffId:   8874,
				},
				{
					Id:        3,
					Frequency: 4,
					StaffId:   8874,
				},
				{
					Id:        4,
					Frequency: 4,
					StaffId:   8874,
				},
				{
					Id:        1,
					Frequency: 2,
					StaffId:   496,
				},
				{
					Id:        2,
					Frequency: 3,
					StaffId:   496,
				},
				{
					Id:        3,
					Frequency: 5,
					StaffId:   496,
				},
				{
					Id:        4,
					Frequency: 2,
					StaffId:   496,
				},
			}},
			want: []*DimensionFreq{
				{
					ID:     3,
					Name:   "支持型",
					Number: 2,
				},
				{
					ID:     4,
					Name:   "授权型",
					Number: 1,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := leaderShipStyleFreqHandler(tt.args.axesV1); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("leaderShipStyleFreqHandler() = %v, want %v", got, tt.want)
			}
		})
	}
}
