package v2_scene

import (
    "ifchange/dhr/models"
)

const Scene1 = 1 // 人才发展建议
const Scene2 = 2 // 人才结构扫描
const Scene3 = 3 // 高潜人才识别
const Scene4 = 4 // 人才能力分层

func ConvertSceneModels(src []*models.ProjectsScenes) []*SceneModel {
    if len(src) == 0 {
        return nil
    }

    dst := make([]*SceneModel, 0, len(src))

    for _, v := range src {
        dst = append(dst, &SceneModel{
            ProjectsScenes: v,
        })
    }

    return dst
}
