package stat

import (
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	"gitlab.ifchange.com/bot/logger"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

func GetProjectInterviewData(companyID, projectID int, interviewType interview.Type) (*InterviewResult, error) {
	result, err := client.GetGroupInterviewData(nil, &pb.GroupInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    pb.StatType_PROJECT,
		Id:          int64(projectID),
		InterviewId: int64(interviewType),
	})
	if err != nil {
		return nil, err
	}
	if result == nil || result.Axes == nil {
		return nil, nil
	}

	data := make(EvalAxes, 0)
	for _, a := range result.Axes {
		data = append(data, EvalAxis{
			ID:             int(a.Id),
			Name:           a.Name,
			Score:          a.Score,
			Freq:           a.Frequency,
			ExcellentScore: a.ExcellentScore,
			Total:          getInterviewTotal(interviewType),
		})
	}

	avg := result.Avg
	// 这两个测评的平均分取的是所有员工得分的平均分
	if interviewType == interview.OrgCommitment || interviewType == interview.CriticalThinking {
		avg = result.Score
	}

	ret := &InterviewResult{
		Avg:  avg,
		Data: getStatFormResponseData(data, getStatOption(interviewType, result.ExcellentScore)),
	}

	if interviewType == interview.LeadershipStyle {
		ret.Data.DimensionFreqs = leaderShipStyleFreqHandler(result.AxesV1)
	}

	return ret, nil
}

func getInterviewTotal(typ interview.Type) int {
	total := 5

	switch typ {
	case interview.PracticalIntelligence, interview.EmotionalIntelligence, interview.CriticalThinking, interview.PersonalityDisorder, interview.OccupationalPersonality, interview.OrgCommitment:
		total = 10
	case interview.LeadershipStyle:
		total = 12
	case interview.Personality:
		total = 9
	}

	return total
}

func leaderShipStyleFreqHandler(axesV1 []*pb.Axis) []*DimensionFreq {
	staffID2FreqObj := make(map[int64][]*FreqObj)
	for _, a := range axesV1 {
		freqObj := &FreqObj{
			ID:   int(a.Id),
			Freq: int(a.Frequency),
		}
		staffID2FreqObj[a.StaffId] = append(staffID2FreqObj[a.StaffId], freqObj)
	}

	dimensionFreqMap := make(map[int]*DimensionFreq)
	for _, objs := range staffID2FreqObj {
		_, topID := GetTopFreq(objs)
		for _, id := range topID {
			if _, ok := dimensionFreqMap[id]; ok {
				dimensionFreqMap[id].Number++
				continue
			}
			dimensionFreqMap[id] = &DimensionFreq{
				ID:     id,
				Name:   LeadershipStyleAxesMap[id].Name,
				Number: 1,
			}
		}
	}
	dimensionFreqs := make([]*DimensionFreq, 0, 4)
	for _, each := range dimensionFreqMap {
		dimensionFreqs = append(dimensionFreqs, each)
		logger.Infof("dimensionFreq:%v ", each)
	}
	return dimensionFreqs
}

var LeadershipStyleAxesMap = map[int]Axis{
	1: {ID: 1, Name: "命令型"},
	2: {ID: 2, Name: "教练型"},
	3: {ID: 3, Name: "支持型"},
	4: {ID: 4, Name: "授权型"},
}
