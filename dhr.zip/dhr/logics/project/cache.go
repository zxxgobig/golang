package project

import (
	"encoding/json"
	"fmt"
	"time"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/redis"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/logger"
)

var expiredIn = time.Second * 60

func getStaffIDsFormDB(projectID int) ([]int, error) {
	staffs, err := models.ProjectsStaffsModel.Search(db.Cond{
		"project_id": projectID,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, fmt.Errorf("getProjectStaffIDs models.ProjectsStaffsModel.Search error: %v", err)
	}

	staffIDs := make([]int, 0)
	for _, s := range staffs {
		staffIDs = append(staffIDs, s.StaffId)
	}

	return staffIDs, nil
}

func GetStaffIDs(projectID int) ([]int, error) {
	ids, err := getStaffsCache(projectID)
	if err != nil {
		logger.Errorf("getStaffsCache error: %v", err)
	}
	if len(ids) != 0 {
		return ids, nil
	}

	ids, err = getStaffIDsFormDB(projectID)
	if err != nil {
		return nil, fmt.Errorf("getStaffs error: %v", err)
	}

	err = setStaffsCache(projectID, ids)
	if err != nil {
		logger.Errorf("getStaffsCache error: %v", err)
	}

	return ids, nil
}

func getStaffsCache(projectID int) ([]int, error) {
	data, err := redis.Get(projectStaffsKey(projectID))
	if err != nil {
		return nil, fmt.Errorf("get from redis error: %v", err)
	} // 28.15 - 27.91 = 0.24 * 700 = 168 块

	if data == nil {
		return nil, nil
	}

	d := data.(string)
	ids := make([]int, 0)
	err = json.Unmarshal([]byte(d), &ids)
	if err != nil {
		return nil, fmt.Errorf("get cache json.Unmarshal error: %v", err)
	}

	return ids, nil
}

func setStaffsCache(projectID int, ids []int) error {
	data, err := json.Marshal(&ids)
	if err != nil {
		return fmt.Errorf("set cache json.Marshal error: %v", err)
	}

	err = redis.SetEx(projectStaffsKey(projectID), string(data), int(expiredIn.Seconds()))
	if err != nil {
		return fmt.Errorf("set to redis error: %v", err)
	}

	return nil
}

func projectStaffsKey(projectID int) string {
	return fmt.Sprintf("%s-projectID-%d", config.AppConfig.Redis.Prefix, projectID)
}
