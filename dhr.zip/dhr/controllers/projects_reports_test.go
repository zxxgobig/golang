package controllers

import (
    "ifchange/dhr/logics/project"
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/projects_reports", &ProjectsReport{})
}

/*
go test ./controllers -run TestProjectsReportsList -e local -v
*/
func TestProjectsReportsList(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: 54,
    }
    rsp := test.Do(t, "/projects_reports/list", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/list results: <%+s>", b)

}

func TestProjectsReportsDistributionInterviewList(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: 60,
    }
    rsp := test.Do(t, "/projects_reports/distribution_interview_list", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/list results: <%+s>", b)

}

/*
go test ./controllers -run TestProjectReportDelete -e local -v
*/
func TestProjectReportDelete(t *testing.T) {
    session, _ := GetSession()
    params := &struct {
        *Session
        ProjectID int `json:"project_id"`
        ReportID  int `json:"report_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: 1,
        ReportID:  2,
    }

    rsp := test.Do(t, "/projects_reports/delete", &params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/projects_reports/delete results: <%+s>", b)
}

/*
go test ./controllers -run TestProjectReportEdit -e local -v
*/
func TestProjectReportEdit(t *testing.T) {
    session, _ := GetSession()

    params := &struct {
        *Session
        ProjectId int    `json:"project_id" validate:"required"`
        Id        int    `json:"id" validate:"required"`
        Name      string `json:"name" validate:"required"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectId: 2,
        Id:        1,
        Name:      "修改之后名字",
    }

    rsp := test.Do(t, "/projects_reports/edit", &params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/projects_reports/edit results: <%+s>", b)
}

func TestProjectsReportDump(t *testing.T) {
    session, _ := GetSession()

    params := &struct {
        *Session
        ProjectId    int                   `json:"project_id" validate:"required"`
        Name         string                `json:"name" validate:"required"`
        AdjustStaffs []project.AdjustStaff `json:"adjust_staffs" validate:"required"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectId: 50,
        Name:      "修改之后名字",
        AdjustStaffs: []project.AdjustStaff{
            {ID: 1,
                Original: 1,
                Target:   1,
            },
        },
    }

    rsp := test.Do(t, "/projects_reports/dump", &params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/projects_reports/dump results: <%+s>", b)
}

func TestProjectsReportDayDumpCount(t *testing.T) {
    session, _ := GetSession()

    params := &struct {
        *Session
        ProjectId int `json:"project_id" validate:"required"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectId: 1,
    }

    rsp := test.Do(t, "/projects_reports/day_dump_count", &params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/projects_reports/day_dump_count results: <%+s>", b)
}
