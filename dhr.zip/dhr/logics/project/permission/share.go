package permission

import (
    "ifchange/dhr/libraries"
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/hfw/db"
)

func ShareTo(companyID, accountID, projectID int, toAccountIDList []int) error {
    data, err := models.ProjectsPermissionsModel.Search(db.Cond{
        "project_id": projectID,
        "user_id in": toAccountIDList,
        "is_deleted": 0,
    })
    if len(data) == len(toAccountIDList) { // All data saved
        return nil
    }

    existData := make(map[int]bool, 0)
    for _, p := range data {
        existData[p.UserId] = true
    }

    perms := make([]*models.ProjectsPermissions, 0)
    for _, userID := range toAccountIDList {
        if existData[userID] {
            continue
        }
        perms = append(perms, &models.ProjectsPermissions{
            CompanyId: companyID,
            ProjectId: projectID,
            UserId:    userID,
            Category:  1, // 1 表示项目
            CreatedBy: accountID,
            UpdatedBy: accountID,
        })
    }
    _, err = models.ProjectsPermissionsModel.Insert(perms...)

    return err
}

type SimpleAccountInfo struct {
    ID    int    `json:"id"`
    Name  string `json:"name"`
    Email string `json:"email"`
}

func CanShareTo(currentUserID, companyID, projectID int) (result []SimpleAccountInfo, err error) {
    accounts, err := libraries.GetUserListByCompanyID(companyID)
    if err != nil {
        return nil, err
    }

    perms, err := models.ProjectsPermissionsModel.Search(db.Cond{
        "company_id": companyID,
        "project_id": projectID,
        "is_deleted": 0,
    })
    if err != nil {
        return nil, err
    }

    shared := make(map[int]bool)
    for _, p := range perms {
        shared[p.UserId] = true
    }

    result = make([]SimpleAccountInfo, 0)
    for id, a := range accounts {
        // 过滤已分享的账号和当前登录的账号
        if shared[id] || a.Id == currentUserID {
            continue
        }
        
        // 排除超级管理员
        if a.RoleType == 1 || a.RoleType == 3{
            continue
        }

        result = append(result, SimpleAccountInfo{
            ID:    a.Id,
            Name:  a.UserName,
            Email: a.LoginEmail,
        })
    }

    return result, nil
}
