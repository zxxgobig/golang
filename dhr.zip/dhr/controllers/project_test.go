package controllers

import (
	"fmt"
	"math/rand"
	"testing"
	"time"

	"ifchange/dhr/logics/interview"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"github.com/json-iterator/go/extra"
	"gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
	extra.RegisterTimeAsInt64Codec(time.Second)
	_ = hfw.Handler("/projects", &Projects{})
}

func TestPerformance(t *testing.T) {
	session, err := GetSession()
	if err != nil {
		t.Fatal(err)
	}
	param := struct {
		*Session
		ProjectID int `json:"project_id"`
	}{
		Session: &Session{
			SessionID: session,
		},
		ProjectID: 1,
	}

	rsp := test.Do(t, "/projects/detail", param)
	b, err := rsp.Results.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("/projects/detail results: <%+s>", b)

}

/*
go test ./controllers -run TestProjectsEdit -v
*/

func TestProjectsEdit(t *testing.T) {
	session, err := GetSession()
	if err != nil {
		t.Fatal(err)
	}
	param := struct {
		*Session
		ProjectID int    `json:"project_id"`
		Name      string `json:"name"`
	}{
		Session: &Session{
			SessionID: session,
		},
		ProjectID: 48,
		Name:      "新项目名",
	}
	rsp := test.Do(t, "/projects/edit", param)
	b, err := rsp.Results.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("/projects/edit results: <%+s>", b)

}

func TestProjcetsDelete(t *testing.T) {
	session, err := GetSession()
	if err != nil {
		t.Fatal(err)
	}
	param := struct {
		*Session
		ProjectID int `json:"project_id"`
	}{
		Session: &Session{
			SessionID: session,
		},
		ProjectID: 1,
	}
	rsp := test.Do(t, "/projects/delete", param)
	b, err := rsp.Results.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("/projects/delete results: <%+s>", b)
}

/*
go test ./controllers -run TestProjectsPositions -v
*/
func TestProjectsPositions(t *testing.T) {
	session, err := GetSession()
	if err != nil {
		t.Fatal(err)
	}
	param := struct {
		*Session
		// ProjectID int `json:"project_id"`
	}{
		Session: &Session{
			SessionID: session,
		},
		// ProjectID: 1,
	}
	rsp := test.Do(t, "/projects/positions", param)
	b, err := rsp.Results.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("/projects/positions results: <%+s>", b)
}

/*
go test ./controllers -run TestProjectsListByStaff -e local -v
*/
func TestProjectsListByStaff(t *testing.T) {
	session, _ := GetSession()

	params := struct {
		*Session
		StaffId  int `json:"staff_id"`
		Page     int `json:"page"`
		PageSize int `json:"page_size"`
	}{
		Session: &Session{
			SessionID: session,
		},
		StaffId: 1,
	}

	rsp := test.Do(t, "/projects/list_by_staff", &params)
	b, _ := rsp.Results.MarshalJSON()
	t.Logf("/projects/list_by_staff res: <%+s>", b)
}

/*
go test ./controllers -run TestProjectsList -v
*/
func TestProjectsList(t *testing.T) {
	session, _ := GetSession()
	params := struct {
		*Session
		Key         string `json:"key"`
		PositionIds []int  `json:"position_ids"`
		Page        int    `json:"page"`
		PageSize    int    `json:"page_size"`
	}{
		Session: &Session{
			SessionID: session,
		},
		Key:         "",
		PositionIds: []int{1, 2},
		Page:        0,
		PageSize:    0,
	}

	rsp := test.Do(t, "/projects/list", &params)
	b, _ := rsp.Results.MarshalJSON()
	t.Logf("/projects/list res:<%+s>", b)
}

/*
go test ./controllers -run TestProjectsCreate -v -count=1
*/
func TestProjectsCreate(t *testing.T) {
	rand.Seed(time.Now().UnixNano())

	session, _ := GetSession()
	type requestParam struct {
		*Session
		Name                      string                       `json:"name" validate:"required"`
		SceneId                   int                          `json:"scene_id" validate:"required"`
		PositionId                int                          `json:"position_id" validate:"required"`
		IndustryId                int                          `json:"industry_id" validate:"required"`
		PositionFunctionId        int                          `json:"position_function_id" validate:"required"`
		IsManagerPosition         int                          `json:"is_manager_position"`
		PositionLevelId           int                          `json:"position_level_id" validate:"required"`
		Desc                      string                       `json:"desc"`
		StartAt                   time.Time                    `json:"start_at" validate:"required"`
		InterviewConfigItemParams []*interview.ConfigItemParam `json:"interview_config_item_params" validate:"required"`
		StaffIds                  []int                        `json:"staff_ids" validate:"required"`
		InterviewsConfigs         *interview.InterviewsConfigs `json:"interview_configs"`
	}

	intvConfigs := &interview.InterviewsConfigs{
		WorkValues: []int{1},
		KeyExpr: &interview.KeyExprConfigs{
			ManageExpr:   []int{1},
			BusinessExpr: []int{2},
		},
	}
	_ = intvConfigs

	interviewConfigItemParams := []*interview.ConfigItemParam{
		&interview.ConfigItemParam{
			Id:   1,
			Name: "素质",
			SubItems: []interview.ConfigSubItem{
				interview.ConfigSubItem{
					Id:   11,
					Name: "诚信正直",
				},
				interview.ConfigSubItem{
					Id:   15,
					Name: "有效督导",
				},
				interview.ConfigSubItem{
					Id:   16,
					Name: "组织承诺",
				},
			},
		},
		&interview.ConfigItemParam{
			Id:   2,
			Name: "性格",
		},
		&interview.ConfigItemParam{
			Id:   3,
			Name: "专业技能",
			SubItems: []interview.ConfigSubItem{
				interview.ConfigSubItem{
					Id:   492,
					Name: "货品管理",
				},
				interview.ConfigSubItem{
					Id:   491,
					Name: "融资",
				},
				interview.ConfigSubItem{
					Id:   489,
					Name: "饲养技术",
				},
			},
		},
		&interview.ConfigItemParam{
			Id:   4,
			Name: "专业知识",
			SubItems: []interview.ConfigSubItem{
				interview.ConfigSubItem{
					Id:   517,
					Name: "舞台表演基本理论知识",
				},
				interview.ConfigSubItem{
					Id:   512,
					Name: "金融基本理论知识",
				},
			},
		},
		&interview.ConfigItemParam{
			Id:   5,
			Name: "潜力",
		},
	}

	for x := 1; x <= 200; x = x + 1 {
		params := requestParam{
			Session: &Session{
				SessionID: session,
			},
			Name:                      fmt.Sprintf("%d", time.Now().UnixNano()),
			SceneId:                   rand.Intn(3) + 1,
			PositionId:                1,
			IndustryId:                []int{1, 3, 4, 5, 2, 29}[rand.Intn(len([]int{1, 3, 4, 5, 2, 29}))],
			PositionFunctionId:        61428,
			IsManagerPosition:         rand.Intn(1),
			PositionLevelId:           1,
			Desc:                      fmt.Sprintf("测试项目%d", x),
			StartAt:                   time.Now(),
			InterviewConfigItemParams: interviewConfigItemParams,
			StaffIds:                  []int{14, 32, 38},
			InterviewsConfigs:         intvConfigs,
		}
		rsp := test.Do(t, "/projects/create", &params)
		if rsp.ErrNo > 0 || len(rsp.ErrMsg) > 0 {
			t.Fatalf("%+v", rsp)
		}
		b, _ := rsp.Results.MarshalJSON()
		t.Logf("/projects/create res: <%+v>", b)
	}

}

/*
go test ./controllers -run TestProjectsInterviewConfigItemsRecommend -e local -v
*/
func TestProjectsInterviewConfigItemsRecommendt(t *testing.T) {
	session, _ := GetSession()
	params := &struct {
		*Session
		PositionFunctionID int `json:"position_function_id" validate:"required"`
		PositionLevelID    int `json:"position_level_id" validate:"required"`
	}{
		Session: &Session{
			SessionID: session,
		},
		PositionFunctionID: 61384,
		PositionLevelID:    3,
	}

	rsp := test.Do(t, "/projects/interview_config_items_recommend", &params)
	if rsp.ErrNo > 0 || len(rsp.ErrMsg) > 0 {
		t.Fatalf("%+v", rsp)
	}
	b, _ := rsp.Results.MarshalJSON()
	t.Logf("/projects/interviewconfig_items_recommend res: <%s>", b)
}

/*
go test ./controllers -run TestProjectsCheck -v
*/
func TestProjectsCheck(t *testing.T) {
	session, _ := GetSession()
	params := struct {
		*Session
		ProjectName string `json:"project_name"`
	}{
		Session: &Session{
			SessionID: session,
		},
		ProjectName: "测试项目1",
	}

	rsp := test.Do(t, "/projects/check", &params)
	b, _ := rsp.Results.MarshalJSON()
	t.Logf("/projects/list res:<%+v>", b)
}

/*
go test ./controllers -run TestCheckKeyExprConfigs -v -count=1
*/
func TestCheckKeyExprConfigs(t *testing.T) {
	wv, err := models.InterviewsModel.SearchOne(db.Cond{
		"id": 6,
	})
	if err != nil {
		t.Fatal(err)
	}

	workValuesConfigs := []*interview.ConfigItemParam{}
	err = encoding.JSON.UnmarshalFromString(wv.Config, &workValuesConfigs)
	if err != nil {
		t.Fatal(err)
	}
	for _, i := range workValuesConfigs {
		t.Logf("%+v", *i)
	}
}

/*
go test ./controllers -run TestCheckWorkValuesConfigs -v -count=1
*/
func TestCheckWorkValuesConfigs(t *testing.T) {
	wv, err := models.InterviewsModel.SearchOne(db.Cond{
		"id": 7,
	})
	if err != nil {
		t.Fatal(err)
	}

	keyExprConfigs := []*interview.ConfigSubItem{}
	err = encoding.JSON.UnmarshalFromString(wv.Config, &keyExprConfigs)
	if err != nil {
		t.Fatal(err)

	}
	t.Log(wv.Config)
	for _, i := range keyExprConfigs {
		t.Logf("%+v", *i)
	}
}

/*
go test ./controllers -run TestKeyExpr -v -count=1
*/
func TestKeyExpr(t *testing.T) {
	session, _ := GetSession()
	params := struct {
		*Session
		IndustryID         int `json:"industry_id" validate:"required"`
		PositionFunctionID int `json:"position_function_id" validate:"required"`
		PositionLevelID    int `json:"position_level_id" validate:"required"`
		SceneID            int `json:"scene_id" validate:"required"`
	}{
		Session: &Session{
			SessionID: session,
		},
		IndustryID:         1,
		PositionFunctionID: 1,
		PositionLevelID:    1,
		SceneID:            1,
	}
	rsp := test.Do(t, "/projects/key_expr", params)
	b, err := rsp.Results.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("/projects/key_expr results: <%+s>", b)
}

/*
go test ./controllers -run TestWorkValues -v -count=1
*/
func TestWorkValues(t *testing.T) {
	session, _ := GetSession()
	params := struct {
		*Session
		IndustryID         int `json:"industry_id" validate:"required"`
		PositionFunctionID int `json:"position_function_id" validate:"required"`
		PositionLevelID    int `json:"position_level_id" validate:"required"`
		SceneID            int `json:"scene_id" validate:"required"`
	}{
		Session: &Session{
			SessionID: session,
		},
		IndustryID:         1,
		PositionFunctionID: 1,
		PositionLevelID:    1,
		SceneID:            1,
	}
	rsp := test.Do(t, "/projects/work_values", params)
	b, err := rsp.Results.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("/projects/work_values results: <%+s>", b)
}
