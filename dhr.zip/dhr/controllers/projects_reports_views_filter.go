package controllers

import "gitlab.ifchange.com/bot/hfw"

/**
 * @api {post} /projects_report/distribution_filter_list 项目详情-专业知识技能列表
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-专业知识技能列表
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object[]} result 返回结果
 * @apiSuccess {Object[]} result.result a员工盘点结果列表
 * @apiSuccess {Number} result.result.id a员工盘点结果 ID
 * @apiSuccess {String} result.result.name a员工盘点结果名称
 * @apiSuccess {Object[]} result.profession_skills 专业技能列表
 * @apiSuccess {Number} result.profession_skills.id 专业技能 ID
 * @apiSuccess {String} result.profession_skills.name 专业技能名称
 * @apiSuccess {Object[]} result.potential 潜力列表
 * @apiSuccess {Number} result.potential.id 潜力 ID
 * @apiSuccess {String} result.potential.name 潜力名称
 * @apiSuccess {Object[]} result.quality 素质列表
 * @apiSuccess {Number} result.quality.id 素质 ID
 * @apiSuccess {String} result.quality.name 素质名称
 * @apiSuccess {Object[]} result.performance 绩效等级列表
 * @apiSuccess {Number} result.performance.id 绩效等级 ID
 * @apiSuccess {String} result.performance.name 绩效等级名称
 * @apiSuccess {Object[]} result.personality 性格列表
 * @apiSuccess {Number} result.personality.id 性格 ID
 * @apiSuccess {String} result.personality.name 性格名称
 *
 * @apiSuccessExample {json} Response-Example:
 *	{
 *		"result": [{
 *			"id": 1,
 *			"name": "待发展者"
 *		},{
 *			"id": 2,
 *			"name": "未来之星"
 *		},{
 *			"id": 3,
 *			"name": "明星员工"
 *		},{
 *			"id": 4,
 *			"name": "待观察者"
 *		},{
 *			"id": 5,
 *			"name": "中坚员工"
 *		},{
 *			"id": 6,
 *			"name": "业务能手"
 *		},{
 *			"id": 7,
 *			"name": "低效员工"
 *		},{
 *			"id": 8,
 *			"name": "合格员工"
 *		},{
 *			"id": 9,
 *			"name": "高产员工"
 *		}],
 *		"profession_skills": [{
 *			"id": 1,
 *			"name": "专业薄弱"
 *		},{
 *			"id": 2,
 *			"name": "专业一般"
 *		},{
 *			"id": 3,
 *			"name": "专业扎实"
 *		},{
 *			"id": 4,
 *			"name": "专业精深"
 *		},{
 *			"id": 5,
 *			"name": "专业大牛"
 *		}],
 *		"quality": [{
 *			"id": 1,
 *			"name": "力有不逮"
 *		},{
 *			"id": 2,
 *			"name": "中规中矩"
 *		},{
 *			"id": 3,
 *			"name": "得心应手"
 *		},{
 *			"id": 4,
 *			"name": "融会贯通"
 *		},{
 *			"id": 5,
 *			"name": "出类拔萃"
 *		}],
 *		"potential": [{
 *			"id": 1,
 *			"name": "潜力有限"
 *		},{
 *			"id": 2,
 *			"name": "潜力一般"
 *		},{
 *			"id": 3,
 *			"name": "潜力较高"
 *		},{
 *			"id": 4,
 *			"name": "潜力十足"
 *		},{
 *			"id": 5,
 *			"name": "潜力超群"
 *		}],
 *		"performance": [{
 *			"id": 1,
 *			"name": "S"
 *		},{
 *			"id": 2,
 *			"name": "A"
 *		},{
 *			"id": 3,
 *			"name": "B"
 *		},{
 *			"id": 4,
 *			"name": "C"
 *		}],
 *		"personality": [{
 *			"id": 1,
 *			"name": "内驱力"
 *		},{
 *			"id": 2,
 *			"name": "外向"
 *		},{
 *			"id": 3,
 *			"name": "领导能力"
 *		},{
 *			"id": 4,
 *			"name": "哈哈"
 *		}]
 * }
 *
 */
func (r *ProjectsReport) DistributionFilterList(httpCtx *hfw.HTTPContext) {

}
