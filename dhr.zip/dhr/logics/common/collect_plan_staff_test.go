package common

import (
	"testing"

	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	hfwutil "gitlab.ifchange.com/bot/hfwkit/utils"
)

func TestCollectPlanStaffUpdate(t *testing.T) {
	t.Log(hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Bei).BeforeTime()))
}
