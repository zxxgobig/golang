package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/projects_scenes", &ProjectsScenes{})
}

/*
go test ./controllers -run TestProjectsScenesList  -v
*/

func TestProjectsScenesList(t *testing.T) {
    session, _ := GetSession()

    params := &struct {
        *Session
    }{
        Session: &Session{
            SessionID: session,
        },
    }

    rsp := test.Do(t, "/projects_scenes/list", &params)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_scenes/list results: <%+s>", b)
}

/*
go test ./controllers -run TestProjectsScenesSelectList  -v
*/
func TestProjectsScenesSelectList(t *testing.T) {
    session, _ := GetSession()

    params := &struct {
        *Session
        ProjectID int `json:"project_id" validate:"required"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: 32,
    }

    rsp := test.Do(t, "/projects_scenes/select_list", &params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/projects_scenes/select_list res: <%s>", b)
}
