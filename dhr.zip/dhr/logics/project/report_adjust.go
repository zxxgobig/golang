package project

import (
	"encoding/json"
	"fmt"

	commonlogics "ifchange/dhr/logics/common"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	"gitlab.ifchange.com/bot/logger"
	commonpb "gitlab.ifchange.com/bot/proto/common"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

const (
	COMPOSITE = 0 // 综合能力
	QUALITY   = 1 // 素质
	SKILL     = 3 // 专业知识技能
	POTENTIAL = 5 // 潜力
)

var (
	Interviews = []int{COMPOSITE, QUALITY, SKILL, POTENTIAL}
)

type (
	AdjustStaff struct {
		ID                   int `json:"id"`
		Original             int `json:"original"`
		Target               int `json:"target"`
		OriginalAchievements int `json:"-"`
		TargetAchievements   int `json:"-"`
	}

	StaffData struct {
		ID        int    `json:"id"`
		Name      string `json:"name"`
		AxisX     int    `json:"axis_x"`
		AxisY     int    `json:"axis_y"`
		AxisP     int    `json:"axis_p"`
		AxisClass int    `json:"axis_class"`
	}

	IsReportNameExistResult struct {
		IsExist bool `json:"is_exist"`
	}
)

// Adjust
func Adjust(companyID, projectID, sceneID, interviewID int, name string, adjustStaffs []*AdjustStaff) (reportID int, err error) {
	project, err := models.ProjectsModel.SearchOne(db.Cond{
		"is_deleted": 0,
		"id":         projectID,
	})
	if err != nil {
		return 0, fmt.Errorf("get project error: %v", err)
	}
	if project == nil {
		return 0, fmt.Errorf("no such project for id: %v", projectID)
	}

	isExist, err := isReportNameExist(projectID, name)
	if err != nil {
		return 0, fmt.Errorf("adjust error: %v", err)
	}
	if isExist {
		return 0, common.NewRespErr(20304043, "盘点记录名称已存在")
	}

	ProjectsDistributions := new(models.ProjectsDistributions)
	models.ProjectsDistributionsModel.Dao.SearchOne(
		ProjectsDistributions,
		db.Cond{
			"project_id": projectID,
			"scene_id":   sceneID,
			"is_deleted": 0,
			"orderby":    "created_at desc",
		},
	)

	// 事务开启
	projectsDistributionsDao, err := models.NewProjectsDistributions()
	if err != nil {
		return 0, fmt.Errorf("dump models.NewProjectsReports error: %v", err)
	}
	err = projectsDistributionsDao.Begin()
	if err != nil {
		return 0, fmt.Errorf("dump models.NewProjectsReports.Begin error: %v", err)
	}
	defer func() {
		if err != nil {
			_ = projectsDistributionsDao.Rollback()
		} else {
			_ = projectsDistributionsDao.Commit()
		}
	}()

	projectDistributions := &models.ProjectsDistributions{
		ProjectId: projectID,
		Name:      name,
		SceneId:   sceneID,
	}
	_, err = projectsDistributionsDao.Insert(projectDistributions)
	if err != nil {
		return 0, fmt.Errorf("adjust  projectsDistributionsDao.Insert error: %v", err)
	}

	staffsAdjust := staffAchievements(adjustStaffs)

	allProjectsDistributionsData := make([]*models.ProjectsDistributionsData, 0)
	adjustStaffsMap := make(map[int]AdjustStaff)
	for _, s := range staffsAdjust {
		adjustStaffsMap[s.ID] = *s
	}

	logger.Debugf(
		"====== %s",
		func() string {
			data, _ := json.Marshal(adjustStaffsMap)
			return string(data)
		}())

	for _, ID := range Interviews {
		logger.Debugf("++++++[InterviewID: %d]", ID)

		pbAdjustStaffs := make([]*pb.AdjustStaff, 0)

		switch interviewID {
		case ID:
			pbAdjustStaffs = getCurrentPbAdjustStaff(staffsAdjust)
		default:
			pbAdjustStaffs, err = getOtherPbAdjustStaff(companyID, projectID, ID, adjustStaffsMap)
			if err != nil {
				return 0, fmt.Errorf("getOtherPbAdjustStaff, error: %v", err)
			}
		}

		// 添加历史记录
		pbAdjustStaffs = getlog(projectID, ProjectsDistributions.Id, ID, pbAdjustStaffs, adjustStaffsMap)

		logger.Debugf(
			"++++++++[Data] %s",
			func() string {
				data, _ := json.Marshal(pbAdjustStaffs)
				return string(data)
			}())

		// 获取调整之后的数据 (调用 dhr_stat , 落点为 0-8)
		distributions, err := getAdjustReportDistributions(companyID, projectID, ID, pbAdjustStaffs)
		if err != nil {
			return 0, fmt.Errorf("adjust getAdjustReportDistributions error: %v", err)
		}

		logger.Debugf(
			"++++++++[NEW] %s",
			func() string {
				data, _ := json.Marshal(distributions)
				return string(data)
			}())

		distributionList, err := getAdjustReportDistributionList(companyID, projectID, ID, 0, pbAdjustStaffs)
		if err != nil {
			return 0, fmt.Errorf("adjust getAdjustReportDistributions error: %v", err)
		}

		staffsData := make(map[int]StaffData)
		for _, d := range distributions {
			for _, s := range d.Staffs {
				staffsData[s.ID] = StaffData{
					ID:        s.ID,
					Name:      s.Name,
					AxisX:     d.AxisX,
					AxisY:     d.AxisY,
					AxisP:     d.AxisP,
					AxisClass: d.AxisClass,
				}
			}
		}

		allProjectsDistributionsData = append(allProjectsDistributionsData, &models.ProjectsDistributionsData{
			ProjectId:      projectID,
			DistributionId: projectDistributions.Id,
			InterviewId:    ID,
			Data:           getString(distributions),
			List:           getString(distributionList),
			StaffsData:     getString(staffsData),
			Adjust:         getString(pbAdjustStaffs),
		})

	}

	projectsDistributionsDataDao, err := models.NewProjectsDistributionsData(projectsDistributionsDao.Dao)
	if err != nil {
		return 0, fmt.Errorf("adjust models.NewProjectsDistributionsData error: %v", err)
	}
	_, err = projectsDistributionsDataDao.Insert(allProjectsDistributionsData...)

	if err != nil {
		return 0, fmt.Errorf("adjust projectsDistributionsDataDao.Insert error: %v", err)
	}

	return projectDistributions.Id, nil
}

func getOtherPbAdjustStaff(companyID, projectID, interviewID int, adjustStaffsMap map[int]AdjustStaff) ([]*pb.AdjustStaff, error) {
	// 获取历史数据 (落点为 1-9)
	originalDistributions, err := getAdjustReportDistributions(companyID, projectID, interviewID, nil)
	if err != nil {
		return nil, fmt.Errorf("adjust Original getAdjustReportDistributions error: %v", err)
	}
	if originalDistributions == nil {
		return nil, nil
	}

	ordinalStaffs := make(map[int]int)
	for _, d := range originalDistributions {
		for _, s := range d.Staffs {
			ordinalStaffs[s.ID] = commonlogics.ConvertXY2P(d.AxisX, d.AxisY)
		}
	}
	// 3 -> 1
	result := make([]*pb.AdjustStaff, 0)
	for _, x := range adjustStaffsMap {
		result = append(
			result,
			&pb.AdjustStaff{
				Id:       int64(x.ID),
				Original: int64(ordinalStaffs[x.ID]) - 1,
				Target:   int64(targetPoint(ordinalStaffs[x.ID], x.TargetAchievements) - 1),
			})
	}

	return result, nil
}

func getString(data interface{}) string {
	if data == nil {
		return ""
	}
	d, err := json.Marshal(data)
	if err != nil {
		logger.Errorf("getString json.Marshal error: %v", err)
	}
	return string(d)
}

func IsReportNameExist(projectID int, name string) (*IsReportNameExistResult, error) {
	isExist, err := isReportNameExist(projectID, name)
	if err != nil {
		return nil, err
	}
	return &IsReportNameExistResult{
		IsExist: isExist,
	}, nil
}

func isReportNameExist(projectID int, name string) (bool, error) {
	var isExist bool
	reports, err := models.ProjectsReportsModel.Search(db.Cond{
		"project_id": projectID,
		"is_deleted": 0,
		"name":       name,
	})

	if err != nil {
		return false, fmt.Errorf("IsReportNameExist  models.ProjectsReportsModel.Search error: %v", err)
	}

	if len(reports) > 0 {
		isExist = true
	}

	return isExist, nil
}

func getCurrentPbAdjustStaff(adjustStaffs []*AdjustStaff) (result []*pb.AdjustStaff) {
	if adjustStaffs == nil || len(adjustStaffs) == 0 {
		return nil
	}

	result = make([]*pb.AdjustStaff, 0, len(adjustStaffs))
	for _, v := range adjustStaffs {
		result = append(result, &pb.AdjustStaff{
			Id:       int64(v.ID),
			Original: int64(v.Original),
			Target:   int64(v.Target),
		})
	}

	return
}

// 获取实时并移动人才盘点九宫格数据
func getAdjustReportDistributions(companyID int, projectID, interviewID int, adjustStaffs []*pb.AdjustStaff) (result []*_InventoryDistributionResult, err error) {
	data, err := client.GetGroupInventoryDistribution(nil, &pb.GroupInventoryDistributionRequest{
		CompanyId:   int64(companyID),
		ProjectId:   int64(projectID),
		ReportId:    0,
		InterviewId: int64(interviewID),
		Adjust:      adjustStaffs,
	})
	if err != nil {
		return nil, err
	}

	err = json.Unmarshal(data, &result)
	if err != nil {
		return nil, err
	}

	return result, nil
}

// 获取实时并移动人才盘点列表数据
func getAdjustReportDistributionList(companyID int, projectID, interviewID, reportID int, adjustStaffs []*pb.AdjustStaff) (result []*_InventoryDistributionListResult, err error) {
	data, err := client.GetGroupInventoryDistributionList(nil, &pb.GroupInventoryDistributionListRequest{
		CompanyId: int64(companyID),
		ProjectId: int64(projectID),
		ReportId:  int64(reportID),
		Keyword:   "",
		Order:     nil,
		Filter:    nil,
		Page: &commonpb.PageParam{
			Ignore: true,
		},
		Adjust:      adjustStaffs,
		InterviewId: int64(interviewID),
	})

	var ret struct {
		Total int64                               `json:"total"`
		List  []*_InventoryDistributionListResult `json:"list"`
	}

	err = json.Unmarshal(data, &ret)
	if err != nil {
		return nil, err
	}

	return ret.List, nil
}

// 员工绩效
func staffAchievements(adjustStaffs []*AdjustStaff) []*AdjustStaff {
	staffs := make([]*AdjustStaff, 0)
	for index := range adjustStaffs {
		staffs = append(
			staffs,
			&AdjustStaff{
				ID:                   adjustStaffs[index].ID,
				Original:             adjustStaffs[index].Original,
				Target:               adjustStaffs[index].Target,
				OriginalAchievements: achievements(adjustStaffs[index].Original),
				TargetAchievements:   achievements(adjustStaffs[index].Target),
			})
	}
	return staffs
}

func achievements(point int) int {
	x, _ := commonlogics.ConvertP2XY(point + 1)
	return x
}

func getlog(projectID int, reportID int, interviewID int, pbAdjustStaffs []*pb.AdjustStaff, adjustStaffsMap map[int]AdjustStaff) []*pb.AdjustStaff {
	// data := make(map[int]*models.ProjectsDistributionsData, 0)
	data, err := models.ProjectsDistributionsDataModel.SearchOne(
		db.Cond{
			"project_id":      projectID,
			"distribution_id": reportID,
			"interview_id":    interviewID,
			"is_deleted":      0,
		})
	if err != nil {
		logger.Errorf("[ProjectsDistributionsData] select error: %s", err.Error())
		return pbAdjustStaffs
	}
	if data == nil || data.Id == 0 {
		return pbAdjustStaffs
	}

	logAdjustList := make([]*pb.AdjustStaff, 0)
	err = json.Unmarshal([]byte(data.Adjust), &logAdjustList)
	if err != nil {
		logger.Debugf("[ProjectsDistributionsData] json.Unmarshal error: %s", err.Error())
	}

	for _, x := range logAdjustList {
		if _, ok := adjustStaffsMap[int(x.Id)]; !ok {
			pbAdjustStaffs = append(
				pbAdjustStaffs,
				&pb.AdjustStaff{
					Id:       int64(int(x.Id)),
					Original: int64(x.Original),
					Target:   int64(x.Target),
				})
		}
	}
	return pbAdjustStaffs
}

// 根据初始位置和绩效变更,获取最新落点
func targetPoint(original /*(1-9)*/, x int) int /*(1-9)*/ {
	_, originalY := commonlogics.ConvertP2XY(original)
	return commonlogics.ConvertXY2P(x, originalY)
}
