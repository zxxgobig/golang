package libraries

import (
    logger "gitlab.ifchange.com/bot/logger"
    mqKit "gitlab.ifchange.com/bot/commonkit/mq"
    "gitlab.ifchange.com/bot/commonkit/mq/pub"
    "gitlab.ifchange.com/bot/hfwkit/config"
)

var NsqServer []string
var mqPub MqPub
var err error

type MqPub struct {
    Pub mqKit.Pub
}

func init() {
    mqInit()
}

func GetMqPub() mqKit.Pub {
    return mqPub.Pub
}

func mqInit() {
    NsqServer = config.GetServers().BotNsqLookupds
    if len(NsqServer) < 1 {
        panic("nsq config is nil")
    }

    nsqConfig := map[string]interface{}{
        "lookupds_address": NsqServer,
    }

    mqPub.Pub, err = pub.New(mqKit.NSQ, func(log string) error {
        logger.Warnf("init nsq error %v", log)
        return nil
    }, nsqConfig)
    if err != nil {
        panic(err)
    }

}
