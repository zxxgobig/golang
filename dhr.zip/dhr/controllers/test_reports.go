package controllers

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"net/url"

	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/logger"

	"ifchange/dhr/core"
	"ifchange/dhr/models"
	"net/http"
	"strconv"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dfs"
)

type TestReports struct {
	core.Controller
}

/**
 * @api {get} /test_reports/download?session=abc&interview_id=12&staff_id=1231  个人测评结果导出
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 人才盘点分布表下载
 * @apiParam {string} session session
 * @apiParam {int} interview_id 测评类型(8 情绪智力 emotional_intelligence, 9 批判思维 critical_thinking, 10 管理实践能力 practical_intelligence , 11 职业人格 occupational_personality, 12 性格风险 personality_disorder, 13 领导风格 leadership_style, 14 组织忠诚度 org_commitment)
 * @apiParam {int} staff_id 被查看的员工ID
 * @apiSuccess {Object} results 返回结果
 * @apiSuccessExample {json} Response-Example:
	{
	}
 **/
type GetPfdLinkParams struct {
	InterviewId int    `json:"interview_id"`
	Uuid        string `json:"uuid"`
}
type GetPfdLinkResult struct {
	Success   bool   `json:"success"`
	ReportUrl string `json:"report_url"`
	FileName  string `json:"file_name"`
	GroupName string `json:"group_name"`
}

func getPdfLink(userId string, interviewId int) (getPfdLinkResult *GetPfdLinkResult, err error) {
	getPfdLinkResult = &GetPfdLinkResult{}
	p := api.Post{}
	p.P = &GetPfdLinkParams{
		InterviewId: interviewId,
		Uuid:        userId,
	}

	logger.Infof(config.AppConfig.Custom["ThirdEvaluation"] + "get_report_url")
	err = api.SimpleCurl(nil, config.AppConfig.Custom["ThirdEvaluation"]+"get_report_url", p, &getPfdLinkResult)
	if err != nil {
		logger.Errorf("Activity get third_evaluation/get_report_url err:%v", err)
		return nil, err
	}
	logger.Infof("***getPfdLink***:%v", getPfdLinkResult)
	return getPfdLinkResult, nil
}
func (c *TestReports) Download(httpCtx *hfw.HTTPContext) {
	logger.Infof("***TestReports Download Start***")
	params := httpCtx.Request.URL.Query()
	logger.Infof("***TestReports Download params:%v", params)
	session := params.Get("session")
	interviewId := params.Get("interview_id")
	staffId := params.Get("staff_id")
	if session == "" || interviewId == "" || staffId == "" {
		httpCtx.ThrowCheck(20304001, "session,interview_id,staff_id not empty")
	}
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, &Session{
		SessionID: session,
	}))
	//解析session的参数
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	//调用芝景接口获取pdf链接
	interviewID, err := strconv.Atoi(interviewId)
	staffID, err := strconv.Atoi(staffId)
	//产品策略定：去数据库找此人最新的uuid
	uuidInfo, err := models.StaffsInterviewsModel.SearchOne(db.Cond{
		"company_id":   curUser.CompanyId,
		"staff_id":     staffID,
		"is_deleted":   0,
		"interview_id": interviewID,
		"orderby":      "updated_at desc",
	})
	if err != nil {
		httpCtx.ThrowCheck(20305000, err)
	}
	if uuidInfo == nil {
		httpCtx.ThrowCheck(20304001, "该用户暂时没有可以下载的文档")
	}
	logger.Infof("***interviewID:%v,uuidInfo:%v***", interviewID, uuidInfo)
	getpfdLinkResult, err := getPdfLink(uuidInfo.Uuid, interviewID)
	if err != nil {
		httpCtx.ThrowCheck(20305016, "获取PDF链接失败:"+err.Error())
	}
	logger.Infof("****getpfdLinkResult****:%v", getpfdLinkResult)
	//用pdf链接获取内容导出
	dfs := &dfs.Dfs{
		FileName:    getpfdLinkResult.ReportUrl,
		GroupName:   getpfdLinkResult.GroupName,
		OffSet:      0,
		Length:      0,
		ContentType: "json",
	}
	dataString, err := dfs.Read()
	//logger.Infof("***DFS READ data:%v***/n", dataString)
	if err != nil {
		errMassage := fmt.Sprint(err)
		httpCtx.ThrowCheck(20305013, "获取DFS上的PDF失败:"+errMassage)
	}
	if dataString == "" {
		httpCtx.ThrowCheck(20305015, "获取DFS上的内容为空")
	}
	decodeString, err := base64.StdEncoding.DecodeString(dataString)
	if err != nil {
		httpCtx.ThrowCheck(20305000, "获取的DFS DecodeString解码错误"+err.Error())
	}
	httpCtx.ReturnFileContent("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", url.QueryEscape(getpfdLinkResult.FileName), bytes.NewBuffer([]byte(decodeString)))
}
func (c *TestReports) After(httpCtx *hfw.HTTPContext) {
	if httpCtx.ErrNo > 0 {
		httpCtx.ResponseWriter.WriteHeader(http.StatusInternalServerError)
	}
	c.Controller.After(httpCtx)
}
