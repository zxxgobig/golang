package interview

import (
	"fmt"
	"ifchange/dhr/core"
	"strconv"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"

	common2 "ifchange/dhr/logics/common"

	"ifchange/dhr/models"
)

func SaveVoice(emailUUID string, interviewID int, param *BeiSaveVoice) (result *FinishStatus, err error) {
	result = new(FinishStatus)
	allStaffsInterviews, err := GetStaffsInterviewsByEmailUuid(emailUUID)

	if err != nil {
		return
	}
	result.setInterviewsInfo(allStaffsInterviews)

	if len(allStaffsInterviews) == 0 {
		err = fmt.Errorf("no record found")
		return
	}
	var CurStaffsInterviews []*models.StaffsInterviews
	finishFlag := true
	for _, x := range allStaffsInterviews {
		if x.Status < 2 {
			finishFlag = false
			break
		}
	}
	// 全部完成
	if finishFlag == true {
		return result, nil
	}

	// 正在进行的题目
	for _, x := range allStaffsInterviews {
		if x.Status == 1 {
			CurStaffsInterviews = append(CurStaffsInterviews, x)
		}
	}

	// 多道题正在进行中
	if len(CurStaffsInterviews) > 1 {
		err = fmt.Errorf("expect 1 staffsInterview %d", len(CurStaffsInterviews))
		return
	}

	// 获取需要做的题目
	if len(CurStaffsInterviews) == 0 {
		for _, x := range allStaffsInterviews {
			if x.InterviewId == interviewID {
				CurStaffsInterviews = append(CurStaffsInterviews, x)
			}
		}
		if len(CurStaffsInterviews) != 1 {
			err = fmt.Errorf("expect 1 staffsInterview %d", len(CurStaffsInterviews))
			return
		}
	}

	// 当前的答题
	if len(CurStaffsInterviews) == 0 {
		return result, common.NewRespErr(core.Completed, "测评已完成或不存在")
	}
	staffsInterview := CurStaffsInterviews[0]
	result.CurInterviewId = staffsInterview.InterviewId
	result.CurInterviewUuid = staffsInterview.Uuid

	if staffsInterview.InterviewId != interviewID {
		err = fmt.Errorf("interviewId not equal ")
		return
	}

	plan, err := common2.GetPlanById(staffsInterview.DataCollectId)
	if err != nil {
		return
	}
	if plan == nil {
		err = fmt.Errorf("plan not exist: <%+v>", staffsInterview.DataCollectId)
		logger.Warn(err)
		return
	}
	// 题目状态异常
	if plan.Status >= 4 {
		err = common.NewRespErr(int64(20306000+plan.Status), "plan status unvalid")
		return
	}
	if staffsInterview.Status == 2 {
		return result, nil
	} else if staffsInterview.Status == 0 {
		_, err = models.StaffsInterviewsModel.Update(db.Cond{
			"status": 1,
		}, db.Cond{
			"id": staffsInterview.Id,
		})
		if err != nil {
			return
		}
	} else if staffsInterview.Status != 1 {
		err = common.NewRespErr(6001, "staffs interview status unvalid")
		return
	}
	// bei 跳转
	param.InterviewID, err = strconv.Atoi(staffsInterview.Uuid)
	if err != nil {
		return
	}

	err = CreateInterview(staffsInterview.InterviewId).SaveVoice(param)
	if err != nil {
		return
	}
	return result, nil
}
