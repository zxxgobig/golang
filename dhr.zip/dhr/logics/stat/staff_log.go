package stat

import (
	"encoding/json"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
)

type StaffData struct {
	ID        int    `json:"id"`
	Name      string `json:"name"`
	AxisX     int    `json:"axis_x"`
	AxisY     int    `json:"axis_y"`
	AxisP     int    `json:"axis_p"`
	AxisClass int    `json:"axis_class"`
}

func getStaffHistoryGrids(projectID, staffID int) (result map[int][]*Grid, err error) {
	data, err := models.ProjectsDistributionsDataModel.Search(db.Cond{
		"project_id": projectID,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}

	// interview id -> distribution list
	result = make(map[int][]*Grid)

	for _, d := range data {
		if d.Data == "" {
			continue
		}

		staffsData := make(map[int]StaffData)
		err := json.Unmarshal([]byte(d.StaffsData), &staffsData)
		if err != nil {
			return nil, err
		}

		staffData, exist := staffsData[staffID]
		if !exist {
			continue
		}

		distributionData, exist := result[d.InterviewId]
		if !exist {
			distributionData = make([]*Grid, 0)
		}
		distributionData = append(distributionData, &Grid{
			AxisX:    int64(staffData.AxisX),
			AxisY:    int64(staffData.AxisY),
			Name:     staffData.Name,
			RecordAt: d.UpdatedAt.Unix(),
		})

		result[d.InterviewId] = distributionData
	}

	return result, nil
}
