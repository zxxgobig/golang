package v2_interview

import (
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    EmotionalIntelligenceRecommend struct {
        Name     string `json:"name"`
        Desc     string `json:"desc"`
        Index    int    `json:"index"`
        IsAdvice bool   `json:"is_advice"`
        IsMust   bool   `json:"is_must"`
    }
)

func ProcessEmotionalIntelligenceRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *EmotionalIntelligenceRecommend {
    interview, ok := interviewsM[kitinterview.EmotionalIntelligence]
    if !ok {
        return nil
    }

    return &EmotionalIntelligenceRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.EmotionalIntelligence),
        IsAdvice: GetIsAdvice(kitinterview.EmotionalIntelligence, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.EmotionalIntelligence, sceneId, sceneTemplateId),
    }
}
