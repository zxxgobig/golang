package v2_interview

import (
    "sort"

    "gitlab.ifchange.com/bot/hfw/db"
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    BeiRecommend struct {
        Name     string                 `json:"name"`
        Desc     string                 `json:"desc"`
        Index    int                    `json:"index"`
        IsAdvice bool                   `json:"is_advice"`
        IsMust   bool                   `json:"is_must"`
        IsEdit   bool                   `json:"is_edit"`
        MaxCheck int                    `json:"max_check"`
        SubItems []*BeiRecommendSubItem `json:"sub_items"`
    }

    BeiRecommendSubItem struct {
        Id             int             `json:"id"`
        Name           string          `json:"name"`
        Desc           string          `json:"desc"`
        TypeName       string          `json:"type_name"`
        InitialScore   int             `json:"initial_score"`
        IsRecommend    bool            `json:"is_recommend"`
        RecommendScore int             `json:"recommend_score"`
        Scores         []*BeiScoreItem `json:"scores"`
    }

    BeiScoreItem struct {
        Score int    `json:"score"`
        Desc  string `json:"desc"`
    }
)

func ProcessBeiRecommend(sceneId, sceneTemplateId, functionsId, levelId int, interviewsM map[kitinterview.Type]*models.Interviews) *BeiRecommend {
    interview, ok := interviewsM[kitinterview.Bei]
    if !ok {
        return nil
    }

    result := BeiRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.Bei),
        IsAdvice: GetIsAdvice(kitinterview.Bei, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.Bei, sceneId, sceneTemplateId),
        IsEdit:   GetIsEdit(kitinterview.Bei),
        MaxCheck: GetMaxCheck(kitinterview.Bei),
        SubItems: nil,
    }

    itemM := make(map[int]*BeiRecommendSubItem)

    parseSubItems := ParseSubItems(interview.Config)
    for _, v := range parseSubItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &BeiRecommendSubItem{
                Id:             v.Id,
                Name:           v.Name,
                Desc:           v.Content,
                TypeName:       "",
                InitialScore:   1,
                IsRecommend:    false,
                RecommendScore: 0,
                Scores:         nil,
            }
        }
    }

    // 获取所有子维度分数列表
    scoreDecs, err := models.PositionFunctionBeiScoreDescModel.Search(db.Cond{
        "is_deleted": 0,
        "orderby":    "group_id ASC",
    })
    if err != nil {
        return nil
    }
    for _, v := range scoreDecs {
        if _, ok := itemM[v.GroupId]; ok {
            itemM[v.GroupId].TypeName = v.TypeName
            itemM[v.GroupId].Scores = append(itemM[v.GroupId].Scores, &BeiScoreItem{
                Score: v.Score,
                Desc:  v.Content,
            })
        }
    }

    // 获取子维度推荐
    recommends, _ := models.PositionFunctionBeiRecommendModel.Search(db.Cond{
        "is_deleted":  0,
        "function_id": functionsId,
        "level_id":    levelId,
    })
    for _, v := range recommends {
        if _, ok := itemM[v.GroupId]; ok {
            itemM[v.GroupId].IsRecommend = true
            itemM[v.GroupId].RecommendScore = v.Score
        }
    }

    for _, v := range itemM {
        result.SubItems = append(result.SubItems, v)
    }

    sort.Slice(result.SubItems, func(i, j int) bool {
        return result.SubItems[i].Id > result.SubItems[j].Id
    })

    return &result
}
