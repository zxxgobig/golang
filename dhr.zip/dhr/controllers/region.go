package controllers

import (
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/region"
)

type Region struct {
	core.Controller
}

type GetRegionInfoReq struct {
	Session string `json:"session"`
}

/**
 * @api {post} /region/get_region_infos 获取区域信息：省份、城市、县区
 * @apiVersion 1.0.0
 * @apiGroup Region
 * @apiDescription 获取省、市、区信息
 *
 * @apiParam {String} session session信息
 * @apiParamExample {json} Request-Example:
   {
		"session": "",
   }
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {String} id province_id
 * @apiSuccess {String} name province_name
 * @apiSuccess {String} pin_yin 拼音字母
 * @apiSuccess {Object[]} children 城市列表
 * @apiSuccess {String} id city_id
 * @apiSuccess {String} name city_name
 * @apiSuccess {String} pin_yin 拼音字母
 * @apiSuccessExample {json} Response-Example:
   {
		[
			{
				"id": 2,
                "name": "北京",
                "pin_yin": "beijing",
                "children": [
                    {
                        "id": 33,
                        "name": "北京市",
                        "pin_yin": "beijingshi"
                    },
                    {
                        "id": 3969,
                        "name": "东城区",
                        "pin_yin": "dongchengqu"
                    },
                    {
                        "id": 3973,
                        "name": "朝阳区",
                        "pin_yin": "chaoyangqu"
                    },
                    {
                        "id": 3974,
                        "name": "海淀区",
                        "pin_yin": "haidianqu"
                    }
                ]
            },
            {
                "id": 10,
                "name": "上海",
                "pin_yin": "shanghai",
                "children": [
                    {
                        "id": 3987,
                        "name": "黄浦区",
                        "pin_yin": "huangpuqu"
                    },
                    {
                        "id": 3998,
                        "name": "浦东新区",
                        "pin_yin": "pudongxinqu"
                    }
                ]
            }
		]
   }
 *
*/
func (_ *Region) GetRegionInfos(httpCtx *hfw.HTTPContext) {
	req := new(GetRegionInfoReq)
	httpCtx.ThrowCheck(0, api.RequestUnmarshal(httpCtx, req))
	httpCtx.ThrowCheck(0, validate(req))
	regionInfos, err := region.GetRegionInfos()
	httpCtx.ThrowCheck(0, err)
	httpCtx.Results = regionInfos
}
