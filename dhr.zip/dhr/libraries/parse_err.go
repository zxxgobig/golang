package libraries

import (
    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfw/common"
    "ifchange/dhr/core"
)

func ParseErr(err error) (errNo int64, errMsg string) {
    if err == nil {
        return 0, ""
    }
    if e, ok := err.(*common.RespErr); ok {
        errNo = int64(e.ErrNo())
    } else {
        errNo = core.SystemErrNo
    }
    errMsg = hfw.GetErrorMap(errNo)
    logger.Errorf("errNo: [%d], errMsg: [%s]", errNo, errMsg)
    return
}
