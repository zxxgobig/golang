package data_collect

import (
	"bytes"
	"encoding/json"
	"fmt"
	htmlTemplate "html/template"
	"strconv"
	"strings"
	"time"

	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/interview"
	"ifchange/dhr/logics/message"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/hfwkit/utils"
	"gitlab.ifchange.com/bot/logger"
)

//////////////////////// open api

const (
	employe_level = ",employe" // 员工层级，雇员
	leader_level  = ",leader"  // 员工层级，领导

	notice_type_invite = 1 // 邀请类型
	notice_type_remind = 2 // 提醒类型
)

// 一封邮件需要的元数据
type MailMetaData struct {
	uniqueMailKey string
	planId        int
	projectId     int
	staffId       int
	companyId     int
	noticeType    int
	staffLevel    string // employe_level 或者 leader_level
}

// 一封邮件最终需要的真数据
type MailRealData struct {
	MailMetaData
	projectName    string
	staffName      string
	staffMail      string
	mailTemplate   string
	endTime        time.Time
	startTime      time.Time
	address        string      // 性格链接地址
	qrCode         string      // 素质，潜力 二维码
	qrCodeJumpLink string      // 素质，潜力 二维码跳转链接
	mailUUIDs      []*MailUUID // 一份邮件存在多个emailUUID情况, 一个emailUUID代表一次测评试题, 比如1 5,2 是一封邮件
}

type MailUUID struct {
	mailUUID    string
	interviewId int
}

func getStaffLevelByInterviewId(interviewId int) (staffLevel string) {
	switch interviewId {
	case 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 21:
		// 素质，潜力测评，工作选择价值观，关键经历、情绪智力、批判思维、管理实践能力、职业人格、性格风险、领导风格、组织忠诚度、8维素质
		return employe_level
	case 3, 4:
		// 专业技能、专业知识
		return leader_level
	default:
		return employe_level
	}
}

func getPlanById(planId int) (endTime *models.DataCollectPlans, err error) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planId})
	if err != nil {
		return nil, err
	}
	return plan, nil
}

func generaUniqueMailKey(staffId int, staffLevel string) (uniqueMailKey string) {
	return strconv.Itoa(staffId) + staffLevel
}

func GeneraGroupMailData(planId int, noticeType int, filterStaff map[int]int) (data []*MailRealData, err error) {
	interviewL, err := models.StaffsInterviewsModel.Search(db.Cond{
		"where":   fmt.Sprintf("is_deleted = 0 and data_collect_id = %d", planId),
		"groupby": "email_uuid",
		"select":  "*",
	})
	if err != nil {
		return nil, err
	}
	if interviewL == nil || len(interviewL) == 0 {
		return nil, fmt.Errorf("GeneraGroupMailData StaffsInterviewsModel.Search by planID %d is nil", planId)
	}

	b, _ := json.Marshal(interviewL)
	logger.Debugf("GeneraGroupMailData interviewL is: %s", string(b))

	uniqueMailKeyQueue := make(map[string]bool)
	mailRealDataL := make([]*MailRealData, 0)
	for _, interview := range interviewL {
		staffId := interview.StaffId
		emailUUID := interview.EmailUuid
		companyId := interview.CompanyId
		projectId := interview.ProjectId
		planId := interview.DataCollectId
		interviewId := interview.InterviewId

		if filterStaff != nil && len(filterStaff) != 0 {
			// 需要过滤，撞到需要过滤的staffId则跳过不用发邮件
			if _, ok := filterStaff[staffId]; ok {
				continue
			}
		}

		staffLevel := getStaffLevelByInterviewId(interviewId)
		uniqueMailKey := generaUniqueMailKey(staffId, staffLevel)
		_, ok := uniqueMailKeyQueue[uniqueMailKey]
		if ok { // 重复出现，则为员工level
			// 更新mailRealDataL
			// 因为interviewL结果中，同一个staff_id只会有一条领导测评，
			// 所以如果重复出现所以则肯定为员工level
			for _, mailRealData := range mailRealDataL {
				if mailRealData.uniqueMailKey == uniqueMailKey {
					mailUUID := &MailUUID{
						mailUUID:    emailUUID,
						interviewId: interviewId,
					}
					// 本邮件新增一条mailUUID
					mailRealData.mailUUIDs = append(mailRealData.mailUUIDs, mailUUID)
				}
			}
		} else { // 首次出现，可能是员工level 或 领导level
			// 不存在唯一索引，则新增
			plan, err := getPlanById(planId)
			if err != nil {
				return nil, err
			}
			if plan == nil {
				return nil, fmt.Errorf("insertMailRealDataL DataCollectPlansModel.SearchOne response null,by planId: %d", planId)
			}
			project, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectId})
			if err != nil {
				return nil, err
			}
			if project == nil {
				return nil, fmt.Errorf("insertMailRealDataL ProjectsModel.SearchOne response null,by projectId: %d", projectId)
			}
			staff, err := dhr_staff.GetStaffById(nil, companyId, staffId, true)
			if err != nil {
				return nil, err
			}
			if staff == nil {
				logger.Warnf("GeneraGroupMailData, libraries.GetStaffsByIDsOrNos response staffs is null, by staffId: %d", staffId)
				// 脏数据删除
				affected, err := models.StaffsInterviewsModel.Update(db.Cond{
					"is_deleted": 1,
				}, db.Cond{
					"staff_id": staffId,
				})
				if err != nil {
					logger.Warnf("GeneraGroupMailData, StaffsInterviewsModel Update err: %v, by staffId: %d", err, staffId)
				} else {
					logger.Warnf("GeneraGroupMailData, StaffsInterviewsModel Update, affected: %d by staffId: %d", affected, staffId)
				}
				continue
			}

			mailRealData := new(MailRealData)
			mailRealData.uniqueMailKey = uniqueMailKey
			mailRealData.planId = planId
			mailRealData.projectId = projectId
			mailRealData.companyId = companyId
			mailRealData.noticeType = noticeType
			mailRealData.staffLevel = getStaffLevelByInterviewId(interviewId)

			mailRealData.endTime = plan.EndTime
			mailRealData.startTime = plan.StartTime
			mailUUID := &MailUUID{mailUUID: emailUUID, interviewId: interviewId} // 新增一条mailUUID
			mailRealData.mailUUIDs = append(mailRealData.mailUUIDs, mailUUID)
			mailRealData.projectName = project.Name

			if interviewId == 3 || interviewId == 4 {
				if len(interview.StaffIds) == 0 {
					continue
				}
				leader, err := getLeaderInfo(companyId, interview.StaffIds[0])
				if err != nil || leader == nil {
					continue
				}
				mailRealData.staffId = leader.Id
				mailRealData.staffName = leader.Name
				mailRealData.staffMail = leader.Email
			} else {
				staff, err := dhr_staff.GetStaffById(nil, companyId, staffId, true)
				if err != nil {
					logger.Errorf("GeneraGroupMailData interviewId not 3 or 4, GetStaffById %d err:%v", interview.StaffIds[0], err)
					continue
				}
				if staff.Status == 3 { // staff leave
					continue
				}
				mailRealData.staffId = staffId
				mailRealData.staffName = staff.Name
				mailRealData.staffMail = staff.Email
				logger.Debugf("GeneraGroupMailData staff:%d ,%s ,%s", staffId, staff.Name, staff.Email)
			}

			uniqueMailKeyQueue[uniqueMailKey] = true
			mailRealDataL = append(mailRealDataL, mailRealData)
		}
	}
	return mailRealDataL, nil
}

func getLeaderInfo(companyId int, staffId int) (result *dhr_staff.Staff, err error) {
	staff, err := dhr_staff.GetStaffById(nil, companyId, staffId, true)
	if err != nil {
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetStaffById %d err:%v", staffId, err)
		return nil, err
	}
	if staff == nil || staff.Status == 3 {
		// staff leave
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetStaffById %d be leave", staffId)
		return nil, nil
	}

	leader, err := dhr_staff.GetStaffById(nil, companyId, staff.ParentId, true)
	if err != nil {
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetLeaderById %d err:%v", staff.ParentId, err)
		return nil, err
	}
	if leader == nil || leader.Status == 3 {
		// leader leave
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetLeaderById %d be leave", staff.ParentId)
		return nil, nil
	} else {
		return leader, nil
	}
}

func GeneraStaffMailData(planId int, staffID int) (data []*MailRealData, err error) {
	interviewSql := fmt.Sprintf("SELECT id, email_uuid, company_id, project_id, data_collect_id, staff_id, interview_id FROM"+
		" `staffs_interviews` WHERE is_deleted = 0 and `data_collect_id` = %d and `staff_id` = %d and `interview_id` <> 3 GROUP BY email_uuid",
		planId, staffID)
	interviewL, err := models.StaffsInterviewsModel.Query(interviewSql)
	if err != nil {
		return nil, err
	}

	uniqueMailKeyQueue := make(map[string]bool)
	mailRealDataL := make([]*MailRealData, 0)
	for _, interview := range interviewL {
		staffId, err := strconv.Atoi(string(interview["staff_id"][:]))
		if err != nil {
			return nil, err
		}
		emailUUID := string(interview["email_uuid"][:])
		companyId, err := strconv.Atoi(string(interview["company_id"][:]))
		if err != nil {
			return nil, err
		}
		projectId, err := strconv.Atoi(string(interview["project_id"][:]))
		if err != nil {
			return nil, err
		}
		planId, err := strconv.Atoi(string(interview["data_collect_id"][:]))
		if err != nil {
			return nil, err
		}
		interviewId, err := strconv.Atoi(string(interview["interview_id"][:]))
		if err != nil {
			return nil, err
		}
		plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planId})
		if err != nil {
			return nil, err
		}
		if plan == nil {
			return nil, fmt.Errorf("insertMailRealDataL DataCollectPlansModel.SearchOne response null,by planId: %d", planId)
		}
		project, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectId})
		if err != nil {
			return nil, err
		}
		if project == nil {
			return nil, fmt.Errorf("insertMailRealDataL ProjectsModel.SearchOne response null,by projectId: %d", projectId)
		}
		staff, err := dhr_staff.GetStaffById(nil, companyId, staffId, true)
		if err != nil {
			return nil, err
		}
		if staff == nil {
			logger.Warnf("GeneraStaffMailData company %d GetStaffById %d, result is null", companyId, staffId)
			return nil, nil
		}
		if staff.Status == 3 { // staff leave
			logger.Warnf("GeneraStaffMailData company %d GetStaffById %d, the staff be leave", companyId, staffId)
			return nil, nil
		}

		staffLevel := getStaffLevelByInterviewId(interviewId)
		uniqueMailKey := generaUniqueMailKey(staffId, staffLevel)
		_, ok := uniqueMailKeyQueue[uniqueMailKey]
		if ok { // 重复出现，则为员工level
			// 更新mailRealDataL
			// 因为interviewL结果中，同一个staff_id只会有一条领导测评，
			// 所以如果重复出现所以则肯定为员工level
			for _, mailRealData := range mailRealDataL {
				if mailRealData.uniqueMailKey == uniqueMailKey {
					mailUUID := &MailUUID{mailUUID: emailUUID, interviewId: interviewId}
					// 本邮件新增一条mailUUID
					mailRealData.mailUUIDs = append(mailRealData.mailUUIDs, mailUUID)
				}
			}
		} else { // 首次出现，可能是员工level 或 领导level
			// 不存在唯一索引，则新增
			mailRealData := &MailRealData{}
			mailRealData.uniqueMailKey = uniqueMailKey

			mailRealData.planId = planId
			mailRealData.projectId = projectId
			mailRealData.staffId = staffId
			mailRealData.companyId = companyId

			mailRealData.noticeType = notice_type_remind
			mailRealData.staffLevel = getStaffLevelByInterviewId(interviewId)

			mailRealData.projectName = project.Name
			mailRealData.endTime = plan.EndTime
			mailRealData.startTime = plan.StartTime
			mailRealData.staffName = staff.Name
			mailRealData.staffMail = staff.Email

			mailUUID := &MailUUID{mailUUID: emailUUID, interviewId: interviewId} // 新增一条mailUUID
			mailRealData.mailUUIDs = append(mailRealData.mailUUIDs, mailUUID)

			uniqueMailKeyQueue[uniqueMailKey] = true
			mailRealDataL = append(mailRealDataL, mailRealData)
		}
	}
	return mailRealDataL, nil
}

func GeneraLeaderMailData(planId int, staffID int) (data []*MailRealData, err error) {
	staffsInterviewsL, err := models.StaffsInterviewsModel.Search(db.Cond{
		"data_collect_id": planId,
		"interview_id":    3,
	})
	if err != nil {
		return nil, err
	}

	var leaderID int
	var currStaffsInterviews *models.StaffsInterviews
FOR:
	for _, staffsInterviews := range staffsInterviewsL {
		for _, staffId := range staffsInterviews.StaffIds {
			// 员工ID
			if staffId == staffID {
				staff, err := dhr_staff.GetStaffById(nil, staffsInterviews.CompanyId, staffId, true)
				if err != nil || staff == nil {
					logger.Warnf("GeneraLeaderMailData GetStaffById %d, result is null", staffID)
					break FOR
				}
				// 需要给此leader发送测评邮件
				leaderID = staff.ParentId
				currStaffsInterviews = staffsInterviews
				break FOR
			}
		}
	}
	if leaderID == 0 || currStaffsInterviews == nil {
		logger.Warnf("GeneraLeaderMailData the staff ID is %d, not leader", staffID)
		return nil, nil
	}

	// leader信息
	staff, err := dhr_staff.GetStaffById(nil, currStaffsInterviews.CompanyId, leaderID, true)
	if err != nil {
		return nil, err
	}
	if staff == nil {
		logger.Warnf("GeneraLeaderMailData company %d GetStaffById %d, result is null",
			currStaffsInterviews.CompanyId, leaderID)
		return nil, nil
	}
	if staff.Status == 3 { // leader leave
		logger.Warnf("GeneraStaffMailData company %d GetStaffById %d, the leader be leave",
			currStaffsInterviews.CompanyId, leaderID)
		return nil, nil
	}
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planId})
	if err != nil {
		return nil, err
	}
	if plan == nil {
		return nil, fmt.Errorf("insertMailRealDataL DataCollectPlansModel.SearchOne response null,by planId: %d", planId)
	}
	project, err := models.ProjectsModel.SearchOne(db.Cond{"id": currStaffsInterviews.ProjectId})
	if err != nil {
		return nil, err
	}
	if project == nil {
		return nil, fmt.Errorf("insertMailRealDataL ProjectsModel.SearchOne response null,by projectId: %d", currStaffsInterviews.ProjectId)
	}

	mailRealDataL := make([]*MailRealData, 0)
	// 不存在唯一索引，则新增
	mailRealData := &MailRealData{}

	mailRealData.planId = planId
	mailRealData.projectId = currStaffsInterviews.ProjectId
	mailRealData.staffId = leaderID
	mailRealData.companyId = currStaffsInterviews.CompanyId

	mailRealData.noticeType = notice_type_remind
	mailRealData.staffLevel = getStaffLevelByInterviewId(3)

	mailRealData.projectName = project.Name
	mailRealData.endTime = plan.EndTime
	mailRealData.startTime = plan.StartTime
	mailRealData.staffName = staff.Name
	mailRealData.staffMail = staff.Email

	mailUUID := &MailUUID{mailUUID: currStaffsInterviews.EmailUuid, interviewId: 3} // 新增一条mailUUID
	mailRealData.mailUUIDs = append(mailRealData.mailUUIDs, mailUUID)

	mailRealDataL = append(mailRealDataL, mailRealData)

	return mailRealDataL, nil
}

// ////////////////////// open api

type TemplateBaseInfo struct {
	StaffName      string // 被采集人名称
	ProjectName    string // 项目名称
	PlanEndTime    string // 采集计划结束时间
	PlanStartTime  string // 采集计划开始时间
	Address        string // 性格测评或专业知识技能跳转链接
	QrCode         string // 二维码
	QrCodeJumpLink string // 二维码跳转链接
}

type MailComponent struct{}

func (m *MailComponent) SendEmail(MailRealDataL []*MailRealData) (err error) {
	for _, realData := range MailRealDataL {
		logger.Debugf("SendEmail planId: %d, staffId %d, mailUUIDs: %v", realData.planId, realData.staffId, realData.mailUUIDs)
		template, err := m.BornTemplate(realData.noticeType, realData.staffLevel, realData.mailUUIDs)
		if err != nil {
			return err
		}
		realData.mailTemplate = template
		realData.address = m.getAddress(realData.mailUUIDs)

		verifyCode, err := GetCollectPlanVerifyCode(realData.planId)
		if err != nil {
			return err
		}

		qrCodeAddress, mailUUID, err := m.getBeiPotentialQrcodeAddress(realData.mailUUIDs, realData.staffName,
			realData.companyId, realData.staffId, verifyCode)
		if err != nil {
			return err
		}
		qrcode, err := m.qrcodeAddressToQrcode(qrCodeAddress)
		if err != nil {
			return err
		}
		realData.qrCode = qrcode
		realData.qrCodeJumpLink = m.qrcodeJumpLink(mailUUID)
		templateBaseInfo := m.BornTemplateBaseInfo(realData)

		_, err = m.sendMail(templateBaseInfo, realData)
		if err != nil {
			return err
		}

		// 给员工发送采集邮件后
		// 更新采集计划状态
		_, err = models.DataCollectPlansModel.Update(db.Cond{
			"status": 2,
		}, db.Cond{
			"id": realData.planId,
		})
		if err != nil {
			return fmt.Errorf("SendEmail DataCollectPlansModel Update err: %v", err)
		}
	}
	return nil
}

func (m *MailComponent) BornTemplate(noticeType int, staffLevel string, mailUUIDs []*MailUUID) (template string, err error) {
	if noticeType == notice_type_invite {
		if staffLevel == employe_level {
			if m.hasNormstarTest(mailUUIDs) {
				// 邀请，雇员，有二维码，有链接
				return interview.EmployeeInviteContent, nil
			} else {
				// 邀请，雇员，有二维码，没有链接
				return interview.EmployeeInviteNoNormstarContent, nil
			}
		} else if staffLevel == leader_level {
			// 邀请，领导
			return interview.LeaderInviteContent, nil
		}
	} else if noticeType == notice_type_remind {
		if staffLevel == employe_level {
			if m.hasNormstarTest(mailUUIDs) {
				// 提醒，雇员，有二维码，有链接
				return interview.EmployeeRemindContent, nil
			} else {
				// 提醒，雇员，有二维码，没有链接
				return interview.EmployeeRemindNoNormstarContent, nil
			}
		} else if staffLevel == leader_level {
			// 提醒，领导
			return interview.LeaderRemindContent, nil
		}
	}
	return "", fmt.Errorf("BornTemplate err: noticeType %d, staffLevel %s, mailUUIDs %v",
		noticeType, staffLevel, mailUUIDs)
}

func (m *MailComponent) BornTemplateBaseInfo(realData *MailRealData) (
	templateBaseInfo *TemplateBaseInfo) {
	return &TemplateBaseInfo{
		StaffName:      realData.staffName,
		ProjectName:    realData.projectName,
		PlanEndTime:    realData.endTime.Format("2006年01月02日"),
		PlanStartTime:  realData.startTime.Format("2006年01月02日"),
		Address:        realData.address,
		QrCode:         realData.qrCode,
		QrCodeJumpLink: realData.qrCodeJumpLink,
	}
}

func (m *MailComponent) sendMail(templateBaseInfo *TemplateBaseInfo, mailRealData *MailRealData) (
	mailBody string, err error) {
	var outBody bytes.Buffer
	t, err := htmlTemplate.New("email").Parse(mailRealData.mailTemplate)
	if err != nil {
		return "", err
	}
	err = t.Execute(&outBody, templateBaseInfo)
	if err != nil {
		return "", err
	}
	emailBody := strings.Replace(outBody.String(), "{QrCodeImg}", templateBaseInfo.QrCode, -1)

	subject := fmt.Sprintf("%s测评邀请函", mailRealData.projectName)
	mailData := message.MailData{
		Subject: subject,
		Email:   []string{mailRealData.staffMail},
		Content: emailBody,
	}
	err = message.SendMail(libraries.GetMqPub(), mailData)
	if err != nil {
		return "", err
	}
	logger.Infof("SendMail mailData: %+v", mailData)

	// 写入邮件记录
	mailResend := &models.MailResend{
		Subject:  subject,
		Email:    mailRealData.staffMail,
		Content:  emailBody,
		Status:   2,
		ExecTime: time.Now(),
		PlanId:   mailRealData.planId,
	}
	_, err = models.MailResendModel.Insert(mailResend)
	if err != nil {
		logger.Warnf("sendEmail err: %v", err)
	}
	return emailBody, nil
}

func (m *MailComponent) hasNormstarTest(mailUUIDs []*MailUUID) (hasNormstar bool) {
	hasNormstarTest := false
	for _, mailUUID := range mailUUIDs {
		if mailUUID.interviewId == 2 {
			hasNormstarTest = true
		}
	}
	return hasNormstarTest
}

func (m *MailComponent) getAddress(mailUUIDs []*MailUUID) (address string) {
	for _, mailUUID := range mailUUIDs {
		if mailUUID.interviewId == 2 { // 性格测评，链接
			return config.AppConfig.Custom["DhrUrl"] + "interviews/get?uuid=" + mailUUID.mailUUID + "&interview_id=2"
		} else if mailUUID.interviewId == 3 { // 知识技能测评，链接 正式环境配置
			return config.AppConfig.Custom["TalentReviewURL"] + "leaderAssess?uuid=" + mailUUID.mailUUID + "&interview_id=3"
		}
	}
	return ""
}

// 二维码中的链接地址
func (m *MailComponent) getBeiPotentialQrcodeAddress(mailUUIDs []*MailUUID, staffName string, companyId, staffId int, verifyCode int) (
	qrcode string, mailUUID string, err error) {
	for _, mailUUID := range mailUUIDs {
		// 素质，潜力测评，工作选择价值观，关键经历、情绪智力、批判思维、管理实践能力、职业人格、性格风险、领导风格、组织忠诚度、8维素质，二维码
		switch mailUUID.interviewId {
		case 1, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 21:
			secretKey, err := utils.CreateUuid(staffId)
			if err != nil {
				return "", "", err
			}
			qrCodeAddress := config.AppConfig.Custom["DhrUrl"] + "interviews/assessment/uuid=" + mailUUID.mailUUID + "&company_id=" +
				strconv.Itoa(companyId) + "&src_id=1&name=" + staffName + "&secret_key=" + secretKey + "&verify_phone=" +
				strconv.Itoa(verifyCode) + "&product_code=1&staff_id=" + strconv.Itoa(staffId)
			logger.Debugf("getBeiPotentialQrcodeAddress qrCodeAddress: %s", qrCodeAddress)
			return qrCodeAddress, mailUUID.mailUUID, nil
		}
	}
	return "", "", nil
}

// 用getBeiPotentialQrcodeAddress二维码链接地址，
// 编码为二维码base64格式
func (m *MailComponent) qrcodeAddressToQrcode(qrcodeAddress string) (qrcode string, err error) {
	if qrcodeAddress == "" {
		return "", nil
	}
	qCode := new(libraries.QrCode)
	qrcode, err = qCode.EncodeBase64(qrcodeAddress)
	return qrcode, err
}

func (m *MailComponent) qrcodeJumpLink(mailUUID string) string {
	qrcodeLink := config.AppConfig.Custom["TalentReviewURL"] + "show/code?uuid=" + mailUUID
	return qrcodeLink
}
