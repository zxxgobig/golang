package commit

import (
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/logger"
	"ifchange/dhr/libraries/mq"
	logicsCommon "ifchange/dhr/logics/common"
	"ifchange/dhr/logics/interview"
)

func ConsumerServer() {
	go mq.Sub(mq.NewSub(), "hdr_interview_finish_event", "default", consume)
	go mq.Sub(mq.NewSub(), "WorkValuesResult", "default", consumeWorkValue)
	go mq.Sub(mq.NewSub(), "KeyExperienceResult", "default", consumeWorkExp)
	go mq.Sub(mq.NewSub(), "ThirdEvaluationResult", "default", consumeThirdEvaluation)
}

func consume(j []byte) error {
	logger.Debugf("************************** j: %v", string(j))
	data := string(j)
	//if err != nil {
	//	logger.Debugf("************************** err: %v", err)
	//	return common.NewRespErr(core.SystemErrNo, err)
	//}
	logger.Debugf("************************** ID: %v", data)
	params := &logicsCommon.GetResultParams{Id: 0, Uuid: data}
	err := interview.GetResult(params)
	return err
}

func consumeWorkValue(j []byte) error {
	k := &struct {
		UniqueId string `json:"unique_id"`
	}{}
	err := encoding.JSON.Unmarshal(j, k)
	if err != nil {
		return err
	}
	logger.Debugf("************************** j: %+v", k)

	logger.Debugf("************************** ID: %v", k.UniqueId)
	params := &logicsCommon.GetResultParams{Id: 0, Uuid: k.UniqueId}
	err = interview.GetResult(params)
	return err
}

func consumeWorkExp(j []byte) error {
	k := &struct {
		UniqueId string `json:"unique_id"`
	}{}
	err := encoding.JSON.Unmarshal(j, k)
	if err != nil {
		return err
	}
	logger.Debugf("************************** j: %+v", k)

	logger.Debugf("************************** ID: %v", k.UniqueId)
	params := &logicsCommon.GetResultParams{Id: 0, Uuid: k.UniqueId}
	err = interview.GetResult(params)
	return err
}

func consumeThirdEvaluation(j []byte) error {
	k := &struct {
		Uuid        string `json:"uuid"`
		InterviewId int    `json:"interview_id"`
		UserId      int    `json:"user_id"`
	}{}
	err := encoding.JSON.Unmarshal(j, k)
	if err != nil {
		return err
	}
	logger.Debugf("************************** j: %+v", k)

	logger.Debugf("************************** ThirdEvaluation: %#v", k)
	params := &logicsCommon.GetResultParams{
		Id:          0,
		Uuid:        k.Uuid,
		InterviewId: k.InterviewId,
		UserId:      k.UserId,
	}
	err = interview.GetResult(params)
	return err
}
