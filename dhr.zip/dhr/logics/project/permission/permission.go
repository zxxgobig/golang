package permission

import (
	"fmt"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"ifchange/dhr/models"
)

func IsProjectOwnedByUser(userID, projectID int) (yes bool, err error) {
	proj, err := models.ProjectsModel.SearchOne(db.Cond{
		"id":         projectID,
		//"is_deleted": 0,
	})
	if err != nil {
		return false, err
	}
	if proj == nil {
		return false, common.NewRespErr(20304026, fmt.Errorf("project[id=%d] not exist", projectID))
	}
	
	if proj.UserId != userID {
		return false, common.NewRespErr(20304046, fmt.Errorf("project[id=%d] not belone to user[id=%d]", projectID, userID))
	}
	
	return true, nil
}

func IsCollectionPlanOwnedByUser(userID, planID int) (yes bool, err error) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"id": planID,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if plan == nil {
		return  false, common.NewRespErr(20304052, fmt.Errorf("data collection plan[id=%d] not exist", planID))
	}
	
	return IsProjectOwnedByUser(userID, plan.ProjectId)
}
