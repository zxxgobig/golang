package stat

import (
	"fmt"
	"sort"
	"strings"

	"ifchange/dhr/logics/common"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	"gitlab.ifchange.com/bot/logger"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

func ProfessionalSkills(companyID, projectID, staffID int) (*ProfessionalSkillsResult, error) {
	statType, id := parseStatTypeAndID(companyID, projectID)

	result, err := client.GetStaffInterviewData(nil, &pb.StaffInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    statType,
		Id:          int64(id),
		StaffId:     int64(staffID),
		InterviewId: int64(interview.Skill),
	})
	if err != nil {
		return nil, err
	}
	if result == nil {
		return nil, nil
	}

	r := &ProfessionalSkillsResult{
		StaffID: staffID,
		ProfessionalSkills: getStatFormResponseDataStaff("此员工得分", result.Axes, &Option{
			InterviewID:    int(interview.Skill),
			StatScore:      true,
			StatAVG:        true,
			StatExcellent:  true,
			ExcellentScore: result.ExcellentScore,
		}),
	}

	return r, nil
}

func Potential(companyID, projectID, staffID int) (*PotentialResult, error) {
	statType, id := parseStatTypeAndID(companyID, projectID)

	result, err := client.GetStaffInterviewData(nil, &pb.StaffInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    statType,
		Id:          int64(id),
		StaffId:     int64(staffID),
		InterviewId: 5,
	})
	if err != nil {
		return nil, err
	}
	if result == nil {
		return &PotentialResult{
			Potential: EvalAxes{},
		}, nil
	}

	return &PotentialResult{
		StaffID:   staffID,
		Potential: pbAxesToEvalAxes(result.Axes),
	}, nil
}

func Quality(companyID, projectID, staffID int) (*QualityResult, error) {
	statType, id := parseStatTypeAndID(companyID, projectID)

	result, err := client.GetStaffInterviewData(nil, &pb.StaffInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    statType,
		Id:          int64(id),
		StaffId:     int64(staffID),
		InterviewId: int64(interview.Bei),
	})
	if err != nil {
		return nil, err
	}
	if result == nil {
		return nil, nil
	}

	return &QualityResult{
		StaffID: staffID,
		Quality: getStatFormResponseDataStaff("此员工得分", result.Axes, &Option{
			InterviewID:    int(interview.Bei),
			StatScore:      true,
			StatAVG:        true,
			StatExcellent:  true,
			ExcellentScore: result.ExcellentScore,
		}),
	}, nil
}

var performanceLevelStandardMap = map[int]string{
	1: "高",
	2: "中",
	3: "低",
}

func getPerformance(companyID, staffID int) (*PerformanceInterviewResult, error) {
	data, err := client.GetStaffPerformanceData(nil, &pb.StaffPerformanceDataRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_COMPANY,
		Id:        int64(companyID),
		StaffId:   int64(staffID),
	})
	if err != nil {
		return nil, err
	}

	if data == nil {
		return &PerformanceInterviewResult{
			Labels: []string{},
		}, nil
	}

	labels := make([]string, 0)
	if len(data.Labels) != 0 {
		labels = data.Labels
	}

	return &PerformanceInterviewResult{
		Level:  strings.ToUpper(data.Level),
		Labels: labels,
		Desc:   data.Eval,
	}, nil
}

func InventoryDistribution(hfwCtx *hfw.HTTPContext, companyID, projectID, staffID, reportID int) (resp *InventoryDistributionResult, err error) {
	reportID = detrick(reportID)
	resp = new(InventoryDistributionResult)
	proj, err := models.ProjectsModel.SearchOne(db.Cond{
		"id": projectID,
	})
	if err != nil {
		return nil, err
	}
	if proj == nil {
		return
	}

	data, err := client.GetStaffInventoryResult(hfwCtx, &pb.StaffInventoryResultRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_PROJECT,
		Id:        int64(projectID),
		StaffId:   int64(staffID),
	})
	if err != nil {
		return nil, err
	}
	if data == nil {
		return
	}

	// 根据每个interviewId进行区分
	distributionMap := make(map[int64]*Distribution)
	for _, distribution := range data.Distributions {
		interviewId := distribution.InterviewId
		distributionMap[interviewId] = &Distribution{
			InterviewId: interviewId,
			Grids: []*Grid{
				{
					AxisX:    distribution.AxisX,
					AxisY:    distribution.AxisY,
					Name:     distribution.Name,
					RecordAt: proj.CreatedAt.Unix(),
				},
			},
		}
		logger.Debugf("interview-id: %v, 九宫格分布 = X-%d,Y-%d", interviewId, distribution.AxisX, distribution.AxisY)
	}

	// 盘点分布
	distributions := make([]*Distribution, 0, len(distributionMap))
	for _, distribution := range distributionMap {
		distributions = append(distributions, distribution)
	}

	// 个人发展建议
	var advice []*Advice
	for _, a := range data.Advice {
		advice = append(advice, &Advice{
			AxisName: a.Name,
			AxisID:   int(a.Id),
			Advice:   a.Advice,
		})
	}

	return &InventoryDistributionResult{
		StaffID:        staffID,
		StaffAvatarURL: "",
		Distributions:  distributions,
		Pros:           data.Pros,
		Cons:           data.Cons,
		Advice:         advice,
	}, nil
}

func Performance(companyID, staffID, reportID int) (*PerformanceResult, error) {
	r, err := getPerformance(companyID, staffID)
	if err != nil {
		return nil, err
	}
	if r == nil {
		r = &PerformanceInterviewResult{
			Labels: []string{},
		}
	}

	return &PerformanceResult{
		StaffID:     staffID,
		Performance: r,
	}, nil
}

// 员工详情-员工标签
func StaffLabels(companyId, projectId, staffId, reportId int) (staffLabels *common.StaffLabels, err error) {
	// 获取tag数据
	staffsInterviewsDetails, err := models.StaffsInterviewsDetailsModel.Search(db.Cond{
		"where":      fmt.Sprintf("project_id = %v and staff_id = %v and interview_id IN(6, 7)", projectId, staffId),
		"is_deleted": 0,
	})
	if err != nil {
		return nil, fmt.Errorf("projectId:%v and staffId:%v correspond empty", projectId, staffId)
	}

	jobChoiceValueLabels, keyExperienceLabels := make([]string, 0), make([]string, 0)
	for _, each := range staffsInterviewsDetails {
		if each.InterviewId == 6 {
			jobChoiceValueLabels = append(jobChoiceValueLabels, each.Tag)
		}
		if each.InterviewId == 7 {
			keyExperienceLabels = append(keyExperienceLabels, each.Tag)
		}
	}

	labels := append(jobChoiceValueLabels, keyExperienceLabels...)
	staffLabels = &common.StaffLabels{
		StaffId:              staffId,
		JobChoiceValueLabels: jobChoiceValueLabels,
		KeyExperienceLabels:  keyExperienceLabels,
		Labels:               labels,
	}

	return
}

func InventorySwitchScene(hfwCtx *hfw.HTTPContext, companyID, projectID, staffID, interviewID int) (resp *InventorySwitchSceneResult, err error) {
	defer func() {
		if e := recover(); e != nil {
			err = fmt.Errorf("recover: %v", e)
		} else if err != nil {
			logger.Errorf("call InventorySwitchScene failed. err:%v", err)
		}
	}()
	resp = new(InventorySwitchSceneResult)

	projects, err := searchProjects(staffID)
	if err != nil {
		return resp, err
	}

	distributionGrids := make([]*Grid, 0, 3)
	num := len(projects)
	if num == 1 {
		distributionGrid, err := getDistributionGrid(hfwCtx, companyID, projects[0].Id, staffID, int64(interviewID))
		if err != nil {
			return nil, err
		}
		if distributionGrid != nil {
			distributionGrid.RecordAt = projects[0].CreatedAt.Unix()
			distributionGrids = append(distributionGrids, distributionGrid)
		}
	}

	if num > 1 {
		// 按照创建时间，从最近到以前，由大到小
		sort.Slice(projects, func(i, j int) bool {
			return projects[i].CreatedAt.Unix() > projects[j].CreatedAt.Unix()
		})
		switch num {
		case 2, 3:
			for _, each := range projects {
				distributionGrid, err := getDistributionGrid(hfwCtx, companyID, each.Id, staffID, int64(interviewID))
				if err != nil {
					return nil, err
				}
				if distributionGrid != nil {
					distributionGrid.RecordAt = each.CreatedAt.Unix()
					distributionGrids = append(distributionGrids, distributionGrid)
				}
			}
		default:
			flag := 1
			for idx, each := range projects {
				if each.Id == projectID {
					distributionGrid, err := getDistributionGrid(hfwCtx, companyID, projects[idx].Id, staffID, int64(interviewID))
					if err != nil {
						return nil, err
					}
					if distributionGrid != nil {
						distributionGrid.RecordAt = projects[idx].CreatedAt.Unix()
						distributionGrids = append(distributionGrids, distributionGrid)
					}

					for j := idx - 1; j >= 0; j-- {
						distributionGrid, err = getDistributionGrid(hfwCtx, companyID, projects[j].Id, staffID, int64(interviewID))
						if err != nil {
							return nil, err
						}
						if distributionGrid != nil {
							distributionGrid.RecordAt = projects[j].CreatedAt.Unix()
							distributionGrids = append(distributionGrids, distributionGrid)
							flag++
						}
						if flag == 3 {
							break
						}
					}

					if flag == 3 {
						break
					}

					for i := idx + 1; i < num; i++ {
						distributionGrid, err = getDistributionGrid(hfwCtx, companyID, projects[i].Id, staffID, int64(interviewID))
						if err != nil {
							return nil, err
						}
						if distributionGrid != nil {
							distributionGrid.RecordAt = projects[i].CreatedAt.Unix()
							distributionGrids = append(distributionGrids, distributionGrid)
							flag++
						}
						if flag == 3 {
							break
						}
					}

					break
				}
			}
		}
	}

	sort.Slice(distributionGrids, func(i, j int) bool {
		return distributionGrids[i].RecordAt < distributionGrids[j].RecordAt
	})

	return &InventorySwitchSceneResult{
		StaffID: staffID,
		Grids:   distributionGrids,
	}, nil
}

func getDistributionGrid(hfwCtx *hfw.HTTPContext, companyID, projectID, staffID int, interviewID int64) (grid *Grid, err error) {
	data, err := client.GetStaffInventoryResult(hfwCtx, &pb.StaffInventoryResultRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_PROJECT,
		Id:        int64(projectID),
		StaffId:   int64(staffID),
	})
	if err != nil || data == nil {
		return
	}

	for _, each := range data.Distributions {
		if each.InterviewId == interviewID {
			grid = &Grid{
				AxisX:     each.AxisX,
				AxisY:     each.AxisY,
				Name:      each.Name,
				RecordAt:  each.RecordAt,
				ProjectID: projectID,
			}
		}
		logger.Debugf("interview-id: %v, 九宫格分布 = X-%d,Y-%d，九宫格名称 = %s", each.InterviewId, each.AxisX, each.AxisY, each.Name)
	}
	return
}

func searchProjects(staffID int) (projs []*models.Projects, err error) {
	projectStaffs, err := models.ProjectsStaffsModel.Search(db.Cond{"staff_id": staffID})
	if err != nil {
		return
	}

	projectIDMap := make(map[int]struct{})
	projectIDs := make([]int, 0, len(projectStaffs))
	for _, each := range projectStaffs {
		if _, ok := projectIDMap[each.ProjectId]; ok {
			continue
		}
		projectIDMap[each.ProjectId] = struct{}{}
		projectIDs = append(projectIDs, each.ProjectId)
	}
	projs, err = models.ProjectsModel.Search(db.Cond{
		"id in":      projectIDs,
		"is_deleted": 0,
	})

	return
}
