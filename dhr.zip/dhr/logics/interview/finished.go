package interview

import (
	"ifchange/dhr/models"
	"time"

	"gitlab.ifchange.com/bot/hfw/db"
)

type InterviewFinishedParams struct {
	ProjectId int `json:"project_id"`
	StaffId   int `json:"staff_id"`
}

type InterviewFinished struct {
	InterviewId int       `json:"interview_id"`
	Uuid        string    `json:"uuid"`
	UpdateAt    time.Time `json:"update_at"`
}

type InterviewFinishedResult struct {
	FinishedInterviews []*InterviewFinished `json:"finished_interviews"`
	StaffId            int                  `json:"staff_id"`
	ProjectId          int                  `json:"project_id"`
}

func (self *InterviewFinishedParams) Search() (res *InterviewFinishedResult, err error) {

	projectsInterviewsConfigs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"project_id": self.ProjectId,
		"is_deleted": 0,
		"is_show":    models.SHOW,
	})
	if err != nil {
		return res, err
	}
	interviewId := make([]int, 0, len(projectsInterviewsConfigs))
	for i := 0; i < len(projectsInterviewsConfigs); i++ {
		interviewId = append(interviewId, projectsInterviewsConfigs[i].InterviewId)
	}
	staffsInterviews, err := models.StaffsInterviewsModel.Search(db.Cond{
		"is_deleted":      0,
		"staff_id":        self.StaffId,
		"interview_id in": interviewId,
		"where":           "interview_id not in (3, 4)",
		"status":          2,
	})
	if err != nil {
		return res, err
	}

	staffsInterviewsDetails, err := models.StaffsInterviewsDetailsModel.Search(db.Cond{
		"is_deleted":      0,
		"staff_id":        self.StaffId,
		"interview_id in": []int{3, 4},
		"status":          2,
	})
	if err != nil {
		return res, err
	}

	interviewFinished, err := self.Parse(staffsInterviews, staffsInterviewsDetails)
	res = &InterviewFinishedResult{
		FinishedInterviews: interviewFinished,
		StaffId:            self.StaffId,
		ProjectId:          self.ProjectId,
	}

	return res, err
}

func (self *InterviewFinishedParams) Parse(params []*models.StaffsInterviews, params1 []*models.StaffsInterviewsDetails) (res []*InterviewFinished, err error) {
	res = make([]*InterviewFinished, 0, 10)
	dataMap := make(map[int]*InterviewFinished)
	for i := 0; i < len(params); i++ {
		data := params[i]
		key := data.InterviewId
		_, ok := dataMap[key]
		var num int64
		if ok {
			num = dataMap[key].UpdateAt.Unix()
		}
		if num == 0 || num < data.UpdatedAt.Unix() {
			dataKey := &InterviewFinished{
				InterviewId: data.InterviewId,
				UpdateAt:    data.UpdatedAt,
				Uuid:        data.Uuid,
			}
			dataMap[key] = dataKey
		}
	}
	for i := 0; i < len(params1); i++ {
		data := params1[i]
		key := data.InterviewId
		_, ok := dataMap[key]
		var num int64
		if ok {
			num = dataMap[key].UpdateAt.Unix()
		}
		if num == 0 || num < data.UpdatedAt.Unix() {
			dataKey := &InterviewFinished{
				InterviewId: data.InterviewId,
				UpdateAt:    data.UpdatedAt,
			}
			staffsInterviews, err := models.StaffsInterviewsModel.SearchOne(db.Cond{
				"is_deleted":      0,
				"project_id":      data.ProjectId,
				"interview_id in": []int{3, 4},
				"data_collect_id": data.DataCollectId,
				"status":          2,
			})
			if err != nil {
				return res, err
			}
			if staffsInterviews == nil {
				continue
			}
			dataKey.Uuid = staffsInterviews.Uuid
			dataMap[key] = dataKey
		}
	}
	for k, _ := range dataMap {
		res = append(res, dataMap[k])
	}
	return res, err
}
