package data_collect

import (
	"fmt"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
)

// 去重
func RemoveRepeatedElement(arr []int) (newArr []int) {
	newArr = make([]int, 0)
	for i := 0; i < len(arr); i++ {
		repeat := false
		for j := i + 1; j < len(arr); j++ {
			if arr[i] == arr[j] {
				repeat = true
				break
			}
		}
		if !repeat {
			newArr = append(newArr, arr[i])
		}
	}
	return
}

func GetCollectPlanVerifyCode(planID int) (verifyCode int, err error) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"id": planID,
	})
	if err != nil {
		return 1, err
	}
	if plan == nil {
		return 1, fmt.Errorf("getCollectPlanVerifyCode DataCollectPlansModel.SearchOne is nil")
	}
	return plan.VerifyPhone, nil
}
