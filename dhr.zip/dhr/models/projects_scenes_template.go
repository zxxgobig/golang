package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var ProjectsScenesTemplateModel = &ProjectsScenesTemplate{}

func init() {
	var err error
	ProjectsScenesTemplateModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	ProjectsScenesTemplateModel.Dao.EnableCache(ProjectsScenesTemplateModel)
	//ProjectsScenesTemplateModel.Dao.DisableCache(ProjectsScenesTemplateModel)
	//gob: type not registered for interface
	gob.Register(ProjectsScenesTemplateModel)
}

type ProjectsScenesTemplate struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id         int       `json:"id" xorm:"not null pk autoincr comment('自增主键') INT(11)"`
	Name       string    `json:"name" xorm:"not null default '' comment('名称') VARCHAR(32)"`
	Desc       string    `json:"desc" xorm:"not null default '' comment('描述') VARCHAR(128)"`
	Icon       string    `json:"icon" xorm:"not null default '' comment('图标') VARCHAR(128)"`
	Cover      string    `json:"cover" xorm:"not null default '' comment('介绍图') VARCHAR(128)"`
	FunctionId int       `json:"function_id" xorm:"not null comment('职能 ID') INT(11)"`
	LevelId    int       `json:"level_id" xorm:"not null comment('层级 ID') INT(11)"`
	IsManager  int       `json:"is_manager" xorm:"not null comment('是否为管理岗') TINYINT(1)"`
	SceneId    int       `json:"scene_id" xorm:"not null comment('场景 ID') INT(11)"`
	IsDeleted  int       `json:"is_deleted" xorm:"not null default 0 comment('删除状态（0: 未删除 1: 已删除）') TINYINT(1)"`
	CreatedAt  time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created comment('创建时间') TIMESTAMP"`
	UpdatedAt  time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated comment('更新时间') TIMESTAMP"`
}

func (m *ProjectsScenesTemplate) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *ProjectsScenesTemplate) GetName() (val string) {
	if m == nil {
		return
	}
	return m.Name
}

func (m *ProjectsScenesTemplate) GetDesc() (val string) {
	if m == nil {
		return
	}
	return m.Desc
}

func (m *ProjectsScenesTemplate) GetIcon() (val string) {
	if m == nil {
		return
	}
	return m.Icon
}

func (m *ProjectsScenesTemplate) GetCover() (val string) {
	if m == nil {
		return
	}
	return m.Cover
}

func (m *ProjectsScenesTemplate) GetFunctionId() (val int) {
	if m == nil {
		return
	}
	return m.FunctionId
}

func (m *ProjectsScenesTemplate) GetLevelId() (val int) {
	if m == nil {
		return
	}
	return m.LevelId
}

func (m *ProjectsScenesTemplate) GetIsManager() (val int) {
	if m == nil {
		return
	}
	return m.IsManager
}

func (m *ProjectsScenesTemplate) GetSceneId() (val int) {
	if m == nil {
		return
	}
	return m.SceneId
}

func (m *ProjectsScenesTemplate) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *ProjectsScenesTemplate) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *ProjectsScenesTemplate) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *ProjectsScenesTemplate) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *ProjectsScenesTemplate) TableName() string {
	return "projects_scenes_template"
}

func (m *ProjectsScenesTemplate) Save(t ...*ProjectsScenesTemplate) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsScenesTemplate
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *ProjectsScenesTemplate) Saves(t []*ProjectsScenesTemplate) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *ProjectsScenesTemplate) Insert(t ...*ProjectsScenesTemplate) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsScenesTemplate
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *ProjectsScenesTemplate) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *ProjectsScenesTemplate) SearchOne(cond db.Cond) (t *ProjectsScenesTemplate, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *ProjectsScenesTemplate) Search(cond db.Cond) (t []*ProjectsScenesTemplate, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *ProjectsScenesTemplate) SearchAndCount(cond db.Cond) (t []*ProjectsScenesTemplate, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *ProjectsScenesTemplate) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *ProjectsScenesTemplate) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *ProjectsScenesTemplate) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *ProjectsScenesTemplate) GetMulti(ids ...interface{}) (t []*ProjectsScenesTemplate, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *ProjectsScenesTemplate) GetByIds(ids ...interface{}) (t []*ProjectsScenesTemplate, err error) {
	return m.GetMulti(ids...)
}

func (m *ProjectsScenesTemplate) GetById(id interface{}) (t *ProjectsScenesTemplate, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *ProjectsScenesTemplate) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *ProjectsScenesTemplate) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *ProjectsScenesTemplate) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *ProjectsScenesTemplate) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *ProjectsScenesTemplate) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewProjectsScenesTemplate(c ...interface{}) (m *ProjectsScenesTemplate, err error) {
	m = &ProjectsScenesTemplate{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *ProjectsScenesTemplate) Close() {
	m.Dao.Close()
}

func (m *ProjectsScenesTemplate) Begin() error {
	return m.Dao.Begin()
}

func (m *ProjectsScenesTemplate) Rollback() error {
	return m.Dao.Rollback()
}

func (m *ProjectsScenesTemplate) Commit() error {
	return m.Dao.Commit()
}
