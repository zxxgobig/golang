package mq

import (
    "math"
    "time"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/signal"
    "github.com/pkg/errors"
    "gitlab.ifchange.com/bot/commonkit/mq"
    "gitlab.ifchange.com/bot/commonkit/mq/sub"
)

var (
    signalContext = signal.GetSignalContext()
)

func NewSub() mq.Sub {
    mqConfig := map[string]interface{}{
        "lookupds_address":      mqServers,
        "max_attempts":          4,
        "default_requeue_delay": 60 * time.Second,
        "msg_timeout":           60 * time.Second,
        "concurrency":           10,
    }

    mqSub, err := sub.New(mq.NSQ, func(log string) error {
        return nil
    }, mqConfig)
    if err != nil {
        panic(err)
    }

    return mqSub
}

func Sub(mqSub mq.Sub, topic, channel string, callback func(data []byte) error) {
    err := mqSub.Init(topic, channel)
    if err != nil {
        logger.Errorf("mq.sub topic: [%s], channel: [%s] init error: %v", topic, channel, err)
    }

    err = mqSub.Subscribe(func(msg *mq.Message) error {
        signalContext.WgAdd()
        defer signalContext.WgDone()

        startTime := time.Now()
        err := callback(msg.Content)
        if err != nil {
            logger.Debugf("mq.sub topic: [%s], channel: [%s], nsqAttempts: [%d], nsqContent: [%s], costTime: [%s] error: %s",
                topic, channel, msg.Attempts, string(msg.Content), time.Now().Sub(startTime), err)
            delayTime := math.Pow(2, float64(msg.Attempts))*30 + 60
            msg.Delay = time.Duration(delayTime) * time.Second
            return errors.Wrapf(err, "mq.sub topic: [%s], channel: [%s] callback error", topic, channel)
        }

        logger.Debugf("mq.sub topic: [%s], channel: [%s], nsqAttempts: [%d], nsqContent: [%s], costTime: [%s] success",
            topic, channel, msg.Attempts, string(msg.Content), time.Now().Sub(startTime))
        return nil
    })
    if err != nil {
        logger.Errorf("mq.sub topic: [%s], channel: [%s] subscribe error: %v", topic, channel, err)
    }

    for {
        select {
        case <-signalContext.Ctx.Done():
            err := mqSub.Stop()
            if err != nil {
                logger.Errorf("mq.sub topic: [%s], channel: [%s] stop error: %v", topic, channel, err)
            }
            logger.Warnf("mq.sub topic: [%s], channel: [%s] server shutdown, stop consumer server", topic, channel)
        }
    }
}
