package v2_interview

import (
    "sort"

    "gitlab.ifchange.com/bot/hfwkit/common"
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    KnowledgeRecommend struct {
        Name     string                       `json:"name"`
        Desc     string                       `json:"desc"`
        Index    int                          `json:"index"`
        IsAdvice bool                         `json:"is_advice"`
        IsMust   bool                         `json:"is_must"`
        IsEdit   bool                         `json:"is_edit"`
        MaxCheck int                          `json:"max_check"`
        SubItems []*KnowledgeRecommendSubItem `json:"sub_items"`
    }

    KnowledgeRecommendSubItem struct {
        Id          int    `json:"id"`
        Name        string `json:"name"`
        IsRecommend bool   `json:"is_recommend"`
    }

    KnowledgeSubitem struct {
        Id   int    `json:"id"`
        Name string `json:"name"`
    }
)

func ProcessKnowledgeRecommend(companyId, sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews,
    professionalRecommends []*models.PositionFunctionSkillRecommend) *KnowledgeRecommend {
    interview, ok := interviewsM[kitinterview.Knowledge]
    if !ok {
        return nil
    }

    result := KnowledgeRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.Knowledge),
        IsAdvice: GetIsAdvice(kitinterview.Knowledge, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.Knowledge, sceneId, sceneTemplateId),
        IsEdit:   GetIsEdit(kitinterview.Knowledge),
        MaxCheck: GetMaxCheck(kitinterview.Knowledge),
        SubItems: nil,
    }

    itemM := make(map[int]*KnowledgeRecommendSubItem)

    parseSubItems := ParseSubItems(interview.Config)
    for _, v := range parseSubItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &KnowledgeRecommendSubItem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    // 获取自定义的子维度
    subItems, _ := fetchProfessional(companyId, kitinterview.Knowledge)
    for _, v := range subItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &KnowledgeRecommendSubItem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    // 处理子维度推荐 Recommend.type (1: 知识 2: 技能)
    var curRecommendCount int
    for _, v := range professionalRecommends {
        if result.MaxCheck > 0 && curRecommendCount == result.MaxCheck {
            break
        }
        if _, ok := itemM[v.SkillId]; ok && v.Type == 1 {
            itemM[v.SkillId].IsRecommend = true
        }
    }

    for _, v := range itemM {
        result.SubItems = append(result.SubItems, v)
    }

    sort.Slice(result.SubItems, func(i, j int) bool {
        return result.SubItems[i].Id > result.SubItems[j].Id
    })

    return &result
}

func ProcessKnowledgeSubItem(companyId int, interviewsM map[kitinterview.Type]*models.Interviews) *common.ListResult {
    interview, ok := interviewsM[kitinterview.Knowledge]
    if !ok {
        return nil
    }

    itemM := make(map[int]*KnowledgeSubitem)

    parseSubItems := ParseSubItems(interview.Config)
    for _, v := range parseSubItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &KnowledgeSubitem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    subItems, _ := fetchProfessional(companyId, kitinterview.Knowledge)
    for _, v := range subItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &KnowledgeSubitem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    items := make([]*KnowledgeSubitem, 0, len(itemM))
    for _, v := range itemM {
        items = append(items, v)
    }

    sort.Slice(items, func(i, j int) bool {
        return items[i].Id > items[j].Id
    })

    return &common.ListResult{List: items}
}
