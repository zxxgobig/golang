package answer_problem

import (
    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfw/encoding"
    "gitlab.ifchange.com/bot/proto/dhr/request_answer"
    "ifchange/dhr/core"
    "ifchange/dhr/models"
)

func GetAnswerByProblemId(params *request_answer.AnswerByRequestIdRequest) (result []*request_answer.AnswerByRequestIdResult, err error) {
    data, err := models.RequestAnswerModel.Search(db.Cond{"is_deleted": 0, "request_id in": params.RequestIds})
    if err != nil {
        err = common.NewRespErr(core.SystemErrNo, err)
    }
    if data == nil {
        return result, common.NewRespErr(core.DbQueryNotExist, "数据不存在")
    }
    dataBytes, err := encoding.JSON.Marshal(data)
    if err != nil {
        return result, common.NewRespErr(core.SystemErrNo, err)
    }
    err = encoding.JSON.Unmarshal(dataBytes, &result)
    if err != nil {
        return result, common.NewRespErr(core.SystemErrNo, err)
    }
    return result, err
}
