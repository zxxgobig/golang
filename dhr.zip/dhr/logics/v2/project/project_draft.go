package v2_project

import (
	hfwcommon "gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfw/redis"

	"ifchange/dhr/core"
)

type ()

func (f *Project) CheckDraft(companyId, accountId int) (result interface{}, err error) {
	exist, err := redis.IsExist(genDraftProjectCacheKey(companyId, accountId))
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "call redis service error")
		return
	}

	result = map[string]bool{"exist": exist}

	return
}

func (f *Project) CleanDraft(companyId, accountId int) (err error) {
	key := genDraftProjectCacheKey(companyId, accountId)
	return cleanDraft(key)
}

func (f *Project) GetDraft(companyId, accountId int) (result *CreateParam, err error) {
	val, err := redis.Get(genDraftProjectCacheKey(companyId, accountId))
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "call redis service error")
		return
	}
	if val == nil {
		err = hfwcommon.NewRespErr(20304026, "draft project is nil")
		return
	}

	err = encoding.JSON.Unmarshal(val.([]byte), &result)
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "exec encoding.JSON.Unmarshal error")
		return
	}

	return
}

func saveDraft(key string, p *CreateParam) (err error) {
	bytes, err := encoding.JSON.Marshal(p)
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "exec encoding.JSON.Marshal error")
		return
	}
	_, err = redis.Set(key, bytes)
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "exec encoding.JSON.Unmarshal error")
		return
	}

	return
}

func cleanDraft(key string) (err error) {
	_, err = redis.Del(key)
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "call redis service error")
		return
	}

	return
}
