package project

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"time"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	"gitlab.ifchange.com/bot/logger"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"

	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/data_collect"
	"ifchange/dhr/models"
)

// TODO remove the function
func getLast7DaysData(projectID int) (*models.ProjectsDailyReports, error) {
	date := time.Now().AddDate(0, 0, -7).Format(libraries.DateFormat)
	daily, err := models.ProjectsDailyReportsModel.SearchOne(db.Cond{
		"project_id": projectID,
		"date":       date,
	})

	if err != nil && err != sql.ErrNoRows {
		return nil, fmt.Errorf("getLast7DaysData  error:  models.ProjectsDailyReportsModel.SearchOne %v", err)
	}

	return daily, nil
}

func GetCurrentProgress(companyID, projectID int) (result *ProgressResult, err error) {
	result = new(ProgressResult)
	staffIds, err := GetStaffIDs(projectID)
	if err != nil {
		err = fmt.Errorf("getProgress getStaffIDs for project: %d, error: %v", projectID, err)
		return
	}
	if len(staffIds) == 0 {
		return
	}

	result.Total = len(staffIds)

	data, err := client.GetGroupInventoryDistribution(nil, &pb.GroupInventoryDistributionRequest{
		CompanyId: int64(companyID),
		ProjectId: int64(projectID),
	})
	if err != nil {
		err = fmt.Errorf("getProgress getProcessCurrentReport for project: %d, error: %v", projectID, err)
		return
	}

	if len(data) == 0 {
		return
	}

	var disResult []*_InventoryDistributionResult
	err = json.Unmarshal(data, &disResult)
	if err != nil {
		err = fmt.Errorf("getCurrentProcess json.Unmarshal data error: %v", err)
		return
	}

	var starCount, inefficiencyCount int
	for _, s := range disResult {
		if s.AxisP == 3 {
			starCount += s.Count
		} else if s.AxisP == 7 {
			inefficiencyCount += s.Count
		}
	}

	result.StarStaff = starCount
	result.InefficiencyStaff = inefficiencyCount

	projectL := NewProjects()
	finishedStatus, err := projectL.GetFinishedStatus(projectID)
	if err != nil {
		return result, err
	}

	result.FinishRate = projectL.GetFinishedStatusTotal(finishedStatus)

	cp := data_collect.NewDataCollectPlan()
	total, completed, err := cp.GetDataCollectPlanCompletedStaffNum(projectID)
	if err != nil {
		return result, err
	}
	result.Total = int(total)
	result.Finish = int(completed)
	return result, nil
}

func InventoryProgress(companyID, projectID int) (result *ProgressResult, err error) {
	result, err = GetCurrentProgress(companyID, projectID)
	if err != nil {
		return
	}

	count, err := getLast7DaysStaffsData(projectID)
	if err != nil {
		err = fmt.Errorf("getProgress getLast7DaysStaffsData for project: %d, error: %v", projectID, err)
		return
	}
	if count > 0 {
		result.FinishLastAdd = count
	} else {
		result.FinishLastAdd = 0
		result.StarStaffLastAdd = result.StarStaff
		result.InefficiencyStaffLastAdd = result.InefficiencyStaff
	}
	b, _ := json.Marshal(result)
	logger.Debugf("[InventoryProgress] result: %s", string(b))
	return
}

func getLast7DaysStaffsData(projectID int) (count int, err error) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"project_id": projectID,
		"is_deleted": 0,
	})
	if err != nil {
		return 0, err
	}
	if plan == nil {
		return 0, nil
	}
	logger.Debugf("[getLast7DaysStaffsData] DataCollectPlansModel.SearchOne planID %d by projectID %d", plan.Id, projectID)

	date := time.Now().AddDate(0, 0, -7).Format(libraries.DateFormat)
	pStaffs, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"sql": fmt.Sprintf("select * from data_collect_plan_staffs where plan_id = %d and (skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) "+
			"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (emotional_intelligence = 2 or emotional_intelligence = 3) "+
			"and (critical_thinking = 2 or critical_thinking = 3) and (practical_intelligence = 2 or practical_intelligence = 3) "+
			"and (occupational_personality = 2 or occupational_personality = 3) and (personality_disorder = 2 or personality_disorder = 3) "+
			"and (leadership_style = 2 or leadership_style = 3) and (org_commitment = 2 or org_commitment = 3) "+
			"and (work_values = 2 or work_values = 3) and (key_expr = 2 or key_expr = 3) and updated_at > '%s' and is_deleted = 0", plan.Id, date),
	})
	if err != nil {
		return 0, err
	}

	return len(pStaffs), nil
}
