package data_collect

import (
    "gitlab.ifchange.com/bot/hfw/db"
    "ifchange/dhr/models"
    "testing"
)

func TestStaffDimission(t *testing.T) {
    var staffID = 14
    planStaffsAll, _ := models.DataCollectPlanStaffsModel.Search(db.Cond{
        "staff_id": staffID,
        "groupby":  "plan_id",
    })
    t.Log("planStaffsAll lenght ", len(planStaffsAll))

    var planIDAll []int
    var planIDLeaves []int
    var planIDAllM = make(map[int]int)
    var planIDJobM = make(map[int]int)

    for _, staff := range planStaffsAll {
        planIDAll = append(planIDAll, staff.PlanId)
        planIDAllM[staff.PlanId] = staff.PlanId
    }
    planStaffOnJobs, _ := models.DataCollectPlanStaffsModel.Search(db.Cond{
        "plan_id in": planIDAll,
        "is_deleted": 0,
        "groupby":    "plan_id",
    })
    for _, staff := range planStaffOnJobs {
        t.Log(staff.PlanId)
        planIDJobM[staff.PlanId] = staff.PlanId
    }
    t.Log("planStaffOnJobs lenght ", len(planStaffOnJobs))

    for k := range planIDJobM {
        delete(planIDAllM, k)
    }

    for k := range planIDAllM {
        t.Log("planIDAllM ", k)
        planIDLeaves = append(planIDLeaves, k)
    }
    t.Log("leave lenght", len(planIDLeaves))
}
