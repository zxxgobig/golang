package stat

import (
	"reflect"
	"testing"

	"gitlab.ifchange.com/bot/hfw"
)

func TestInventorySwitchScene(t *testing.T) {
	type args struct {
		hfwCtx      *hfw.HTTPContext
		companyID   int
		projectID   int
		staffID     int
		interviewID int
	}
	tests := []struct {
		name     string
		args     args
		wantResp *InventoryDistributionResult
		wantErr  bool
	}{
		// TODO: Add test cases.
		{
			name: "potential_scene",
			args: args{
				companyID:   122223,
				projectID:   709,
				staffID:     641,
				interviewID: 3, //
			},
			wantResp: nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotResp, err := InventorySwitchScene(tt.args.hfwCtx, tt.args.companyID, tt.args.projectID, tt.args.staffID, tt.args.interviewID)
			if (err != nil) != tt.wantErr {
				t.Errorf("InventorySwitchScene() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotResp, tt.wantResp) {
				t.Errorf("InventorySwitchScene() gotResp = %v, want %v", gotResp, tt.wantResp)
			}
		})
	}
}
