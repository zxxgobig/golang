package controllers

import (
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"

    "ifchange/dhr/core"
    v2_industry "ifchange/dhr/logics/v2/industry"
)

/**
 * @api {post} /v2_project/industry_list 基础数据 - 行业列表
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 行业列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object} results.list 列表
 * @apiSuccess {Number} results.list.id 行业 ID
 * @apiSuccess {String} results.list.name 行业名称
 * @apiSuccess {Object[]} results.list.children 子级行业列表
 * @apiSuccess {Number} results.list.children.id 子级行业 ID
 * @apiSuccess {String} results.list.children.name 子级行业名称
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"list": [
			{
				"id": 1,
				"function_id": 1000001,
				"name": "操作工",
				"parent_id": 0,
				"depth": 1,
				"children": [
					{
						"id": 30,
						"function_id": 2000001,
						"name": "cnc操机工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 52,
						"function_id": 2000023,
						"name": "啤机工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 53,
						"function_id": 2000024,
						"name": "喷油工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 70,
						"function_id": 2000041,
						"name": "抛光工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 72,
						"function_id": 2000043,
						"name": "钻床工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 75,
						"function_id": 2000046,
						"name": "数控车床操作工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 80,
						"function_id": 2000051,
						"name": "木工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 85,
						"function_id": 2000056,
						"name": "焊工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 87,
						"function_id": 2000058,
						"name": "安装工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 96,
						"function_id": 2000067,
						"name": "维修工",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					},
					{
						"id": 113,
						"function_id": 2000084,
						"name": "车间操作工人",
						"parent_id": 1000001,
						"depth": 2,
						"children": null
					}
				]
			},
			{
				"id": 2,
				"function_id": 1000002,
				"name": "影视传媒类",
				"parent_id": 0,
				"depth": 1,
				"children": [
					{
						"id": 34,
						"function_id": 2000005,
						"name": "主持",
						"parent_id": 1000002,
						"depth": 2,
						"children": null
					},
					{
						"id": 71,
						"function_id": 2000042,
						"name": "化妆摄影",
						"parent_id": 1000002,
						"depth": 2,
						"children": null
					},
					{
						"id": 98,
						"function_id": 2000069,
						"name": "编辑",
						"parent_id": 1000002,
						"depth": 2,
						"children": null
					},
					{
						"id": 111,
						"function_id": 2000082,
						"name": "群众演员",
						"parent_id": 1000002,
						"depth": 2,
						"children": null
					}
				]
			}
		]
	}
 *
*/
func (p *V2Project) IndustryList(httpCtx *hfw.HTTPContext) {
    params := &struct {
        *Session
    }{}
    httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
    //sess := httpCtx.Ctx.Value("session").(*session.Session)

    result, err := v2_industry.IndustryLogic.ProjectCreateUsedList()
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = result
}
