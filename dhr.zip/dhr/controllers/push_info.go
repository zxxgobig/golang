package controllers

import (
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"ifchange/dhr/core"
	"ifchange/dhr/libraries/mq"
)

type Push struct {
	core.Controller
}

func (_ *Push) Index(httpCtx *hfw.HTTPContext) {
	params := &struct {
		Topic       string `json:"topic"`
		Uuid        string `json:"uuid"`
		InterviewId int    `json:"interview_id"`
		UserId      int    `json:"user_id"`
	}{}
	err := api.RequestUnmarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	data, _ := encoding.JSON.Marshal(params)
	err = mq.Push(params.Topic, data)
	httpCtx.ThrowCheck(20305000, err)
}

func (_ *Push) Dev(httpCtx *hfw.HTTPContext) {
	params := &struct {
		Topic string `json:"topic"`
		Id    int    `json:"id"`
	}{}
	err := api.RequestUnmarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	data, _ := encoding.JSON.Marshal(params.Id)
	err = mq.Push(params.Topic, data)
	httpCtx.ThrowCheck(20305000, err)
}

func (_ *Push) Bei(httpCtx *hfw.HTTPContext) {
	params := &struct {
		Topic string `json:"topic"`
		Ids   []int  `json:"ids"`
	}{}
	err := api.RequestUnmarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	for i := 0; i < len(params.Ids); i ++ {
		data, _ := encoding.JSON.Marshal(params.Ids[i])
		err = mq.Push(params.Topic, data)
		if err != nil {
			break
		}
	}
	httpCtx.ThrowCheck(20305000, err)
}
