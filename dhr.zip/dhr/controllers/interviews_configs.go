package controllers

import (
    "fmt"
    "ifchange/dhr/core"
    "ifchange/dhr/logics/interview"

    "gitlab.ifchange.com/bot/hfwkit/api"

    "gitlab.ifchange.com/bot/hfw"
)

type InterviewsConfigs struct {
    core.Controller
}

func (c *InterviewsConfigs) List(httpCtx *hfw.HTTPContext) {

}

/**
 * @api {post} /interviews_configs/add_skill 添加测评知识技能
 * @apiVersion 0.1.0
 * @apiGroup InterviewsConfigs
 * @apiDescription 添加测评知识技能
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} interview_id 试题id(支持3技能 4知识)
 * @apiParam {Number} name 名称
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"interview_id": 1,
			"name": "java"
		}
	}
 *
 * @apiSuccessExample {json} Response-Example:
 {}
 *
*/
func (c *InterviewsConfigs) AddSkill(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        InterviewId int    `json:"interview_id"`
        Name        string `json:"name"`
    }{}

    err := api.RequestUnmarshal(httpCtx, &param)
    httpCtx.ThrowCheck(20304001, err)

    httpCtx.ThrowCheck(20304001, validate(param))
    // 验证session
    httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

    curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
    httpCtx.ThrowCheck(20304001, err)

    if param.InterviewId != 3 && param.InterviewId != 4 {
        httpCtx.ThrowCheck(20304001, fmt.Errorf("InterviewId unvalid"))
    }
    typeId := 0
    if param.InterviewId == 3 {
        typeId = 2
    }
    if param.InterviewId == 4 {
        typeId = 1
    }

    _, err = interview.NewInterviews().AddSkill(curUser.CompanyId, typeId, param.Name)
    httpCtx.ThrowCheck(20304001, err)

    httpCtx.Results = nil
}
