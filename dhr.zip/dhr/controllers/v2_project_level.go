package controllers

import (
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"

    "ifchange/dhr/core"
    v2_level "ifchange/dhr/logics/v2/level"
)

/**
 * @api {post} /v2_project/level_list 基础数据 - 层级列表
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 层级列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object} results.list 列表
 * @apiSuccess {Number} results.list.id 层级 ID
 * @apiSuccess {String} results.list.name 层级名称
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"list": [
			{
				"id": 1,
				"name": "总经理/权威"
			},
			{
				"id": 2,
				"name": "总监/专家"
			},
			{
				"id": 3,
				"name": "高级经理/资深"
			},
			{
				"id": 4,
				"name": "主管和经理/高级和中级"
			},
			{
				"id": 5,
				"name": "专业大学生/专员/初级"
			}
		]
	}
 *
*/
func (p *V2Project) LevelList(httpCtx *hfw.HTTPContext) {
    params := &struct {
        *Session
    }{}
    httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
    //sess := httpCtx.Ctx.Value("session").(*session.Session)

    result, err := v2_level.LevelLogic.ProjectCreateUsedList()
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = result
}
