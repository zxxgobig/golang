package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/answer_problem"
    "ifchange/dhr/logics/lambda"
    "ifchange/dhr/logics/project"
    "ifchange/dhr/logics/staff"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"
    "gitlab.ifchange.com/bot/proto/dhr/request_answer"
)

type Sas struct {
    core.Controller
}

/**
 * @api {post} /sas/get_answer 根据问题id获取答案
 * @apiVersion 0.1.0
 * @apiGroup sas
 * @apiDescription 根据问题id获取答案
 * @apiParam {String} request_id
 *
 * @apiParamExample {json} Request-Example:
 * {
 *	   "request_id": 1, 	   //问题id
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccessExample {json} Response-Example:
 * {
 *	   "id": 1,                //主键id
 *	   "request_id": 1, 	   //问题id
 *	   "request_category": "", //问题分类
 *	   "request_intention": 1, //问题意图
 *	   "specific_request": "", //具体问题
 *	   "answer": "",		   //回答
 *	   "note": "",		       //备注
 * }
 *
 */

func (_ *Sas) GetAnswer(httpCtx *hfw.HTTPContext) {
    params := &request_answer.AnswerByRequestIdRequest{}
    httpCtx.ThrowCheck(core.RequestError, api.RequestUnmarshal(httpCtx, params))
    httpCtx.ThrowCheck(core.RequestError, params.Validate())
    result, err := answer_problem.GetAnswerByProblemId(params)
    httpCtx.ThrowCheck(core.RequestError, err)
    httpCtx.Results = result
}

/**
 * @api {post} /sas/project_by_name 根据项目名字获取项目列表
 * @apiVersion 0.1.0
 * @apiGroup sas
 * @apiDescription 根据项目名字获取项目列表
 * @apiParam {String} name
 *
 * @apiParamExample {json} Request-Example:
 * {
 *	   "name": "", 	   // 项目名字
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccessExample {json} Response-Example:
 * [
 * ]
 *
 */
func (_ *Sas) ProjectByName(httpCtx *hfw.HTTPContext) {
    reqParam := &struct {
        CompanyID int    `json:"company_id" validate:"required"`
        Name      string `json:"name" validate:"required"`
    }{}

    httpCtx.ThrowCheck(core.RequestError, api.RequestUnmarshal(httpCtx, reqParam))

    result, err := project.GetProjectIdByName(reqParam.CompanyID, reqParam.Name)
    httpCtx.ThrowCheck(20305000, err)

    httpCtx.Results = result
}

/*
 * @api {post} /sas/interview_id_by_name 根据关键词获取interview的ID
 * @apiVersion 0.1.0
 * @apiGroup sas
 * @apiDescription 根据关键词获取interview的ID
 * @apiParam {String} name
 *
 * @apiParamExample {json} Request-Example:
 * {
 *      "name": "",     // 关键词
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccessExample {json} Response-Example:
 * {
 *		"results": 1,   // interview的ID
 * }
 *
 */
func (_ *Sas) InterviewIdByName(httpCtx *hfw.HTTPContext) {
    reqParams := &struct {
        Name string `json:"name" validate:"required"`
    }{}

    err := api.RequestUnmarshal(httpCtx, reqParams)
    httpCtx.ThrowCheck(core.RequestError, err)

    id := lambda.GetInterviewIdByName(reqParams.Name)

    httpCtx.Results = id
}

/*
 * @api {post} /sas/name_list 获取员工、项目、岗位、部门名字列表
 * @apiVersion 0.1.0
 * @apiGroup sas
 * @apiDescription 获取员工、项目、岗位、部门名字列表
 * @apiParam {String} scope 缺省:全部, staff:员工名, project:项目名，position:岗位名, department:部门名
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "scope":""
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccessExample {json} Response-Example:
 * {
 *
 *   "staff":[
 *     "名字1",
 *     "名字2"
 *   ],
 *
 *   "project":[
 *     "项目1",
 *     "项目2"
 *   ],
 *
 *   "position":[
 *     "岗位1",
 *     "岗位2"
 *   ],
 *
 *   "department":[
 *     "部门1",
 *     "部门2"
 *   ]
 * }
 *
 */
func (_ *Sas) NameList(httpCtx *hfw.HTTPContext) {
    reqParam := &struct {
        Scope string `json:"scope"`
    }{}

    httpCtx.ThrowCheck(core.RequestError, api.RequestUnmarshal(httpCtx, reqParam))

    type NameList struct {
        Staff      []string `json:"staff"`
        Project    []string `json:"project"`
        Position   []string `json:"position"`
        Department []string `json:"department"`
    }
    projects, err := project.GetProjects()
    httpCtx.ThrowCheck(core.RequestError, err)

    projectNames := make([]string, 0)
    for _, project := range projects {
        projectNames = append(projectNames, project.Name)
    }
    departmentNames, err := staff.GetDepartments()
    httpCtx.ThrowCheck(core.RequestError, err)
    positionNames, err := staff.GetPositions()
    httpCtx.ThrowCheck(core.RequestError, err)
    staffNames, err := staff.GetStaffs()
    httpCtx.ThrowCheck(core.RequestError, err)

    nameList := &NameList{
        Staff:      staffNames,
        Project:    projectNames,
        Position:   positionNames,
        Department: departmentNames,
    }
    httpCtx.Results = nameList
}
