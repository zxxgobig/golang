package controllers

import (
	"fmt"

	"gitlab.ifchange.com/bot/hfw"

	"ifchange/dhr/core"
	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/external"
)

type External struct {
	core.Controller
}

/**
* @api {get} /external/excellent_characters 公司高效人才特征抽取
* @apiVersion 0.1.0
* @apiGroup External
* @apiDescription 公司高效人才特征抽取
*
* @apiParam {String} statDate 获取日期
* @apiParamExample {curl} Request-Example
* http://127.0.0.1:63333/external/excellent_characters?statDate=yyyyMMdd
*
* @apiSuccess {Object[]} results 返回结果
* @apiSuccess {String} results.com_id 公司 id
* @apiSuccess {Number} results.commercial_value 商业价值
* @apiSuccess {[]String} results.labels 特征列表
* @apiSuccessExample {json} Response-Example:
[
    {
      "com_id":10,
      "commercial_value":2900002400,
      "labels":[
        "工作认真",
        "业务能力强"
      ]
    },
    {
      "com_id":11,
      "commercial_value":2900002400,
      "labels":[
        "工作认真",
        "业务能力强"
      ]
    }
]
*
*/
// 示例 http://127.0.0.1:63333/external/excellent_characters?statDate=yyyyMMdd
func (c *External) ExcellentCharacters(httpCtx *hfw.HTTPContext) {
	params := httpCtx.Request.URL.Query()
	statDate := params.Get("statDate")
	if libraries.StrLen(statDate) == 0 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("statDate invalid"))
	}

	result, err := external.ExcellentCharacters()
	httpCtx.ThrowCheck(20305001, err)
	httpCtx.Results = result
}
