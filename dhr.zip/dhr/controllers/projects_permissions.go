package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/project/permission"

    "gitlab.ifchange.com/bot/hfw"
)

/**
 * @api {post} /projects/share_to  分享项目
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 分享项目
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} project_id 项目id
 * @apiParam {[]Number} account_id_list 分享给哪个账号 id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_id": 1,
			"account_id_list": [2]
		}
	}
 *
 *
 * @apiSuccess {Object} result 结果
 * @apiSuccess {Boolean} result.success 操作是否成功：true 成功，false 失败
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results": {
		"success": true
	}
}
 *
*/
func (p *Projects) ShareTo(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        ProjectID     int   `json:"project_id"`
        AccountIDList []int `json:"account_id_list"`
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, &param)
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)
    
    if curUser.RoleType != 1 { // 若为普通账号，先判断是否属于自己的项目
        _, err = permission.IsProjectOwnedByUser(curUser.Id, param.ProjectID)
        httpCtx.ThrowCheck(20304046, err)
    }
    err = permission.ShareTo(curUser.CompanyId, curUser.Id, param.ProjectID, param.AccountIDList)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = &struct {
        Success bool `json:"success"`
    }{true}

    return
}

/**
 * @api {post} /projects/can_share_to  可用于分享项目的账号列表
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 可用于分享项目的账号列表
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} project_id 项目id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_id": 1
		}
	}
 *
 *
 * @apiSuccess {Object} results 结果
 * @apiSuccess {[]Object} results.list 账号列表
 * @apiSuccess {Number} results.list.id 账号 id
 * @apiSuccess {String} results.list.name 账号用户名
 * @apiSuccess {String} results.list.email 账号 email
 *
 * @apiSuccessExample {json} Response-Example:
 {
    "results":{
        "list":[
            {
                "id":1,
                "name":"秦皓",
                "email":"hao.qin@ifchange.com"
            }
        ]
    }
}
 *
*/
func (p *Projects) CanShareTo(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, &param)
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)
    
    if curUser.RoleType != 1 { // 若为普通账号，先判断是否属于自己的项目
        _, err = permission.IsProjectOwnedByUser(curUser.Id, param.ProjectID)
        httpCtx.ThrowCheck(20304046, err)
    }
    
    list, err := permission.CanShareTo(curUser.Id, curUser.CompanyId, param.ProjectID)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = &struct {
        List interface{} `json:"list"`
    }{list}

    return
}

/**
 * @api {post} /projects/revert_share_from  取消分享项目
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 取消项目
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} project_id 项目id
 * @apiParam {[]Number} account_id_list 从哪个账号 id 取消分享
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_id": 1,
			"account_id_list": [2]
		}
	}
 *
 *
 * @apiSuccess {Object} result 结果
 * @apiSuccess {Boolean} result.success 操作是否成功：true 成功，false 失败
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results": {
		"success": true
	}
}
 *
*/
func (p *Projects) RevertShareFrom(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        ProjectID     int   `json:"project_id"`
        AccountIDList []int `json:"account_id_list"`
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, &param)
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)
    
    if curUser.RoleType != 1 { // 若为普通账号，先判断是否属于自己的项目
        _, err = permission.IsProjectOwnedByUser(curUser.Id, param.ProjectID)
        httpCtx.ThrowCheck(20304046, err)
    }
    
    err = permission.RevertShareFrom(curUser.CompanyId, 0, param.ProjectID, param.AccountIDList)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = &struct {
        Success bool `json:"success"`
    }{true}

    return
}

/**
 * @api {post} /projects/can_revert_from  根据项目 id 获取可取消分享的账号列表
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 根据项目 id 获取可取消分享的账号列表
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} project_id 项目id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_id": 1
		}
	}
 *
 *
 * @apiSuccess {Object} results 结果
 * @apiSuccess {[]Object} results.list 账号列表
 * @apiSuccess {Number} results.list.id 账号 id
 * @apiSuccess {String} results.list.name 账号用户名
 * @apiSuccess {String} results.list.email 账号 email
 *
 * @apiSuccessExample {json} Response-Example:
 {
    "results":{
        "list":[
            {
                "id":1,
                "name":"秦皓",
                "email":"hao.qin@ifchange.com"
            }
        ]
    }
}
*/
func (p *Projects) CanRevertFrom(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, &param)
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)
    
    if curUser.RoleType != 1 { // 若为普通账号，先判断是否属于自己的项目
        _, err = permission.IsProjectOwnedByUser(curUser.Id, param.ProjectID)
        httpCtx.ThrowCheck(20304046, err)
    }
    
    list, err := permission.CanRevertFrom(curUser.CompanyId, param.ProjectID)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = &struct {
        List interface{} `json:"list"`
    }{list}

    return
}
