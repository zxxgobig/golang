package interview

import (
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"gitlab.ifchange.com/bot/hfwkit/utils"

	"ifchange/dhr/core"
	logicsCommon "ifchange/dhr/logics/common"

	"gitlab.ifchange.com/bot/hfw"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
)

type Config struct {
	HttpCtx           *hfw.HTTPContext `json:"http_ctx"`
	ProjectID         int              `json:"project_id"`
	StaffID           int              `json:"staff_id"`
	Name              string           `json:"name"`
	Sex               int              `json:"sex"`
	EmailUuid         string           `json:"email_uuid"`
	Uuid              string           `json:"uuid"`
	CompanyID         int              `json:"company_id"`
	DataCollectPlanId int              `json:"data_collect_plan_id"`
	InterviewID       int              `json:"interview_id"`
	TimeStamp         time.Time        `json:"time_stamp"`
}

type Bei struct {
	Config *Config
}

type BeiCreateParam struct {
	UserId int    `json:"user_id" validate:"required"`
	SrcId  int    `json:"src_id"`
	Uuid   string `json:"uuid" `
	Config struct {
		IDs []int `json:"question_ids" validate:"required"`
	} `json:"config" validate:"required"`
}

// type BeiNextCommitParam struct {
// 	UserId int            `json:"user_id" validate:"required"`
// 	Uuid   string         `json:"uuid" validate:"required"`
// 	Event  string         `json:"event" validate:"required"`
// 	Income BeiCommitParam `json:"income"`
// }

type BeiCommitParam struct {
	InterviewId int              `json:"interview_id"`
	TypeId      int              `json:"type_id"`
	SelectSort  CommitSelectSort `json:"select_sort"`
	Question    CommitQuestion   `json:"question"`
}

type CommitQuestion struct {
	Key       string `json:"key"`
	IsInspect int    `json:"is_inspect"`
	Answer    string `json:"answer"`
}
type CommitSelectSort struct {
	Select int   `json:"select"`
	Sort   []int `json:"sort"`
}
type BeiSaveVoice struct {
	InterviewID int    `json:"interview_id"`
	Stage       string `json:"stage"`
	Voice       []byte `json:"voice"`
}

// 创建
func (b *Bei) Create(configSubItems []ConfigSubItem) (result interface{}, err error) {
	ids := []int{}
	for _, configSubItem := range configSubItems {
		ids = append(ids, configSubItem.Id)
	}

	if len(ids) == 0 {
		return result, fmt.Errorf("Bei.Create no items")
	}
	if b.Config.EmailUuid == "" {
		b.Config.EmailUuid, err = utils.CreateUuid(b.Config)
		if err != nil {
			return result, common.NewRespErr(20305000, err)
		}
	}
	params := BeiCreateParam{
		UserId: 100101,
		SrcId:  1,
		Uuid:   "dhr",
	}
	params.Config.IDs = ids

	p := api.NewPost("", "")
	p.P = params
	beiResult := &struct {
		Uuid string `json:"id"`
	}{}
	err = api.SimpleCurl(nil, config.GetServers().BotBei+"interview_create", p, &beiResult)
	if err != nil {
		return
	}
	b.Config.Uuid = beiResult.Uuid
	return nil, err
}

func (b *Bei) SetConfig(config interface{}) (err error) {
	var ok bool
	b.Config, ok = config.(*Config)
	if !ok {
		b.Config = nil
	}
	if b.Config.EmailUuid == "" {
		b.Config.EmailUuid, err = utils.CreateUuid(b.Config)
		if err != nil {
			return err
		}
	}
	return err
}

type BeiGetParam struct {
	InterviewId int `json:"interview_id"`
}

// 获取下一题
func (b *Bei) Get(uuid string, param interface{}) (t interface{}, err error) {
	interviewId, err := strconv.Atoi(uuid)
	if err != nil {
		return
	}

	p := api.NewPost("", "")
	p.P = BeiGetParam{
		InterviewId: interviewId,
	}

	beiResult := json.RawMessage{}
	err = api.SimpleCurl(nil, config.GetServers().BotBei+"interview_next", p, &beiResult)
	if err != nil {
		return
	}
	return beiResult, nil
}

// 提交答案 返回是否完成
func (b *Bei) Commit(uuid string, param interface{}) (t interface{}, err error) {
	interviewId, err := strconv.Atoi(uuid)
	if err != nil {
		return
	}

	if param == nil {
		err = fmt.Errorf("param can't be nil")
		return
	}

	commit := BeiCommitParam{}
	str, err := param.(json.RawMessage).MarshalJSON()
	err = json.Unmarshal([]byte(str), &commit)
	if err != nil {
		return
	}
	commit.InterviewId = interviewId

	p := api.NewPost("", "")
	p.P = commit

	beiCommitResult := json.RawMessage{}
	err = api.SimpleCurl(nil, config.GetServers().BotBei+"interview_commit", p, &beiCommitResult)
	if err != nil {
		return
	}
	return beiCommitResult, nil
}

type BeiCommitResult struct {
	IsFinished int `json:"is_finished"`
}

func (b *Bei) CheckFinished(response interface{}) (isFinished bool, err error) {
	if response == nil {
		err = fmt.Errorf("bei response unvalid")
		return
	}
	res := response.(json.RawMessage)
	result := BeiCommitResult{}
	err = json.Unmarshal(res, &result)
	if err != nil {
		return
	}

	return result.IsFinished == 1, nil
}

func (b *Bei) ResultCommit(interviewID int, emailUuid string, param interface{}) (err error) {
	paramBytes, err := json.Marshal(param)
	if err != nil {
		return common.NewRespErr(core.SystemErrNo, err)
	}
	err = logicsCommon.UpdateStaffsInterview(emailUuid, string(paramBytes), param, interviewID)
	if err != nil {
		return err
	}
	return
}

func (b *Bei) SaveVoice(param interface{}) (err error) {
	p := api.NewPost("", "")
	p.P = param

	beiResult := json.RawMessage{}
	return api.SimpleCurl(nil, config.GetServers().BotBei+"interview_save_voice", p, &beiResult)
}
