package v2_interview

import (
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    PotentialRecommend struct {
        Name     string `json:"name"`
        Desc     string `json:"desc"`
        Index    int    `json:"index"`
        IsAdvice bool   `json:"is_advice"`
        IsMust   bool   `json:"is_must"`
    }
)

func ProcessPotentialRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *PotentialRecommend {
    interview, ok := interviewsM[kitinterview.Potential]
    if !ok {
        return nil
    }

    return &PotentialRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.Potential),
        IsAdvice: GetIsAdvice(kitinterview.Potential, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.Potential, sceneId, sceneTemplateId),
    }
}
