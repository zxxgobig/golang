package v2_scene

import (
    "ifchange/dhr/models"
)

func ConvertSceneTemplateModels(src []*models.ProjectsScenesTemplate) []*SceneTemplateModel {
    if len(src) == 0 {
        return nil
    }

    dst := make([]*SceneTemplateModel, 0, len(src))

    for _, v := range src {
        dst = append(dst, &SceneTemplateModel{
            ProjectsScenesTemplate: v,
        })
    }

    return dst
}
