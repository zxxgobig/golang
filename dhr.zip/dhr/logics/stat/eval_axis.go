package stat

import "sort"

type EvalAxis struct {
	ID             int     `json:"id"`
	Name           string  `json:"name"`
	Score          float64 `json:"score"`
	Total          int     `json:"total,omitempty"`
	Freq           int64   `json:"freq,omitempty"`
	Desc           string  `json:"desc,omitempty"`
	ExcellentScore float64 `json:"excellent_score,omitempty"`
	ExcellentDesc  string  `json:"excellent_desc,omitempty"`
}

type EvalAxes []EvalAxis

func (ea EvalAxes) SortByScoreDesc() {
	if len(ea) < 2 {
		return
	}

	sort.Slice(ea, func(i, j int) bool { return ea[i].Score > ea[j].Score })
}

func (ea EvalAxes) SortByScoreAsc() {
	if len(ea) < 2 {
		return
	}

	sort.Slice(ea, func(i, j int) bool { return ea[i].Score < ea[j].Score })
}

func (ea EvalAxes) SortByIDDesc() {
	if len(ea) < 2 {
		return
	}

	sort.Slice(ea, func(i, j int) bool { return ea[i].ID > ea[j].ID })
}

func (ea EvalAxes) SortByIDAsc() {
	if len(ea) < 2 {
		return
	}

	sort.Slice(ea, func(i, j int) bool { return ea[i].ID < ea[j].ID })
}

func (ea EvalAxes) SortByScoreAndIDDesc() {
	if len(ea) < 2 {
		return
	}

	sort.Slice(ea, func(i, j int) bool {
		if ea[i].Score == ea[j].Score {
			return ea[i].ID < ea[j].ID
		}
		return ea[i].Score > ea[j].Score
	})
}
