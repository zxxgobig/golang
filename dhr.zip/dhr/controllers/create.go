package controllers

import (
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"
    "ifchange/dhr/core"
    "ifchange/dhr/logics/interview"
)

type Create struct {
    core.Controller
}

func (_ *Create) Index(httpCtx *hfw.HTTPContext) {
    params := &struct {
        ProjectID         int `json:"project_id"`
        CompanyID         int `json:"company_id"`
        DataCollectPlanID int `json:"data_collect_plan_id"`
    }{}
    err := api.RequestUnmarshal(httpCtx, params)
    httpCtx.ThrowCheck(20304001, err)
    err = interview.Create(nil, params.ProjectID, params.CompanyID, params.DataCollectPlanID)
    httpCtx.ThrowCheck(20305000, err)
    httpCtx.Results = true
}
