package writedb

import (
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"

    "ifchange/dhr/core"
)

type WaitWriteDbList struct {
    WaitWriteDbs []*WaitWriteDb
}
type WaitWriteDb struct {
    TableName   string
    Type        string // insert or update
    UpdateData  db.Cond
    UpdateWhere db.Cond
    InsertData  interface{}
}

func (params *WaitWriteDbList) WriteDb() (err error) {
    dao, err := db.NewXormDao(hfw.Config, hfw.Config.Db)
    if err != nil {
        return err
    }
    dao.NewSession()
    defer dao.Close()
    err = dao.Begin()
    if err != nil {
        return err
    }

    staffsInterviewsModel, err := models.NewStaffsInterviews(dao)
    if err != nil {
        return common.NewRespErr(core.SystemErrNo, err)
    }

    staffsInterviewsDetailsModel, err := models.NewStaffsInterviewsDetails(dao)
    if err != nil {
        return common.NewRespErr(core.SystemErrNo, err)
    }

    for i := 0; i < len(params.WaitWriteDbs); i++ {

        data := params.WaitWriteDbs[i]
        if data.TableName == "staffs_interviews" {

            if data.Type == "insert" {
                dbInfo := data.InsertData.(*models.StaffsInterviews)
                // models.NewStaffsInterviews(dao)
                affected, err := staffsInterviewsModel.Insert(dbInfo)
                if err != nil {
                    return common.NewRespErr(core.SystemErrNo, err)
                }
                if affected == 0 {
                    return common.NewRespErr(core.SystemErrNo, "insert table staffsInterviews affected rows is 0")
                }
            }

        } else if data.TableName == "staffs_interviews_details" {

            if data.Type == "insert" {
                dbInfo := data.InsertData.(*models.StaffsInterviewsDetails)
                affected, err := staffsInterviewsDetailsModel.Insert(dbInfo)
                if err != nil {
                    return common.NewRespErr(core.SystemErrNo, err)
                }
                if affected == 0 {
                    return common.NewRespErr(core.SystemErrNo, "insert table staffsInterviewsDetails affected rows is 0")
                }
            }

        }

    }

    err = staffsInterviewsDetailsModel.Commit()
    if err != nil {
        return common.NewRespErr(core.DbTransactionCommitError, err)
    }
    return
}
