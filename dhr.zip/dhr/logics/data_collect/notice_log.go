package data_collect

import (
	"fmt"
	"ifchange/dhr/core/channels"

	"ifchange/dhr/models"
	"time"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

type DataCollectNoticeLogI interface {
	// //////////////////////////对外接口
	// 一键提醒
	OnceRemind(planId int) error
	// 重新发送测评链接
	EvaluationLink(planId int) error
	// 提醒员工
	NoticeStaff(planId int, staffID int, noticeTarget string) error
	// //////////////////////////对内接口
	// 今天是否提醒采集计划
	TodayIsNotice(planId int) (isNotice bool, err error)
	// 今天是否发送测评链接
	TodayIsEvalLink(planId int) (isEvalLink bool, err error)
	// 定时采集任务
	NoticeMailWhenTiming() error
	// 创建采集计划邮件
	// 大于今天10点就直接发送邮件
	NoticeMailWhenCreate(planId int) error
}

type dataCollectNoticeLog struct {
}

func NewDataCollectNoticeLog() DataCollectNoticeLogI {
	return &dataCollectNoticeLog{}
}

func (_ *dataCollectNoticeLog) OnceRemind(planId int) error {
	noticeLog, err := models.DataCollectNoticeLogModel.SearchOne(db.Cond{
		"plan_id":     planId,
		"notice_type": 1,
		"orderby":     "id desc",
	})
	if err != nil {
		return err
	}
	if noticeLog != nil {
		create := noticeLog.CreatedAt
		recentlyNoticeTime := time.Date(create.Year(), create.Month(), create.Day(),
			0, 0, 0, 0, create.Location())
		now := time.Now()
		nowTime := time.Date(now.Year(), now.Month(), now.Day(),
			0, 0, 0, 0, now.Location())
		if nowTime.Equal(recentlyNoticeTime) {
			return common.NewRespErr(20304039, "OnceRemind today already noticed")
		}
	}

	planStaffL, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"is_deleted": 0,
		"plan_id":    planId,
		// TODO logical problems roll back
		//"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
		//	"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (work_values = 2 or work_values = 3) " +
		//	"and (key_expr = 2 or key_expr = 3)")
		"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
			"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (emotional_intelligence = 2 or emotional_intelligence = 3) " +
			"and (critical_thinking = 2 or critical_thinking = 3) and (practical_intelligence = 2 or practical_intelligence = 3) " +
			"and (occupational_personality = 2 or occupational_personality = 3) and (personality_disorder = 2 or personality_disorder = 3) " +
			"and (leadership_style = 2 or leadership_style = 3) and (org_commitment = 2 or org_commitment = 3) " +
			"and (work_values = 2 or work_values = 3) and (key_expr = 2 or key_expr = 3)")})
	if err != nil {
		return err
	}

	// // 已完成采集任务，需要从发送邮件任务中过滤掉的staff
	filterStaff := make(map[int]int, 0)
	for _, planStaff := range planStaffL {
		filterStaff[planStaff.StaffId] = planStaff.Id
	}
	groupMailData, err := GeneraGroupMailData(planId, notice_type_remind, filterStaff)
	if err != nil {
		return err
	}
	err = new(MailComponent).SendEmail(groupMailData)
	if err != nil {
		return err
	}

	noticeLog = &models.DataCollectNoticeLog{
		PlanId:     planId,
		NoticeType: 1,
	}
	/*_, err = models.DataCollectNoticeLogModel.Insert(noticeLog)
	if err != nil {
		return err
	}*/
	_ = channels.GetCh().PushDataCollectNoticeLog(noticeLog)
	return nil
}

func (_ *dataCollectNoticeLog) EvaluationLink(planId int) error {
	noticeLog, err := models.DataCollectNoticeLogModel.SearchOne(db.Cond{
		"plan_id":     planId,
		"notice_type": 2,
		"orderby":     "id desc",
	})
	if err != nil {
		return err
	}
	if noticeLog != nil {
		create := noticeLog.CreatedAt
		recentlyNoticeTime := time.Date(create.Year(), create.Month(), create.Day(),
			0, 0, 0, 0, create.Location())
		now := time.Now()
		nowTime := time.Date(now.Year(), now.Month(), now.Day(),
			0, 0, 0, 0, now.Location())
		if nowTime.Equal(recentlyNoticeTime) {
			return common.NewRespErr(20304040, "EvaluationLink today already noticed")
		}
	}

	groupMailData, err := GeneraGroupMailData(planId, notice_type_invite, nil)
	if err != nil {
		return err
	}
	err = new(MailComponent).SendEmail(groupMailData)
	if err != nil {
		return err
	}

	noticeLog = &models.DataCollectNoticeLog{
		PlanId:     planId,
		NoticeType: 2,
	}
	/*_, err = models.DataCollectNoticeLogModel.Insert(noticeLog)
	if err != nil {
		return err
	}*/
	_ = channels.GetCh().PushDataCollectNoticeLog(noticeLog)
	return nil
}

func (_ *dataCollectNoticeLog) NoticeStaff(planID int, staffID int, noticeTarget string) (err error) {
	var data []*MailRealData
	switch noticeTarget {
	case "normal":
		data, err = GeneraStaffMailData(planID, staffID)
		if err != nil {
			return err
		}
	case "leader":
		data, err = GeneraLeaderMailData(planID, staffID)
	}
	err = new(MailComponent).SendEmail(data)
	if err != nil {
		return err
	}
	return nil
}

func (_ *dataCollectNoticeLog) TodayIsNotice(planId int) (isNotice bool, err error) {
	noticeLog, err := models.DataCollectNoticeLogModel.SearchOne(db.Cond{
		"plan_id":     planId,
		"notice_type": 1,
		"orderby":     "id desc",
	})
	if err != nil {
		return false, err
	}
	if noticeLog == nil {
		return false, nil
	}
	create := noticeLog.CreatedAt
	recentlyNoticeTime := time.Date(create.Year(), create.Month(), create.Day(),
		0, 0, 0, 0, create.Location())
	now := time.Now()
	nowTime := time.Date(now.Year(), now.Month(), now.Day(),
		0, 0, 0, 0, now.Location())
	bool := nowTime.Equal(recentlyNoticeTime)
	return bool, nil
}

func (_ *dataCollectNoticeLog) TodayIsEvalLink(planId int) (isEvalLink bool, err error) {
	noticeLog, err := models.DataCollectNoticeLogModel.SearchOne(db.Cond{
		"plan_id":     planId,
		"notice_type": 2,
		"orderby":     "id desc",
	})
	if err != nil {
		return false, err
	}
	if noticeLog == nil {
		return false, nil
	}
	create := noticeLog.CreatedAt
	recentlyNoticeTime := time.Date(create.Year(), create.Month(), create.Day(),
		0, 0, 0, 0, create.Location())
	now := time.Now()
	nowTime := time.Date(now.Year(), now.Month(), now.Day(),
		0, 0, 0, 0, now.Location())
	bool := nowTime.Equal(recentlyNoticeTime)
	return bool, nil
}

func (d *dataCollectNoticeLog) NoticeMailWhenCreate(planId int) error {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planId})
	if err != nil {
		return err
	}
	if plan == nil {
		logger.Debug("NoticeMailWhenCreate plan is nil")
		return nil
	}
	now := time.Now()
	tenClock := time.Date(now.Year(), now.Month(), now.Day(), 10, 0, 0, 0, now.Location())
	zeroClock := time.Date(now.Year(), now.Month(), now.Day(), 23, 59, 59, 0, now.Location())

	if plan.StartTime.After(zeroClock) {
		logger.Debugf("NoticeMailWhenCreate plan startTime after zeroClock, StartTime: %v", plan.StartTime)
		return nil
	}
	if now.After(tenClock) && now.Before(zeroClock) {
		groupMailData, err := GeneraGroupMailData(planId, notice_type_invite, nil)
		if err != nil {
			return err
		}
		err = new(MailComponent).SendEmail(groupMailData)
		if err != nil {
			return err
		}
	}
	return nil
}

// 每天10点定时发送采集通知
func (_ *dataCollectNoticeLog) NoticeMailWhenTiming() error {
	now := time.Now()
	startTime := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	endTime := time.Date(now.Year(), now.Month(), now.Day(), 23, 59, 59, 0, time.Local)

	planL, err := models.DataCollectPlansModel.Search(db.Cond{
		"where": fmt.Sprintf("`status` = 1 and is_deleted = 0 and start_time>='%s' and start_time<='%s'", startTime, endTime),
	})
	if err != nil {
		return err
	}
	if planL == nil || len(planL) == 0 {
		logger.Info("SendEmail, no collect plan of today")
		return nil
	}

	logger.Infof("NoticeMailWhenTiming, at this time plans number is %d", len(planL))
	groupMailDataL := make([]*MailRealData, 0)
	for _, plan := range planL {
		groupMailData, err := GeneraGroupMailData(plan.Id, notice_type_invite, nil)
		if err != nil {
			logger.Warnf("NoticeMailWhenTiming, GeneraGroupMailData err %v", err)
			continue
		}
		groupMailDataL = append(groupMailDataL, groupMailData...)
	}
	err = new(MailComponent).SendEmail(groupMailDataL)
	if err != nil {
		return err
	}
	return nil
}
