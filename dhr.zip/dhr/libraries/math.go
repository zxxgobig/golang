package libraries

func ComputePercentage(a, b int) (percentage int) {
    digit := FixedTwoDigit(float64(a) / float64(b))
    return int(digit * 100)
}
