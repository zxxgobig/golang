package v2_interview

import (
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    KeyExprRecommend struct {
        Name         string                     `json:"name"`
        Desc         string                     `json:"desc"`
        Index        int                        `json:"index"`
        IsAdvice     bool                       `json:"is_advice"`
        IsMust       bool                       `json:"is_must"`
        IsEdit       bool                       `json:"is_edit"`
        MaxCheck     int                        `json:"max_check"`
        ManageExpr   []*KeyExprRecommendSubItem `json:"manage_expr"`
        BusinessExpr []*KeyExprRecommendSubItem `json:"business_expr"`
    }

    KeyExprRecommendSubItem struct {
        Id          int    `json:"id"`
        Name        string `json:"name"`
        IsRecommend bool   `json:"is_recommend"`
    }
)

func ProcessKeyExprRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *KeyExprRecommend {
    interview, ok := interviewsM[kitinterview.KeyExp]
    if !ok {
        return nil
    }

    result := KeyExprRecommend{
        Name:         interview.Name,
        Desc:         interview.Desc,
        Index:    GetIndex(kitinterview.KeyExp),
        IsAdvice:     GetIsAdvice(kitinterview.KeyExp, sceneTemplateId),
        IsMust:       GetIsMust(kitinterview.KeyExp, sceneId, sceneTemplateId),
        IsEdit:       GetIsEdit(kitinterview.KeyExp),
        MaxCheck:     GetMaxCheck(kitinterview.KeyExp),
        ManageExpr:   nil,
        BusinessExpr: nil,
    }

    parseSubItems := ParseSubItems(interview.Config)
    for _, item := range parseSubItems {
        if item.Class == 1 {
            result.ManageExpr = append(result.ManageExpr, &KeyExprRecommendSubItem{
                Id:   item.Id,
                Name: item.Name,
            })
        } else {
            result.BusinessExpr = append(result.BusinessExpr, &KeyExprRecommendSubItem{
                Id:   item.Id,
                Name: item.Name,
            })
        }
    }

    return &result
}
