package project

import (
	"fmt"
	"ifchange/dhr/logics/utils"
	"strconv"

	"ifchange/dhr/logics/data_collect"

	excel "github.com/360EntSecGroup-Skylar/excelize/v2"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/logger"
)

// 历史版本报告
func TalentReport(companyID, projectID, reportID int, excelParser *excel.File) (err error) {
	// 调用谢接口getLogReportDistributionList 拿到须要填写的数据
	result, err := getAdjustReportDistributionList(companyID, projectID, 0, reportID, nil)
	if err != nil {
		return common.NewRespErr(20305006, "调用人才分布报告失败:"+err.Error())
	}
	if len(result) == 0 {
		return common.NewRespErr(20305007, "调用人才分布报告无数据")
	}

	sheet := "Sheet1"
	// 循环填入模板中
	for i, data := range result {
		rowNum := strconv.Itoa(i + 2)
		j := 1
		// 填写员工号
		err = excelParser.SetCellValue(sheet, excelMap[j]+rowNum, data.Name)
		if err != nil {
			break
		}
		// 填写部门
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum, data.Department)
		if err != nil {
			break
		}
		// 填写岗位
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum, data.Position)
		if err != nil {
			break
		}
		// 盘点结果
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum, data.Result)
		if err != nil {
			break
		}
		// 专业知识技能
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum,
			strconv.FormatFloat(data.ProfessionalSkillsScore, 'f', -1, 32))
		if err != nil {
			break
		}
		// 潜力
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum,
			utils.FloatToString(data.PotentialScore))
		if err != nil {
			break
		}
		// 素质
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum,
			strconv.FormatFloat(data.QualityScore, 'f', -1, 32))
		if err != nil {
			break
		}
		// 绩效
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum, data.PerformanceLevel)
		if err != nil {
			break
		}
		// 突出性格
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum, data.Personalities)
		if err != nil {
			break
		}
		// 员工状态
		err = excelParser.SetCellValue(sheet, excelMap[incr(&j)]+rowNum, staffMap[data.Status])
		if err != nil {
			break
		}
	}
	if err != nil {
		err = common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
	}
	return err
}

// 实时版本报告
func Project(companyID, projectID int, excelParser *excel.File) (err error) {
	// 调用谢接口getLogReportDistributionList 拿到须要填写的数据
	result, err := getAdjustReportDistributionList(companyID, projectID, 0, 0, nil)
	if err != nil {
		return common.NewRespErr(20305006, "调用人才分布报告失败:"+err.Error())
	}
	if len(result) == 0 {
		return common.NewRespErr(20305007, "调用人才分布报告无数据")
	}

	sheet := "Sheet1"
	// 循环填入模板中
	row := 2
	for _, data := range result {
		i := 1
		// 填写员工姓名
		column := excelMap[i]
		i++
		site := column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, data.Name)
		if err != nil {
			return err
		}
		// 填写部门
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, data.Department)
		if err != nil {
			return err
		}
		// 填写岗位
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, data.Position)
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 盘点结果
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, data.Result)
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 专业知识技能
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site,
			strconv.FormatFloat(data.ProfessionalSkillsScore, 'f', -1, 32))
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 潜力
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site,
			utils.FloatToString(data.PotentialScore))
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 素质
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site,
			strconv.FormatFloat(data.QualityScore, 'f', -1, 32))
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 绩效
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, data.PerformanceLevel)
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 突出性格
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, data.Personalities)
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		// 员工状态
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue(sheet, site, staffMap[data.Status])
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误:"+err.Error())
		}
		row++
	}
	return err
}

func CollectUsersDetails(companyID, planID int, excelParser *excel.File) (err error) {
	// 调用谢接口getLogReportDistributionList 拿到须要填写的数据
	collectPlan := data_collect.NewDataCollectPlan()
	var result *data_collect.Result
	result, err = collectPlan.Users(companyID, planID)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return common.NewRespErr(20305016, "调用collectPlan.Users失败:"+errMassage)
	}
	if len(result.List) == 0 {
		return common.NewRespErr(20305016, "调用collectPlan.Users失败无数据")
	}
	logger.Infof("***collectPlan.Users result:%v", result)
	// 循环填入模板中
	row := 2
	var text string
	noneed := make([]string, 0)
	for _, data := range result.List {
		unfinished := make(map[int]string, 0)
		i := 1
		// 填写员工姓名
		column := excelMap[i]
		i++
		site := column + strconv.Itoa(row)
		err = excelParser.SetCellValue("Sheet1", site, data.StaffName)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 填写部门
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue("Sheet1", site, data.Department)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 填写岗位
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		err = excelParser.SetCellValue("Sheet1", site, data.Position)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 专业知识
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.Knowledge == 2 {
			text = "已完成"
		} else if data.Knowledge == 1 {
			unfinished[1] = "专业知识"
			text = "-"
		} else if data.Knowledge == 3 {
			text = ""
			noneed = append(noneed, "D")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 专业技能
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.Skill == 2 {
			text = "已完成"
		} else if data.Skill == 1 {
			unfinished[1] = "专业技能"
			text = "-"
		} else if data.Skill == 3 {
			text = ""
			noneed = append(noneed, "E")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 素质
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.Bei == 2 {
			text = "已完成"
		} else if data.Bei == 1 {
			unfinished[1] = "素质"
			text = "-"
		} else if data.Bei == 3 {
			text = ""
			noneed = append(noneed, "F")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 潜力
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.Potential == 2 {
			text = "已完成"
		} else if data.Potential == 1 {
			unfinished[1] = "潜力"
			text = "-"
		} else if data.Potential == 3 {
			text = ""
			noneed = append(noneed, "G")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 性格
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.Normstar == 2 {
			text = "已完成"
		} else if data.Normstar == 1 {
			unfinished[1] = "性格"
			text = "-"
		} else if data.Normstar == 3 {
			text = ""
			noneed = append(noneed, "H")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//关键经历
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.KeyExpr == 2 {
			text = "已完成"
		} else if data.KeyExpr == 1 {
			unfinished[1] = "关键经历"
			text = "-"
		} else if data.KeyExpr == 3 {
			text = ""
			noneed = append(noneed, "I")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//工作选择价值观
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.WorkValues == 2 {
			text = "已完成"
		} else if data.WorkValues == 1 {
			unfinished[1] = "工作选择价值观"
			text = "-"
		} else if data.WorkValues == 3 {
			text = ""
			noneed = append(noneed, "J")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//情绪智力
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.EmotionalIntelligence == 2 {
			text = "已完成"
		} else if data.EmotionalIntelligence == 1 {
			unfinished[1] = "情绪智力"
			text = "-"
		} else if data.EmotionalIntelligence == 3 {
			text = ""
			noneed = append(noneed, "K")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//批判思维
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.CriticalThinking == 2 {
			text = "已完成"
		} else if data.CriticalThinking == 1 {
			unfinished[1] = "批判思维"
			text = "-"
		} else if data.CriticalThinking == 3 {
			text = ""
			noneed = append(noneed, "L")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//管理实践能力
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.PracticalIntelligence == 2 {
			text = "已完成"
		} else if data.PracticalIntelligence == 1 {
			unfinished[1] = "管理实践能力"
			text = "-"
		} else if data.PracticalIntelligence == 3 {
			text = ""
			noneed = append(noneed, "M")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//职业人格
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.OccupationalPersonality == 2 {
			text = "已完成"
		} else if data.OccupationalPersonality == 1 {
			unfinished[1] = "职业人格"
			text = "-"
		} else if data.OccupationalPersonality == 3 {
			text = ""
			noneed = append(noneed, "N")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//性格风险
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.PersonalityDisorder == 2 {
			text = "已完成"
		} else if data.PersonalityDisorder == 1 {
			unfinished[1] = "性格风险"
			text = "-"
		} else if data.PersonalityDisorder == 3 {
			text = ""
			noneed = append(noneed, "O")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//领导风格
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.LeadershipStyle == 2 {
			text = "已完成"
		} else if data.LeadershipStyle == 1 {
			unfinished[1] = "领导风格"
			text = "-"
		} else if data.LeadershipStyle == 3 {
			text = ""
			noneed = append(noneed, "P")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//组织忠诚度
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if data.OrgCommitment == 2 {
			text = "已完成"
		} else if data.OrgCommitment == 1 {
			unfinished[1] = "组织忠诚度"
			text = "-"
		} else if data.OrgCommitment == 3 {
			text = ""
			noneed = append(noneed, "Q")
		} else {
			text = ""
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		//完成情况
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		if _, ok := unfinished[1]; ok {
			text = "未完成"
		} else {
			text = "已完成"
		}
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		// 员工状态
		column = excelMap[i]
		i++
		site = column + strconv.Itoa(row)
		text := staffMap[data.Status]
		err = excelParser.SetCellValue("Sheet1", site, text)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "填写excel内容错误:"+errMassage)
		}
		row++
	}
	// 删除不需要采集的列
	noneed = noneed[:len(result.Hide)]
	renoneed := reverse(noneed)
	logger.Infof("***need deleted colnum:%v***", renoneed)
	for _, colnum := range renoneed {
		err = excelParser.RemoveCol("Sheet1", colnum)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return common.NewRespErr(20305004, "删除excel采集的列错误:"+errMassage)
		}
	}
	return
}
func reverse(s []string) []string {
	for i, j := 0, len(s)-1; i < j; i, j = i+1, j-1 {
		s[i], s[j] = s[j], s[i]
	}
	return s
}

var staffMap = map[int]string{
	1: "试用期",
	2: "在职",
	3: "离职",
}
var excelHeaderMap = map[string]string{
	"专业知识":    "D",
	"专业技能":    "E",
	"素质":      "F",
	"潜力":      "G",
	"性格":      "H",
	"关键经历":    "I",
	"工作选择价值观": "J",
	"情绪智力":    "K",
	"批判思维":    "L",
	"管理实践能力":  "M",
	"职业人格":    "N",
	"性格风险":    "O",
	"领导风格":    "P",
	"组织忠诚度":   "Q",
}

func incr(i *int) int {
	*i++
	return *i
}
