package common

import (
	"fmt"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

const (
	CollectionWaiting   = 1 // 待采集
	Collecting          = 2 // 采集中
	CollectionCompleted = 3 // 采集完成
	CollectionPause     = 4 // 采集暂停
	CollectionEnd       = 5 // 采集结束
	CollectionDeletion  = 6 // 采集删除
)

// 获取有效的项目
func GetValidProject(companyId int, projectId int) (
	project *models.Projects, err error) {

	project, err = models.ProjectsModel.SearchOne(db.Cond{
		"company_id": companyId,
		"id":         projectId,
		"is_deleted": 0,
	})
	if err != nil {
		logger.Warn(err)
		return
	}
	if project == nil {
		err = fmt.Errorf("project not found: %d", projectId)
	}
	return
}

func GetPlanById(id int) (dataCollectPlansModel *models.DataCollectPlans, err error) {
	return models.DataCollectPlansModel.SearchOne(db.Cond{
		"id": id,
		// "is_deleted": 0,
	})
}

func GetPlanByProjectID(projectID int, status int) *models.DataCollectPlans {
	dataCollectPlansModel := new(models.DataCollectPlans)
	models.DataCollectPlansModel.Dao.SearchOne(dataCollectPlansModel, db.Cond{
		"project_id": projectID,
		"status":     status,
		"is_deleted": 0,
	})
	return dataCollectPlansModel
}
