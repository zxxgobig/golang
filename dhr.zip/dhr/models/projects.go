package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var ProjectsModel = &Projects{}

func init() {
	var err error
	ProjectsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	ProjectsModel.Dao.EnableCache(ProjectsModel)
	//ProjectsModel.Dao.DisableCache(ProjectsModel)
	//gob: type not registered for interface
	gob.Register(ProjectsModel)
}

type Projects struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id                  int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	CompanyId           int       `json:"company_id" xorm:"not null default 0 comment('公司id') INT(11)"`
	UserId              int       `json:"user_id" xorm:"not null default 0 comment('用户id') INT(11)"`
	Name                string    `json:"name" xorm:"not null default '' comment('项目名称') VARCHAR(32)"`
	SceneId             int       `json:"scene_id" xorm:"not null default 0 comment('场景id') INT(11)"`
	SceneTemplateId     int       `json:"scene_template_id" xorm:"not null comment('场景模版 ID') INT(11)"`
	PositionId          int       `json:"position_id" xorm:"not null default 0 comment('岗位id') INT(11)"`
	PositionIndustryId  int       `json:"position_industry_id" xorm:"not null default 0 comment('行业id') INT(11)"`
	PositionFunctionId  int       `json:"position_function_id" xorm:"not null default 0 comment('职能id') INT(11)"`
	PositionLevelId     int       `json:"position_level_id" xorm:"not null default 0 comment('层级id') INT(11)"`
	IsManagerPosition   int       `json:"is_manager_position" xorm:"not null default 0 comment('是否是管理岗位 0否 1是') INT(10)"`
	InterviewUsersCount int       `json:"interview_users_count" xorm:"not null default 0 comment('用户测评数量') INT(11)"`
	ComplateRate        int       `json:"complate_rate" xorm:"not null default 0 comment('完成度 1000/1') INT(11)"`
	GoalDesc            string    `json:"goal_desc" xorm:"not null default '' comment('目标') VARCHAR(32)"`
	Desc                string    `json:"desc" xorm:"not null comment('描述') TEXT"`
	StartAt             time.Time `json:"start_at" xorm:"not null default 'CURRENT_TIMESTAMP' comment('开始时间') DATETIME"`
	IsDeleted           int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
	UpdatedAt           time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
	CreatedAt           time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
	ReportId            int       `json:"report_id" xorm:"-"`
	InterviewMode       int       `json:"interview_mode" xorm:"not null default 1 comment('1: BEI+选择排序, 2: 素质能力, 3: 360, 4: BEI+选择排序+360测评, 5: 素质能力+360测评') TINYINT(4)"`
}

func (m *Projects) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *Projects) GetCompanyId() (val int) {
	if m == nil {
		return
	}
	return m.CompanyId
}

func (m *Projects) GetUserId() (val int) {
	if m == nil {
		return
	}
	return m.UserId
}

func (m *Projects) GetName() (val string) {
	if m == nil {
		return
	}
	return m.Name
}

func (m *Projects) GetSceneId() (val int) {
	if m == nil {
		return
	}
	return m.SceneId
}

func (m *Projects) GetSceneTemplateId() (val int) {
	if m == nil {
		return
	}
	return m.SceneTemplateId
}

func (m *Projects) GetPositionId() (val int) {
	if m == nil {
		return
	}
	return m.PositionId
}

func (m *Projects) GetPositionIndustryId() (val int) {
	if m == nil {
		return
	}
	return m.PositionIndustryId
}

func (m *Projects) GetPositionFunctionId() (val int) {
	if m == nil {
		return
	}
	return m.PositionFunctionId
}

func (m *Projects) GetPositionLevelId() (val int) {
	if m == nil {
		return
	}
	return m.PositionLevelId
}

func (m *Projects) GetIsManagerPosition() (val int) {
	if m == nil {
		return
	}
	return m.IsManagerPosition
}

func (m *Projects) GetInterviewUsersCount() (val int) {
	if m == nil {
		return
	}
	return m.InterviewUsersCount
}

func (m *Projects) GetComplateRate() (val int) {
	if m == nil {
		return
	}
	return m.ComplateRate
}

func (m *Projects) GetGoalDesc() (val string) {
	if m == nil {
		return
	}
	return m.GoalDesc
}

func (m *Projects) GetDesc() (val string) {
	if m == nil {
		return
	}
	return m.Desc
}

func (m *Projects) GetStartAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.StartAt
}

func (m *Projects) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *Projects) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *Projects) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *Projects) GetInterviewMode() (val int) {
	if m == nil {
		return
	}
	return m.InterviewMode
}

func (m *Projects) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *Projects) TableName() string {
	return "projects"
}

func (m *Projects) Save(t ...*Projects) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *Projects
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *Projects) Saves(t []*Projects) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *Projects) Insert(t ...*Projects) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *Projects
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *Projects) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *Projects) SearchOne(cond db.Cond) (t *Projects, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *Projects) Search(cond db.Cond) (t []*Projects, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *Projects) SearchAndCount(cond db.Cond) (t []*Projects, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *Projects) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *Projects) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *Projects) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *Projects) GetMulti(ids ...interface{}) (t []*Projects, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *Projects) GetByIds(ids ...interface{}) (t []*Projects, err error) {
	return m.GetMulti(ids...)
}

func (m *Projects) GetById(id interface{}) (t *Projects, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *Projects) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *Projects) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *Projects) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *Projects) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *Projects) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewProjects(c ...interface{}) (m *Projects, err error) {
	m = &Projects{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *Projects) Close() {
	m.Dao.Close()
}

func (m *Projects) Begin() error {
	return m.Dao.Begin()
}

func (m *Projects) Rollback() error {
	return m.Dao.Rollback()
}

func (m *Projects) Commit() error {
	return m.Dao.Commit()
}
