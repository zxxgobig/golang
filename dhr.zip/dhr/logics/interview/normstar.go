package interview

import (
    "fmt"
    "ifchange/dhr/core"
    logicsCommon "ifchange/dhr/logics/common"
    "ifchange/dhr/logics/lambda"
    "strings"

    "gitlab.ifchange.com/bot/hfwkit/utils"

    "gitlab.ifchange.com/bot/hfw/encoding"

    "gitlab.ifchange.com/bot/logger"

    "gitlab.ifchange.com/bot/hfw/common"
    pe "gitlab.ifchange.com/bot/hfwkit/personality_eval"
    proto "gitlab.ifchange.com/bot/proto/personality_eval"
)

type NormStart struct {
    Config *Config
}

func (n *NormStart) SaveVoice(param interface{}) (err error) {
	return nil
}

func (n *NormStart) SetConfig(config interface{}) (err error) {
    var ok bool
    n.Config, ok = config.(*Config)
    if !ok {
        n.Config = nil
    }
    n.Config.EmailUuid, err = utils.CreateUuid(n.Config)
    // n.Config.Uuid = n.Config.EmailUuid
    // n.Config.Uuid, err = libraries.CreateUuid(n.Config)
    if err != nil {
        return err
    }
    return err
}

func (n *NormStart) Create(c []ConfigSubItem) (result interface{}, err error) {
    sex := ""
    if n.Config.Sex == 1 {
        sex = "man"
    } else if n.Config.Sex == 2 {
        sex = "woman"
    } else {
        sex = "man"
    }

    projectData, err := logicsCommon.GetValidProject(n.Config.CompanyID, n.Config.ProjectID)
    if err != nil {
        return result, err
    }
    if projectData == nil {
        return result, fmt.Errorf("项目不存在")
    }
    isManager := false
    if projectData.IsManagerPosition == 1 {
        isManager = true
    }
    positionFunction, err := logicsCommon.GetPositionFunctionById(projectData.PositionFunctionId)
    if err != nil {
        return result, err
    }
    mark := fmt.Sprintf("dhr|%s|%d", n.Config.EmailUuid, n.Config.StaffID)
    // mark := "dhr"
    params := &proto.GetEvaluationURLRequest{
        SrcId:  1,
        UserId: int64(n.Config.StaffID),
        PersonInfo: &proto.PersonInfo{
            Tname: strings.ReplaceAll(n.Config.Name, " ", ""),
            Sex:   sex,
        },
        FunctionId:   int32(positionFunction.FunctionId),
        IsManagement: isManager,
        Mark:         mark,
    }
    url, err := pe.GetEvaluationURL(n.Config.HttpCtx, params)
    logger.Debugf("NormStartUrl: %v", url)
    if url != "" {
        n.Config.Uuid = strings.Split(url, "key=")[1]
    } else {
        err = common.NewRespErr(core.PersonalityEvalServiceError, "NormStartUrl is empty")
    }
    return url, err
}

func (n *NormStart) Get(uuid string, param interface{}) (t interface{}, err error) {

    return
}
func (n *NormStart) Commit(uuid string, p interface{}) (t interface{}, err error) { return }

type CommitNormStart struct {
    EmailUuid  string `json:"email_uuid"`
    Feedback   string `json:"feedback"`
    OrginScore string `json:"orgin_score"`
    Score      int    `json:"score"`
}

func (n *NormStart) ResultCommit(interviewID int, emailUuid string, params interface{}) (err error) {
    paramStr := params.(string)
    paramsMap := make(map[string]float64)
    err = encoding.JSON.Unmarshal([]byte(paramStr), &paramsMap)
    if err != nil {
        return common.NewRespErr(core.SystemErrNo, err)
    }
    paramsIntMap := make(map[int]float64)
    for k, v := range paramsMap {
        if lambda.GetPersonalityAxisID(k) > 0 {
            paramsIntMap[lambda.GetPersonalityAxisID(k)] = v
        }
    }
    logger.Debugf("%+v", paramsIntMap)
    err = logicsCommon.UpdateStaffsInterview(emailUuid, paramStr, paramsIntMap, interviewID)
    if err != nil {
        return err
    }
    return
}

func (n *NormStart) CheckFinished(response interface{}) (isFinished bool, err error) {
    return
}
