package libraries

import "testing"

func TestQrCodeEncodeBash64(t *testing.T) {
    qCode := new(QrCode)
    url := "http://192.168.1.174/api/dhrinterviews/assessment/uuid=b182940b-8004-3707-9ad6-784c62d38dbb&company_id=109&src_id=1&name=王辉&secret_key=b02ee3ed-8189-371f-9e33-f9c30904dac1"
    base64Str, err := qCode.EncodeBase64(url)
    if err != nil {
        t.Error(err)
        return
    }
    t.Log(base64Str)
}
