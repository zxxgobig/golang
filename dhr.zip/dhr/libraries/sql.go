package libraries

import (
    "xorm.io/builder"
)

func MustToBoundSQL(cond interface{}) string {
    s, _ := builder.ToBoundSQL(cond)
    return s
}
