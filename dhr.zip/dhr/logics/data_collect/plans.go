package data_collect

import (
	"fmt"

	pb "gitlab.ifchange.com/bot/proto/dhr_staff/staff"

	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/project/permission"
	"strconv"
	"strings"
	"time"

	"ifchange/dhr/logics/interview"
	"ifchange/dhr/logics/staff"
	"ifchange/dhr/models"

	com "ifchange/dhr/logics/common"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/logger"
)

type DataCollectPlanI interface {
	// //////////////////////////对外接口
	// 修改采集计划时间
	TimeEdit(planIDReq int, startTimeReq, endTimeReq time.Time) (planID int, startTimeResp, endTimeResp time.Time, err error)
	// 修改采集计划状态
	StatusOperate(planIdReq int, inputStateCommand int) (planIdResp, status int, err error)
	// 采集计划详情
	PlanDetailByPlanId(planId int) (dcp *models.DataCollectPlans, err error)
	// 采集计划列表/筛选
	List(planNameKey string, positionIds []int, status []int, companyId int, page, pageSize, userId, roleType int, roleIDs []int, session string) (total int64, resp []*models.DataCollectPlans, err error)
	// 用户参与的采集记录列表
	ListByStaffId(companyId int, staffId int, page, pageSize int) (dcpL []*models.DataCollectPlans, total int64, err error)
	// //////////////////////////对内接口
	// 通过项目Ids获取项目名字
	GetProjectNameByIds(projectIds []int) (pL []*models.Projects, err error)
	// 采集计划进度
	GetProcessRate(planId int) (float64, error)
	// 采集剩余天数
	RemainingDays(status int, startTime, endTime, updateTime time.Time) int
	// 生成采集计划

	CreateCollectPlan(httpCtx *hfw.HTTPContext, projectID, companyID int, name string, startTime, endTime time.Time) (planResult *PlanResult, err error)
	// 采集对象详情
	Users(companyID, planID int) (result *Result, err error)
	// 采集任务完成
	CompletedPlans() (affected int64, err error)
	// 通过id获取采集基本信息
	GetCollectPlanById(id int) (plan *models.DataCollectPlans, err error)
	// 通过公司id获取近期采集计划列表
	GetRecentList(companyID int) (planList []*PlanInfo, err error)
	// 计划列表分析
	ProgressAnalysis(companyID, projectID, interviewID int) (
		totalNums int, planProgressList []*planProgress, err error)
	// 采集计划是否已完成
	IsCompleted(projectID int) (yes bool, err error)
	// 获取采集 总人数、完成人数
	GetDataCollectPlanCompletedStaffNum(projectID int) (total, completed int64, err error)
}

type dataCollectPlan struct {
}

func NewDataCollectPlan() DataCollectPlanI {
	return &dataCollectPlan{}
}

func (cp *dataCollectPlan) TimeEdit(planIdReq int, startTimeReq, endTimeReq time.Time) (planID int, startTimeResp, endTimeResp time.Time, err error) {
	// 查询该planID数据
	collectPlanData, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planIdReq})
	if err != nil {
		return planIdReq, startTimeReq, endTimeReq, fmt.Errorf("TimeEdit DataCollectPlansModel SearchOne err: %v", err)
	}
	if collectPlanData == nil {
		return planIdReq, startTimeReq, endTimeReq, fmt.Errorf("TimeEdit DataCollectPlansModel SearchOne is nil")
	}

	now := time.Now()
	zeroClock := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
	twentyFourClock := time.Date(now.Year(), now.Month(), now.Day(), 23, 59, 59, 0, now.Location())
	// 没在待采集状态，不能修改开始时间
	if collectPlanData.Status != 1 && collectPlanData.Status != 0 {
		logger.Warn("TimeEdit collect status Not in readyStartState")
		startTimeReq = collectPlanData.StartTime
	} else if collectPlanData.StartTime.After(twentyFourClock) && startTimeReq.After(zeroClock) && startTimeReq.Before(twentyFourClock) {
		// 不能把开始时间从明天修改为今天，也就是时间往后修改后不能改回今天 6.26日需求
		logger.Warn("TimeEdit StartTime edit not today")
		startTimeReq = collectPlanData.StartTime
	} else if now.After(startTimeReq) {
		logger.Warn("TimeEdit StartTimeReq cannot be modified before the current time")
		// 非法修改开始时间，不能修改为早于当前时间
		startTimeReq = collectPlanData.StartTime
	}
	// 非法修改结束时间，不能修改为早于开始时间+7天内
	if startTimeReq.Add(7 * 24 * time.Hour).After(endTimeReq) {
		logger.Warn("TimeEdit endTimeReq must be more than 7 days old")
		endTimeReq = collectPlanData.EndTime
	}
	// 修改时间
	_, err = models.DataCollectPlansModel.Update(db.Cond{
		"start_time": startTimeReq.Format("2006-01-02 15:04:05"),
		"end_time":   endTimeReq.Format("2006-01-02 15:04:05"),
	}, db.Cond{
		"id": planIdReq,
	})
	if err != nil {
		return planIdReq, startTimeReq, endTimeReq, fmt.Errorf("TimeEdit DataCollectPlansModel Update err: %v", err)
	}
	return planIdReq, startTimeReq, endTimeReq, nil
}

const (
	initState = iota
	readyStartState
	ingState
	completeState
	suspendedState
	endState
	deleteState
)

func (_ *dataCollectPlan) StatusOperate(planIdReq int, inputStateCommand int) (planIdResp, status int, err error) {
	if planIdReq == 0 || inputStateCommand == 0 {
		return planIdReq, -1, common.NewRespErr(20304001,
			fmt.Sprintf("StatusOperate planIdReq: %d, inputStateCommand: %d", planIdReq, inputStateCommand))
	}

	currentCollectData, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planIdReq})
	if err != nil {
		return -1, -1, fmt.Errorf("StatusOperate DataCollectPlansModel SearchOne err: %v", err)
	}
	if currentCollectData == nil {
		return -1, -1, fmt.Errorf("StatusOperate DataCollectPlansModel SearchOne is nil")
	}

	// 写入有限状态机
	// 参考 http://192.168.1.150:8090/pages/viewpage.action?pageId=69862029
	operateState := 0 // 最终写入的状态
	isDelete := 0     // 是否删除数据, 删除:1, 默认:0
	switch currentCollectData.Status {
	case initState, readyStartState:
		if inputStateCommand == endState {
			operateState = 5
		} else {
			return -1, -1, fmt.Errorf("illegal operation")
		}
	case ingState:
		if inputStateCommand == suspendedState {
			operateState = 4
		} else if inputStateCommand == endState {
			operateState = 5
		} else {
			return -1, -1, fmt.Errorf("illegal operation")
		}
	case completeState, endState:
		if inputStateCommand == deleteState {
			operateState = 6
			isDelete = 1
		} else {
			return -1, -1, fmt.Errorf("illegal operation")
		}
	case suspendedState:
		if inputStateCommand == ingState {
			operateState = 2
			err := pauseToRestartUpdateEndTime(currentCollectData)
			if err != nil {
				return -1, -1, err
			}
		} else if inputStateCommand == endState {
			operateState = 5
		} else {
			return -1, -1, fmt.Errorf("illegal operation")
		}
	case deleteState:
		if inputStateCommand == deleteState {
			return planIdReq, deleteState, nil
		} else {
			return -1, -1, fmt.Errorf("illegal operation")
		}
	}

	// 更新状态
	_, err = models.DataCollectPlansModel.Update(db.Cond{
		"status":     operateState,
		"is_deleted": isDelete,
	}, db.Cond{
		"id": planIdReq,
	})

	// 写入采集日志
	dcpLog := &models.DataCollectPlanLog{
		PlanId: planIdReq,
		Status: operateState,
	}
	_, err = models.DataCollectPlanLogModel.Save(dcpLog)
	if err != nil {
		logger.Warnf("StatusOperate DataCollectPlanLogModel save err: %v", err)
	}
	return planIdReq, operateState, nil
}

// 从暂停状态切换到进行中状态时，需要修改结束时间，向后推时间
// 结束时间 = 当前时间 + 剩余天数
func pauseToRestartUpdateEndTime(plan *models.DataCollectPlans) error {
	plan.EndTime = time.Now().Add(plan.EndTime.Sub(plan.UpdatedAt))
	_, err := models.DataCollectPlansModel.Update(db.Cond{
		"end_time": plan.EndTime,
	}, db.Cond{
		"id": plan.Id,
	})
	if err != nil {
		return err
	}
	return nil
}

func (_ *dataCollectPlan) PlanDetailByPlanId(planId int) (dcp *models.DataCollectPlans, err error) {
	dcp, err = models.DataCollectPlansModel.SearchOne(db.Cond{"id": planId})
	if err != nil {
		return nil, err
	}
	return dcp, nil
}

func (_ *dataCollectPlan) GetProjectNameByIds(projectIds []int) (pL []*models.Projects, err error) {
	pL, err = models.ProjectsModel.Search(db.Cond{"id in": projectIds})
	if err != nil {
		return nil, err
	}
	return pL, nil
}

func (_ *dataCollectPlan) List(planNameKey string, positionIds []int, status []int, companyId int, page, pageSize,
	userId, roleType int, roleIDs []int, session string) (total int64, resp []*models.DataCollectPlans, err error) {
	// 获取员工所在公司下的所有已经创建的采集ID
	interviewSql := fmt.Sprintf("SELECT data_collect_id FROM"+
		" `staffs_interviews` WHERE `company_id` = %d GROUP BY data_collect_id", companyId)
	interviewL, err := models.StaffsInterviewsModel.Query(interviewSql)
	if err != nil {
		return -1, nil, err
	}
	if len(interviewL) == 0 {
		return
	}
	planIds := make([]int, 0)

	var dataPermission int
	userList := make([]*permission.UserPermission, 0)
	if roleType == 2 {
		// 根据权限筛选掉一部分人，从 session 里获取权限信息:只取 user id 匹配（自己创建的），和被分享的(在 project_permissions 里可以找到只有被分享的用户)
		judgeDataPermissionReq := &permission.JudgeDataPermissionReq{
			RoleIds:   roleIDs,
			CompanyID: companyId,
			ModuleKey: "bot_module_collection", // 标识项目模块
		}
		dataPermission, err = permission.JudgeResourceDataPermission(judgeDataPermissionReq)
		if err != nil {
			return 0, nil, err
		}
		permissionUserList, err := permission.GetPermissionUserList(session)
		if err != nil {
			return 0, nil, err
		}
		userList = permissionUserList.UserList
	}
	for _, interview := range interviewL {
		planId, err := strconv.Atoi(string(interview["data_collect_id"][:]))
		if err != nil {
			return -1, nil, err
		}
		if roleType == 2 && dataPermission == 2 { // 1.超级管理员 2.普通用户
			// 判断数据来源
			dataSourceType, err := staff.GetDataSourceType(companyId, userId, planId, userList)
			if err != nil {
				return -1, nil, err
			}
			if dataSourceType != staff.DataSourceTypeOther {
				planIds = append(planIds, planId)
			}
		} else {
			planIds = append(planIds, planId)
		}
	}
	// 获取采集基本详情列表
	cond := db.Cond{
		"id in":      planIds,
		"is_deleted": 0,
	}

	if planNameKey != "" {
		cond["where"] = fmt.Sprintf("`name` like %s", "'%"+planNameKey+"%'")
	}
	if len(status) > 0 {
		cond["status in"] = status
	}
	if len(positionIds) > 0 {
		cond["position_id in"] = positionIds
	}
	total, err = models.DataCollectPlansModel.Count(cond)
	if err != nil {
		return -1, nil, err
	}

	if page > 0 {
		cond["page"] = page
	}
	if pageSize > 0 {
		cond["pagesize"] = pageSize
	}
	dcpL, err := models.DataCollectPlansModel.Search(cond)
	if err != nil {
		return -1, nil, err
	}
	return total, dcpL, nil
}

func (_ *dataCollectPlan) ListByStaffId(companyId int, staffId int, page, pageSize int) (dcpL []*models.DataCollectPlans, total int64, err error) {
	valid, err := staff.CheckStaffs(companyId, []int{staffId})
	if err != nil {
		return nil, -1, err
	}
	if valid == false {
		return nil, -1, fmt.Errorf("staff not valid")
	}

	collectPlanStaffsL, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"staff_id":   staffId,
		"page":       page,
		"pageSize":   pageSize,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, -1, err
	}

	total, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"staff_id": staffId,
	})
	if err != nil {
		return nil, -1, err
	}

	planIdL := make([]int, 0)
	if collectPlanStaffsL != nil && len(collectPlanStaffsL) > 0 {
		for _, planStaff := range collectPlanStaffsL {
			planIdL = append(planIdL, planStaff.PlanId)
		}

		collectPlanL, err := models.DataCollectPlansModel.Search(db.Cond{"id in": planIdL, "is_deleted": 0})
		if err != nil {
			return nil, -1, err
		}
		return collectPlanL, total, nil
	}
	return nil, -1, fmt.Errorf("ListByStaffId DataCollectPlanStaffsModel search result is nil")
}

func (_ *dataCollectPlan) RemainingDays(status int, startTime, endTime, updateTime time.Time) int {
	if status == 3 || status == 5 {
		return 0
	}
	if status == 4 {
		startTime = updateTime
	}
	// 采集进行中，结束时间递减
	if status == 2 {
		startTime = time.Now()
	}
	endTime = time.Date(endTime.Year(), endTime.Month(), endTime.Day(), 10, 0, 0, 0, time.Local)
	return timeSubDays(startTime, endTime)
}

// 相隔24小时内为一天
// 相隔非24小时整数，并在结果上加一天
func timeSubDays(startTime, endTime time.Time) int {
	subSeconds := endTime.Sub(startTime).Seconds()
	if subSeconds <= 0 {
		return 0
	}
	// 24小时内算一天
	if subSeconds > 0 && subSeconds <= 86400 {
		return 1
	}
	// 对一天的总秒数取余数
	remainder := int(subSeconds) % 86400
	// 除以一天的总秒数
	division := int(subSeconds) / 86400
	// 余数结果是一天的整天数
	if remainder == 0 {
		return division
	} else {
		// 余数结果大于一天并且非整天数
		return division + 1
	}
}

// 获取采集进度
func (_ *dataCollectPlan) GetProcessRate(planId int) (float64, error) {
	collectPlanStaff := NewDataCollectPlanStaffs()
	totalCount, err := collectPlanStaff.GetCollectPlanTotalCountByPlanId(planId)
	if err != nil {
		return -1, err
	}
	if totalCount == 0 {
		return 0, nil
	}
	completedCount, err := collectPlanStaff.GetCollectPlanCompletedCountByPlanId(planId)
	if err != nil {
		return -1, err
	}

	rateFloat64, err := strconv.ParseFloat(fmt.Sprintf("%.2f", float64(completedCount)/float64(totalCount)), 64)
	if err != nil {
		return -1, err
	}
	return rateFloat64, nil
}

type PlanResult struct {
	PlanID int `json:"plan_id"`
}

// CreateCollectPlan ..
func (*dataCollectPlan) CreateCollectPlan(httpCtx *hfw.HTTPContext, projectID, companyID int, name string, starttime, endtime time.Time) (planResult *PlanResult, err error) {
	planResult = &PlanResult{}
	// 判断采集计划名字是否存在（目前是采集计划名字全局唯一，不能重复）
	planOld, err := models.DataCollectPlansModel.SearchOne(db.Cond{"name": name, "is_deleted": 0})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}
	if planOld != nil {
		return nil, common.NewRespErr(20304042, "该采集计划名称已存在")
	}
	// 判断项目是否存在
	_, err = interview.GetValidProject(companyID, projectID)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20304026, "项目不存在:"+errMassage)
	}
	// 调接口GetDataCollectDemandStaffs接口获取有采集计划的员工数据，该部分数据为全量需要计入data_collect_plan_staffs的数据
	// 把本次采集计划里所有员工的做题信息提炼出来，从而更新表data_collect_plan_staffs这张表
	extendedStaffs, err := interview.GetDataCollectDemandStaffs(companyID, projectID, nil)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20305005, "调用采集所需staff信息错误:"+errMassage)
	}
	if len(extendedStaffs) == 0 {
		return nil, common.NewRespErr(20304055, "没有须要采集的员工")
	}
	// 如果有须要采集人员，采集计划生成
	data, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectID})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}
	if data == nil {
		return nil, common.NewRespErr(20304028, "没有符合条件数据")
	}
	/* startTime, err := time.Parse("2006-01-02 03:04:05", startTime)
	   endTime, err := time.Parse("2006-01-02 03:04:05", endTime)*/
	// 创建时间合理性判断
	now := time.Now()
	d, _ := time.ParseDuration("-24h")
	d1 := now.Add(d)
	Yesterday := time.Date(d1.Year(), d1.Month(), d1.Day(), 23, 59, 59, 0, d1.Location())
	if starttime.Before(Yesterday) || endtime.Before(starttime) {
		return nil, common.NewRespErr(20304037, "采集计划起止时间有误")
	}
	day, _ := time.ParseDuration("24h")
	lessDay := starttime.Add(day * 7)
	if endtime.Before(lessDay) {
		return nil, common.NewRespErr(20304038, "采集计划至少7天")
	}

	verifyCode, err := libraries.ToCVerifyPhone(companyID)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}

	// 将信息插入到collect_plans数据库
	plan := &models.DataCollectPlans{
		ProjectId:   projectID,
		PositionId:  data.PositionId,
		Name:        name,
		StartTime:   starttime,
		EndTime:     endtime,
		Status:      1,
		VerifyPhone: verifyCode,
		IsDeleted:   1,
	}
	_, err = models.DataCollectPlansModel.Insert(plan)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20305025, "插入数据库失败:"+errMassage)
	}
	// 循环插入collect_plan_staff数据库
	for _, extendedStaff := range extendedStaffs {
		// 判断直属leader是否存在，若不存在，返回抛错；（一荣俱荣、一损俱损）
		if extendedStaff.LeaderIsEmpty {
			return nil, common.NewRespErr(20304036, "部分员工没有找到直属上级，请核对您的员工信息")
		}
		data := &models.DataCollectPlanStaffs{
			PlanId:                  plan.Id,
			StaffId:                 extendedStaff.Id,
			Skill:                   3,
			Knowledge:               3,
			Bei:                     3,
			Potential:               3,
			Normstar:                3,
			KeyExpr:                 3,
			WorkValues:              3,
			EmotionalIntelligence:   3,
			CriticalThinking:        3,
			PracticalIntelligence:   3,
			OccupationalPersonality: 3,
			PersonalityDisorder:     3,
			LeadershipStyle:         3,
			OrgCommitment:           3,
			IsDeleted:               1,
		}
		_, err := models.DataCollectPlanStaffsModel.Insert(data)
		if err != nil {
			errMassage := fmt.Sprint(err)
			return nil, common.NewRespErr(20305025, "插入数据库失败:"+errMassage)
		}
		// 设置已完成采集的维度
		for _, n := range extendedStaff.CompletedConfigItemParams {
			if n.Id == 21 {
				continue
			}
			_, err = models.DataCollectPlanStaffsModel.Update(db.Cond{com.InterviewMapping[n.Id]: com.CollectPlanFinished}, db.Cond{"plan_id": plan.Id, "staff_id": extendedStaff.Id})
			if err != nil {
				return nil, common.NewRespErr(20304035, "更新数据库失败:"+fmt.Sprint(err))
			}
		}

		// 设置未完成采集的维度
		for _, v := range extendedStaff.NoCompletedConfigItemParams {
			if v.Id == 21 {
				continue
			}
			_, err = models.DataCollectPlanStaffsModel.Update(db.Cond{com.InterviewMapping[v.Id]: com.CollectPlanUnfinished}, db.Cond{"plan_id": plan.Id, "staff_id": extendedStaff.Id})
			if err != nil {
				return nil, common.NewRespErr(20304035, "更新数据库失败"+fmt.Sprint(err))
			}
		}
		if err = com.InterviewNewBeiHandler(projectID, extendedStaff.Id, plan.Id); err != nil {
			return nil, common.NewRespErr(20305000, fmt.Sprint(err))
		}
	}
	logger.Infof("***GetDataCollectDemandStaffs data:%+v***", extendedStaffs)
	// 回调
	logger.Infof("***companyID :%+v***", companyID)
	err = interview.Create(httpCtx, projectID, companyID, plan.Id)
	if err != nil {
		return nil, common.NewRespErr(20305003, err)
	}
	// 调用邮件提示
	dataCollect := NewDataCollectNoticeLog()
	err = dataCollect.NoticeMailWhenCreate(plan.Id)
	if err != nil {
		return nil, common.NewRespErr(20305012, "创建采集计划时调用邮件系统错误"+fmt.Sprint(err))
	}
	// 创建过程无误，将collect_plans和collect_plan_staffs的对应状态改成0
	_, err = models.DataCollectPlansModel.Update(db.Cond{"is_deleted": 0}, db.Cond{"id": plan.Id})
	if err != nil {
		return nil, common.NewRespErr(20305035, "更新数据库失败"+fmt.Sprint(err))
	}
	for _, extendedStaff := range extendedStaffs {
		_, err = models.DataCollectPlanStaffsModel.Update(db.Cond{"is_deleted": 0}, db.Cond{"plan_id": plan.Id, "staff_id": extendedStaff.Id})
		if err != nil {
			return nil, common.NewRespErr(20305035, "更新数据库失败"+fmt.Sprint(err))
		}
	}
	planResult.PlanID = plan.Id
	return planResult, err
}

func GetPlanById(id int) (dataCollectPlansModel *models.DataCollectPlans, err error) {
	return models.DataCollectPlansModel.SearchOne(db.Cond{
		"id": id,
		// "is_deleted": 0,
	})
}

type Result struct {
	Total     int      `json:"total"`
	ProjectId int      `json:"project_id"`
	ReportId  int      `json:"report_id"`
	Hide      []string `json:"hide"`
	Status    int      `json:"status"`
	List      []Staff  `json:"list"`
}
type Staff struct {
	StaffName               string `json:"staff_name"`
	StaffId                 int    `json:"staff_id"`
	Status                  int    `json:"status"`
	LeaderStatus            int    `json:"leader_status"`
	Department              string `json:"department"`
	Position                string `json:"position"`
	Skill                   int    `json:"skill"`
	Knowledge               int    `json:"knowledge"`
	Bei                     int    `json:"bei"`
	Potential               int    `json:"potential"`
	Normstar                int    `json:"normstar"`
	EmotionalIntelligence   int    `json:"emotional_intelligence"`
	CriticalThinking        int    `json:"critical_thinking"`
	PracticalIntelligence   int    `json:"practical_intelligence"`
	OccupationalPersonality int    `json:"occupational_personality"`
	PersonalityDisorder     int    `json:"personality_disorder"`
	LeadershipStyle         int    `json:"leadership_style"`
	OrgCommitment           int    `json:"org_commitment"`
	WorkValues              int    `json:"work_values"`
	KeyExpr                 int    `json:"key_expr"`
}

const ReportVersion = 0 // 最新版本
func (_ *dataCollectPlan) Users(companyID, planID int) (result *Result, err error) {
	result = new(Result)
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planID, "is_deleted": 0})
	if err != nil {
		return nil, common.NewRespErr(20305024, "查数据库失败"+fmt.Sprint(err))
	}
	if plan == nil {
		return
	}
	result.Status = plan.Status
	result.ProjectId = plan.ProjectId
	// 0表示最新版本
	result.ReportId = ReportVersion
	// 根据planID查询出所有相关的staffId
	datalist, err := models.DataCollectPlanStaffsModel.Search(db.Cond{"plan_id": planID, "is_deleted": 0})
	if err != nil {
		return nil, common.NewRespErr(20305024, "查数据库失败"+fmt.Sprint(err))
	}
	if len(datalist) == 0 {
		return nil, nil
	}
	staffIDs := make([]int, 0)
	for _, data := range datalist {
		staffIDs = append(staffIDs, data.StaffId)
	}

	// 用staffId调用GetStaffsByIDs 来获取部门和岗位名称 （todo by zzj 包含离职员工）
	staffs, err := dhr_staff.ListStaffByIds(nil, companyID, staffIDs, true, []pb.Status{pb.Status_DIMISSION})
	if err != nil {
		return nil, common.NewRespErr(20305001, "调用staff信息错误"+fmt.Sprint(err))
	}
	if staffs == nil {
		return nil, common.NewRespErr(20305002, "没有符合要求的staff信息")
	}
	// 组装结果将staff根据id组装成map
	staffMap := make(map[int]*dhr_staff.Staff)
	for _, staff := range staffs {
		staffMap[staff.Id] = staff
	}

	result.Total = len(staffs)
	// 填写隐藏字段列表
	if datalist[0].Skill == 3 {
		result.Hide = append(result.Hide, "skill")
	}
	if datalist[0].Knowledge == 3 {
		result.Hide = append(result.Hide, "knowledge")
	}
	if datalist[0].Bei == 3 {
		result.Hide = append(result.Hide, "bei")
	}
	if datalist[0].Potential == 3 {
		result.Hide = append(result.Hide, "potential")
	}
	if datalist[0].Normstar == 3 {
		result.Hide = append(result.Hide, "normstar")
	}
	if datalist[0].EmotionalIntelligence == 3 {
		result.Hide = append(result.Hide, "emotional_intelligence")
	}
	if datalist[0].CriticalThinking == 3 {
		result.Hide = append(result.Hide, "critical_thinking")
	}
	if datalist[0].PracticalIntelligence == 3 {
		result.Hide = append(result.Hide, "practical_intelligence")
	}
	if datalist[0].OccupationalPersonality == 3 {
		result.Hide = append(result.Hide, "occupational_personality")
	}
	if datalist[0].PersonalityDisorder == 3 {
		result.Hide = append(result.Hide, "personality_disorder")
	}
	if datalist[0].LeadershipStyle == 3 {
		result.Hide = append(result.Hide, "leadership_style")
	}
	if datalist[0].OrgCommitment == 3 {
		result.Hide = append(result.Hide, "org_commitment")
	}
	if datalist[0].WorkValues == 3 {
		result.Hide = append(result.Hide, "work_values")
	}
	if datalist[0].KeyExpr == 3 {
		result.Hide = append(result.Hide, "key_expr")
	}

	for _, v := range datalist {
		var leaderStatus int
		leader, err := staff.GetLeaderInfo(companyID, v.StaffId)
		if err != nil || leader == nil {
			leaderStatus = 3
		} else {
			leaderStatus = leader.Status
		}

		staff := Staff{
			StaffName:               staffMap[v.StaffId].Name,
			StaffId:                 v.StaffId,
			Status:                  staffMap[v.StaffId].Status,
			LeaderStatus:            leaderStatus,
			Department:              staffMap[v.StaffId].DepartmentName,
			Position:                staffMap[v.StaffId].PositionName,
			Skill:                   v.Skill,
			Knowledge:               v.Knowledge,
			Bei:                     v.Bei,
			Potential:               v.Potential,
			Normstar:                v.Normstar,
			EmotionalIntelligence:   v.EmotionalIntelligence,
			CriticalThinking:        v.CriticalThinking,
			PracticalIntelligence:   v.PracticalIntelligence,
			OccupationalPersonality: v.OccupationalPersonality,
			PersonalityDisorder:     v.PersonalityDisorder,
			LeadershipStyle:         v.LeadershipStyle,
			OrgCommitment:           v.OrgCommitment,
			WorkValues:              v.WorkValues,
			KeyExpr:                 v.KeyExpr,
		}
		result.List = append(result.List, staff)
	}
	return
}

func (_ *dataCollectPlan) CompletedPlans() (affected int64, err error) {
	now := time.Now()
	startTime := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	endTime := time.Date(now.Year(), now.Month(), now.Day(), 23, 59, 59, 0, time.Local)

	// 获取所有截止日期是今天的采集计划
	planL, err := models.DataCollectPlansModel.Search(db.Cond{
		"is_deleted": 0,
		"status":     2,
		"where":      fmt.Sprintf("end_time>='%s' and end_time<='%s'", startTime, endTime),
	})
	if err != nil {
		return -1, err
	}
	ids := []int{}
	for _, plan := range planL {
		ids = append(ids, plan.Id)
	}
	// 置为已完成
	affected, err = models.DataCollectPlansModel.Update(db.Cond{
		"status": 3,
	}, db.Cond{
		"id in": ids,
	})
	if err != nil {
		return -1, err
	}
	return affected, nil
}

func (_ *dataCollectPlan) GetCollectPlanById(id int) (plan *models.DataCollectPlans, err error) {
	plan, err = models.DataCollectPlansModel.SearchOne(db.Cond{"id": id})
	return plan, err
}

// 一个项目只可以发起一次采集计划 - 新规则，所以可以用一次采集计划的人数来代表这个项目
func (_ *dataCollectPlan) GetDataCollectPlanCompletedStaffNum(projectID int) (total, completed int64, err error) {
	dataCollectPlans, err := models.DataCollectPlansModel.Search(db.Cond{
		"project_id": projectID,
		"is_deleted": 0,
	})
	if err != nil {
		return 0, 0, err
	}

	for _, plan := range dataCollectPlans {
		collectPlanStaff := NewDataCollectPlanStaffs()
		totalCount, err := collectPlanStaff.GetCollectPlanTotalCountByPlanId(plan.Id)
		if err != nil {
			return -1, -1, err
		}
		if totalCount == 0 {
			return -1, -1, nil
		}
		completedCount, err := collectPlanStaff.GetCollectPlanCompletedCountByPlanId(plan.Id)
		if err != nil {
			return -1, -1, err
		}
		total += totalCount
		completed += completedCount
	}
	return
}

// PlanInfo 返回给前端的单个采集计划信息
type PlanInfo struct {
	PlanID      int              `json:"plan_id"`
	PlanName    string           `json:"plan_name"`
	ProjectID   int              `json:"project_id"`
	ProjectName string           `json:"project_name"`
	Interviews  []*InterviewInfo `json:"interviews"`
}

type InterviewInfo struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

// GetRecentList 只获取*进行中*和*近七天有数据变化*的采集计划列表
func (p *dataCollectPlan) GetRecentList(companyID int) (planList []*PlanInfo, err error) {
	planList = []*PlanInfo{}

	// 获取company_id 下所有项目id列表
	projects, err := models.ProjectsModel.Search(db.Cond{
		"is_deleted": 0,
		"company_id": companyID,
	})
	if err != nil {
		return
	}
	if len(projects) == 0 {
		return
	}
	projectsIDStrs := []string{}
	for _, p := range projects {
		projectsIDStrs = append(projectsIDStrs, strconv.Itoa(p.Id))
	}

	// 获取近期计划列
	//aWeekBefore := time.Now().Add(-time.Hour * 7 * 24) // 七天之前
	recentPlansQuery := fmt.Sprintf(`SELECT * FROM data_collect_plans
						WHERE project_id in (%s)
						AND (status=2 OR (status=3 AND DATE_SUB(CURDATE(), INTERVAL 6 DAY) <= date(updated_at)))
						AND is_deleted=0
						ORDER BY created_at desc`,
		strings.Join(projectsIDStrs, ","))

	plans, err := models.DataCollectPlansModel.Search(db.Cond{
		"sql": recentPlansQuery,
	})

	if len(plans) == 0 {
		return
	}

	for _, p := range plans {
		proj, err := models.ProjectsModel.SearchOne(db.Cond{
			"is_deleted": 0,
			"id":         p.ProjectId,
		})
		if err != nil {
			return planList, err
		}
		if proj == nil {
			logger.Warnf("project not exist, project_id: <%+v>", p.ProjectId)
			continue
		}
		interviews, err := interview.GetInterviewsConfigsByProjectID(proj.Id)
		if err != nil {
			logger.Warn(err)
			err = nil
			continue
		}
		intvInfos := []*InterviewInfo{}
		for _, i := range interviews {
			intvInfo := &InterviewInfo{
				ID:   i.InterviewId,
				Name: kitinterview.Type(i.InterviewId).ChineseName("dhr"),
			}
			intvInfos = append(intvInfos, intvInfo)
		}

		plan := &PlanInfo{
			PlanID:      p.Id,
			PlanName:    p.Name,
			ProjectID:   proj.Id,
			ProjectName: proj.Name,
			Interviews:  intvInfos,
		}
		planList = append(planList, plan)
	}
	return
}

type planProgress struct {
	Date         int64   `json:"date"`
	ComplateRate float32 `json:"completion_rate"`
	ComplateNums int     `json:"complete_nums"`
}

// ProgressAnalysis 获取某项采集计划的进度情况, totalNums 测评总人数
func (*dataCollectPlan) ProgressAnalysis(companyID, planID, interviewID int) (
	totalNums int, planProgressList []*planProgress, err error) {
	planProgressList = []*planProgress{}

	totalInt64Nums, err := models.DataCollectPlanStaffsModel.Count(db.Cond{
		"is_deleted": 0,
		"plan_id":    planID,
	})
	if err != nil {
		return
	}

	totalNums = int(totalInt64Nums) // 总人数
	if totalNums == 0 {
		return
	}

	/*
		q := fmt.Sprintf(`SELECT Date(updated_at), id FROM data_collect_plan_staffs
								  //WHERE plan_id=%d
								  //AND %s=2
								  //AND is_deleted=0
								  //GROUP BY Date(updated_at)`, planID, interviewEnName)
	*/
	q := fmt.Sprintf(`SELECT updated_at, count(id) as id FROM data_collect_plan_staffs
							  WHERE plan_id=%d
							  AND %s=2
							  AND is_deleted=0
							  GROUP BY Date(updated_at)`, planID, kitinterview.Type(interviewID).EnglishName())

	res, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"sql": q,
	})
	if err != nil {
		return
	}
	if len(res) == 0 {
		logger.Info("data_collect_plan progress analysis data is nil")
		return
	}
	logger.Infof("data_collect_plan progress analysis data got length: <%+v>", len(res))

	// 组织数据
	complateNums := 0 // 累计完成人数
	for _, r := range res {
		logger.Infof("the update_at of query res is: <%+v>", r.UpdatedAt)
		complateNums = complateNums + r.Id // id 已在上面的sql语句替换成了人数
		pg := &planProgress{
			Date:         r.UpdatedAt.Unix(),
			ComplateRate: float32(complateNums) / float32(totalNums),
			ComplateNums: complateNums,
		}
		planProgressList = append(planProgressList, pg)
		logger.Infof("the update_at of return to fontend is: <%+v>", pg.Date)
	}
	return
}

func (*dataCollectPlan) IsCompleted(projectID int) (completed bool, err error) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"project_id": projectID,
	})

	if err != nil {
		return
	}
	if plan == nil {
		return
	}

	if plan.Status == 3 || plan.Status == 5 {
		completed = true
	}
	if plan.EndTime.Before(time.Now()) {
		completed = true
	}

	return
}
