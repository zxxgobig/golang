package v2_level

import (
    "ifchange/dhr/models"
)

func ConvertLevelModels(src []*models.PositionLevels) []*LevelModel {
    if len(src) == 0 {
        return nil
    }

    dst := make([]*LevelModel, 0, len(src))

    for _, v := range src {
        dst = append(dst, &LevelModel{
            PositionLevels: v,
        })
    }

    return dst
}
