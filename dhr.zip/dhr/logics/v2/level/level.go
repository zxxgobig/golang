package v2_level

import (
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfwkit/common"

    "ifchange/dhr/models"
)

var LevelLogic *Level

func init() {
    LevelLogic = new(Level)
}

type (
    Level struct {
    }

    LevelModel struct {
        *models.PositionLevels
        IsDeleted common.Omitempty `json:"is_deleted,omitempty"`
        CreatedAt common.Omitempty `json:"created_at,omitempty"`
        UpdatedAt common.Omitempty `json:"updated_at,omitempty"`
    }
)

func (f *Level) ProjectCreateUsedList() (result *common.ListResult, err error) {
    levels, err := models.PositionLevelsModel.Search(db.Cond{
        "is_deleted": 0,
        "orderby":    "id asc",
    })
    if err != nil {
        return nil, err
    }

    result = &common.ListResult{
        List: ConvertLevelModels(levels),
    }

    return
}
