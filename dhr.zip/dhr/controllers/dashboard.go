package controllers

import (
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/dashboard"
)

type Dashboard struct {
	core.Controller
}

/**
 * @api {post} /dashboard/scene_stat 场景项目统计
 * @apiVersion 0.1.0
 * @apiGroup Dashboard
 * @apiDescription 首页场景项目统计
 *
 * @apiParam {String} session Session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0="
	}
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object[]} result.list 列表
 * @apiSuccess {Object} result.list.scene 场景/目标
 * @apiSuccess {Number} result.list.scene.id ID
 * @apiSuccess {String} result.list.scene.name 名称
 * @apiSuccess {String} result.list.scene.desc 描述
 * @apiSuccess {Number} result.list.project_count 项目数
 * @apiSuccess {Number} result.list.completion_rate 完成率
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"list": [
			{
				"scene": {
					"id": 1,
					"name": "人才发展",
					"desc": "为您找出员工群体和个人的关键能力缺口<br />使得您的培训与发展更有针对性"
				},
				"project_count": 8,
				"completion_rate": 75
			},
			{
				"scene": {
					"id": 2,
					"name": "任用晋升策略",
					"desc": "为您提供人员招聘、任用、晋升<br />等方面的决策参考"
				},
				"project_count": 8,
				"completion_rate": 75
			},
			{
				"scene": {
					"id": 3,
					"name": "识别高潜人才",
					"desc": "帮助您找到组织中最具有发展潜力<br />和成长潜力的员工"
				},
				"project_count": 0,
				"completion_rate": 0
			},
			{
				"scene": {
					"id": 4,
					"name": "形成分层级能力标准",
					"desc": "帮助您将关键岗位上的大批量员工按照能力进行分层<br />形成员工发展阶梯与分层级能力标准"
				},
				"project_count": 6,
				"completion_rate": 75
			}
		]
	}
*/
func (p *Dashboard) SceneStat(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
	}{}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	result, err := dashboard.SceneStat(curUser.CompanyId)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /dashboard/interview_list Y 轴列表
 * @apiVersion 0.1.0
 * @apiGroup Dashboard
 * @apiDescription 首页 Y 轴列表
 *
 * @apiParam {String} session Session
 * @apiParam {Number} scene_id 场景 ID
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
		"scene_id": 1
	}
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object[]} result.list 列表
 * @apiSuccess {Number} result.list.id ID
 * @apiSuccess {String} result.list.name 名称
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"list": [
			{
				"id": 0,
				"name": "综合能力"
			},
			{
				"id": 1,
				"name": "素质"
			},
			{
				"id": 3,
				"name": "专业知识技能"
			},
			{
				"id": 5,
				"name": "潜力"
			}
		]
	}
*/
func (p *Dashboard) InterviewList(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		SceneId int `json:"scene_id" validate:"gt=0"`
	}{}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	result, err := dashboard.InterviewList(curUser.CompanyId, params.SceneId)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /dashboard/distribution_stat 人才分布统计
 * @apiVersion 0.1.0
 * @apiGroup Dashboard
 * @apiDescription 首页人才分布统计
 *
 * @apiParam {String} session Session
 * @apiParam {Number} scene_id 场景 ID
 * @apiParam {Number} interview_id 测评 ID（0：综合能力）
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
		"scene_id": 1,
		"interview_id": 0
	}
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object[]} result.grid 九宫格
 * @apiSuccess {Number} result.grid.x X 坐标
 * @apiSuccess {Number} result.grid.y Y 坐标
 * @apiSuccess {Number} result.grid.staff_count 员工数
 * @apiSuccess {Object[]} result.structure 细分结构对比
 * @apiSuccess {Object} result.structure.project 项目
 * @apiSuccess {Number} result.structure.project.id ID
 * @apiSuccess {String} result.structure.project.name 名称
 * @apiSuccess {Object[]} result.structure.class 分类
 * @apiSuccess {String} result.structure.class.name 名称
 * @apiSuccess {Number} result.structure.class.percent 百分比
 * @apiSuccess {Object} result.collect 汇总分布
 * @apiSuccess {Object[]} result.collect.class 分类
 * @apiSuccess {String} result.collect.class.name 名称
 * @apiSuccess {Number} result.collect.class.percent 百分比
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"grid": [
			{
				"x": 1,
				"y": 3,
				"staff_count": 44
			},
			{
				"x": 2,
				"y": 3,
				"staff_count": 999
			},
			{
				"x": 3,
				"y": 3,
				"staff_count": 1
			},
			{
				"x": 1,
				"y": 2,
				"staff_count": 22
			},
			{
				"x": 2,
				"y": 2,
				"staff_count": 22
			},
			{
				"x": 3,
				"y": 2,
				"staff_count": 8
			},
			{
				"x": 1,
				"y": 1,
				"staff_count": 22
			},
			{
				"x": 2,
				"y": 1,
				"staff_count": 22
			},
			{
				"x": 3,
				"y": 1,
				"staff_count": 22
			}
		],
		"structure": [
			{
				"project": {
					"id": 1,
					"name": "识别高潜人才"
				},
				"class": [
					{
						"name": "优秀",
						"percent": 15
					},
					{
						"name": "中等",
						"percent": 35
					},
					{
						"name": "待改进",
						"percent": 40
					},
					{
						"name": "不胜任",
						"percent": 10
					}
				]
			}
		],
		"collect": {
			"class": [
				{
					"name": "优秀",
					"percent": 15
				},
				{
					"name": "中等",
					"percent": 35
				},
				{
					"name": "待改进",
					"percent": 40
				},
				{
					"name": "不胜任",
					"percent": 10
				}
			]
		}
	}
*/
func (p *Dashboard) DistributionStat(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		SceneId     int `json:"scene_id" validate:"gt=0"`
		InterviewID int `json:"interview_id" validate:"gte=0"`
	}{}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	result, err := dashboard.DistributionStat(curUser.CompanyId, params.SceneId, params.InterviewID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /dashboard/interview_score_distribution_stat 测评得分分布
 * @apiVersion 0.1.0
 * @apiGroup Dashboard
 * @apiDescription 测评得分分布
 *
 * @apiParam {String} session Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} interview_id 测评 ID（1：素质, 3: 专业知识技能）
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
		"project_id": 1,
		"interview_id": 0
	}
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object} result.structure.project 项目
 * @apiSuccess {Number} result.structure.project.id ID
 * @apiSuccess {String} result.structure.project.name 名称
 * @apiSuccess {Object[]} result.structure.class 分类
 * @apiSuccess {String} result.structure.class.name 名称
 * @apiSuccess {Number} result.structure.class.percent 百分比
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"structure": [
			{
				"project": {
					"id": 1,
					"name": "识别高潜人才"
				},
				"class": [
					{
						"name": "优秀",
						"percent": 15
					},
					{
						"name": "中等",
						"percent": 35
					},
					{
						"name": "待改进",
						"percent": 40
					},
					{
						"name": "不胜任",
						"percent": 10
					}
				]
			}
		]
	}
*/
func (p *Dashboard) InterviewScoreDistributionStat(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID   int `json:"project_Id" validate:"gt=0"`
		InterviewID int `json:"interview_id" validate:"gte=0"`
	}{}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	result, err := dashboard.InterviewScoreDistributionStat(curUser.CompanyId, params.ProjectID, params.InterviewID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}
