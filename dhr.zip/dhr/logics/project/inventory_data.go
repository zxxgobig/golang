package project

import (
	"context"
	"fmt"
	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/stat"
	"ifchange/dhr/models"
	"time"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/hfwkit/grpc/client"
	"gitlab.ifchange.com/bot/logger"
	pb "gitlab.ifchange.com/bot/proto/career_assessment"
	"gitlab.ifchange.com/bot/proto/dhr_potential"
	"google.golang.org/grpc"
	"xorm.io/builder"
)

// 整合14个测评盘点数据

const (
	InterviewAll                     = iota
	InterviewBEI                     // 素质
	InterviewPersonalityEval         // 性格
	InterviewSkill                   // 技能
	InterviewKnowledge               // 知识
	InterviewPotential               // 潜力
	InterviewWorkValues              // 驱动力
	InterviewKeyExperience           // 关键经历
	InterviewEmotionalIntelligence   // 情绪智力测评
	InterviewCriticalThinking        // 批判思维测评
	InterviewPracticalIntelligence   // 管理实践能力测评
	InterviewOccupationalPersonality // 职业人格测评
	InterviewPersonalityDisorder     // 性格风险测评
	InterviewLeadershipStyle         // 领导风格测评
	InterviewOrgCommitment           // 组织忠诚度测评
)

func GetInventoryData(projectId int, interviewIds []int) (resp *InventoryData, err error) {
	defer func() {
		if err != nil {
			logger.Errorf("GetInventoryData failed. err:%v", err)
		}
		err = nil
	}()
	project, err := models.ProjectsModel.SearchOne(db.Cond{"where": fmt.Sprintf("id = %v and is_deleted = 0", projectId)}) //  and status = 3
	if err != nil {
		return nil, err
	}
	if project == nil {
		return nil, fmt.Errorf("projectId:%v empty", projectId)
	}

	interviewIds, err = processProjectInterviewConfigs(projectId, interviewIds)
	if err != nil {
		return nil, err
	}

	where := builder.NewCond()
	where = where.Or(
		builder.Eq{"status": 2}.
			And(builder.In("interview_id", interviewIds)). // 有限期是最近六个月内的
			And(builder.Gt{"updated_at": libraries.FormatDateTime(time.Now().AddDate(0, -6, 0))}),
	)

	staffsInterviews, err := models.StaffsInterviewsModel.Search(db.Cond{
		"where":      libraries.MustToBoundSQL(where),
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}
	staffIds := make([]int, 0, len(staffsInterviews))
	for _, each := range staffsInterviews {
		staffIds = append(staffIds, each.StaffId)
	}

	// 获取员工姓名
	staffs, err := dhr_staff.ListStaffByIds(nil, project.CompanyId, staffIds, true, nil)
	if err != nil {
		return nil, err
	}
	staffMap := make(map[int]*dhr_staff.Staff)
	for _, staff := range staffs {
		staffMap[staff.Id] = staff
	}

	// 获取项目下员工
	projectStaffIds, err := getStaffIdsFromDB(projectId)
	if err != nil {
		return nil, err
	}
	projectStaffMap := make(map[int]struct{})
	for _, id := range projectStaffIds {
		projectStaffMap[id] = struct{}{}
	}

	inventories := make([]*Inventory, 0)
	for _, each := range staffsInterviews {
		inventory := new(Inventory)
		uuid := each.Uuid

		_, ok := projectStaffMap[each.StaffId]
		if !ok && each.InterviewId != InterviewSkill {
			continue
		}
		switch each.InterviewId {
		case InterviewBEI:
			inventory, err = qualityInterviewHandler(each.CompanyId, each.ProjectId, each.StaffId, 0)
			if err != nil {
				logger.Errorf("get qualityInterviewHandler failed. err:%v", err)
				continue
			}

		case InterviewPersonalityEval:
			inventory, err = personalityEvalInterviewHandler(each.CompanyId, each.ProjectId, each.StaffId, 0)
			if err != nil {
				logger.Errorf("get personalityEvalInterviewHandler failed. err:%v", err)
				continue
			}

		case InterviewSkill:
			inventory, err = professionalSkillInterviewHandler(each.CompanyId, each.ProjectId, each.StaffId, 0)
			if err != nil {
				logger.Errorf("get professionalSkillInterviewHandler failed. err:%v", err)
				continue
			}

		case InterviewKnowledge: // 没有专业知识这个测评

		case InterviewPotential: // 处理潜力 - 5
			inventory, err = potentialInterviewHandler(uuid)
			if err != nil {
				logger.Errorf("get potentialInterviewHandler failed. err:%v", err)
				continue
			}

		case InterviewWorkValues: // 驱动力 - 6
			inventory, err = workValueInterviewHandler(uuid)
			if err != nil {
				logger.Errorf("get keyExperienceInterviewHandler failed. err:%v", err)
				continue
			}

		case InterviewKeyExperience: // 关键经历 - 7
			inventory, err = keyExperienceInterviewHandler(uuid)
			if err != nil {
				logger.Errorf("get keyExperienceInterviewHandler failed. err:%v", err)
				continue
			}

		case InterviewEmotionalIntelligence, InterviewCriticalThinking, InterviewPracticalIntelligence,
			InterviewOccupationalPersonality, InterviewPersonalityDisorder, InterviewLeadershipStyle,
			InterviewOrgCommitment:
			inventory, err = thirdInterviewHandler(uuid)
			if err != nil {
				logger.Errorf("get thirdInterviewHandler failed. err:%v", err)
				continue
			}

		}
		if staff, ok := staffMap[each.StaffId]; ok { // 员工存在的时候才有名字
			inventory.StaffNo = staff.No
			inventory.StaffName = staff.Name
			if each.InterviewId == InterviewSkill || each.InterviewId == InterviewKnowledge {
				// 这个时候应该使用 staff_ids 里的staff_id
				for _, subStaffId := range each.StaffIds {
					if subStaff, ok := staffMap[subStaffId]; ok {
						inventory.StaffNo = subStaff.No
						inventory.StaffName = subStaff.Name
						break
					}
				}
			}
		}
		inventory.InterviewId = each.InterviewId
		inventory.InterviewName = InterviewId2Name[each.InterviewId]
		inventory.FinishTime = each.UpdatedAt.Format("2006-01-02 15:04:05")
		inventories = append(inventories, inventory)
	}

	inventoryData := new(InventoryData)
	inventoryData.Inventories = inventories
	inventoryData.ProjectId = projectId
	return inventoryData, nil
}

// 获取素质结果, reportId 传0 代表当前最新的
func qualityInterviewHandler(companyId, projectId, staffId, reportId int) (*Inventory, error) {
	results, err := stat.Quality(companyId, projectId, staffId)
	if err != nil {
		return nil, err
	}
	if results == nil {
		return nil, fmt.Errorf("qualityInterview results is nil")
	}
	logger.Infof("quality_results:%v", results)
	resp := new(Inventory)
	for _, each := range results.Quality.Dimension {
		resp.FirstList = append(resp.FirstList, &FirstLevel{
			Name:    each.Name,
			Score:   each.Score,
			Explain: each.Desc,
		})
	}
	return resp, nil
}

// 获取性格测评数据
func personalityEvalInterviewHandler(companyId, projectId, staffId, reportId int) (*Inventory, error) {
	results, err := stat.GetStaffInterviewData(companyId, projectId, staffId, reportId, interview.Personality)
	if err != nil {
		return nil, err
	}
	if results == nil {
		return nil, fmt.Errorf("personalityEvalInterview results is nil")
	}
	logger.Infof("personalityEval_results:%v and PersonalityEval:%v", results, results.Data)
	resp := new(Inventory)
	for _, each := range results.Data.Dimension {
		resp.FirstList = append(resp.FirstList, &FirstLevel{
			Name:    each.Name,
			Score:   each.Score,
			Explain: each.Desc,
		})
	}
	return resp, nil
}

// 获取专业技能测评数据
func professionalSkillInterviewHandler(companyId, projectId, staffId, reportId int) (*Inventory, error) {
	results, err := stat.ProfessionalSkills(companyId, projectId, staffId)
	if err != nil {
		return nil, err
	}
	if results == nil {
		return nil, fmt.Errorf("professionalSkill results is nil")
	}
	logger.Infof("professionalSkill_results:%v", results)
	resp := new(Inventory)
	for _, each := range results.ProfessionalSkills.Dimension {
		resp.FirstList = append(resp.FirstList, &FirstLevel{
			Name:    each.Name,
			Score:   each.Score,
			Explain: each.Desc,
		})
	}
	return resp, nil
}

// dhr_potential结果处理
func potentialInterviewHandler(uuid string) (*Inventory, error) {
	p := api.NewPost("", "")
	p.P = struct {
		UniqueId string `json:"unique_id"`
	}{
		UniqueId: uuid,
	}

	result := make([]*dhr_potential.PotentialResult, 0)
	err := api.SimpleCurl(nil, config.AppConfig.Custom["DhrPotential"]+"/index/potential_results", p, &result)
	if err != nil {
		return nil, err
	}

	logger.Infof("potential_results:%v", result)
	resp := new(Inventory)
	for _, each := range result {
		var (
			id    = int(each.AxisId)
			score = int(each.AxisLevel)
		)

		resp.FirstList = append(resp.FirstList, &FirstLevel{
			Name:    each.AxisName,
			Score:   float64(each.AxisLevel),
			Explain: PotentialDescriptions[id][score],
		})
	}
	return resp, nil
}

// 驱动力
func workValueInterviewHandler(uuid string) (resp *Inventory, err error) {
	defer func() {
		if err != nil {
			logger.Errorf("workValueInterviewHandler failed. err:%v", err)
		}
	}()

	params := pb.WorkValuesResultsRequest{
		UniqueId: uuid,
	}
	ret, err := client.Do(nil, config.GetGrpcServers().CareerAssessment,
		func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
			res, err := pb.NewWorkValuesClient(conn).WorkValuesResults(ctx, &params)
			if err != nil {
				return nil, err
			}
			if res.GetErrNo() != 0 {
				return nil, err
			}
			return res.GetResults(), nil
		}, 5*time.Second)
	if err != nil {
		return nil, err
	}

	result, ok := ret.([]*pb.WorkValuesResults)
	if !ok {
		return nil, fmt.Errorf("ret:%#v convert WorkValuesResultsResponse failed", ret)
	}

	logger.Infof("workValueInterview result:%v", result)
	resp = new(Inventory)
	for _, each := range result {
		resp.FirstList = append(resp.FirstList, &FirstLevel{
			Name:    each.Values,
			Explain: WorkValueDescriptions[each.Id].WorkValuesDescribe,
		})
	}

	return resp, nil
}

//  关键经历
func keyExperienceInterviewHandler(uuid string) (resp *Inventory, err error) {
	defer func() {
		if err != nil {
			logger.Errorf("keyExperienceInterviewHandler failed. err:%v", err)
		}
	}()

	params := pb.KeyExperienceResultsRequest{
		UniqueId: uuid,
	}
	ret, err := client.Do(nil, config.GetGrpcServers().CareerAssessment,
		func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
			res, err := pb.NewKeyExperienceClient(conn).KeyExperienceResults(ctx, &params)
			if err != nil {
				return nil, err
			}
			if res.GetErrNo() != 0 {
				return nil, err
			}
			return res.GetResults(), nil
		}, 5*time.Second)
	if err != nil {
		return nil, err
	}

	result, ok := ret.([]*pb.Result)
	if !ok {
		return nil, fmt.Errorf("ret:%v convert KeyExperienceResultsResponse failed", ret)
	}
	logger.Infof("keyExperienceInterview result:%v", result)
	resp = new(Inventory)
	for _, ret := range result {
		for _, each := range ret.Options {
			resp.FirstList = append(resp.FirstList, &FirstLevel{
				Name:        each.Name,
				Explain:     KeyExperienceDescriptions[each.Id].Description,
				SelfExplain: each.Story,
			})
		}
	}

	return resp, nil
}

// third_evaluation结果处理
func thirdInterviewHandler(uuid string) (*Inventory, error) {
	p := api.NewPost("", "")
	p.P = struct {
		Uuid string `json:"uuid"`
	}{
		Uuid: uuid,
	}

	result := new(ThirdInterviewResult)
	err := api.SimpleCurl(nil, config.AppConfig.Custom["ThirdEvaluation"]+"export_report", p, &result)
	if err != nil {
		return nil, err
	}

	resp := new(Inventory)
	resp.InterviewId = result.Details.InterviewId
	resp.InterviewName = result.Details.InterviewName
	resp.FinishTime = result.Details.FinishTime
	for _, each := range result.Details.Axis2 {
		secondLevels := make([]*SecondLevel, 0)
		// 目前就8、11有二级纬度
		if resp.InterviewId == InterviewEmotionalIntelligence || resp.InterviewId == InterviewOccupationalPersonality {
			for _, child := range each.Data {
				secondLevels = append(secondLevels, &SecondLevel{
					Name:    child.Name,
					Score:   int(child.Score),
					Explain: child.Desc,
				})
			}
		}

		resp.FirstList = append(resp.FirstList, &FirstLevel{
			Name:       each.ParentName,
			Score:      each.ParentScore,
			SecondList: secondLevels,
		})
	}

	return resp, nil
}

func getStaffIdsFromDB(projectId int) ([]int, error) {
	staffs, err := models.ProjectsStaffsModel.Search(db.Cond{
		"project_id": projectId,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}

	if len(staffs) == 0 {
		return nil, fmt.Errorf("projectId:%v no staffs", projectId)
	}

	staffIds := make([]int, 0)
	for _, s := range staffs {
		staffIds = append(staffIds, s.StaffId)
	}

	return staffIds, nil
}

func processProjectInterviewConfigs(projectId int, interviewIds []int) (resp []int, err error) {
	configs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"where":   fmt.Sprintf("project_id = %v AND is_deleted = 0", projectId),
		"is_show": models.SHOW,
	})
	if err != nil {
		return
	}

	interviewMap := make(map[int]struct{})
	for _, each := range configs {
		interviewMap[each.InterviewId] = struct{}{}
	}
	for _, id := range interviewIds {
		if _, ok := interviewMap[id]; ok {
			resp = append(resp, id)
		}
	}
	if len(interviewIds) == 0 {
		for _, each := range configs {
			resp = append(resp, each.InterviewId)
		}
	}

	return
}
