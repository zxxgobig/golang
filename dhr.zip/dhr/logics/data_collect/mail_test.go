package data_collect

import (
	"fmt"
	"gitlab.ifchange.com/bot/hfw/db"
	"ifchange/dhr/models"
	"testing"
	"time"
)

func TestMailSearchOne(t *testing.T) {
	mailResend, err := models.MailResendModel.SearchOne(db.Cond{
		"plan_id": 187,
	})
	if err != nil {
		t.Fatal(err)
	}
	t.Log(mailResend.PlanId)
}

func TestMailInsert(t *testing.T) {
	mailResend := &models.MailResend{}
	mailResend.Status = 2
	mailResend.ExecTime = time.Now()
	mailResend.PlanId = 100
	_, err := models.MailResendModel.Insert(mailResend)
	if err != nil {
		t.Fatal(err)
	}
}

func TestMailSearchBySql(t *testing.T) {
	interviews, _ := models.InterviewsModel.Search(db.Cond{
		"sql": fmt.Sprint("SELECT id,name,enname FROM interviews"),
	})
	for _, v := range interviews {
		t.Log(v.Id, v.Name, v.Enname)
	}
}
