package stat

import (
	"encoding/json"
	"fmt"
	"math"
	"sort"
	"strconv"
	"time"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/logger"
	commonpb "gitlab.ifchange.com/bot/proto/common"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"

	"ifchange/dhr/logics/common"
	"ifchange/dhr/logics/lambda"
	"ifchange/dhr/models"
)

type SubInterviewId = int
type Score = float64

type ProgressResult struct {
	Total                    int `json:"total"`
	Finish                   int `json:"finish"`
	FinishLastAdd            int `json:"finish_last_add"`
	StarStaff                int `json:"star_staff"`
	StarStaffLastAdd         int `json:"star_staff_last_add"`
	InefficiencyStaff        int `json:"inefficiency_staff"`
	InefficiencyStaffLastAdd int `json:"inefficiency_staff_last_add"`
}

type InventoryResultItem struct {
	Name           string          `json:"name"`
	List           []string        `json:"list"`
	PositionLevels []PositionLevel `json:"position_levels,omitempty"`
}

type PositionLevel struct {
	Name      string               `json:"name"`
	Count     int                  `json:"count"`
	StaffList []PositionLevelStaff `json:"staff_list,omitempty"`
	Desc      []string             `json:"desc"`
}

type PositionLevelStaff struct {
	ID             int    `json:"id"` // 员工ID
	DistributionID int    `json:"distribution_id"`
	Name           string `json:"name"`       // 员工姓名
	Department     string `json:"department"` // 部门名称
	Status         int    `json:"status"`     // 员工状态
}

type PositionLevelAdvice struct {
	Desc           string          `json:"desc"`
	PositionLevels []PositionLevel `json:"position_levels"`
}

type ExcellentCharacterResult struct {
	MainDesc   string      `json:"main_desc"`
	Axes       []Axis      `json:"axes"`
	ExtraDesc  string      `json:"extra_desc"`
	Characters []Character `json:"characters"`
}

type Axis struct {
	ID   int    `json:"id,omitempty"`
	Name string `json:"name"`
	Desc string `json:"desc"`
}

type Character struct {
	ID             int     `json:"id"`
	Name           string  `json:"name"`
	Type           int     `json:"type"`
	ExcellentScore float64 `json:"excellent_score,omitempty"`
	AvgScore       float64 `json:"avg_score,omitempty"`
}

type InterviewData struct {
	Avg  float64  `json:"avg"` // 总的平局分
	Data EvalAxes `json:"data"`
}

type DistributionReportResult map[string]interface{}

type (
	Condition struct {
		Order  []*OrderByParams  `json:"order"`
		Filter []*FilterByParams `json:"filter"`
	}

	OrderByParams struct {
		Key   string `json:"key"`
		Order int    `json:"order"`
	}

	FilterByParams struct {
		Key    string   `json:"key"`
		Values []string `json:"values"`
	}

	_InventoryDistributionListResult struct {
		Filter *_InventoryDistributionListFilter `json:"filter"`
		Total  int64                             `json:"total"`
		List   []*_InventoryDistributionListItem `json:"list"`
	}

	_InventoryDistributionListItem struct {
		ID                          int          `json:"id"`
		Name                        string       `json:"name"`
		Sex                         int          `json:"sex"`
		Status                      int          `json:"status"`
		Department                  string       `json:"department"`
		Position                    string       `json:"position"`
		Result                      string       `json:"result"`
		ProfessionalSkillsScore     float64      `json:"professional_skills_score"`
		ProfessionalSkillsScoreDesc string       `json:"professional_skills_score_desc"`
		PotentialScore              float64      `json:"potential_score"`
		PotentialScoreDesc          string       `json:"potential_score_desc"`
		QualityScore                float64      `json:"quality_score"`
		QualityScoreDesc            string       `json:"quality_score_desc"`
		PerformanceLevel            string       `json:"performance_level"`
		PerformanceLevelStandard    lambda.Level `json:"performance_level_standard"`
		Personalities               []string     `json:"personalities"`
	}

	_InventoryDistributionListFilter struct {
		Result                  []*_InventoryDistributionListFilterItem `json:"result"`
		ProfessionalSkillsScore []*_InventoryDistributionListFilterItem `json:"professional_skills_score"`
		PotentialScore          []*_InventoryDistributionListFilterItem `json:"potential_score"`
		QualityScore            []*_InventoryDistributionListFilterItem `json:"quality_score"`
		PerformanceLevel        []*_InventoryDistributionListFilterItem `json:"performance_level"`
		Personalities           []*_InventoryDistributionListFilterItem `json:"personalities"`
	}

	_InventoryDistributionListFilterItem struct {
		Key   string `json:"key"`
		Value string `json:"value"`
		Desc  string `json:"desc"`
	}
)

type AxisStat struct {
	ID    int
	Total float64
	Count int
}

func getProjectProfessionalSkills(companyID, projectID int) (*ResponseData, error) {
	result, err := client.GetGroupInterviewData(nil, &pb.GroupInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    pb.StatType_PROJECT,
		Id:          int64(projectID),
		InterviewId: 3,
	})
	if err != nil {
		return nil, err
	}
	if result == nil || result.Axes == nil {
		return nil, nil
	}

	data := make(EvalAxes, 0)
	for _, a := range result.Axes {
		data = append(data, EvalAxis{
			ID:             int(a.Id),
			Name:           a.Name,
			Score:          a.Score,
			ExcellentScore: a.ExcellentScore,
		})
	}

	return getStatFormResponseData(data, getStatOption(interview.Skill, result.ExcellentScore)), nil
}

func getProjectPotential(companyID, projectID int) (EvalAxes, error) {
	result, err := client.GetGroupInterviewData(nil, &pb.GroupInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    pb.StatType_PROJECT,
		Id:          int64(projectID),
		InterviewId: 5,
	})
	if err != nil {
		return nil, err
	}
	if result == nil || result.Axes == nil {
		return nil, nil
	}

	data := make(EvalAxes, 0)
	for _, a := range result.Axes {
		data = append(data, EvalAxis{
			ID:    int(a.Id),
			Name:  a.Name,
			Score: a.Score,
			Total: 5,
		})
	}

	return data, nil
}

func getProjectQuality(companyID, projectID int) (*ResponseData, error) {
	result, err := client.GetGroupInterviewData(nil, &pb.GroupInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    pb.StatType_PROJECT,
		Id:          int64(projectID),
		InterviewId: 1,
	})
	if err != nil {
		return nil, err
	}
	if result == nil || result.Axes == nil {
		return nil, nil
	}

	data := make(EvalAxes, 0)
	for _, a := range result.Axes {
		data = append(data, EvalAxis{
			ID:             int(a.Id),
			Name:           a.Name,
			Score:          a.Score,
			ExcellentScore: a.ExcellentScore,
		})
	}

	return getStatFormResponseData(data, getStatOption(interview.Bei, result.ExcellentScore)), nil
}

func ProjectPersonalityEval(companyID, projectID int) (*PersonalityResponseData, error) {
	result, err := client.GetGroupPersonalityStat(nil, &pb.GroupPersonalityStatRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_PROJECT,
		Id:        int64(projectID),
	})
	if err != nil {
		return nil, err
	}
	if result == nil {
		return nil, nil
	}

	rsp := new(PersonalityResponseData)
	err = json.Unmarshal(result, &rsp)
	if err != nil {
		return nil, err
	}
	// sort.Sort(rsp.Dimension)

	return rsp, nil
}

type ProjectPerformanceInterviewResult struct {
	Level       string   `json:"level"`
	Percent     float64  `json:"percent"`
	Labels      []string `json:"labels"`
	ID          int      `json:"-"`
	Number      int64    `json:"number"`
	LabelResult []*Label `json:"label_result"`
}

type Label struct {
	Title string   `json:"title"`
	List  []string `json:"list"`
}

func getProjectPerformance(companyID, projectID int) ([]ProjectPerformanceInterviewResult, error) {
	result, err := client.GetGroupPerformanceData(nil, &pb.GroupPerformanceDataRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_PROJECT,
		Id:        int64(projectID),
	})
	if err != nil {
		return nil, err
	}
	if result == nil {
		return nil, nil
	}

	data := make([]ProjectPerformanceInterviewResult, 0)
	for _, perf := range result {
		labelRet := make([]*Label, 0, 2)
		labelRet = append(labelRet, &Label{
			Title: "正向",
			List:  perf.TagMap[1].Labels, // 使用 1 2 是因为数据源只配置了正向 and 负向
		}, &Label{
			Title: "负向",
			List:  perf.TagMap[2].Labels,
		})

		data = append(data, ProjectPerformanceInterviewResult{
			ID:          int(perf.LevelStandard),
			Percent:     perf.Percent,
			Labels:      perf.Labels,
			Level:       performanceLevelStandardMap[int(perf.LevelStandard)],
			Number:      perf.Number,
			LabelResult: labelRet,
		})
	}

	return data, nil
}

func ExcellentCharacter(companyID, projectID int) (result *ExcellentCharacterResult, err error) {
	data, err := client.GetGroupExcellentCharacter(nil, &pb.GroupExcellentCharacterRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_PROJECT,
		Id:        int64(projectID),
	})
	if err != nil {
		return nil, err
	}

	logger.Debugf("hahha get getExcellentCharacter data: %v", string(data))

	err = json.Unmarshal(data, &result)
	if err != nil {
		return nil, err
	}

	return result, nil
}

func Result(companyID, projectID, sceneID int) (result []InventoryResultItem, err error) {
	data, err := client.GetGroupInventoryResult(nil, &pb.GroupInventoryResultRequest{
		CompanyId: int64(companyID),
		StatType:  pb.StatType_PROJECT,
		Id:        int64(projectID),
		SceneId:   int64(sceneID),
	})

	if err != nil {
		return nil, err
	}
	if len(data) == 0 || string(data) == "" {
		return nil, nil
	}

	logger.Debugf("dhr_stat get result data: %v", string(data))
	err = json.Unmarshal(data, &result)
	if err != nil {
		return nil, err
	}

	return result, nil
}

// 项目详情-关键经历 7
func KeyExperience(companyId, projectId int64) (*common.KeyExperience, error) {
	req := &pb.GroupInterviewDataRequest{
		CompanyId:   companyId,
		StatType:    pb.StatType_PROJECT,
		Id:          projectId,
		InterviewId: 7, // 关键经历
	}
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("happen panic:%v\n", err)
		}
	}()

	result, err := client.GetGroupInterviewData(nil, req)
	if err != nil {
		logger.Errorf("call dhr_stat.GetGroupInterviewData failed. err: [%v], req: [%v]", err, req)
		return nil, err
	}

	if result == nil || len(result.Axes) == 0 || result.Avg == 0 {
		logger.Errorf("result:%+v empty", result)
		return nil, nil
	}

	// 查询config文件
	subItemIdMap, err := configFunc(projectId, 7)
	if err != nil {
		logger.Errorf("get interviewConfig failed. err:%v", err)
		return nil, err
	}

	// 子维度名称，number对应每个子维度的人数
	axesMap := make(map[string]*Axes)
	for _, each := range result.Axes {
		if _, ok := axesMap[each.Name]; ok {
			axesMap[each.Name].Number++
			continue
		}
		axesMap[each.Name] = &Axes{Number: 1, SubItemId: each.Id}
	}

	var manageList, businessList []*common.SubKeyExperience
	for name, axis := range axesMap {
		// 包含在config里的itemId是重点关注
		var focus bool
		if _, ok := subItemIdMap[int(axis.SubItemId)]; ok {
			focus = true
		}
		frac := round(float64(axis.Number)/result.Avg, 3)

		// 子纬度ID in (1-7) 都是有管理经历的；其它的都是业务经历的
		if axis.SubItemId >= 1 && axis.SubItemId <= 7 {
			manageList = append(manageList, &common.SubKeyExperience{
				Id:       axis.SubItemId,
				Name:     name,
				Number:   axis.Number,
				Focus:    focus,
				Fraction: frac,
			})
		} else {
			businessList = append(businessList, &common.SubKeyExperience{
				Id:       axis.SubItemId,
				Name:     name,
				Number:   axis.Number,
				Focus:    focus,
				Fraction: frac,
			})
		}

	}

	sort.Slice(manageList, func(i, j int) bool { // 从小到大
		return manageList[i].Id < manageList[j].Id
	})
	sort.Slice(businessList, func(i, j int) bool { // 从小到大
		return businessList[i].Id < businessList[j].Id
	})

	keyExperience := new(common.KeyExperience)
	project, err := projectFunc(projectId)
	if err != nil {
		logger.Errorf("get project failed. err:%v", err)
		return nil, nil
	}
	if project.IsManagerPosition == 1 {
		keyExperience.Type = "manage_list"
	} else {
		keyExperience.Type = "business_list"
	}
	keyExperience.ManageList = manageList
	keyExperience.BusinessList = businessList
	return keyExperience, nil
}

// 项目详情-驱动力 6
func JobChoiceValue(companyId, projectId int64) (*common.JobChoiceValue, error) {
	req := &pb.GroupInterviewDataRequest{
		CompanyId:   companyId,
		StatType:    pb.StatType_PROJECT,
		Id:          projectId,
		InterviewId: 6, // 驱动力
	}

	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("happen panic:%v\n", err)
		}
	}()

	result, err := client.GetGroupInterviewData(nil, req)
	if err != nil {
		logger.Errorf("call dhr_stat.GetGroupInterviewData failed. err: [%v], req: [%v]", err, req)
	}

	if result == nil || len(result.Axes) == 0 || result.Avg == 0 {
		logger.Errorf("result:%+v empty", result)
		return nil, nil
	}

	// 查询config文件
	subItemIdMap, err := configFunc(projectId, 6)
	if err != nil {
		logger.Errorf("get interviewConfig failed. err:%v", err)
		return nil, err
	}

	// 子维度名称
	axesMap := make(map[string]*Axes)
	for _, each := range result.Axes {
		if _, ok := axesMap[each.Name]; ok {
			axesMap[each.Name].Number++
			continue
		}
		axesMap[each.Name] = &Axes{Number: 1, SubItemId: each.Id}
	}

	var list []*common.SubJobChoiceValue
	for name, axis := range axesMap {
		// 包含在config里的itemId是重点关注
		var focus bool
		if _, ok := subItemIdMap[int(axis.SubItemId)]; ok {
			focus = true
		}
		frac := round(float64(axis.Number)/result.Avg, 3)
		ratio := round(float64(axis.Number)/float64(len(result.Axes)), 3)
		list = append(list, &common.SubJobChoiceValue{
			Name:      name,
			Number:    axis.Number,
			Focus:     focus,
			Fraction:  frac,
			AreaRatio: ratio,
		})
	}

	jobChoiceValue := new(common.JobChoiceValue)
	jobChoiceValue.List = list
	return jobChoiceValue, nil
}

type Axes struct {
	Number    int
	SubItemId int64
}

// 四舍五入
func round(f float64, n int) float64 {
	pow := math.Pow10(n)
	return math.Trunc(f*pow+0.5) / pow
}

// 获取配置子纬度ID - 用于判断是否是focus
func configFunc(projectId, interviewId int64) (map[int]struct{}, error) {
	cond := db.Cond{
		"project_id":   projectId,
		"interview_id": interviewId,
		"is_deleted":   0,
		"is_show":      models.SHOW,
	}
	interviewConfig, err := models.ProjectsInterviewsConfigsModel.SearchOne(cond)
	if err != nil {
		return nil, err
	}

	type ConfigSubItem struct {
		Id     int    `json:"id"`
		EnName string `json:"enname"`
		Name   string `json:"name"`
	}
	var cfg []*ConfigSubItem
	_ = json.Unmarshal([]byte(interviewConfig.InterviewConfigs), &cfg)

	subItemIdMap := make(map[int]struct{})
	for _, each := range cfg {
		subItemIdMap[each.Id] = struct{}{}
	}
	return subItemIdMap, nil
}

// 获取Project
func projectFunc(projectId int64) (*models.Projects, error) {
	cond := db.Cond{
		"id":         projectId,
		"is_deleted": 0,
	}
	project, err := models.ProjectsModel.SearchOne(cond)
	if err != nil {
		return nil, err
	}
	return project, nil
}

func ProjectProfessionalSkills(companyID, projectID, reportID int) (*ProfessionalSkillsResult, error) {
	r, err := getProjectProfessionalSkills(companyID, projectID)
	if err != nil {
		return nil, err
	}

	return &ProfessionalSkillsResult{
		ProfessionalSkills: r,
	}, nil
}

func ProjectPotential(companyID, projectID, reportID int) (*PotentialResult, error) {
	r, err := getProjectPotential(companyID, projectID)
	if err != nil {
		return nil, err
	}

	return &PotentialResult{
		Potential: r,
	}, nil
}

func ProjectQuality(companyID, projectID, reportID int) (*QualityResult, error) {
	r, err := getProjectQuality(companyID, projectID)
	if err != nil {
		return nil, err
	}

	return &QualityResult{
		Quality: r,
	}, nil
}

type Performance1 struct {
	Props []ProjectPerformanceInterviewResult `json:"props"`
}
type GroupPerformanceResult struct {
	Performance *Performance1 `json:"performance"`
}

func ProjectPerformance(companyID, projectID, reportID int) (*GroupPerformanceResult, error) {
	r, err := getProjectPerformance(companyID, projectID)
	if err != nil {
		return nil, err
	}

	return &GroupPerformanceResult{
		Performance: &Performance1{
			Props: r,
		},
	}, nil
}

type InventoryOverView struct {
	InterviewID int         `json:"interview_id"`
	Data        interface{} `json:"data"`
}

// 人才盘点分布盘点结果概览
func GroupInventoryOverView(companyID int, projectID, reportID int) (interface{}, error) {
	reportID = detrick(reportID)
	result := new(InventoryOverView)
	project, err := models.ProjectsModel.SearchOne(db.Cond{
		"id": projectID,
	})
	if err != nil {
		return nil, fmt.Errorf("this project is not exist error: %v", err)
	}
	if project == nil {
		return nil, fmt.Errorf("this project is not exist error: %v", err)
	}
	var interviewID = 0
	if project.SceneId == 3 {
		interviewID = 5
	}
	result.InterviewID = interviewID
	data, err := client.GetGroupInventoryOverView(nil, &pb.GroupInventoryOverViewRequest{
		CompanyId:   int64(companyID),
		ProjectId:   int64(projectID),
		ReportId:    int64(reportID),
		InterviewId: int64(interviewID),
	})
	if err != nil {
		return nil, err
	}
	if len(data) == 0 {
		return result, nil
	}
	err = json.Unmarshal(data, &result.Data)
	if err != nil {
		return nil, err
	}
	return result, nil
}

// 人才盘点分布九宫格
func GroupInventoryDistribution(companyID int, projectID, reportID, interviewID int) (result *common.ListResult, err error) {
	reportID = detrick(reportID)
	result = new(common.ListResult)

	data, err := client.GetGroupInventoryDistribution(nil, &pb.GroupInventoryDistributionRequest{
		CompanyId:   int64(companyID),
		ProjectId:   int64(projectID),
		ReportId:    int64(reportID),
		InterviewId: int64(interviewID),
	})
	if err != nil {
		return nil, err
	}
	if len(data) == 0 {
		return result, nil
	}

	err = json.Unmarshal(data, &result.List)
	if err != nil {
		return nil, err
	}

	// Add can adjust filter
	canAdjust, err := isProjectDistributionIsCanAdjust(projectID, reportID)
	if err != nil {
		return nil, err
	}
	result.CanAdjust = canAdjust

	return result, nil
}

func isProjectDistributionIsCanAdjust(projectID, reportID int) (bool, error) {
	report := new(models.ProjectsDistributions)
	_, err := models.ProjectsDistributionsModel.Dao.SearchOne(report, db.Cond{
		"is_deleted": 0,
		"project_id": projectID,
		"orderby":    "created_at desc",
	})

	if err != nil {
		return false, fmt.Errorf("isProjectDistributionIsCanAdjust models.ProjectsReportsModel.Search error: %v", err)
	}

	// 没有历史调整记录，看采集计划是否完成
	switch report.Id {
	case 0:
		plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
			"project_id": projectID,
		})

		if err != nil {
			return false, fmt.Errorf("isProjectDistributionIsCanAdjust models.DataCollectPlansModel.SearchOne error: %v", err)
		}
		if plan == nil {
			return false, nil
		}

		if plan.Status == 3 || plan.Status == 5 {
			return true, nil
		}

		if plan.EndTime.Before(time.Now()) {
			return true, nil
		}
	default:
		if report.Id == reportID {
			return true, nil
		}
	}
	return false, nil
}

// 人才盘点分布列表
func InventoryDistributionList(companyID int, projectID, interviewID, reportID int, orderBy *OrderByParams,
	filterBy []*FilterByParams, search string, pageNum, pageSize int) (result *_InventoryDistributionListResult, err error) {
	reportID = detrick(reportID)
	result = new(_InventoryDistributionListResult)

	req := &pb.GroupInventoryDistributionListRequest{
		CompanyId:   int64(companyID),
		ProjectId:   int64(projectID),
		InterviewId: int64(interviewID),
		ReportId:    int64(reportID),
		Keyword:     search,
		Page: &commonpb.PageParam{
			Num:  int32(pageNum),
			Size: int32(pageSize),
		},
	}

	// Step.Filter
	var filter []*commonpb.CondValuesParam
	for _, v := range filterBy {
		if v.Key == "" || len(v.Values) == 0 {
			continue
		}
		filter = append(filter, &commonpb.CondValuesParam{Key: v.Key, Values: v.Values})
	}
	req.Filter = filter

	// Step.Order
	if orderBy != nil && orderBy.Key != "" {
		req.Order = &commonpb.CondValueParam{
			Key:   orderBy.Key,
			Value: strconv.Itoa(orderBy.Order),
		}
	}

	data, err := client.GetGroupInventoryDistributionList(nil, req)

	err = json.Unmarshal(data, &result)
	if err != nil {
		return nil, err
	}
	for _, v := range result.List {
		v.Sex = getStaffSexByID(companyID, v.ID)
	}
	return result, nil
}

// 获取员工性别
func getStaffSexByID(companyID int, staffID int) (sex int) {
	s, err := getStaffInfoByID(companyID, staffID)
	if err != nil || s == nil {
		return 1
	}
	return s.Sex
}

func getStaffInfoByID(companyID int, staffID int) (s *dhr_staff.Staff, err error) {
	staff, err := dhr_staff.GetStaffById(nil, companyID, staffID, true)
	if err != nil {
		logger.Errorf("[getStaffInfoByID] dhr_staff.GetStaffById %d, err:%v", staffID, err)
		return nil, err
	}
	return staff, nil
}
