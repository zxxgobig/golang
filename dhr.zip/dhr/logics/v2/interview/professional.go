package v2_interview

import (
    "context"
    "time"

    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfwkit/config"
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"
    "gitlab.ifchange.com/bot/hfwkit/grpc/client"
    pb "gitlab.ifchange.com/bot/proto/professional_skills"
    "google.golang.org/grpc"
)

var expireTime = 3 * time.Second

func (i *Interview) AddProfessional(companyId int, interviewId int, name string) (result interface{}, err error) {
    params := pb.EvaluateSkillAddRequest{
        CompanyId: int64(companyId),
        Type:      interviewId2SkillType(kitinterview.Type(interviewId)),
        Name:      name,
    }

    resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewEvaluateClient(conn).SkillsAdd(ctx, &params)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(res.GetErrNo(), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }

    convert := resp.(*pb.EvaluateSkillAddResult)

    result = map[string]int64{"id": convert.Id}

    return
}

func fetchProfessional(companyId int, interviewId kitinterview.Type) (subItems []*InterviewSubItem, err error) {
    params := pb.EvaluateSkillListRequest{
        CompanyId: int64(companyId),
        Type:      interviewId2SkillType(interviewId),
    }
    if interviewId > 0 {
        params.PageSize = 99999
    }

    resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewEvaluateClient(conn).SkillsList(ctx, &params)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(res.GetErrNo(), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }

    result := resp.(*pb.EvaluateSkillsListResult)

    subItems = make([]*InterviewSubItem, 0, len(result.List))
    for _, x := range result.List {
        subItems = append(subItems, &InterviewSubItem{
            Id:   int(x.Id),
            Name: x.Name,
        })
    }

    return
}

func interviewId2SkillType(interviewId kitinterview.Type) pb.SkillType {
    switch interviewId {
    case kitinterview.Skill:
        return pb.SkillType_SKILL
    case kitinterview.Knowledge:
        return pb.SkillType_KNOWLEDGE
    }
    return pb.SkillType_UNKNOWN
}
