package v2_interview

import (
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    PersonalityRecommend struct {
        Name     string `json:"name"`
        Desc     string `json:"desc"`
        Index    int    `json:"index"`
        IsAdvice bool   `json:"is_advice"`
        IsMust   bool   `json:"is_must"`
    }
)

func ProcessPersonalityRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *PersonalityRecommend {
    interview, ok := interviewsM[kitinterview.Personality]
    if !ok {
        return nil
    }

    return &PersonalityRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.Personality),
        IsAdvice: GetIsAdvice(kitinterview.Personality, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.Personality, sceneId, sceneTemplateId),
    }
}
