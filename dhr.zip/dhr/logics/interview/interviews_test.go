package interview

import "testing"

func TestListStaffsInterviews(t *testing.T) {
	resultL, planID, err := ListStaffsInterviews("c461de20-3bc5-3bea-8723-164e69616b88")
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("planID is:%d", planID)
	t.Logf("resultL len is:%d", len(resultL))
	for _, v := range resultL {
		t.Log(v.InterviewId)
	}
}
