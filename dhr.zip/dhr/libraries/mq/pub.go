package mq

import (
    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/commonkit/mq"
    "gitlab.ifchange.com/bot/commonkit/mq/pub"
)

var (
    mqPub mq.Pub
)

func init() {
    NewPub()
}

func NewPub() {
    mqConfig := map[string]interface{}{
        "lookupds_address": mqServers,
    }

    var err error
    mqPub, err = pub.New(mq.NSQ, func(log string) error {
        return nil
    }, mqConfig)
    if err != nil {
        panic(err)
    }
}

func Push(topic string, data []byte) error {
    if err := mqPub.Init(topic); err != nil {
        logger.Errorf("mq.pub topic: [%s] init topic error: [%+v]", topic, err)
        return err
    }

    if err := mqPub.Publish(&mq.Message{Content: data}); err != nil {
        logger.Errorf("mq.pub topic: [%s] publish error: [%+v]", topic, err)
        return err
    }
    return nil
}
