package external

import "testing"

//  go test ./logics/external -v -run TestExcellentCharacters
func TestExcellentCharacters(t *testing.T) {
    data, err := ExcellentCharacters()
    if err != nil {
        t.Error(err)
    }
    t.Logf("scores %#v", data)
}
