package common

import (
	"fmt"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/bei"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	hfwutil "gitlab.ifchange.com/bot/hfwkit/utils"
	"gitlab.ifchange.com/bot/logger"
	career_assessment_pb "gitlab.ifchange.com/bot/proto/career_assessment"
	potential "gitlab.ifchange.com/bot/proto/dhr_potential"
	skills "gitlab.ifchange.com/bot/proto/professional_skills"

	"ifchange/dhr/core"
	"ifchange/dhr/models"
)

// ************
type ThirdEvaluationResult struct {
	Success bool      `json:"success"` // 状态标志。为true时表示获取成功，为false时，同时给出error属性指明错误原因
	Reports []*Report `json:"reports"` // 报告列表
}

type Report struct {
	Valid               bool               `json:"valid"`                  // 该测验结果是否有效
	InterviewId         int                `json:"interview_id"`           // interviewID -> 产品ID
	InterviewName       string             `json:"interview_name"`         // interview名称 -> 产品名称
	Completion          string             `json:"completion"`             // 完成百分比
	ReportDownloadUrl   string             `json:"report_download_url"`    // 报告下载地址，注意测评没有完成仍可下载该报告（按当前提交的数据生成）
	TotalScore          float64            `json:"total_score"`            // 各一级指标得分的累计总分
	FinalScore          float64            `json:"final_score"`            // 按各一级指标权重的计算得分
	ElapsedTimeInMinute float64            `json:"elapsed_time_in_minute"` // 测评总耗费时间
	ReportModels        []*ReportModel     `json:"report_models"`          // 报告原始数据（含一级指标得分、二级指标得分、指标解释、得分解释等）
	AdditionalModels    []*AdditionalModel `json:"additional_models"`      // 报告附加原始数据。部分产品有额外的计算结果（标准模型里未能定义），仅当后台生成好报告后才能一并生成
}

type ReportModel struct {
	Id               int        `json:"id"`                 // 一级纬度ID
	Name             string     `json:"name"`               // 一级维度名称
	Score            float64    `json:"score"`              // 一级维度分数
	SecondarySubItem []*SubItem `json:"secondary_sub_item"` // 二级纬度信息
}

type SubItem struct {
	Id    int     `json:"id"`    // 二级维度ID
	Name  string  `json:"name"`  // 二级维度名称
	Score float64 `json:"score"` // 二级维度分数
}

type AdditionalModel struct {
	SubItem   int     `json:"sub_item"`
	Name      string  `json:"name"`
	Score     float64 `json:"score"`
	Frequency int     `json:"frequency"`
}

// ************

type Score struct {
	DataGroupID int     `json:"data_group_id"`
	EnName      string  `json:"en_name"`
	Level       float64 `json:"level"`
}

type DataGroupsResults struct {
	DataGroupID int    `json:"data_group_id"`
	Title       string `json:"title"`
	Description string `json:"description"`
}

type CommitBeiParams struct {
	IsFinished int                  `json:"is_finished"`
	Scores     []*Score             `json:"scores"`
	Infos      []*DataGroupsResults `json:"infos"`
}

// 测评编号，与数据表 interviews 中的 id 保持一致
const IntvBei = 1                      // 素质
const IntvNormstar = 2                 // 性格
const IntvSkill = 3                    // 专业技能
const IntvKnowlege = 4                 // 专业知识
const IntvPotential = 5                // 潜力
const IntvWorkValues = 6               // 工作选择价值观
const IntvKeyExp = 7                   // 关键经历
const IntvEmotionalIntelligence = 8    // 情绪智力
const IntvCriticalThinking = 9         // 批判思维
const IntvPracticalIntelligence = 10   // 管理实践能力
const IntvOccupationalPersonality = 11 // 职业人格
const IntvPersonalityDisorder = 12     // 性格风险
const IntvLeadershipStyle = 13         // 领导风格
const IntvOrgCommitment = 14           // 组织忠诚度
const ManagementQuality = 21           // 管理素质迫选测验

type RuleParams struct {
	Id      int `json:"id"`
	TypeId  int `json:"type_id"`
	CId     int `json:"c_id"`
	CTypeId int `json:"c_type_id"`
	Choice  int `json:"choice"`
}

var keyMap = map[int]*RuleParams{
	1:  &RuleParams{Id: 50, TypeId: 3, CId: 1, CTypeId: 1, Choice: 1},
	2:  &RuleParams{Id: 36, TypeId: 3, CId: 2, CTypeId: 1, Choice: 1},
	3:  &RuleParams{Id: 39, TypeId: 3, CId: 3, CTypeId: 1, Choice: 1},
	4:  &RuleParams{Id: 34, TypeId: 3, CId: 4, CTypeId: 1, Choice: 1},
	5:  &RuleParams{Id: 25, TypeId: 3, CId: 5, CTypeId: 1, Choice: 1},
	6:  &RuleParams{Id: 30, TypeId: 3, CId: 6, CTypeId: 1, Choice: 1},
	7:  &RuleParams{Id: 31, TypeId: 3, CId: 7, CTypeId: 1, Choice: 1},
	8:  &RuleParams{Id: 29, TypeId: 3, CId: 8, CTypeId: 1, Choice: 1},
	9:  &RuleParams{Id: 51, TypeId: 3, CId: 9, CTypeId: 1, Choice: 1},
	10: &RuleParams{Id: 24, TypeId: 3, CId: 10, CTypeId: 1, Choice: 1},
	11: &RuleParams{Id: 49, TypeId: 3, CId: 11, CTypeId: 1, Choice: 1},
	12: &RuleParams{Id: 28, TypeId: 3, CId: 12, CTypeId: 1, Choice: 1},
	13: &RuleParams{Id: 26, TypeId: 3, CId: 13, CTypeId: 1, Choice: 1},
	14: &RuleParams{Id: 27, TypeId: 3, CId: 14, CTypeId: 1, Choice: 1},
	15: &RuleParams{Id: 52, TypeId: 3, CId: 15, CTypeId: 1, Choice: 1},
	16: &RuleParams{Id: 53, TypeId: 3, CId: 16, CTypeId: 1, Choice: 1},
	17: &RuleParams{Id: 54, TypeId: 3, CId: 17, CTypeId: 1, Choice: 1},
	18: &RuleParams{Id: 32, TypeId: 3, CId: 18, CTypeId: 1, Choice: 1},
	24: &RuleParams{Id: 10, TypeId: 1, CId: 24, CTypeId: 3, Choice: 1},
	25: &RuleParams{Id: 5, TypeId: 1, CId: 25, CTypeId: 3, Choice: 1},
	26: &RuleParams{Id: 13, TypeId: 1, CId: 26, CTypeId: 3, Choice: 1},
	27: &RuleParams{Id: 14, TypeId: 1, CId: 27, CTypeId: 3, Choice: 1},
	28: &RuleParams{Id: 12, TypeId: 1, CId: 28, CTypeId: 3, Choice: 1},
	29: &RuleParams{Id: 8, TypeId: 1, CId: 29, CTypeId: 3, Choice: 1},
	30: &RuleParams{Id: 6, TypeId: 1, CId: 30, CTypeId: 3, Choice: 1},
	31: &RuleParams{Id: 7, TypeId: 1, CId: 31, CTypeId: 3, Choice: 1},
	32: &RuleParams{Id: 18, TypeId: 1, CId: 32, CTypeId: 3, Choice: 1},
	33: &RuleParams{Id: 47, TypeId: 1, CId: 33, CTypeId: 3, Choice: 1},
	34: &RuleParams{Id: 4, TypeId: 1, CId: 34, CTypeId: 3, Choice: 1},
	35: &RuleParams{Id: 44, TypeId: 1, CId: 35, CTypeId: 3, Choice: 1},
	36: &RuleParams{Id: 2, TypeId: 1, CId: 36, CTypeId: 3, Choice: 1},
	37: &RuleParams{Id: 42, TypeId: 1, CId: 37, CTypeId: 3, Choice: 1},
	38: &RuleParams{Id: 45, TypeId: 1, CId: 38, CTypeId: 3, Choice: 1},
	39: &RuleParams{Id: 3, TypeId: 1, CId: 39, CTypeId: 3, Choice: 1},
	40: &RuleParams{Id: 57, TypeId: 3, CId: 40, CTypeId: 1, Choice: 1},
	41: &RuleParams{Id: 56, TypeId: 3, CId: 41, CTypeId: 1, Choice: 1},
	42: &RuleParams{Id: 37, TypeId: 3, CId: 42, CTypeId: 1, Choice: 1},
	43: &RuleParams{Id: 58, TypeId: 3, CId: 43, CTypeId: 1, Choice: 1},
	44: &RuleParams{Id: 35, TypeId: 3, CId: 44, CTypeId: 1, Choice: 1},
	45: &RuleParams{Id: 38, TypeId: 3, CId: 45, CTypeId: 1, Choice: 1},
	46: &RuleParams{Id: 59, TypeId: 3, CId: 46, CTypeId: 1, Choice: 1},
	47: &RuleParams{Id: 33, TypeId: 3, CId: 47, CTypeId: 1, Choice: 1},
	48: &RuleParams{Id: 55, TypeId: 3, CId: 48, CTypeId: 1, Choice: 1},
	49: &RuleParams{Id: 11, TypeId: 1, CId: 49, CTypeId: 3, Choice: 1},
	50: &RuleParams{Id: 1, TypeId: 1, CId: 50, CTypeId: 3, Choice: 1},
	51: &RuleParams{Id: 9, TypeId: 1, CId: 51, CTypeId: 3, Choice: 1},
	52: &RuleParams{Id: 15, TypeId: 1, CId: 52, CTypeId: 3, Choice: 1},
	53: &RuleParams{Id: 16, TypeId: 1, CId: 53, CTypeId: 3, Choice: 1},
	54: &RuleParams{Id: 17, TypeId: 1, CId: 54, CTypeId: 3, Choice: 1},
	55: &RuleParams{Id: 48, TypeId: 1, CId: 55, CTypeId: 3, Choice: 1},
	56: &RuleParams{Id: 41, TypeId: 1, CId: 56, CTypeId: 3, Choice: 1},
	57: &RuleParams{Id: 40, TypeId: 1, CId: 57, CTypeId: 3, Choice: 1},
	58: &RuleParams{Id: 43, TypeId: 1, CId: 58, CTypeId: 3, Choice: 1},
	59: &RuleParams{Id: 46, TypeId: 1, CId: 59, CTypeId: 3, Choice: 1},
}

var ThirdEvaluation2BeiScore = map[int]float64{
	10: 5,
	9:  4,
	8:  3,
	7:  2,
	6:  1,
	5:  1,
	4:  0.5,
	3:  0.5,
	2:  0.5,
	1:  0.5,
}

var Data = &ThirdEvaluationResult{}

func UpdateStaffsInterview(emailUuid, result string, params interface{}, interviewID int) (err error) {

	data, err := models.StaffsInterviewsModel.SearchOne(db.Cond{"email_uuid": emailUuid, "interview_id": interviewID})
	if err != nil {
		return common.NewRespErr(core.SystemErrNo, err)
	}
	if data == nil {
		return common.NewRespErr(core.RequestError, "emailUuid is not exist")
	}

	affected, err := models.StaffsInterviewsModel.Update(db.Cond{"result": result, "status": 2}, db.Cond{"email_uuid": emailUuid,
		"interview_id": interviewID})
	if err != nil {
		return common.NewRespErr(core.SystemErrNo, err)
	}
	if affected == 0 {
		return common.NewRespErr(core.SystemErrNo,
			fmt.Sprintf("update staffs_interviews failed where email_uuid=%s and interview_id=%d", emailUuid, interviewID))
	}
	currentFlage := 0
	if params != nil {
		currentFlage, err = UpdateProjectStaffsInterviewsDetails(data.ProjectId, data.StaffId, data.DataCollectId, interviewID, params)
		if err != nil {
			return err
		}
	}
	if currentFlage == 1 && interviewID > 7 && interviewID <= 14 {
		return err
	}

	return err
}

func parseCommitBeiParams(params *CommitBeiParams) (result map[int]*Score) {
	result = make(map[int]*Score)
	for i := 0; i < len(params.Scores); i++ {
		data := params.Scores[i]
		result[data.DataGroupID] = data
	}
	return result
}

func UpdateProjectStaffsInterviewsDetails(projectID, staffID, dataCollectID, interviewID int, params interface{}) (currentFlage int, err error) {

	currentFlage = 1
	staffIDs := make([]int, 0, 10)
	infos := make([]*models.StaffsInterviewsDetails, 0, 30)

	// 根据projectID 获取项目信息，判断是否是模式二
	proj, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectID, "is_deleted": 0})
	if err != nil {
		return currentFlage, err
	}

	if proj.InterviewMode == 2 { // 模式二，落其中的四个测评，对应落bei的分数
		go interviewModeHandler(projectID, interviewID, staffID, dataCollectID, params)
	}

	switch interviewID {
	case IntvBei:
		paramsData, ok := params.(*CommitBeiParams)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "Bei result is error")
		}
		currentMap := parseCommitBeiParams(paramsData)
		for _, data := range paramsData.Scores {
			score := 0.0
			cMap := keyMap[data.DataGroupID]
			key := cMap.Id
			typeId := cMap.TypeId
			choice := cMap.Choice
			cTypeId := cMap.CTypeId

			if info, ok := currentMap[key]; key != 0 && choice == 1 && ok {
				if cTypeId == 3 {
					score = data.Level*0.7 + score
				} else {
					score = data.Level*0.3 + score
				}

				if typeId == 3 {
					score = info.Level*0.7 + score
				} else {
					score = info.Level*0.3 + score
				}
			} else {
				score = data.Level
			}

			// 创建的时候已经插入基础数据，只是没有分数
			affected, err := models.StaffsInterviewsDetailsModel.Update(db.Cond{"score": score, "status": 2},
				db.Cond{"staff_id": staffID, "data_collect_id": dataCollectID, "sub_item": data.DataGroupID,
					"interview_id": interviewID})
			if err != nil {
				return currentFlage, common.NewRespErr(core.SystemErrNo, err)
			}
			if affected == 0 {
				return currentFlage, common.NewRespErr(core.SystemErrNo, "update project_staffs_interviews_details failed")
			}
		}

	case IntvPotential:
		paramsData, ok := params.([]*potential.PotentialResult)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "PotentialResult is error")
		}
		for i := 0; i < len(paramsData); i++ {
			data := paramsData[i]

			staffsInterviewsDetails, err := models.StaffsInterviewsDetailsModel.SearchOne(db.Cond{"project_id": projectID,
				"staff_id": staffID, "data_collect_id": dataCollectID, "interview_id": interviewID,
				"sub_item": int(data.AxisId), "Score": float64(data.AxisLevel), "status": 2})
			if err != nil {
				return currentFlage, common.NewRespErr(core.SystemErrNo, err)
			}
			if staffsInterviewsDetails != nil {
				continue
			}

			info := &models.StaffsInterviewsDetails{
				ProjectId:     projectID,
				StaffId:       staffID,
				InterviewId:   interviewID,
				DataCollectId: dataCollectID,
				SubItem:       int(data.AxisId),
				Score:         float64(data.AxisLevel),
				Status:        2,
			}
			infos = append(infos, info)
		}

	case IntvNormstar:
		paramsData, ok := params.(map[int]float64)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "norm start result is error")
		}
		for k, v := range paramsData {

			staffsInterviewsDetails, err := models.StaffsInterviewsDetailsModel.SearchOne(db.Cond{"project_id": projectID,
				"staff_id": staffID, "data_collect_id": dataCollectID, "interview_id": interviewID,
				"sub_item": k, "Score": v, "status": 2})
			if err != nil {
				return currentFlage, common.NewRespErr(core.SystemErrNo, err)
			}
			if staffsInterviewsDetails != nil {
				continue
			}

			info := &models.StaffsInterviewsDetails{
				ProjectId:     projectID,
				StaffId:       staffID,
				InterviewId:   interviewID,
				DataCollectId: dataCollectID,
				SubItem:       k,
				Score:         v,
				Status:        2,
			}
			infos = append(infos, info)
		}

	case IntvSkill, IntvKnowlege:
		paramsData, ok := params.([]*skills.Answer)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "SkillAnswers is error")
		}
		for i := 0; i < len(paramsData); i++ {
			for n := 0; n < len(paramsData[i].SkillAnswers); n++ {
				affected, err := models.StaffsInterviewsDetailsModel.Update(db.Cond{"score": paramsData[i].SkillAnswers[n].Score, "status": 2},
					db.Cond{"staff_id": paramsData[i].UserId, "data_collect_id": dataCollectID,
						"sub_item":        paramsData[i].SkillAnswers[n].SkillId,
						"interview_id in": []int{IntvSkill, IntvKnowlege}})
				if err != nil {
					return currentFlage, common.NewRespErr(core.SystemErrNo, err)
				}
				if affected == 0 {
					return currentFlage, common.NewRespErr(core.SystemErrNo, "update project_staffs_interviews_details failed")
				}
			}
			staffIDs = append(staffIDs, int(paramsData[i].UserId))
		}

	case IntvWorkValues:
		paramsData, ok := params.([]*career_assessment_pb.WorkValuesResults)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "SkillAnswers is error")
		}
		for i := 0; i < len(paramsData); i++ {
			info := &models.StaffsInterviewsDetails{
				ProjectId:     projectID,
				StaffId:       staffID,
				InterviewId:   interviewID,
				DataCollectId: dataCollectID,
				SubItem:       int(paramsData[i].Id),
				Tag:           paramsData[i].Values,
				Status:        2,
			}
			infos = append(infos, info)
		}

	case IntvKeyExp:
		paramsData, ok := params.([]*career_assessment_pb.Result)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "IntvKeyExp is error")
		}
		if paramsData == nil {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "IntvKeyExp is nil")
		}
		for i := 0; i < len(paramsData); i++ {
			if paramsData[i].Options == nil {
				return currentFlage, common.NewRespErr(core.SystemErrNo, "IntvKeyExp Options is nil")
			}
			for k := 0; k < len(paramsData[i].Options); k++ {
				info := &models.StaffsInterviewsDetails{
					ProjectId:     projectID,
					StaffId:       staffID,
					InterviewId:   interviewID,
					DataCollectId: dataCollectID,
					SubItem:       int(paramsData[i].Options[k].Id),
					Tag:           paramsData[i].Options[k].Name,
					Status:        2,
				}
				infos = append(infos, info)
			}
		}

	case IntvEmotionalIntelligence, IntvCriticalThinking, IntvPracticalIntelligence, IntvOccupationalPersonality,
		IntvPersonalityDisorder, IntvLeadershipStyle, IntvOrgCommitment, ManagementQuality:
		paramsData, ok := params.(*ThirdEvaluationResult)
		if !ok {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "ThirdEvaluation is error")
		}
		if paramsData == nil {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "ThirdEvaluation is nil")
		}
		if len(paramsData.Reports) > 0 {
			_, err = models.StaffsInterviewsDetailsModel.Update(db.Cond{"is_deleted": 1}, db.Cond{"interview_id": interviewID, "staff_id": staffID})
			if err != nil {
				return currentFlage, err
			}
		}
		status := 0
		for i := 0; i < len(paramsData.Reports); i++ {
			if paramsData.Reports[i].Valid == true {
				status = 2
			} else {
				status = 2
			}
			if interviewID == IntvLeadershipStyle {
				if paramsData.Reports[i].AdditionalModels != nil && len(paramsData.Reports[i].AdditionalModels) > 0 {
					for j := 0; j < len(paramsData.Reports[i].AdditionalModels); j++ {
						currentAdditionalModels := paramsData.Reports[i].AdditionalModels[j]
						info := &models.StaffsInterviewsDetails{
							ProjectId:        projectID,
							StaffId:          staffID,
							InterviewId:      interviewID,
							DataCollectId:    dataCollectID,
							SubItem:          currentAdditionalModels.SubItem,
							Score:            currentAdditionalModels.Score,
							Frequency:        currentAdditionalModels.Frequency,
							SecondarySubItem: 0,
							Tag:              currentAdditionalModels.Name,
							Status:           status,
						}
						infos = append(infos, info)
					}
				}
			} else {
				for _, currentReportModels := range paramsData.Reports[i].ReportModels {
					if currentReportModels == nil {
						return currentFlage, common.NewRespErr(core.SystemErrNo, "ThirdEvaluation ReportModels is nil")
					}

					var info *models.StaffsInterviewsDetails
					if interviewID == IntvOrgCommitment || interviewID == IntvCriticalThinking ||
						interviewID == IntvPersonalityDisorder || interviewID == ManagementQuality {
						info = &models.StaffsInterviewsDetails{
							ProjectId:        projectID,
							StaffId:          staffID,
							InterviewId:      interviewID,
							DataCollectId:    dataCollectID,
							SubItem:          0,
							Score:            currentReportModels.Score,
							SecondarySubItem: 0,
							Tag:              currentReportModels.Name,
							Status:           status,
						}
					} else {
						info = &models.StaffsInterviewsDetails{
							ProjectId:        projectID,
							StaffId:          staffID,
							InterviewId:      interviewID,
							DataCollectId:    dataCollectID,
							SubItem:          currentReportModels.Id,
							Score:            currentReportModels.Score,
							SecondarySubItem: 0,
							Tag:              currentReportModels.Name,
							Status:           status,
						}
					}
					infos = append(infos, info)

					for _, currentSecondarySubItem := range currentReportModels.SecondarySubItem {
						if interviewID == IntvOrgCommitment || interviewID == IntvCriticalThinking ||
							interviewID == IntvPersonalityDisorder || interviewID == ManagementQuality {
							info = &models.StaffsInterviewsDetails{
								ProjectId:        projectID,
								StaffId:          staffID,
								InterviewId:      interviewID,
								DataCollectId:    dataCollectID,
								SubItem:          currentSecondarySubItem.Id,
								SecondarySubItem: 0,
								Score:            currentSecondarySubItem.Score,
								Tag:              currentSecondarySubItem.Name,
								Status:           status,
							}
						} else {
							info = &models.StaffsInterviewsDetails{
								ProjectId:        projectID,
								StaffId:          staffID,
								InterviewId:      interviewID,
								DataCollectId:    dataCollectID,
								SubItem:          currentReportModels.Id,
								SecondarySubItem: currentSecondarySubItem.Id,
								Score:            currentSecondarySubItem.Score,
								Tag:              currentSecondarySubItem.Name,
								Status:           status,
							}
						}

						infos = append(infos, info)
					}
				}
			}
			currentFlage--
		}
	}

	_, err = models.StaffsInterviewsDetailsModel.Saves(infos)
	if err != nil {
		return currentFlage, common.NewRespErr(core.SystemErrNo, err)
	}
	if currentFlage == 1 && interviewID > 7 && interviewID <= 14 {
		return currentFlage, err
	}
	if interviewID != 3 && interviewID != 4 {
		err = UpdateCollectPlanStaff(staffID, interviewID, dataCollectID)
		if err != nil {
			return currentFlage, common.NewRespErr(core.SystemErrNo, "update data_collect_plan_staffs failed")
		}
	}

	if len(staffIDs) > 0 {
		for i := 0; i < len(staffIDs); i++ {
			err = UpdateCollectPlanStaff(staffIDs[i], interviewID, dataCollectID)
			if err != nil {
				return currentFlage, common.NewRespErr(core.SystemErrNo, "update data_collect_plan_staffs failed")
			}
		}
	}

	return currentFlage, err
}

func InterviewExists(staffID, interviewID int) (err error) {
	data, err := models.StaffsInterviewsModel.SearchOne(db.Cond{
		"staff_id": staffID, "interview_id": interviewID, "status": 2})
	if err != nil {
		err = common.NewRespErr(core.SystemErrNo, err)
		return err
	}
	if data != nil {
		err = common.NewRespErr(core.SystemErrNo, "")
		return err
	}
	return err
}

func GetInterviewById(id int) (result *models.StaffsInterviews, err error) {
	result, err = models.StaffsInterviewsModel.SearchOne(db.Cond{"id": id})
	if err != nil {
		return result, common.NewRespErr(core.SystemErrNo, err)
	}
	if result == nil {
		return result, common.NewRespErr(core.DbQueryNotExist, "数据不存在")
	}
	return result, err
}

func GetInterviewByUuid(uuid string) (result *models.StaffsInterviews, err error) {
	result, err = models.StaffsInterviewsModel.SearchOne(db.Cond{"uuid": uuid})
	if err != nil {
		return result, common.NewRespErr(core.SystemErrNo, err)
	}
	if result == nil {
		return result, common.NewRespErr(core.DbQueryNotExist, "数据不存在")
	}
	return result, err
}

func GetInterviewByUuidAndInterviewId(uuid string, interviewId int) (result *models.StaffsInterviews, err error) {
	result, err = models.StaffsInterviewsModel.SearchOne(db.Cond{"uuid": uuid, "interview_id": interviewId, "is_deleted": 0})
	if err != nil {
		return result, common.NewRespErr(core.SystemErrNo, err)
	}
	if result == nil {
		return result, common.NewRespErr(core.DbQueryNotExist, "数据不存在")
	}
	return result, err
}

func GetInterviewByStaffID(staffID, interviewID int, emailUuid string) (result *models.StaffsInterviews, err error) {
	result, err = models.StaffsInterviewsModel.SearchOne(db.Cond{"staff_id": staffID, "interview_id": interviewID, "email_uuid": emailUuid})
	if err != nil {
		return result, common.NewRespErr(core.SystemErrNo, err)
	}
	if result == nil {
		return result, common.NewRespErr(core.DbQueryNotExist, "数据不存在")
	}
	return result, err
}

func UpdateStaffsInterviewStatus(emailUuid string, interviewID, status int) (err error) {

	affected, err := models.StaffsInterviewsModel.Update(db.Cond{"status": status}, db.Cond{"email_uuid": emailUuid,
		"interview_id": interviewID})
	if err != nil {
		return common.NewRespErr(core.SystemErrNo, err)
	}
	if affected == 0 {
		return common.NewRespErr(core.SystemErrNo,
			fmt.Sprintf("update staffs_interviews failed where email_uuid=%s and interview_id=%d", emailUuid, interviewID))
	}
	return err
}

func SelectStaffsInterviewDetails() error {
	datas, err := models.StaffsInterviewsModel.Search(db.Cond{
		"status":          2,
		"interview_id in": []int{6, 7},
		"is_deleted":      0,
	})
	if err != nil {
		return err
	}
	for i := 0; i < len(datas); i++ {
		data := datas[i]
		err = UpdateCollectPlanStaff(data.StaffId, data.InterviewId, data.DataCollectId)
		if err != nil {
			return err
		}
	}
	return nil
}

func interviewModeHandler(projectID, interviewID, staffID, dataCollectID int, params interface{}) {
	var isBeiCompleted bool
	var err error

	defer func() {
		if err != nil {
			logger.Errorf("bei newMode handler failed. err: %v", err)
		}
	}()

	switch interviewID {
	case IntvPracticalIntelligence, IntvOccupationalPersonality, IntvCriticalThinking, ManagementQuality:
		// 1. 获取config表中的配置文件，进行映射到bei中
		var config []*models.ProjectsInterviewsConfigs
		config, err = models.ProjectsInterviewsConfigsModel.Search(db.Cond{
			"where":      fmt.Sprintf("project_id = %d AND interview_id = %d", projectID, IntvBei),
			"is_deleted": 0,
		})
		if err != nil {
			return
		}

		type ConfigSubItem struct {
			Id     int    `json:"id"`
			EnName string `json:"enname"`
			Name   string `json:"name"`
		}

		var items []ConfigSubItem
		_ = encoding.JSON.UnmarshalFromString(config[0].InterviewConfigs, &items)
		beiInterviewIDMapping := make(map[int]struct{})
		for _, item := range items {
			if len(beiInterviewIDMapping) == 4 { // 最多只有四个测评
				break
			}

			beiSubItem := bei.BeiSubitem2InterviewSubitems[item.Id]
			if _, ok := beiInterviewIDMapping[beiSubItem.InterviewID]; !ok {
				beiInterviewIDMapping[beiSubItem.InterviewID] = struct{}{}
			}
		}

		// 2. 获取interview_detail 表中存在哪些测评
		var details []*models.StaffsInterviewsDetails
		where := fmt.Sprintf(`staff_id = %d AND interview_id IN(9,10,11,21) AND is_deleted = 0 AND updated_at > '%s'`,
			staffID, hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Bei).BeforeTime())) // 这里使用bei的有效期 === 9，10，11，21
		logger.Infof("bei newMode handler where:%v", where)
		details, err = models.StaffsInterviewsDetailsModel.Search(db.Cond{
			"where":   where,
			"orderby": "updated_at DESC",
		})
		if err != nil {
			return
		}
		interviewIDMapping := make(map[int]struct{})
		for _, detail := range details {
			if len(interviewIDMapping) == 4 {
				break
			}
			interviewIDMapping[detail.InterviewId] = struct{}{}
		}
		interviewIDMapping[interviewID] = struct{}{}

		logger.Infof("beiInterviewIDMapping-interviewIDMapping length:[%v-%v]", len(beiInterviewIDMapping), len(interviewIDMapping))
		isBeiCompleted = isInterviewCompleted(beiInterviewIDMapping, interviewIDMapping)

		// 3. update bei 对应的分数
		paramsData, ok := params.(*ThirdEvaluationResult)
		if !ok {
			err = common.NewRespErr(core.SystemErrNo, "ThirdEvaluation is error")
			return
		}

		infos := make([]*models.StaffsInterviewsDetails, 0)
		for _, report := range paramsData.Reports {
			for _, reportModel := range report.ReportModels {
				for _, each := range reportModel.SecondarySubItem {
					for beiSubItemID, thirdSubItem := range bei.BeiSubitem2InterviewSubitems {
						if report.InterviewId == ManagementQuality || report.InterviewId == IntvCriticalThinking {
							thirdSubItem.ItemID = 1
						}
						if report.InterviewId == thirdSubItem.InterviewID && reportModel.Id == thirdSubItem.ItemID &&
							each.Id == thirdSubItem.SubitemID {
							// 插入details表
							infos = append(infos, &models.StaffsInterviewsDetails{
								ProjectId:     projectID,
								StaffId:       staffID,
								InterviewId:   IntvBei,
								DataCollectId: dataCollectID,
								SubItem:       beiSubItemID,
								Score:         ThirdEvaluation2BeiScore[int(each.Score)],
								Status:        1,
							})
						}
					}
				}
			}
		}

		_, err = models.StaffsInterviewsDetailsModel.Saves(infos)
		if err != nil {
			return
		}
	}

	if isBeiCompleted {
		_, err = models.StaffsInterviewsModel.Update(db.Cond{"status": 2}, db.Cond{
			"where": fmt.Sprintf("project_id = %v AND interview_id = %v AND staff_id = %v AND is_deleted = 0",
				projectID, IntvBei, staffID),
		})
		if err != nil {
			return
		}

		_, err = models.StaffsInterviewsDetailsModel.Update(db.Cond{"status": 2}, db.Cond{
			"where": fmt.Sprintf("project_id = %v AND interview_id = %v AND staff_id = %v AND is_deleted = 0",
				projectID, IntvBei, staffID),
		})
		if err != nil {
			return
		}

		err = UpdateCollectPlanStaff(staffID, IntvBei, dataCollectID)
		if err != nil {
			err = common.NewRespErr(core.SystemErrNo, "update data_collect_plan_staffs failed")
			return
		}
	}

	return
}

func InterviewNewBeiHandler(projectID, staffID, dataCollectID int) (err error) {
	defer func() {
		if err != nil {
			logger.Errorf("bei newMode handler failed. err: %v", err)
		}
	}()

	// 1. 获取config表中的配置文件，进行映射到bei中
	var config []*models.ProjectsInterviewsConfigs
	config, err = models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"where":      fmt.Sprintf("project_id = %d AND interview_id = %d", projectID, IntvBei),
		"is_deleted": 0,
	})
	if err != nil {
		return
	}

	type ConfigSubItem struct {
		Id     int    `json:"id"`
		EnName string `json:"enname"`
		Name   string `json:"name"`
	}

	var items []ConfigSubItem
	_ = encoding.JSON.UnmarshalFromString(config[0].InterviewConfigs, &items)
	beiInterviewIDMapping := make(map[int]struct{})
	for _, item := range items {
		if len(beiInterviewIDMapping) == 4 { // 最多只有四个测评
			break
		}

		beiSubItem := bei.BeiSubitem2InterviewSubitems[item.Id]
		if _, ok := beiInterviewIDMapping[beiSubItem.InterviewID]; !ok {
			beiInterviewIDMapping[beiSubItem.InterviewID] = struct{}{}
		}
	}

	// 2. 获取interview_detail 表中存在哪些测评
	var details []*models.StaffsInterviewsDetails
	where := fmt.Sprintf(`staff_id = %d AND interview_id IN(9,10,11,21) AND is_deleted = 0 AND updated_at > '%s'`,
		staffID, hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Bei).BeforeTime())) // 这里使用bei的有效期 === 9，10，11，21
	logger.Infof("bei newMode handler where:%v", where)
	details, err = models.StaffsInterviewsDetailsModel.Search(db.Cond{
		"where":   where,
		"orderby": "updated_at DESC",
	})
	if err != nil {
		return
	}
	interviewIDMapping := make(map[int]struct{})
	for _, detail := range details {
		if len(interviewIDMapping) == 4 {
			break
		}

		if _, ok := interviewIDMapping[detail.InterviewId]; !ok {
			interviewIDMapping[detail.InterviewId] = struct{}{}
		}
	}

	logger.Infof("beiInterviewIDMapping-interviewIDMapping length:[%v-%v]", len(beiInterviewIDMapping), len(interviewIDMapping))
	isBeiCompleted := isInterviewCompleted(beiInterviewIDMapping, interviewIDMapping)

	// 3. update bei 对应的分数 -- 将details里的分数映射到新版bei中
	infos := make([]*models.StaffsInterviewsDetails, 0)
	for _, detail := range details {
		for beiSubItemID, thirdSubItem := range bei.BeiSubitem2InterviewSubitems {
			if (detail.InterviewId == ManagementQuality || detail.InterviewId == IntvCriticalThinking) &&
				(detail.InterviewId == thirdSubItem.InterviewID && detail.SubItem == thirdSubItem.SubitemID) {
				infos = append(infos, &models.StaffsInterviewsDetails{
					ProjectId:     projectID,
					StaffId:       staffID,
					InterviewId:   IntvBei,
					DataCollectId: dataCollectID,
					SubItem:       beiSubItemID,
					Score:         ThirdEvaluation2BeiScore[int(detail.Score)],
					Status:        1,
				})
			}

			if detail.InterviewId == thirdSubItem.InterviewID && detail.SubItem == thirdSubItem.ItemID &&
				detail.SecondarySubItem == thirdSubItem.SubitemID {
				infos = append(infos, &models.StaffsInterviewsDetails{
					ProjectId:     projectID,
					StaffId:       staffID,
					InterviewId:   IntvBei,
					DataCollectId: dataCollectID,
					SubItem:       beiSubItemID,
					Score:         ThirdEvaluation2BeiScore[int(detail.Score)],
					Status:        1,
				})
			}
		}
	}

	_, err = models.StaffsInterviewsDetailsModel.Saves(infos)
	if err != nil {
		return
	}

	if isBeiCompleted {
		_, err = models.StaffsInterviewsModel.Update(db.Cond{"status": 2}, db.Cond{
			"where": fmt.Sprintf("project_id = %v AND interview_id = %v AND staff_id = %v AND is_deleted = 0",
				projectID, IntvBei, staffID),
		})
		if err != nil {
			return
		}

		_, err = models.StaffsInterviewsDetailsModel.Update(db.Cond{"status": 2}, db.Cond{
			"where": fmt.Sprintf("project_id = %v AND interview_id = %v AND staff_id = %v AND is_deleted = 0",
				projectID, IntvBei, staffID),
		})
		if err != nil {
			return
		}

		err = UpdateCollectPlanStaff(staffID, IntvBei, dataCollectID)
		if err != nil {
			err = common.NewRespErr(core.SystemErrNo, "update data_collect_plan_staffs failed")
			return
		}
	}

	return
}

func isInterviewCompleted(configMap, completedMap map[int]struct{}) bool {
	if len(completedMap) == 4 {
		return true
	}

	for interviewID := range configMap {
		if _, ok := completedMap[interviewID]; !ok {
			return false
		}
	}
	return true
}
