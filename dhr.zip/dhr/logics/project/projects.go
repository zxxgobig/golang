package project

import (
	"encoding/json"
	"fmt"
	"ifchange/dhr/logics/project/permission"
	"time"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/utils"

	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"

	"ifchange/dhr/core"
	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/data_collect"
	"ifchange/dhr/logics/interview"
	"ifchange/dhr/logics/lambda"
	"ifchange/dhr/logics/staff"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/logger"
)

type Projects struct {
}

func NewProjects() *Projects {
	return new(Projects)
}

type NoticeResult struct {
	PerformStaffCount         int                        `json:"perform_staff_count"`
	PerformStaffLackCount     int                        `json:"perform_staff_lack_count"`
	DataCollectStaffLackCount int                        `json:"data_collect_staff_lack_count"`
	DataCollectPlans          []*models.DataCollectPlans `json:"data_collect_plans"`
}

func (p *Projects) GetNotice(companyId int, projectId int) (noticeResult *NoticeResult, err error) {
	_, err = GetValidProject(companyId, projectId)
	if err != nil {
		return
	}
	noticeResult = new(NoticeResult)

	dataCollectStaff, err := interview.GetDataCollectDemandStaffs(companyId, projectId, nil)
	if err != nil {
		return
	}

	noticeResult.DataCollectStaffLackCount = len(dataCollectStaff)

	noticeResult.PerformStaffCount, noticeResult.PerformStaffLackCount, err = PerformStatffCount(projectId)
	if err != nil {
		return
	}
	noticeResult.DataCollectPlans, err = models.DataCollectPlansModel.Search(db.Cond{
		"project_id": projectId,
		"is_deleted": 0,
	})

	return
}

func (p *Projects) ListByStaffId(companyId, staffId, page, pageSize int) (_models []*models.Projects, total int64, err error) {

	valid, err := staff.CheckStaffs(companyId, []int{staffId})
	if err != nil {
		return
	}
	if valid == false {
		return nil, 0, fmt.Errorf("staff not valid")
	}

	projectsStaffs, err := models.ProjectsStaffsModel.Search(db.Cond{
		"is_deleted": 0,
		"staff_id":   staffId,
		"page":       page,
		"pageSize":   pageSize,
	})
	if err != nil {
		return
	}

	total, err = models.ProjectsStaffsModel.Count(db.Cond{
		"is_deleted": 0,
		"staff_id":   staffId,
	})
	if err != nil {
		return
	}

	if projectsStaffs != nil {
		ids := []int{}
		for _, x := range projectsStaffs {
			ids = append(ids, x.Id)
		}
		_models, err = models.ProjectsModel.Search(db.Cond{
			"is_deleted": 0,
			"id in":      ids,
		})
		if err != nil {
			return
		}
	}
	return
}

// List 使用关键词 岗位id列表，页码，每页数量获取项目详情列表
func (p *Projects) List(companyId int, key string, positionIds []int, page, pageSize int) (_models []*models.Projects, total int64, err error) {
	cond := db.Cond{
		"is_deleted": 0,
		"company_id": companyId,
		"page":       page,
		"pagesize":   pageSize,
		"orderby":    "id desc",
	}
	if len(key) >= 1 {
		cond["where"] = fmt.Sprintf("name like '%%%s%%'", key)
	}
	if len(positionIds) > 0 {
		cond["position_id in"] = positionIds
	}

	_models, err = models.ProjectsModel.Search(cond)
	if err != nil {
		return
	}

	delete(cond, "page")
	delete(cond, "pagesize")

	total, err = models.ProjectsModel.Count(cond)

	return
}

func (p *Projects) Create(project models.Projects, interviewConfigItemParams []*interview.ConfigItemParam,
	intvConfigs *interview.InterviewsConfigs, staffIds []int) (err error) {
	// 场景
	scene, err := models.ProjectsScenesModel.GetById(project.SceneId)
	if err != nil {
		return
	}
	if scene == nil {
		return fmt.Errorf("scene not found:%d", project.SceneId)
	}
	// 岗位是否有效
	valid, err := staff.CheckPositionByID(project.CompanyId, project.PositionId)
	if err != nil {
		return
	}
	if valid == false {
		return fmt.Errorf("position not found:%d", project.PositionId)
	}

	// 行业是否有效
	positionIndustry, err := models.PositionIndustriesModel.SearchOne(db.Cond{
		"id":         project.PositionIndustryId,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if positionIndustry == nil {
		return fmt.Errorf("industry not found:%d", project.PositionIndustryId)
	}

	// 职能是否有效
	positionFunction, err := models.PositionFunctionsModel.SearchOne(db.Cond{"id": project.PositionFunctionId, "is_deleted": 0, "depth": 2})
	if err != nil {
		return
	}
	if positionFunction == nil {
		return fmt.Errorf("function not found:%d", project.PositionFunctionId)
	}

	// 是否是管理岗位
	if project.IsManagerPosition != 1 && project.IsManagerPosition != 0 {
		return
	}

	// 层级是否存在
	positionLevel, err := models.PositionLevelsModel.SearchOne(db.Cond{"id": project.PositionLevelId, "is_deleted": 0})
	if err != nil {
		return
	}
	if positionLevel == nil {
		return fmt.Errorf("position level not found:%d", project.PositionFunctionId)
	}

	// 层级是否存在
	projectsScene, err := models.ProjectsScenesModel.SearchOne(db.Cond{"id": project.SceneId, "is_deleted": 0})
	if err != nil {
		return
	}
	if projectsScene == nil {
		return fmt.Errorf("position level not found:%d", project.PositionFunctionId)
	}

	project.GoalDesc = projectsScene.Name

	// 获取员工列表
	valid, err = staff.CheckStaffs(project.CompanyId, staffIds)
	if err != nil {
		return
	}
	if valid == false {
		return fmt.Errorf("staffids not valid:%d", project.PositionId)
	}

	if len(staffIds) == 0 {
		return fmt.Errorf("no staffids valid")
	}

	interviewConfigIds := []int{}
	for _, interviewConfigItemParam := range interviewConfigItemParams {
		interviewConfigIds = append(interviewConfigIds, interviewConfigItemParam.Id)

		// bei是否有效
		if interviewConfigItemParam.Id == interview.IntvBei {
			for _, item := range interviewConfigItemParam.SubItems {
				if item.Id < 1 || item.Id > 48 {
					return fmt.Errorf("bei subitem unvalid")
				}
			}
		}
		// todo 校验有效
		interviewsConfigsModel, err := models.InterviewsModel.SearchOne(db.Cond{
			"id":         interviewConfigItemParam.Id,
			"is_deleted": 0,
		})

		if err != nil {
			return err
		}

		if interviewsConfigsModel == nil {
			return fmt.Errorf("no interviews configs valid")
		}
	}

	if len(libraries.UniqueNumbers(interviewConfigIds)) != len(interviewConfigIds) {
		return fmt.Errorf("interviewConfigIds duplicate")
	}

	// 插入项目
	project.InterviewUsersCount = len(staffIds)
	project.IsDeleted = 1
	_, err = models.ProjectsModel.Insert(&project)
	if err != nil {
		return
	}
	// 员工
	staffs := []*models.ProjectsStaffs{}
	for _, staffId := range staffIds {
		staffs = append(staffs, &models.ProjectsStaffs{
			ProjectId: project.Id,
			StaffId:   staffId,
		})
	}
	if len(staffs) == 0 {
		return fmt.Errorf("no staff")
	}

	// 配置
	interviewsConfigs := []*models.ProjectsInterviewsConfigs{}
	for _, interviewConfigItemParam := range interviewConfigItemParams {
		config, err := json.Marshal(interviewConfigItemParam.SubItems)
		if err != nil {
			return err
		}
		interviewsConfigs = append(interviewsConfigs, &models.ProjectsInterviewsConfigs{
			ProjectId:        project.Id,
			InterviewId:      interviewConfigItemParam.Id,
			InterviewConfigs: string(config),
		})
	}
	// 新增的关键经历和工作选择价值观的维度配置, 子维度结构配置与之前的测评不同
	if intvConfigs != nil {
		// 工作选择价值观维度保存，工作选择价值观最多2个子维度，最少1个子维度
		workValuesSubItems := []*interview.ConfigSubItem{}
		if intvConfigs.WorkValues != nil && len(intvConfigs.WorkValues) != 0 {
			for _, id := range intvConfigs.WorkValues {
				newSubItem := &interview.ConfigSubItem{
					Id: id,
				}
				workValuesSubItems = append(workValuesSubItems, newSubItem)
			}
			if len(workValuesSubItems) > 0 {
				str, err := encoding.JSON.MarshalToString(workValuesSubItems)
				if err != nil {
					return err
				}
				interviewsConfigs = append(interviewsConfigs, &models.ProjectsInterviewsConfigs{
					ProjectId:        project.Id,
					InterviewId:      interview.IntvWorkValues,
					InterviewConfigs: str,
				})
			}
		}

		// 关键经历
		keyExprSubItems := []*interview.ConfigSubItem{}
		if intvConfigs.KeyExpr != nil {
			if intvConfigs.KeyExpr.ManageExpr != nil &&
				len(intvConfigs.KeyExpr.ManageExpr) != 0 {
				for _, id := range intvConfigs.KeyExpr.ManageExpr {
					newSubItem := &interview.ConfigSubItem{Id: id}
					keyExprSubItems = append(keyExprSubItems, newSubItem)
				}
			}
			if intvConfigs.KeyExpr.BusinessExpr != nil {
				for _, id := range intvConfigs.KeyExpr.BusinessExpr {
					newSubItem := &interview.ConfigSubItem{Id: id}
					keyExprSubItems = append(keyExprSubItems, newSubItem)
				}
			}
			if len(keyExprSubItems) > 0 { // 关键经历子维度个数大于0
				str, err := encoding.JSON.MarshalToString(keyExprSubItems)
				if err != nil {
					return err
				}
				interviewsConfigs = append(interviewsConfigs, &models.ProjectsInterviewsConfigs{
					ProjectId:        project.Id,
					InterviewId:      interview.IntvKeyExp,
					InterviewConfigs: str,
				})
			}
		}
	}

	// 插入员工
	_, err = models.ProjectsStaffsModel.Insert(staffs...)
	if err != nil {
		return
	}
	// 插入配置
	_, err = models.ProjectsInterviewsConfigsModel.Insert(interviewsConfigs...)
	if err != nil {
		return
	}

	// 事务补偿
	project.IsDeleted = 0
	_, err = models.ProjectsModel.Save(&project)
	if err != nil {
		return
	}
	return
}

type ProjectDetail struct {
	Id                int                             `json:"id"`
	Position          *dhr_staff.Position             `json:"position"`
	PositionIndustry  *models.PositionIndustries      `json:"position_industry"`
	PositionFunction  *models.PositionFunctions       `json:"position_function"`
	PositionLevel     *models.PositionLevels          `json:"position_level"`
	GoalDesc          string                          `json:"goal_desc"`
	SceneId           int                             `json:"scene_id"`
	IsManagerPosition int                             `json:"is_manager_position"`
	Desc              string                          `json:"desc"`
	Reports           []*models.ProjectsDistributions `json:"reports"`
	CreatedAt         time.Time                       `json:"created_at"`
}

// 获取详情
func (p *Projects) Detail(id int) (
	detail *ProjectDetail, err error) {
	project, err := models.ProjectsModel.SearchOne(db.Cond{
		"id":         id,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if project == nil {
		err = fmt.Errorf("project not found")
		return
	}
	position, err := dhr_staff.SysGetWithInvalidPositionById(nil, project.CompanyId, project.PositionId, false)
	if err != nil {
		return
	}
	if position == nil {
		return nil, fmt.Errorf("position not found:%d", project.Id)
	}
	positionIndustry, err := models.PositionIndustriesModel.SearchOne(db.Cond{
		"id":         project.PositionIndustryId,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if positionIndustry == nil {
		return nil, fmt.Errorf("position industry not found:%d", project.PositionIndustryId)
	}

	positionFunction, err := models.PositionFunctionsModel.SearchOne(db.Cond{
		"id":         project.PositionFunctionId,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if positionFunction == nil {
		return nil, fmt.Errorf("position function not found:%d", project.PositionFunctionId)
	}

	positionReports, err := models.ProjectsDistributionsModel.Search(db.Cond{
		"project_id": project.Id,
		"is_deleted": 0,
		"pagesize":   100,
	})
	if err != nil {
		return
	}
	if positionReports == nil {
		positionReports = []*models.ProjectsDistributions{}
	}
	/** 来自前端的需求
	  positionReports = append(positionReports, &models.ProjectsReports{
	  	Id:        0,
	  	Name:      project.Name + "最新采集计划",
	  	ProjectId: project.Id,
	  })
	  **/

	positionLevel, err := models.PositionLevelsModel.SearchOne(db.Cond{
		"id":         project.PositionLevelId,
		"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if positionLevel == nil {
		return nil, fmt.Errorf("position level not found:%d", project.PositionFunctionId)
	}

	return &ProjectDetail{
		Id:                project.Id,
		Position:          position,
		PositionIndustry:  positionIndustry,
		PositionFunction:  positionFunction,
		PositionLevel:     positionLevel,
		GoalDesc:          project.GoalDesc,
		SceneId:           project.SceneId,
		Desc:              project.Desc,
		Reports:           positionReports,
		IsManagerPosition: project.IsManagerPosition,
		CreatedAt:         project.CreatedAt,
	}, nil
}

// 返回二维码
func (p *Projects) Qrcode(id int) (content string) {
	return ""
}

type FinishedStatus struct {
	Id   int     `json:"id"`
	Name string  `json:"name"`
	Rate float64 `json:"rate"`
}

func (p *Projects) GetFinishedStatusTotal(finishedStatuses []*FinishedStatus) float64 {
	if len(finishedStatuses) == 0 {
		return 0
	}
	var a = 0.0
	for _, finishedStatus := range finishedStatuses {
		a += finishedStatus.Rate
	}
	return libraries.FixedThreeDigit(a / float64(len(finishedStatuses)))
}

func (p *Projects) GetFinishedStatus(projectId int) (finishedStatuses []*FinishedStatus, err error) {
	dataCollectPlans, err := models.DataCollectPlansModel.Search(db.Cond{
		"project_id": projectId,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}

	finishedStatuses = []*FinishedStatus{}
	cp := data_collect.NewDataCollectPlan()
	for _, dataCollectPlan := range dataCollectPlans {
		rate, err := cp.GetProcessRate(dataCollectPlan.Id)
		if err != nil {
			return nil, err
		}
		finishedStatuses = append(finishedStatuses, &FinishedStatus{
			Id:   dataCollectPlan.Id,
			Name: dataCollectPlan.Name,
			Rate: rate,
		})

	}
	return
}

// 获取有效的项目
func GetValidProject(companyId int, projectId int) (
	project *models.Projects, err error) {
	project, err = models.ProjectsModel.SearchOne(db.Cond{
		"company_id": companyId,
		"id":         projectId,
		"is_deleted": 0,
	})
	if err != nil {
		logger.Warn(err)
		return
	}
	if project == nil {
		err = fmt.Errorf("project not found: %d", projectId)
		err = common.NewRespErr(20304026, err)
		logger.Warn(err)
		return
	}
	return
}

// Delete 项目删除
func (p *Projects) Delete(companyID, projectID int) (err error) {
	proj, err := models.ProjectsModel.SearchOne(db.Cond{
		"company_id": companyID,
		"id":         projectID,
	})
	if err != nil {
		logger.Warn(err)
		err = common.NewRespErr(20305000, err)
		return
	}
	if proj == nil {
		err = common.NewRespErr(20304026, "project not exist")
		logger.Warn(err)
		return
	}
	proj.IsDeleted = 1
	_, err = models.ProjectsModel.Save(proj)
	if err != nil {
		err = common.NewRespErr(20305000, err)
		logger.Warn(err)
		return
	}
	return
}

func (p *Projects) Edit(companyID int, projectID int,
	newProjName string) (err error) {

	count, err := GetCountByProjectName(companyID, newProjName)
	if err != nil {
		logger.Warn(err)
		return
	}
	if count != 0 {
		err = common.NewRespErr(core.ProjectNameDuplicate,
			"project name duplicate")
		return
	}

	proj, err := GetValidProject(companyID, projectID)
	if err != nil {
		logger.Warn(err)
		return
	}

	proj.Name = newProjName
	_, err = models.ProjectsModel.Save(proj)
	if err != nil {
		err = common.NewRespErr(20305000, err)
		logger.Warn(err)
		return
	}

	return
}

// GetPositionsByCompanyID 获取所有项目的岗位列表
func (p *Projects) GetPositionsByCompanyID(companyID int) (ps []*dhr_staff.Position, err error) {

	projs, err := models.ProjectsModel.Search(db.Cond{
		"is_deleted": 0,
		"company_id": companyID,
	})
	if err != nil {
		err = common.NewRespErr(20305000, err)
		logger.Warn(err)
		return
	}

	positionIDs := []int{}
	for _, proj := range projs {
		positionIDs = append(positionIDs, proj.PositionId)
	}

	ps, err = dhr_staff.ListPositionByIds(nil, companyID, positionIDs, false)
	if err != nil {
		err = fmt.Errorf("dhr call dhr_staff err: <%+v>", err)
		logger.Warn(err)
		return
	}

	return
}

type InterviewItem struct {
	ID   int    `json:"interview_id"`
	Name string `json:"name"`
}

func GetInterviewItems(projectID int) ([]InterviewItem, error) {
	confs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"is_deleted": 0,
		"project_id": projectID,
		"orderby":    "interview_id",
		"is_show":    models.SHOW,
	})
	if err != nil {
		return nil, fmt.Errorf("GetInterviewItems models.ProjectsInterviewsConfigsModel.Search error: %v", err)
	}

	items := []InterviewItem{
		{ID: 0, Name: lambda.InterviewItemNames[0]},
	}

	for _, c := range confs {
		switch c.InterviewId {
		case lambda.InterviewPersonalityEval, lambda.InterviewKnowledge, lambda.InterviewWorkValues, lambda.InterviewKeyExperience:
			goto FILTER
		}
		items = append(items, InterviewItem{
			ID:   c.InterviewId,
			Name: lambda.InterviewItemNames[c.InterviewId],
		})
	FILTER:
	}
	return items, nil
}

// GetCountByProjectName 获取同名项目数
func GetCountByProjectName(companyID int, projectName string) (count int64, err error) {
	count, err = models.ProjectsModel.Count(db.Cond{
		"name":       projectName,
		"company_id": companyID,
		"is_deleted": 0,
	})
	return
}

func GetProjectIdByName(companyID int, projectName string) (projects []*models.Projects, err error) {
	projects, err = models.ProjectsModel.Search(db.Cond{
		"where":      fmt.Sprintf("name like '%%%s%%'", projectName),
		"company_id": companyID,
		"is_deleted": 0,
	})
	return
}

func GetProjects() (projects []*models.Projects, err error) {
	projects, err = models.ProjectsModel.Search(db.Cond{
		"is_deleted": 0,
	})
	return
}

type GetProjectListParams struct {
	Session        string `json:"session"`
	CompanyId      int    `json:"company_id"`
	UserId         int    `json:"user_id"`
	Key            string `json:"key"`
	PositionIds    []int  `json:"position_ids"`
	Page           int    `json:"page"`
	PageSize       int    `json:"page_size"`
	RoleType       int    `json:"role_type"`
	DataPermission int    `json:"data_permission"`
	RoleIds        []int  `json:"role_ids"`
}

type ProjectSceneTemplateIdGetter []*models.Projects

func (p ProjectSceneTemplateIdGetter) GetId(i int) int {
	return p[i].SceneTemplateId
}

func (p ProjectSceneTemplateIdGetter) Len() int {
	return len(p)
}

func GetProjectList(httpCtx *hfw.HTTPContext, params *GetProjectListParams, filter string) (result []*ProjectsListResult, total int64, err error) {
	projects, total, err := projectsList(params, filter)
	if err != nil {
		return
	}

	// 处理模版
	templateIds := utils.GetIds(ProjectSceneTemplateIdGetter(projects))
	if len(templateIds) > 0 {
		templates, err := models.ProjectsScenesTemplateModel.Search(db.Cond{"is_deleted": 0, "id in": templateIds})
		if err != nil {
			return nil, 0, err
		}
		for idx, project := range projects {
			for _, template := range templates {
				if project.SceneTemplateId == template.Id {
					projects[idx].GoalDesc = template.Name
				}
			}
		}
	}

	result, err = parseProjects(httpCtx, projects, params)
	return
}

// 获取项目列表
func projectsList(params *GetProjectListParams, filter string) (result []*models.Projects, total int64, err error) {
	defer func() {
		if err != nil {
			logger.Errorf("call projectsList failed. err: [%v]", err)
		}
	}()

	projectIDMap := make(map[int]struct{})
	if filter == "data_collect" {
		projectIDMap, err = dataPlan2ProjectIDList()
		if err != nil {
			return
		}
	}
	logger.Infof("filter: %#v", projectIDMap)

	userID2ProjectList := make(map[int][]*models.Projects)
	projectIDs := make([]int, 0, len(projectIDMap))
	projects, err := models.ProjectsModel.Search(db.Cond{"company_id": params.CompanyId, "is_deleted": 0})
	for _, project := range projects {
		userID2ProjectList[project.UserId] = append(userID2ProjectList[project.UserId], project)
		if _, ok := projectIDMap[project.Id]; ok {
			continue
		}
		projectIDs = append(projectIDs, project.Id)
	}
	logger.Infof("noFilter: %#v", projectIDs)

	if params.RoleType == 2 {
		dataPermission, err := permission.JudgeResourceDataPermission(&permission.JudgeDataPermissionReq{
			RoleIds:   params.RoleIds,
			CompanyID: params.CompanyId,
			ModuleKey: "bot_module_project", // 标识项目模块
		})
		if err != nil {
			return result, total, err
		}

		// 除了自己的也还要能看见：直属下级、虚拟下级创建的项目 by max
		if dataPermission == 2 {
			projectsPermissions, err := models.ProjectsPermissionsModel.Search(db.Cond{"company_id": params.CompanyId, "user_id": params.UserId, "is_deleted": 0})
			if err != nil {
				return result, total, err
			}

			userList, err := permission.GetPermissionUserList(params.Session)
			if err != nil {
				return result, total, err
			}

			tmpProjectList := make([]*models.Projects, 0, len(userID2ProjectList))
			tmpProjectList = append(tmpProjectList, userID2ProjectList[params.UserId]...)
			for _, each := range userList.UserList {
				tmpProjectList = append(tmpProjectList, userID2ProjectList[each.UserId]...)
			}

			projectIDs = make([]int, 0, len(userID2ProjectList))
			for _, v := range projectsPermissions {
				if _, ok := projectIDMap[v.ProjectId]; ok {
					continue
				}
				projectIDs = append(projectIDs, v.ProjectId)
			}

			for _, v := range tmpProjectList {
				if _, ok := projectIDMap[v.Id]; ok {
					continue
				}
				projectIDs = append(projectIDs, v.Id)
			}
			logger.Infof("noFilter: %#v", projectIDs)
		}
	}

	cond := db.Cond{
		"is_deleted": 0,
		"company_id": params.CompanyId,
		"id in":      projectIDs,
		"page":       params.Page,
		"pagesize":   params.PageSize,
		"orderby":    "id desc",
	}
	if len(params.Key) >= 1 {
		cond["where"] = fmt.Sprintf("name like '%%%s%%'", params.Key)
	}
	if len(params.PositionIds) > 0 {
		cond["position_id in"] = params.PositionIds
	}

	result, err = models.ProjectsModel.Search(cond)
	if err != nil {
		return
	}

	projectDistributions, err := models.ProjectsDistributionsModel.Search(db.Cond{
		"is_deleted":    0,
		"project_id in": projectIDs,
		"orderby":       "created_at desc",
	})
	if err != nil {
		return result, total, err
	}
	projectID2Distribution := make(map[int]*models.ProjectsDistributions)
	for _, p := range projectDistributions {
		if _, ok := projectID2Distribution[p.ProjectId]; ok {
			continue
		}
		projectID2Distribution[p.ProjectId] = p
	}
	for _, project := range result {
		pd, ok := projectID2Distribution[project.Id]
		if !ok {
			continue
		}
		project.ReportId = pd.Id
	}

	delete(cond, "page")
	delete(cond, "pagesize")
	total, err = models.ProjectsModel.Count(cond)
	return
}

func dataPlan2ProjectIDList() (projectIDMap map[int]struct{}, err error) {
	dataCollectPlans, err := models.DataCollectPlansModel.Search(db.Cond{"is_deleted": 0})
	if err != nil {
		return
	}
	projectIDMap = make(map[int]struct{})
	if len(dataCollectPlans) > 0 {
		for _, v := range dataCollectPlans {
			projectIDMap[v.ProjectId] = struct{}{}
		}
	}
	return
}

type ProjectsListResult struct {
	Id                  int               `json:"id"`
	SceneId             int               `json:"scene_id"`
	Name                string            `json:"name"`
	Position            string            `json:"position"`
	InterviewUsersCount int               `json:"interview_users_count"`
	FinishedStatus      []*FinishedStatus `json:"finished_status"`
	FinishedStatusRate  float64           `json:"finished_status_rate"`
	GoalDesc            string            `json:"goal_desc"`
	StartAt             time.Time         `json:"start_at"`
	OwnerUsername       string            `json:"owner_username"`
	IsOwned             bool              `json:"is_owned"`
	RoleType            int               `json:"role_type"`
	ReportId            int               `json:"report_id"`
}

// 解析项目列表
func parseProjects(httpCtx *hfw.HTTPContext, params []*models.Projects, params2 *GetProjectListParams) (result []*ProjectsListResult, err error) {
	length := len(params)
	if length > 0 {
		userIds := make([]int, 0, length)
		userMap := make(map[int]int)
		positionIDs := make([]int, 0, length)
		userIds = append(userIds, params2.UserId)
		for i := 0; i < length; i++ {
			positionIDs = append(positionIDs, params[i].PositionId)
			if userMap[params[i].UserId] == 0 {
				userMap[params[i].UserId] = params[i].UserId
				userIds = append(userIds, params[i].UserId)
			}
		}
		if len(userIds) == 0 {
			return result, common.NewRespErr(core.RequestError, "ids 为空")
		}
		positions, err := dhr_staff.SysListWithInvalidPositionByIds(nil, params2.CompanyId, positionIDs, false)
		if err != nil {
			return result, err
		}

		getUserInfoParams := &libraries.GetUserInfoParams{
			Ids:       userIds,
			CompanyId: params2.CompanyId,
		}
		userInfoMap, err := libraries.GetUserInfo(httpCtx, getUserInfoParams)
		if err != nil {
			return result, err
		}
		result = make([]*ProjectsListResult, 0, length)
		for i := 0; i < length; i++ {
			projectL := NewProjects()
			finishedStatus, err := projectL.GetFinishedStatus(params[i].Id)
			if err != nil {
				return result, err
			}
			var isOwned bool
			dataUserId := params[i].UserId
			if dataUserId == params2.UserId {
				isOwned = true
			}
			data := userInfoMap[dataUserId]
			if data == nil {
				logger.Debugf("@@@@@@@@@@@@@@@@@@@@")
				continue
			}
			result = append(result, &ProjectsListResult{
				Id:                  params[i].GetId(),
				Name:                params[i].GetName(),
				SceneId:             params[i].GetSceneId(),
				Position:            GetPositionName(positions, params[i].GetPositionId()),
				InterviewUsersCount: params[i].GetInterviewUsersCount(),
				FinishedStatus:      finishedStatus,
				FinishedStatusRate:  projectL.GetFinishedStatusTotal(finishedStatus),
				GoalDesc:            params[i].GoalDesc,
				StartAt:             params[i].StartAt,
				OwnerUsername:       data.UserName,
				IsOwned:             isOwned,
				RoleType:            params2.RoleType,
				ReportId:            params[i].ReportId,
			})
		}
	}
	return
}

func GetPositionName(positions []*dhr_staff.Position, id int) (name string) {
	name = "岗位被删除"
	for _, p := range positions {
		if p.Id == id {
			name = p.Name
			return
		}
	}
	return
}
