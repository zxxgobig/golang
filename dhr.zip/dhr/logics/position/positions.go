package position

import (
    "gitlab.ifchange.com/bot/hfwkit/dhr_staff"

    "ifchange/dhr/core"
    "ifchange/dhr/libraries"
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
)

// GetPlansPositions 获取公司采集计划的岗位列表
func GetPlansPositions(companyID int) (ps []*dhr_staff.Position, err error) {
    res, err := models.DataCollectPlansModel.Search(db.Cond{
        "is_deleted": 0,
    })
    if err != nil {
        err = common.NewRespErr(core.SystemErrNo, err)
        logger.Warn(err)
        return
    }

    positionIDs := []int{}
    for _, p := range res {
        positionIDs = append(positionIDs, p.PositionId)
    }
    positionIDs = libraries.UniqueNumbers(positionIDs)

    ps, err = dhr_staff.ListPositionByIds(nil, companyID, positionIDs, false)
    if err != nil {
        logger.Warn(err)
        return
    }
    if len(ps) == 0 {
        ps = []*dhr_staff.Position{}
    }
    return
}

// GetProjectsPositions
func GetProjectsPositions(companyID int) (ps []*dhr_staff.Position, err error) {
    projs, err := models.ProjectsModel.Search(db.Cond{
        "company_id": companyID,
        "is_deleted": 0,
    })
    if err != nil {
        logger.Warn(err)
        return
    }
    if len(projs) == 0 {
        logger.Infof("company_id: <%+v> has no projects", companyID)
        return
    }
    positionIDs := []int{}
    for _, proj := range projs {
        positionIDs = append(positionIDs, proj.PositionId)
    }

    ps, err = dhr_staff.ListPositionByIds(nil, companyID, positionIDs, false)
    if err != nil {
        logger.Warn(err)
        return
    }
    if len(ps) == 0 {
        ps = []*dhr_staff.Position{}
    }
    return
}

func GetPositionsByIDs(companyID int, positionIDs []int) (ps []*dhr_staff.Position, err error) {

    // 第二个参数为nil的时候表示全量
    return dhr_staff.ListPositionByIds(nil, companyID, positionIDs, false)
}

// PositionsByProjectIDs 根据项目id列表获取岗位列表
// var projectPosition map[int]string
//                     map[projectID]positionName
func GetPositionsByProjectIDs(
    companyID int, projectIDs []int) (projPosMap map[int]string, err error) {

    positionIDs := []int{}
    projs, err := models.ProjectsModel.GetByIds(projectIDs)
    if err != nil {
        err = common.NewRespErr(20305000, err)
        logger.Warn(err)
        return
    }

    for _, proj := range projs {
        positionIDs = append(positionIDs, proj.PositionId)
    }

    // 岗位详情列表
    positions, err := dhr_staff.ListPositionByIds(nil, companyID, positionIDs, false)
    if err != nil {
        return
    }

    for _, proj := range projs {
        for _, pos := range positions {
            if proj.PositionId == pos.Id {
                projPosMap[proj.Id] = pos.Name
            }
        }
    }

    return
}
