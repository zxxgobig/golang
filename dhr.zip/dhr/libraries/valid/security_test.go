package valid

import (
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/common_service/security"
	"ifchange/dhr/models"
	"testing"
)

func TestInsertEmail(t *testing.T) {
	mail := new(models.MailResend)
	mail.Email = "ifchange@ifchange.com"
	affected, err := models.MailResendModel.Insert(mail)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(affected)
}

func TestSearchEmail(t *testing.T) {
	mail, err := models.MailResendModel.SearchOne(db.Cond{
		"id":         162,
		"is_deleted": 0,
	})
	if err != nil {
		t.Fatal(err)
	}
	t.Log(mail.Email)
}

func TestCrypt(t *testing.T) {
	deStr := "D95324172A2D69090D3CAB3E13C246CE"
	de, _ := security.NewSecurityManagerImpl().Decrypt(deStr)
	t.Log("Decrypt ", de)

	enStr := "15601811126"
	en, _ := security.NewSecurityManagerImpl().Encrypt(enStr)
	t.Log("Encrypt", en)
}
