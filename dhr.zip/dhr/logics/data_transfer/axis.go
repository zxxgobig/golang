package data_transfer

func GetName(interviewId, subItem int) string {
	if interviewId == 1 {
		return QualityAxes[subItem].Name
	} else if interviewId == 2 {
		return PersonalityAxes[subItem].Name
	} else if interviewId == 5 {
		return PotentialAxes[subItem].Name
	} else if interviewId == 6 {
		return JobChoiceValueAxesMap[subItem].Name
	}
	return ""
}

// Axis 测评维度
type Axis struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
	//English string `json:"english"`
}

// QualityAxes 素质维度
var QualityAxes = map[int]Axis{
	1:  {1, "推理分析"},
	2:  {2, "业务视角"},
	3:  {3, "归纳思维"},
	4:  {4, "搜集信息"},
	5:  {5, "团队协作"},
	6:  {6, "战略思维"},
	7:  {7, "灵活应变"},
	8:  {8, "自信"},
	9:  {9, "高效协同"},
	10: {10, "关注细节"},
	11: {11, "发展他人"},
	12: {12, "诚信正直"},
	13: {13, "建立关系"},
	14: {14, "组织忠诚"},
	15: {15, "组织洞察"},
	16: {16, "有效督导"},
	17: {17, "组织变革"},
	18: {18, "情绪管理"},
	19: {19, "跨文化视野"},
	20: {20, "社会责任"},
	21: {21, "营造客户文化"},
	22: {22, "主动行动"},
	23: {23, "追求卓越"},
	24: {24, "人际影响"},
	25: {25, "客户导向"},
	26: {26, "理解他人"},
	27: {27, "团队领导"},
}

// PersonalityAxes 性格维度
var PersonalityAxes = map[int]Axis{
	1:  {1, "客观"},
	2:  {2, "自觉自律"},
	3:  {3, "责任感"},
	4:  {4, "创新精神"},
	5:  {5, "坚韧不拔"},
	6:  {6, "合群"},
	7:  {7, "关心他人"},
	8:  {8, "敬业精神"},
	9:  {9, "品质意识"},
	10: {10, "业绩意识"},
	11: {11, "沟通意识"},
	12: {12, "精力水平"},
	13: {13, "开放分享"},
	14: {14, "同理心"},
	15: {15, "风险偏好"},
	16: {16, "信任他人"},
	17: {17, "适应变化"},
	18: {18, "民主精神"},
	19: {19, "率先垂范"},
	20: {20, "助人为乐"},
	21: {21, "风险意识"},
}

// PotentialAxes 潜力维度
var PotentialAxes = map[int]Axis{
	1: {1, "敏锐学习能力"},
	2: {2, "跨界思考能力"},
	3: {3, "情感管理能力"},
	4: {4, "人际感知能力"},
}

var InterviewItemNames = map[int]string{
	0:  "综合能力",
	1:  "素质",
	2:  "性格",
	3:  "专业知识技能",
	4:  "专业知识技能",
	5:  "潜力",
	6:  "工作选择价值观",
	7:  "关键经历",
	8:  "情绪智力测评",
	9:  "批判思维测评",
	10: "管理实践能力测评",
	11: "职业人格测验",
	12: "性格风险",
	13: "领导风格",
	14: "组织忠诚度量表",
}

// 工作选择价值观
var JobChoiceValueAxesMap = map[int]Axis{
	1:  {ID: 1, Name: "收入与财富"},
	2:  {ID: 2, Name: "兴趣特长"},
	3:  {ID: 3, Name: "权利地位"},
	4:  {ID: 4, Name: "自由独立"},
	5:  {ID: 5, Name: "自我实现"},
	6:  {ID: 6, Name: "人际关系"},
	7:  {ID: 7, Name: "身心健康"},
	8:  {ID: 8, Name: "组织稳定"},
	9:  {ID: 9, Name: "工作稳定"},
	10: {ID: 10, Name: "组织需要"},
	11: {ID: 11, Name: "追求新意"},
}

var KeyExperienceAxesMap = map[int]Axis{
	1:  {ID: 1, Name: "多经营单元负责人管理经历"},
	2:  {ID: 2, Name: "单一经营单元负责人管理经历"},
	3:  {ID: 3, Name: "多部门分管领导经历"},
	4:  {ID: 4, Name: "单一部门负责人管理经历"},
	5:  {ID: 5, Name: "不同部门管理经历"},
	6:  {ID: 6, Name: "团队主管经历"},
	7:  {ID: 7, Name: "无管理经历"},
	8:  {ID: 8, Name: "组建团队"},
	9:  {ID: 9, Name: "扭转士气"},
	10: {ID: 10, Name: "市场开拓"},
	11: {ID: 11, Name: "多业态管理"},
	12: {ID: 12, Name: "新业务孵化"},
	13: {ID: 13, Name: "产品/服务创新"},
	14: {ID: 14, Name: "关键交易/谈判"},
	15: {ID: 15, Name: "危机处理"},
	16: {ID: 16, Name: "扭转业绩"},
	17: {ID: 17, Name: "收购兼并"},
	18: {ID: 18, Name: "海外经历"},
	19: {ID: 19, Name: "业务轮岗"},
	20: {ID: 20, Name: "重大项目"},
	21: {ID: 21, Name: "承担盈亏"},
	22: {ID: 22, Name: "技术/专业突破"},
	23: {ID: 23, Name: "行业转换"},
	24: {ID: 24, Name: "职能建设"},
	25: {ID: 25, Name: "推动组织变革"},
	26: {ID: 26, Name: "关停并转"},
	27: {ID: 27, Name: "经历重大组织变革"},
}

type InterviewAxis struct {
	InterviewID int
	AxisID      int
}

var AxisNameToInterviewIDAxisID = map[string]InterviewAxis{}
var EmotionalIntelligenceAxesMap = map[int]Axis{
	1: {ID: 1, Name: "评价情绪"},
	2: {ID: 2, Name: "觉知情绪"},
	3: {ID: 3, Name: "调控情绪"},
	4: {ID: 4, Name: "表现情绪"},
	5: {ID: 5, Name: "运用情绪"},
}

var EmotionalIntelligenceSecondAxesMap = map[int]map[int]Axis{
	1: {1: {ID: 1, Name: "评价他人的情绪"}, 2: {ID: 2, Name: "评价自己的情绪"}},
	2: {1: {ID: 1, Name: "觉知自己的情绪"}, 2: {ID: 2, Name: "觉知他人的情绪"}, 3: {ID: 3, Name: "人际洞察"}},
	3: {1: {ID: 1, Name: "调控自己的情绪"}, 2: {ID: 2, Name: "调控他人的情绪"}},
}

var CriticalThinkingAxesMap = map[int]Axis{
	1: {ID: 1, Name: "分析"},
	2: {ID: 2, Name: "推断"},
	3: {ID: 3, Name: "解释"},
	4: {ID: 4, Name: "评价"},
}

var PracticalIntelligenceAxesMap = map[int]Axis{
	1:  {ID: 1, Name: "战略思考"},
	2:  {ID: 2, Name: "大局意识"},
	3:  {ID: 3, Name: "关系建立"},
	4:  {ID: 4, Name: "愿景激励"},
	5:  {ID: 5, Name: "变革创新"},
	6:  {ID: 6, Name: "识人用人"},
	7:  {ID: 7, Name: "组织建设"},
	8:  {ID: 8, Name: "资源整合"},
	9:  {ID: 9, Name: "商业敏感"},
	10: {ID: 10, Name: "追求卓越"},
}

var OccupationalPersonalityAxesMap = map[int]Axis{
	1: {ID: 1, Name: "成就动机"},
	2: {ID: 2, Name: "责任意识"},
	3: {ID: 3, Name: "开放创新"},
	4: {ID: 4, Name: "团结协作"},
	5: {ID: 5, Name: "外向活跃"},
	6: {ID: 6, Name: "积极情绪"},
}

var OccupationalPersonalitySecondAxesMap = map[int]map[int]Axis{
	1: {1: {ID: 1, Name: "成就动机"}, 2: {ID: 2, Name: "主动"}, 3: {ID: 3, Name: "坚韧"}},
	2: {1: {ID: 1, Name: "负责"}, 2: {ID: 2, Name: "严谨"}, 3: {ID: 3, Name: "计划"}, 4: {ID: 4, Name: "自律"}},
	3: {1: {ID: 1, Name: "学习精神"}, 2: {ID: 2, Name: "创新"}, 3: {ID: 3, Name: "独立"}, 4: {ID: 4, Name: "灵活"}, 5: {ID: 5, Name: "想象"}},
	4: {1: {ID: 1, Name: "信任"}, 2: {ID: 2, Name: "宽容"}, 3: {ID: 3, Name: "合作"}, 4: {ID: 4, Name: "关爱"}, 5: {ID: 5, Name: "同理心"}},
	5: {1: {ID: 1, Name: "社交"}, 2: {ID: 2, Name: "活跃"}, 3: {ID: 3, Name: "支配"}, 4: {ID: 4, Name: "自信"}},
	6: {1: {ID: 1, Name: "情绪稳定"}, 2: {ID: 2, Name: "乐观"}, 3: {ID: 3, Name: "希望"}, 4: {ID: 4, Name: "抗压"}},
}

var PersonalityDisorderAxesMap = map[int]Axis{
	1: {ID: 1, Name: "分裂型"},
	2: {ID: 2, Name: "边缘型"},
	3: {ID: 3, Name: "反社会型"},
	4: {ID: 4, Name: "表演型"},
	5: {ID: 5, Name: "依赖型"},
	6: {ID: 6, Name: "偏执型"},
	7: {ID: 7, Name: "自恋型"},
}

var LeadershipStyleAxesMap = map[int]Axis{
	1: {ID: 1, Name: "命令型"},
	2: {ID: 2, Name: "教练型"},
	3: {ID: 3, Name: "支持型"},
	4: {ID: 4, Name: "授权型"},
}

var OrgCommitmentAxesMap = map[int]Axis{
	1: {ID: 1, Name: "价值认同"},
	2: {ID: 2, Name: "情感投入"},
	3: {ID: 3, Name: "理想承诺"},
	4: {ID: 4, Name: "敬业奉献"},
	5: {ID: 5, Name: "建言献策"},
	6: {ID: 6, Name: "团结协助"},
	7: {ID: 7, Name: "积极配合"},
	8: {ID: 8, Name: "维护公利"},
}
