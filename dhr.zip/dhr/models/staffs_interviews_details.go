package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var StaffsInterviewsDetailsModel = &StaffsInterviewsDetails{}

func init() {
	var err error
	StaffsInterviewsDetailsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	//StaffsInterviewsDetailsModel.Dao.EnableCache(StaffsInterviewsDetailsModel)
	//StaffsInterviewsDetailsModel.Dao.DisableCache(StaffsInterviewsDetailsModel)
	//gob: type not registered for interface
	gob.Register(StaffsInterviewsDetailsModel)
}

type StaffsInterviewsDetails struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id               int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	ProjectId        int       `json:"project_id" xorm:"not null comment('项目id') INT(11)"`
	StaffId          int       `json:"staff_id" xorm:"not null default 0 comment('用户id') INT(11)"`
	InterviewId      int       `json:"interview_id" xorm:"not null default 0 comment('试题id') INT(11)"`
	DataCollectId    int       `json:"data_collect_id" xorm:"not null default 0 comment('采集id') INT(11)"`
	SubItem          int       `json:"sub_item" xorm:"not null default 0 comment('子维度') INT(11)"`
	SecondarySubItem int       `json:"secondary_sub_item" xorm:"not null default 0 INT(11)"`
	OrginScore       string    `json:"orgin_score" xorm:"not null TEXT"`
	Tag              string    `json:"tag" xorm:"not null default '' comment('标签') VARCHAR(64)"`
	Score            float64   `json:"score" xorm:"not null default 0.00 comment('得分') DOUBLE(11,2)"`
	Frequency        int       `json:"frequency" xorm:"not null default 0 INT(11)"`
	Status           int       `json:"status" xorm:"not null default 0 comment('0 创建完成 1正在答题 2完成') TINYINT(1)"`
	IsDeleted        int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
	UpdatedAt        time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
	CreatedAt        time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
}

func (m *StaffsInterviewsDetails) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *StaffsInterviewsDetails) GetProjectId() (val int) {
	if m == nil {
		return
	}
	return m.ProjectId
}

func (m *StaffsInterviewsDetails) GetStaffId() (val int) {
	if m == nil {
		return
	}
	return m.StaffId
}

func (m *StaffsInterviewsDetails) GetInterviewId() (val int) {
	if m == nil {
		return
	}
	return m.InterviewId
}

func (m *StaffsInterviewsDetails) GetDataCollectId() (val int) {
	if m == nil {
		return
	}
	return m.DataCollectId
}

func (m *StaffsInterviewsDetails) GetSubItem() (val int) {
	if m == nil {
		return
	}
	return m.SubItem
}

func (m *StaffsInterviewsDetails) GetSecondarySubItem() (val int) {
	if m == nil {
		return
	}
	return m.SecondarySubItem
}

func (m *StaffsInterviewsDetails) GetOrginScore() (val string) {
	if m == nil {
		return
	}
	return m.OrginScore
}

func (m *StaffsInterviewsDetails) GetTag() (val string) {
	if m == nil {
		return
	}
	return m.Tag
}

func (m *StaffsInterviewsDetails) GetScore() (val float64) {
	if m == nil {
		return
	}
	return m.Score
}

func (m *StaffsInterviewsDetails) GetFrequency() (val int) {
	if m == nil {
		return
	}
	return m.Frequency
}

func (m *StaffsInterviewsDetails) GetStatus() (val int) {
	if m == nil {
		return
	}
	return m.Status
}

func (m *StaffsInterviewsDetails) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *StaffsInterviewsDetails) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *StaffsInterviewsDetails) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *StaffsInterviewsDetails) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *StaffsInterviewsDetails) TableName() string {
	return "staffs_interviews_details"
}

func (m *StaffsInterviewsDetails) Save(t ...*StaffsInterviewsDetails) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *StaffsInterviewsDetails
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *StaffsInterviewsDetails) Saves(t []*StaffsInterviewsDetails) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *StaffsInterviewsDetails) Insert(t ...*StaffsInterviewsDetails) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *StaffsInterviewsDetails
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *StaffsInterviewsDetails) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *StaffsInterviewsDetails) SearchOne(cond db.Cond) (t *StaffsInterviewsDetails, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *StaffsInterviewsDetails) Search(cond db.Cond) (t []*StaffsInterviewsDetails, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *StaffsInterviewsDetails) SearchAndCount(cond db.Cond) (t []*StaffsInterviewsDetails, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *StaffsInterviewsDetails) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *StaffsInterviewsDetails) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *StaffsInterviewsDetails) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *StaffsInterviewsDetails) GetMulti(ids ...interface{}) (t []*StaffsInterviewsDetails, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *StaffsInterviewsDetails) GetByIds(ids ...interface{}) (t []*StaffsInterviewsDetails, err error) {
	return m.GetMulti(ids...)
}

func (m *StaffsInterviewsDetails) GetById(id interface{}) (t *StaffsInterviewsDetails, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *StaffsInterviewsDetails) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *StaffsInterviewsDetails) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *StaffsInterviewsDetails) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *StaffsInterviewsDetails) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *StaffsInterviewsDetails) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewStaffsInterviewsDetails(c ...interface{}) (m *StaffsInterviewsDetails, err error) {
	m = &StaffsInterviewsDetails{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *StaffsInterviewsDetails) Close() {
	m.Dao.Close()
}

func (m *StaffsInterviewsDetails) Begin() error {
	return m.Dao.Begin()
}

func (m *StaffsInterviewsDetails) Rollback() error {
	return m.Dao.Rollback()
}

func (m *StaffsInterviewsDetails) Commit() error {
	return m.Dao.Commit()
}
