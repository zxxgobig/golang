package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var InterviewsModel = &Interviews{}

func init() {
	var err error
	InterviewsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	InterviewsModel.Dao.EnableCache(InterviewsModel)
	//InterviewsModel.Dao.DisableCache(InterviewsModel)
	//gob: type not registered for interface
	gob.Register(InterviewsModel)
}

type Interviews struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id           int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	Name         string    `json:"name" xorm:"not null default '' comment('试题名称') VARCHAR(32)"`
	Enname       string    `json:"enname" xorm:"not null default '' comment('英文名') VARCHAR(32)"`
	TakeTime     int       `json:"take_time" xorm:"not null default 0 comment('耗时 秒') INT(11)"`
	SubitemCount int       `json:"subitem_count" xorm:"not null default 0 comment('子维度数量') INT(11)"`
	NeedSubitem  int       `json:"need_subitem" xorm:"not null default 0 comment('是否需要子维度 1 需要') TINYINT(1)"`
	Desc         string    `json:"desc" xorm:"not null default '' comment('试题描述') VARCHAR(128)"`
	ProductId    int       `json:"product_id" xorm:"not null default 0 comment('产品id') INT(11)"`
	Config       string    `json:"config" xorm:"not null comment('所有的维度') LONGTEXT"`
	Editable     int       `json:"editable" xorm:"not null default 0 comment('是否可以增加子维度') INT(11)"`
	IsDeleted    int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
	UpdatedAt    time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
	CreatedAt    time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
}

func (m *Interviews) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *Interviews) GetName() (val string) {
	if m == nil {
		return
	}
	return m.Name
}

func (m *Interviews) GetEnname() (val string) {
	if m == nil {
		return
	}
	return m.Enname
}

func (m *Interviews) GetTakeTime() (val int) {
	if m == nil {
		return
	}
	return m.TakeTime
}

func (m *Interviews) GetSubitemCount() (val int) {
	if m == nil {
		return
	}
	return m.SubitemCount
}

func (m *Interviews) GetNeedSubitem() (val int) {
	if m == nil {
		return
	}
	return m.NeedSubitem
}

func (m *Interviews) GetDesc() (val string) {
	if m == nil {
		return
	}
	return m.Desc
}

func (m *Interviews) GetProductId() (val int) {
	if m == nil {
		return
	}
	return m.ProductId
}

func (m *Interviews) GetConfig() (val string) {
	if m == nil {
		return
	}
	return m.Config
}

func (m *Interviews) GetEditable() (val int) {
	if m == nil {
		return
	}
	return m.Editable
}

func (m *Interviews) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *Interviews) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *Interviews) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *Interviews) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *Interviews) TableName() string {
	return "interviews"
}

func (m *Interviews) Save(t ...*Interviews) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *Interviews
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *Interviews) Saves(t []*Interviews) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *Interviews) Insert(t ...*Interviews) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *Interviews
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *Interviews) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *Interviews) SearchOne(cond db.Cond) (t *Interviews, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *Interviews) Search(cond db.Cond) (t []*Interviews, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *Interviews) SearchAndCount(cond db.Cond) (t []*Interviews, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *Interviews) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *Interviews) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *Interviews) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *Interviews) GetMulti(ids ...interface{}) (t []*Interviews, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *Interviews) GetByIds(ids ...interface{}) (t []*Interviews, err error) {
	return m.GetMulti(ids...)
}

func (m *Interviews) GetById(id interface{}) (t *Interviews, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *Interviews) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *Interviews) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *Interviews) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *Interviews) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *Interviews) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewInterviews(c ...interface{}) (m *Interviews, err error) {
	m = &Interviews{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *Interviews) Close() {
	m.Dao.Close()
}

func (m *Interviews) Begin() error {
	return m.Dao.Begin()
}

func (m *Interviews) Rollback() error {
	return m.Dao.Rollback()
}

func (m *Interviews) Commit() error {
	return m.Dao.Commit()
}
