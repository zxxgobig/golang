package interview

import (
    "encoding/json"
    "fmt"
    "ifchange/dhr/core"
    logicsCommon "ifchange/dhr/logics/common"
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfw/encoding"
    "gitlab.ifchange.com/bot/hfwkit/career_assessment"
    "gitlab.ifchange.com/bot/hfwkit/utils"
    career_assessment_pb "gitlab.ifchange.com/bot/proto/career_assessment"
)

type WorkValues struct {
    Config *Config
}

func (n *WorkValues) SaveVoice(param interface{}) (err error) {
	return nil
}

func NewWorkValues() *WorkValues {
    return &WorkValues{}
}

func (n *WorkValues) SetConfig(config interface{}) (err error) {
    var ok bool
    n.Config, ok = config.(*Config)
    if !ok {
        n.Config = nil
    }
    if n.Config.EmailUuid == "" {
        n.Config.EmailUuid, err = utils.CreateUuid(n.Config)
        if err != nil {
            return common.NewRespErr(20305000, err)
        }
    }
    //n.Config.EmailUuid, err = utils.CreateUuid(n.Config)
    n.Config.Uuid = n.Config.EmailUuid
    n.Config.Uuid, err = utils.CreateUuid(n.Config)
    if err != nil {
        return err
    }
    return err
}

func (n *WorkValues) Create(c []ConfigSubItem) (result interface{}, err error) {
    projectData, err := logicsCommon.GetValidProject(n.Config.CompanyID, n.Config.ProjectID)
    if err != nil {
        return result, err
    }
    if projectData == nil {
        return result, fmt.Errorf("项目不存在")
    }

    params := &career_assessment_pb.WorkValuesCreateRequest{
        UniqueId: n.Config.Uuid,
    }

    result, err = career_assessment.WorkValuesCreate(n.Config.HttpCtx, params)
    return result, err
}

func (n *WorkValues) Get(uuid string, param interface{}) (t interface{}, err error) {
    params := &career_assessment_pb.WorkValuesGetRequest{
        UniqueId: uuid,
    }
    t, err = career_assessment.WorkValuesGet(nil, params)
    return t, err
}
func (n *WorkValues) Commit(uuid string, p interface{}) (t interface{}, err error) {

    _param := p.(json.RawMessage)
    str, err := _param.MarshalJSON()
    if err != nil {
        return t, err
    }
    params := &career_assessment_pb.WorkValuesCommitRequest{}
    err = json.Unmarshal(str, params)
    if err != nil {
        return t, err
    }
    params.UniqueId = uuid
    t, err = career_assessment.WorkValuesCommit(nil, params)
    return t, err
}

type CommitWorkValues struct {
    EmailUuid  string `json:"email_uuid"`
    Feedback   string `json:"feedback"`
    OrginScore string `json:"orgin_score"`
    Score      int    `json:"score"`
}

func (n *WorkValues) ResultCommit(interviewID int, emailUuid string, params interface{}) (err error) {
    param := params.([]*career_assessment_pb.WorkValuesResults)
    paramsBytes, err := encoding.JSON.Marshal(param)
    if err != nil {
        return err
    }
    err = logicsCommon.UpdateStaffsInterview(emailUuid, string(paramsBytes), param, interviewID)
    if err != nil {
        return err
    }
    return
}

func (n *WorkValues) CheckFinished(response interface{}) (isFinished bool, err error) {
    return
}

// GetIsMust 是否必须, 1 必须； 0 非必须
func (n *WorkValues) GetIsMust() int {
    return 0
}

// GetAllSubItems 获取全部维度
func (n *WorkValues) GetAllSubItems(industryID, functionID,
    positionLevelID, sceneID int) (subItems []*ConfigSubItem, err error) {
    subItems = []*ConfigSubItem{}
    wv, err := models.InterviewsModel.SearchOne(db.Cond{
        "is_deleted": 0,
        "id":         IntvWorkValues,
    })
    if err != nil {
        return
    }

    if wv == nil {
        err = common.NewRespErr(core.DbQueryNotExist, fmt.Sprintf("the interview: <%+v> not exist", IntvWorkValues))
        return
    }
    err = encoding.JSON.UnmarshalFromString(wv.Config, &subItems)

    return
}

// GetRecommendSubItems 获取推荐维度（目前无
func (n *WorkValues) GetRecommendSubItems(industryID, functionID,
    positionLevelID, sceneID int) (recommendSubItems []*ConfigSubItem, err error) {
    recommendSubItems = []*ConfigSubItem{}
    return
}
