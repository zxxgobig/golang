package controllers

import (
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"

    "ifchange/dhr/core"
    v2_function "ifchange/dhr/logics/v2/function"
)

/**
 * @api {post} /v2_project/function_list 基础数据 - 职能列表
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 职能列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object} results.list 列表
 * @apiSuccess {Number} results.list.id 职能 ID
 * @apiSuccess {String} results.list.name 职能名称
 * @apiSuccess {Object[]} results.list.children 子级职能列表
 * @apiSuccess {Number} results.list.children.id 子级职能 ID
 * @apiSuccess {String} results.list.children.name 子级职能名称
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"list": [
			{
				"id": 1,
				"name": "IT/通信/电子/互联网",
				"parent_id": 0,
				"depth": 1,
				"children": [
					{
						"id": 2,
						"name": "互联网",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 53,
						"name": "IT-综合",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 414,
						"name": "计算机软件",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 415,
						"name": "计算机硬件",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 416,
						"name": "计算机服务(系统、数据服务、维修)",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 417,
						"name": "通信/电信/网络设备",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 418,
						"name": "通信/电信运营、增值服务",
						"parent_id": 1,
						"depth": 2,
						"children": null
					},
					{
						"id": 419,
						"name": "电子技术/半导体/集成电路",
						"parent_id": 1,
						"depth": 2,
						"children": null
					}
				]
			},
			{
				"id": 513,
				"name": "金融",
				"parent_id": 0,
				"depth": 1,
				"children": [
					{
						"id": 537,
						"name": "银行",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 538,
						"name": "保险",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 539,
						"name": "证券",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 540,
						"name": "基金",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 541,
						"name": "信托",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 542,
						"name": "担保",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 543,
						"name": "典当",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 544,
						"name": "拍卖",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 545,
						"name": "投资",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 546,
						"name": "期货",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 678,
						"name": "资产管理",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 679,
						"name": "金融租赁",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 680,
						"name": "征信及信评机构",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 681,
						"name": "资产评估机构",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 683,
						"name": "金融监管机构",
						"parent_id": 513,
						"depth": 2,
						"children": null
					},
					{
						"id": 809,
						"name": "金融服务",
						"parent_id": 513,
						"depth": 2,
						"children": null
					}
				]
			}
		]
	}
 *
*/
func (p *V2Project) FunctionList(httpCtx *hfw.HTTPContext) {
    params := &struct {
        *Session
    }{}
    httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
    //sess := httpCtx.Ctx.Value("session").(*session.Session)

    result, err := v2_function.FunctionLogic.ProjectCreateUsedList()
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = result
}
