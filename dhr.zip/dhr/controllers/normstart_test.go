package controllers

import (
    "ifchange/dhr/logics/interview"
    "testing"
)

// func init() {
// //	_ = hfw.Handler("/norm_star", &NormStarService{})
// //}

func TestNormStarService_Callback(t *testing.T) {
    dimScore := `{"客观": 1}`
    params := &interview.NormStarCallbackParams{
        DimScore: dimScore,
        StaffID:  1,
    }
    err := interview.NormStarCallback(params)
    if err != nil {
        t.Error(err)
    }
    // _ = test.Do(t, "/norm_star/callback", params)
}
