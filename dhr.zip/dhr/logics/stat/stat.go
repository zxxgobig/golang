package stat

// 前端需要根据 report_id 做唯一标识，但对于多个项目的实时数据，report_id 都为 0 ;-<<<
func detrick(reportID int) int {
	if reportID > 10000000 {
		return 0
	}

	return reportID
}

// 员工详情-盘点分布
type InventoryDistributionResult struct {
	StaffID        int             `json:"staff_id"`         // 员工ID
	StaffAvatarURL string          `json:"staff_avatar_url"` // 员工头像URL
	Distributions  []*Distribution `json:"distributions"`    // 员工盘点分布列表
	Pros           []string        `json:"pros"`             // 个人优势
	Cons           []string        `json:"cons"`             // 个人劣势
	Advice         []*Advice       `json:"advice"`           // 个人发展建议
}

// 盘点分布列表
type Distribution struct {
	InterviewId int64   `json:"interview_id"` // zero far all
	Grids       []*Grid `json:"grids"`        // 九宫格
}

// 九宫格
type Grid struct {
	AxisX     int64  `json:"axis_x"`     // 分布位置坐标 x 轴
	AxisY     int64  `json:"axis_y"`     // 分布位置坐标 y 轴
	Name      string `json:"name"`       // 分布位置名称
	RecordAt  int64  `json:"record_at"`  // 分布记录时间
	ProjectID int    `json:"project_id"` // 项目ID
}

type Advice struct {
	AxisID   int      `json:"axis_id"`
	AxisName string   `json:"axis_name"`
	Advice   []string `json:"advice"`
}

type ProfessionalSkillsResult struct {
	StaffID            int           `json:"staff_id"`
	ProfessionalSkills *ResponseData `json:"professional_skills"`
	data               EvalAxes
}

type PotentialResult struct {
	StaffID   int      `json:"staff_id"`
	Potential EvalAxes `json:"potential"`
}

type InterviewResult struct {
	StaffID int           `json:"staff_id,omitempty"`
	Score   float64       `json:"score,omitempty"`
	Avg     float64       `json:"avg,omitempty"`
	Data    *ResponseData `json:"data"`
}

type QualityResult struct {
	StaffID int           `json:"staff_id"`
	Quality *ResponseData `json:"quality"`
	data    EvalAxes
}

type PerformanceResult struct {
	StaffID     int                         `json:"staff_id"`
	Performance *PerformanceInterviewResult `json:"performance"`
}

type PerformanceInterviewResult struct {
	Level  string   `json:"level"`
	Labels []string `json:"labels"`
	Desc   string   `json:"desc"`
}

type PersonalityEvalResult struct {
	StaffID         int                             `json:"staff_id"`
	PersonalityEval *PersonalityEvalInterviewResult `json:"personality_eval"`
}

type PersonalityEvalInterviewResult struct {
	Pros EvalAxes `json:"pros"`
	Cons EvalAxes `json:"cons"`
}

type InventorySwitchSceneResult struct {
	StaffID int     `json:"staff_id"` // 员工ID
	Grids   []*Grid `json:"grids"`    // 九宫格
}
