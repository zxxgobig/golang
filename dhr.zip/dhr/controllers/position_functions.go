package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/position"

    "gitlab.ifchange.com/bot/hfwkit/api"

    "gitlab.ifchange.com/bot/hfw"
)

type PositionFunctions struct {
    core.Controller
}

/**
 * @api {post} /position_functions/list 职级列表
 * @apiVersion 0.1.0
 * @apiGroup Position
 * @apiDescription 职级列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
 {
	"session":""
 }
 *
 * @apiSuccess {Number} results.total 总数
 * @apiSuccess {Object[]} results.list 列表
 * @apiSuccess {Object} results.list.item 一级职级
 * @apiSuccess {Object} results.list.sub_items 子职级
 *
 * @apiSuccessExample {json} Response-Example:
 {
    "total":0,
    "list":[
        {
            "item":{
                "id":61382,
                "function_id":1200018,
                "name":"通用管理",
                "parent_id":0,
                "depth":1,
                "is_deleted":0,
                "updated_at":"1560999235",
                "created_at":"1560999235"
            },
            "sub_items":[
                {
                    "id":61476,
                    "function_id":2200094,
                    "name":"通用管理",
                    "parent_id":1200018,
                    "depth":2,
                    "is_deleted":0,
                    "updated_at":"1560999235",
                    "created_at":"1560999235"
                }
            ]
        }
    ]
 }
 *
*/

func (c *PositionFunctions) List(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        Page            int `json:"page"`
        PageSize        int `json:"page_size"`
    }{}
    err := api.RequestUnmarshal(httpCtx, &param)
    httpCtx.ThrowCheck(20304001, err)
    result, total, err := position.NewPositionFunctions().List(param.Page, param.PageSize)
    httpCtx.ThrowCheck(20304001, err)

    httpCtx.Results = ListResult{
        Total: total,
        List:  result,
    }
}
