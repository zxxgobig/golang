package interview

import (
    "context"
    "encoding/json"
    "fmt"
    "gitlab.ifchange.com/bot/hfwkit/utils"
    "ifchange/dhr/core"
    logcisCommon "ifchange/dhr/logics/common"

    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/encoding"
    "gitlab.ifchange.com/bot/hfwkit/config"
    "gitlab.ifchange.com/bot/hfwkit/grpc/client"
    pb "gitlab.ifchange.com/bot/proto/dhr_potential"
    "google.golang.org/grpc"
)

type Potential struct {
    Config *Config
}

func (p *Potential) SaveVoice(param interface{}) (err error) {
	return nil
}

func (p *Potential) SetConfig(config interface{}) (err error) {
    var ok bool
    p.Config, ok = config.(*Config)
    if !ok {
        p.Config = nil
    }
    if p.Config.EmailUuid == "" {
        p.Config.EmailUuid, err = utils.CreateUuid(p.Config)
        if err != nil {
            return err
        }
    }
    p.Config.Uuid = p.Config.EmailUuid
    p.Config.Uuid, err = utils.CreateUuid(p.Config)
    if err != nil {
        return err
    }
    return err
}
func (p *Potential) Create(c []ConfigSubItem) (result interface{}, err error) {
    params := pb.PotentialCreateRequest{
        UniqueId: p.Config.Uuid,
        Recruit:  1,
    }
    resp, err := client.Do(nil, config.GetGrpcServers().DhrPotential, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewPotentialClient(conn).Create(ctx, &params)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }
    _ = resp.(bool)
    return
}

func (p *Potential) Get(uuid string, param interface{}) (t interface{}, err error) {
    return nil, fmt.Errorf("Potential.Get not support ")
}

func (p *Potential) Commit(uuid string, param interface{}) (t interface{}, err error) {
    potentialCommitRequest := pb.AnswerQuestionRequest{}

    if param != nil {
        _param := param.(json.RawMessage)
        str, err := _param.MarshalJSON()

        err = json.Unmarshal(str, &potentialCommitRequest)
        if err != nil {
            return nil, err
        }
    } else {
        potentialCommitRequest.UniqueId = uuid
    }

    resp, err := client.Do(nil, config.GetGrpcServers().DhrPotential, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewPotentialClient(conn).AnswerQuestion(ctx, &potentialCommitRequest)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }

    result := resp.(*pb.AnswerQuestionResult)
    return result, nil
}

func (p *Potential) ResultCommit(interviewID int, emailUuid string, params interface{}) (err error) {
    paramBytes, err := encoding.JSON.Marshal(params)
    if err != nil {
        return common.NewRespErr(core.SystemErrNo, err)
    }
    err = logcisCommon.UpdateStaffsInterview(emailUuid, string(paramBytes), params, interviewID)
    if err != nil {
        return err
    }
    return
}

func (p *Potential) CheckFinished(response interface{}) (isFinished bool, err error) {
    if response == nil {
        err = fmt.Errorf("potential response unvalid")
        return
    }
    res := response.(*pb.AnswerQuestionResult)
    return res.IsFinish == true, nil
}
