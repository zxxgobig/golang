package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/data_collect_plan", &DataCollectPlan{})
}

func TestDataCollectPlan_Create(t *testing.T) {
    param := struct {
        *Session
        ProjectID int    `json:"project_id"`
        Name      string `json:"name"`
        StartTime string `json:"start_time"`
        EndTime   string `json:"end_time"`
    }{
        Session: &Session{
            SessionID: "eyjmcm9tijoiqiisinnyy19pzci6mswibwfuywdlcl9pzci6mta5lcjjb21wyw55x2lkijoxmdksinvzzxjfawqiojewoswizxhwaxjlijoxntyxndi4odq4lcjzawduyxr1cmuioijimge1ndzindeymjhlmwixzmu3zjrjztrhogrjmjm1zdm4ntq0zme4iiwidxnlcl90exblijoyfq==",
        },
        ProjectID: 1,
        Name:      "产品信息采集",
        StartTime: "2019-06-19 00:00:00",
        EndTime:   "2019-07-05 00:00:00",
    }
    _ = test.Do(t, "/data_collect_plan/create", param)
}
func TestDataCollectPlan_Users(t *testing.T) {
    param := struct {
        *Session
        PlanId int `json:"plan_id"`
    }{
        Session: &Session{
            SessionID: "eyJmcm9tIjoiQiIsInNyY19pZCI6MSwibWFuYWdlcl9pZCI6MTA5LCJjb21wYW55X2lkIjoxMDksInVzZXJfaWQiOjEwOSwiZXhwaXJlIjoxNTYxNDI4ODQ4LCJzaWduYXR1cmUiOiJiMGE1NDZiNDEyMjhlMWIxZmU3ZjRjZTRhOGRjMjM1ZDM4NTQ0ZmE4IiwidXNlcl90eXBlIjoyfQ==",
        },
        PlanId: 1,
    }
    _ = test.Do(t, "/data_collect_plan/users", param)
}

/*
go test ./controllers -run TestDataCollectPlanPositions -v
*/
func TestDataCollectPlanPositions(t *testing.T) {
    session, _ := GetSession()
    params := struct {
        *Session
    }{
        Session: &Session{
            SessionID: session,
        },
    }

    res := test.Do(t, "/data_collect_plan/positions", &params)
    b, _ := res.Results.MarshalJSON()
    t.Logf("%+s", b)
}

/*
go test ./controllers -run TestGetRecentList -v -count=1
* */
func TestGetRecentList(t *testing.T) {
    session, _ := GetSession()
    params := struct {
        *Session
    }{
        Session: &Session{
            SessionID: session,
        },
    }

    res := test.Do(t, "/data_collect_plan/recent_list", &params)
    b, _ := res.Results.MarshalJSON()
    t.Logf("%+s", b)
}

/*
go test ./controllers -run TestProgressAnalysis -v -count=1
* */
func TestProgressAnalysis(t *testing.T) {
    session, _ := GetSession()
    params := struct {
        *Session
        PlanID      int `json:"id"`
        InterviewID int `json:"interview_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        PlanID:      244,
        InterviewID: 5,
    }
    res := test.Do(t, "/data_collect_plan/progress_analysis", &params)
    b, _ := res.Results.MarshalJSON()
    t.Logf("%+s", b)
}
