package controllers

import (
	"ifchange/dhr/core"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"ifchange/dhr/logics/data_collect"
	"ifchange/dhr/logics/project/permission"
)

/**
 * @api {post} /data_collect_plan/send_notice 一键提醒
 * @apiVersion 0.1.0
 * @apiGroup CollectionPlan
 * @apiDescription 一键提醒
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} plan_id 采集计划ID
 * @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1
}
 *
 *
 * @apiSuccessExample {json} Response-Example:
{
}
 *
*/
func (plan *DataCollectPlan) SendNotice(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		PlanID int `json:"plan_id"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, reqParam))

	noticeLog := data_collect.NewDataCollectNoticeLog()
	err = noticeLog.OnceRemind(reqParam.PlanID)
	httpCtx.ThrowCheck(20304030, err)

	httpCtx.Results = ""
}

/**
 * @api {post} /data_collect_plan/evaluation_link 重新发送测评链接
 * @apiVersion 0.1.0
 * @apiGroup CollectionPlan
 * @apiDescription 重新发送测评链接
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} plan_id 采集计划ID
 * @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1
}
 *
 *
 * @apiSuccessExample {json} Response-Example:
{
}
 *
*/
func (plan *DataCollectPlan) EvaluationLink(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		PlanID int `json:"plan_id"`
	}{}

	curUser, err := ValidateAndUnMarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	if curUser.RoleType != 1 {
		// check data permission
		_, err = permission.IsCollectionPlanOwnedByUser(curUser.Id, reqParam.PlanID)
		httpCtx.ThrowCheck(20305001, err)
	}

	noticeLog := data_collect.NewDataCollectNoticeLog()
	err = noticeLog.EvaluationLink(reqParam.PlanID)
	httpCtx.ThrowCheck(20304030, err)

	httpCtx.Results = ""
}

/**
 * @api {post} /data_collect_plan/notice_staff 提醒员工
 * @apiVersion 0.1.0
 * @apiGroup CollectionPlan
 * @apiDescription 提醒员工
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} plan_id 采集计划ID
 * @apiParam {Number} staff_id 员工ID
 * @apiParam {String} notice_target 提醒目标normal/leader
 * @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1,
    "staff_id":1,
    "notice_target":"normal/leader"
}
 *
 *
 * @apiSuccessExample {json} Response-Example:
{
}
 *
*/
func (plan *DataCollectPlan) NoticeStaff(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		PlanID       int    `json:"plan_id"`
		StaffID      int    `json:"staff_id"`
		NoticeTarget string `json:"notice_target"`
	}{}

	_, err := ValidateAndUnMarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	noticeLog := data_collect.NewDataCollectNoticeLog()
	err = noticeLog.NoticeStaff(reqParam.PlanID, reqParam.StaffID, reqParam.NoticeTarget)
	httpCtx.ThrowCheck(20304030, err)

	httpCtx.Results = ""
}
