package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var DataCollectPlanStaffsModel = &DataCollectPlanStaffs{}

func init() {
	var err error
	DataCollectPlanStaffsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	DataCollectPlanStaffsModel.Dao.EnableCache(DataCollectPlanStaffsModel)
	//DataCollectPlanStaffsModel.Dao.DisableCache(DataCollectPlanStaffsModel)
	//gob: type not registered for interface
	gob.Register(DataCollectPlanStaffsModel)
}

type DataCollectPlanStaffs struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id                      int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	PlanId                  int       `json:"plan_id" xorm:"not null default 0 comment('采集任务id') INT(11)"`
	StaffId                 int       `json:"staff_id" xorm:"not null default 0 comment('用户id') INT(11)"`
	Skill                   int       `json:"skill" xorm:"not null default 0 comment('专业技能状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	Knowledge               int       `json:"knowledge" xorm:"not null default 0 comment('专业知识状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	Bei                     int       `json:"bei" xorm:"not null default 0 comment('素质状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	Potential               int       `json:"potential" xorm:"not null default 0 comment('潜力状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	Normstar                int       `json:"normstar" xorm:"not null default 0 comment('性格状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	KeyExpr                 int       `json:"key_expr" xorm:"not null default 0 comment('关键经历状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	WorkValues              int       `json:"work_values" xorm:"not null default 0 comment('工作选择价值观状态（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	EmotionalIntelligence   int       `json:"emotional_intelligence" xorm:"not null default 0 comment('情绪智力（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	CriticalThinking        int       `json:"critical_thinking" xorm:"not null default 0 comment('批判思维（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	PracticalIntelligence   int       `json:"practical_intelligence" xorm:"not null default 0 comment('管理实践能力（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	OccupationalPersonality int       `json:"occupational_personality" xorm:"not null default 0 comment('职业人格（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	PersonalityDisorder     int       `json:"personality_disorder" xorm:"not null default 0 comment('偏离因素（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	LeadershipStyle         int       `json:"leadership_style" xorm:"not null default 0 comment('领导风格（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	OrgCommitment           int       `json:"org_commitment" xorm:"not null default 0 comment('组织忠诚度（1未采集，2已采集，3不需要采集）') TINYINT(1)"`
	IsDeleted               int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
	UpdatedAt               time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
	CreatedAt               time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
}

func (m *DataCollectPlanStaffs) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *DataCollectPlanStaffs) GetPlanId() (val int) {
	if m == nil {
		return
	}
	return m.PlanId
}

func (m *DataCollectPlanStaffs) GetStaffId() (val int) {
	if m == nil {
		return
	}
	return m.StaffId
}

func (m *DataCollectPlanStaffs) GetSkill() (val int) {
	if m == nil {
		return
	}
	return m.Skill
}

func (m *DataCollectPlanStaffs) GetKnowledge() (val int) {
	if m == nil {
		return
	}
	return m.Knowledge
}

func (m *DataCollectPlanStaffs) GetBei() (val int) {
	if m == nil {
		return
	}
	return m.Bei
}

func (m *DataCollectPlanStaffs) GetPotential() (val int) {
	if m == nil {
		return
	}
	return m.Potential
}

func (m *DataCollectPlanStaffs) GetNormstar() (val int) {
	if m == nil {
		return
	}
	return m.Normstar
}

func (m *DataCollectPlanStaffs) GetKeyExpr() (val int) {
	if m == nil {
		return
	}
	return m.KeyExpr
}

func (m *DataCollectPlanStaffs) GetWorkValues() (val int) {
	if m == nil {
		return
	}
	return m.WorkValues
}

func (m *DataCollectPlanStaffs) GetEmotionalIntelligence() (val int) {
	if m == nil {
		return
	}
	return m.EmotionalIntelligence
}

func (m *DataCollectPlanStaffs) GetCriticalThinking() (val int) {
	if m == nil {
		return
	}
	return m.CriticalThinking
}

func (m *DataCollectPlanStaffs) GetPracticalIntelligence() (val int) {
	if m == nil {
		return
	}
	return m.PracticalIntelligence
}

func (m *DataCollectPlanStaffs) GetOccupationalPersonality() (val int) {
	if m == nil {
		return
	}
	return m.OccupationalPersonality
}

func (m *DataCollectPlanStaffs) GetPersonalityDisorder() (val int) {
	if m == nil {
		return
	}
	return m.PersonalityDisorder
}

func (m *DataCollectPlanStaffs) GetLeadershipStyle() (val int) {
	if m == nil {
		return
	}
	return m.LeadershipStyle
}

func (m *DataCollectPlanStaffs) GetOrgCommitment() (val int) {
	if m == nil {
		return
	}
	return m.OrgCommitment
}

func (m *DataCollectPlanStaffs) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *DataCollectPlanStaffs) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *DataCollectPlanStaffs) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *DataCollectPlanStaffs) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *DataCollectPlanStaffs) TableName() string {
	return "data_collect_plan_staffs"
}

func (m *DataCollectPlanStaffs) Save(t ...*DataCollectPlanStaffs) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *DataCollectPlanStaffs
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *DataCollectPlanStaffs) Saves(t []*DataCollectPlanStaffs) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *DataCollectPlanStaffs) Insert(t ...*DataCollectPlanStaffs) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *DataCollectPlanStaffs
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *DataCollectPlanStaffs) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *DataCollectPlanStaffs) SearchOne(cond db.Cond) (t *DataCollectPlanStaffs, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *DataCollectPlanStaffs) Search(cond db.Cond) (t []*DataCollectPlanStaffs, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *DataCollectPlanStaffs) SearchAndCount(cond db.Cond) (t []*DataCollectPlanStaffs, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *DataCollectPlanStaffs) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *DataCollectPlanStaffs) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *DataCollectPlanStaffs) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *DataCollectPlanStaffs) GetMulti(ids ...interface{}) (t []*DataCollectPlanStaffs, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *DataCollectPlanStaffs) GetByIds(ids ...interface{}) (t []*DataCollectPlanStaffs, err error) {
	return m.GetMulti(ids...)
}

func (m *DataCollectPlanStaffs) GetById(id interface{}) (t *DataCollectPlanStaffs, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *DataCollectPlanStaffs) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *DataCollectPlanStaffs) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *DataCollectPlanStaffs) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *DataCollectPlanStaffs) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *DataCollectPlanStaffs) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewDataCollectPlanStaffs(c ...interface{}) (m *DataCollectPlanStaffs, err error) {
	m = &DataCollectPlanStaffs{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *DataCollectPlanStaffs) Close() {
	m.Dao.Close()
}

func (m *DataCollectPlanStaffs) Begin() error {
	return m.Dao.Begin()
}

func (m *DataCollectPlanStaffs) Rollback() error {
	return m.Dao.Rollback()
}

func (m *DataCollectPlanStaffs) Commit() error {
	return m.Dao.Commit()
}
