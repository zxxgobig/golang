package project

import (
    "ifchange/dhr/logics/interview"
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
)

type ProjectsScenes struct {
    *models.ProjectsScenes
    Enable bool `json:"enable"`
}

func NewProjectsScenes() *ProjectsScenes {
    return new(ProjectsScenes)
}

// List 场景列表接口，需要怎样是否选择属性，project_id 为 0 时候，直接返回场景列表
func (p *ProjectsScenes) List(companyID, projectID int) (
    modelsList []*ProjectsScenes, err error) {

    var ps []*models.ProjectsScenes
    if projectID == 0 {
        ps, err = models.ProjectsScenesModel.Search(db.Cond{
            "is_deleted": 0,
            "orderby":    "id asc",
        })
        if err != nil {
            logger.Warn(err)
            return
        }
        for _, p := range ps {
            newPs := &ProjectsScenes{}
            newPs.Enable = true
            newPs.ProjectsScenes = p
            modelsList = append(modelsList, newPs)
        }
        return
    }

    defaultEnable := false
    configs := []*models.ProjectsInterviewsConfigs{}

    proj, err := GetValidProject(companyID, projectID)
    if err != nil {
        return nil, err
    }

    configs, err = interview.
        GetInterviewsConfigsByProjectID(proj.Id)
    if err != nil {
        logger.Warn(err)
        return
    }

    for _, config := range configs {
        if config.InterviewId == interview.IntvPotential { // 潜力
            defaultEnable = true
        }
    }

    ps, err = models.ProjectsScenesModel.Search(db.Cond{
        "is_deleted": 0,
        "orderby":    "id asc",
    })
    if err != nil {
        err = common.NewRespErr(20305000, err)
        logger.Warn(err)
        return nil, err
    }

    for _, scene := range ps {
        projScene := &ProjectsScenes{}
        projScene.ProjectsScenes = scene
        projScene.Enable = true
        if projScene.Id == 3 { // 识别高潜人才
            projScene.Enable = defaultEnable
        }
        modelsList = append(modelsList, projScene)
    }
    return modelsList, nil
}
