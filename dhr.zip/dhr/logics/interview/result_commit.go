package interview

import (
	"context"
	"strconv"
	"time"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/career_assessment"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/grpc/client"
	"gitlab.ifchange.com/bot/logger"
	career_assessment_pb "gitlab.ifchange.com/bot/proto/career_assessment"
	potential "gitlab.ifchange.com/bot/proto/dhr_potential"
	skills "gitlab.ifchange.com/bot/proto/professional_skills"
	"google.golang.org/grpc"

	"ifchange/dhr/core"
	logicsCommon "ifchange/dhr/logics/common"
	"ifchange/dhr/models"
)

func GetResult(params *logicsCommon.GetResultParams) (err error) {
	result := new(models.StaffsInterviews)
	if params.Id != 0 {
		result, err = logicsCommon.GetInterviewById(params.Id)
		if err != nil {
			return err
		}
	} else if params.Uuid != "" {
		if params.InterviewId == 0 {
			result, err = logicsCommon.GetInterviewByUuid(params.Uuid)
			if err != nil {
				return err
			}
		} else {
			result, err = logicsCommon.GetInterviewByUuidAndInterviewId(params.Uuid, params.InterviewId)
			if err != nil {
				return err
			}
		}
	}

	switch result.InterviewId {
	case IntvBei:
		uuid, err := strconv.Atoi(result.Uuid)

		p := api.NewPost("", "")
		p.P = &struct {
			InterviewID int `json:"interview_id"`
		}{
			InterviewID: uuid,
		}
		data := &logicsCommon.CommitBeiParams{}
		err = api.SimpleCurl(nil, config.GetServers().BotBei+"interview_result", p, &data)
		if err != nil {
			return common.NewRespErr(core.BeiError, err)
		}
		if data.IsFinished == 0 {
			return common.NewRespErr(core.BeiError, "Bei IsFinished = 0")
		}
		logger.Debugf("Bei Result: %+v", data)
		err = ResultCommit(result.InterviewId, result.EmailUuid, data)

	case IntvNormstar:

	case IntvPotential:
		params := &potential.PotentialResultsRequest{UniqueId: result.Uuid}
		data, err := GetPotentialResults(nil, params)
		if err != nil {
			return err
		}
		logger.Debugf("PotentialResults: %+v", data)
		err = ResultCommit(result.InterviewId, result.EmailUuid, data)

	case IntvSkill:
		params := &skills.EvaluateResultsRequest{UniqueId: result.Uuid}
		data, err := GetProfessionalSkillsResults(nil, params)
		if err != nil {
			return err
		}
		logger.Debugf("EvaluateResults: %+v", data)
		err = ResultCommit(result.InterviewId, result.EmailUuid, data)

	case IntvWorkValues:
		params := &career_assessment_pb.WorkValuesResultsRequest{UniqueId: result.Uuid}
		data, err := career_assessment.WorkValuesResults(nil, params)
		if err != nil {
			return err
		}
		logger.Debugf("WorkValuesResults: %+v", data)
		err = ResultCommit(result.InterviewId, result.EmailUuid, data)

	case IntvKeyExp:
		params := &career_assessment_pb.KeyExperienceResultsRequest{UniqueId: result.Uuid}
		data, err := career_assessment.KeyExperienceResults(nil, params)
		if err != nil {
			return err
		}
		logger.Debugf("KeyExperienceResults: %+v", data)
		err = ResultCommit(result.InterviewId, result.EmailUuid, data)

	case IntvEmotionalIntelligence, IntvCriticalThinking, IntvPracticalIntelligence, IntvOccupationalPersonality,
		IntvPersonalityDisorder, IntvLeadershipStyle, IntvOrgCommitment, ManagementQuality:
		p := api.NewPost("", "")
		if params.UserId == 0 {
			params.UserId = result.StaffId
			params.InterviewId = result.InterviewId
			params.Uuid = result.Uuid
		}
		p.P = params
		data := &logicsCommon.ThirdEvaluationResult{}
		err = api.SimpleCurl(nil, config.AppConfig.Custom["ThirdEvaluation"]+"get_report", p, &data)
		if err != nil {
			return err
		}
		logger.Debugf("^^^^^^^^^^: %#v", data)
		err = ResultCommit(result.InterviewId, result.EmailUuid, data)
	}

	return
}

func ResultCommit(interviewId int, emailUuid string, param interface{}) (err error) {
	inter := CreateInterview(interviewId)
	err = inter.ResultCommit(interviewId, emailUuid, param)
	return
}

func GetPotentialResults(httpCtx *hfw.HTTPContext, params *potential.PotentialResultsRequest) (result []*potential.PotentialResult, err error) {
	logger.Debugf("PotentialResultsRequest params: %#v", params)

	resp, err := client.Do(httpCtx, config.GetGrpcServers().DhrPotential,
		func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
			res, err := potential.NewPotentialClient(conn).Results(ctx, params)
			if err != nil {
				return nil, common.NewRespErr(core.PotentialResultsRequestError, err)
			}
			if res.GetErrNo() != 0 {
				return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
			}
			return res.GetResults(), nil
		}, 3*time.Second)

	if err != nil {
		return result, common.NewRespErr(core.PotentialResultsRequestError, err)
	}

	res := resp.([]*potential.PotentialResult)
	logger.Debugf("PersonalityEval GetNormStarUrl return: %#v", res)

	return res, nil
}

func GetProfessionalSkillsResults(httpCtx *hfw.HTTPContext, params *skills.EvaluateResultsRequest) (result []*skills.Answer, err error) {
	logger.Debugf("PotentialResultsRequest params: %#v", params)

	resp, err := client.Do(httpCtx, config.GetGrpcServers().ProfessionalSkills,
		func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
			res, err := skills.NewEvaluateClient(conn).Results(ctx, params)
			if err != nil {
				return nil, common.NewRespErr(core.ProfessionalSkillsResultsRequestError, err)
			}
			if res.GetErrNo() != 0 {
				return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
			}
			return res.GetResults(), nil
		}, 3*time.Second)

	if err != nil {
		return result, common.NewRespErr(core.ProfessionalSkillsResultsRequestError, err)
	}

	res := resp.([]*skills.Answer)
	logger.Debugf("GetProfessionalSkillsResults return: %#v", res)

	return res, nil
}
