package project

import (
	"gitlab.ifchange.com/bot/hfw/db"
	"ifchange/dhr/models"
)

// 获取项目列表
func GetProjectSimpleList(params *GetProjectListParams) (result []*models.Projects, total int64, err error) {
	cond := db.Cond{
		"is_deleted": 0,
		"company_id": params.CompanyId,
		"page":       params.Page,
		"pagesize":   params.PageSize,
		"orderby":    "id desc",
	}

	result, err = models.ProjectsModel.Search(cond)
	if err != nil {
		return
	}

	delete(cond, "page")
	delete(cond, "pagesize")

	total, err = models.ProjectsModel.Count(cond)
	return
}
