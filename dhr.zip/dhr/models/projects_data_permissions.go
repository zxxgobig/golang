package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var ProjectsDataPermissionsModel = &ProjectsDataPermissions{}

func init() {
	var err error
	ProjectsDataPermissionsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	ProjectsDataPermissionsModel.Dao.EnableCache(ProjectsDataPermissionsModel)
	//ProjectsDataPermissionsModel.Dao.DisableCache(ProjectsDataPermissionsModel)
	//gob: type not registered for interface
	gob.Register(ProjectsDataPermissionsModel)
}

type ProjectsDataPermissions struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id           int       `json:"id" xorm:"not null pk autoincr comment('自增 id') INT(11)"`
	ProjectType  int       `json:"project_type" xorm:"not null comment('项目类型,1：自己创建的；2：被分享的') INT(1)"`
	ResourceType int       `json:"resource_type" xorm:"not null comment('资源类型：1，项目；2，采集计划') INT(1)"`
	ResourceKey  string    `json:"resource_key" xorm:"not null comment('按钮权限数据 resource key') VARCHAR(64)"`
	Permission   int       `json:"permission" xorm:"not null comment('按钮权限数据 resource value：1， write；2，read；3，hidden') INT(1)"`
	IsDeleted    int       `json:"is_deleted" xorm:"not null default 0 comment('is_deleted') INT(1)"`
	CreatedAt    time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created comment('创建时间') TIMESTAMP"`
	UpdatedAt    time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated comment('更新时间') TIMESTAMP"`
}

func (m *ProjectsDataPermissions) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *ProjectsDataPermissions) GetProjectType() (val int) {
	if m == nil {
		return
	}
	return m.ProjectType
}

func (m *ProjectsDataPermissions) GetResourceType() (val int) {
	if m == nil {
		return
	}
	return m.ResourceType
}

func (m *ProjectsDataPermissions) GetResourceKey() (val string) {
	if m == nil {
		return
	}
	return m.ResourceKey
}

func (m *ProjectsDataPermissions) GetPermission() (val int) {
	if m == nil {
		return
	}
	return m.Permission
}

func (m *ProjectsDataPermissions) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *ProjectsDataPermissions) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *ProjectsDataPermissions) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *ProjectsDataPermissions) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *ProjectsDataPermissions) TableName() string {
	return "projects_data_permissions"
}

func (m *ProjectsDataPermissions) Save(t ...*ProjectsDataPermissions) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsDataPermissions
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *ProjectsDataPermissions) Saves(t []*ProjectsDataPermissions) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *ProjectsDataPermissions) Insert(t ...*ProjectsDataPermissions) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsDataPermissions
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *ProjectsDataPermissions) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *ProjectsDataPermissions) SearchOne(cond db.Cond) (t *ProjectsDataPermissions, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *ProjectsDataPermissions) Search(cond db.Cond) (t []*ProjectsDataPermissions, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *ProjectsDataPermissions) SearchAndCount(cond db.Cond) (t []*ProjectsDataPermissions, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *ProjectsDataPermissions) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *ProjectsDataPermissions) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *ProjectsDataPermissions) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *ProjectsDataPermissions) GetMulti(ids ...interface{}) (t []*ProjectsDataPermissions, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *ProjectsDataPermissions) GetByIds(ids ...interface{}) (t []*ProjectsDataPermissions, err error) {
	return m.GetMulti(ids...)
}

func (m *ProjectsDataPermissions) GetById(id interface{}) (t *ProjectsDataPermissions, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *ProjectsDataPermissions) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *ProjectsDataPermissions) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *ProjectsDataPermissions) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *ProjectsDataPermissions) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *ProjectsDataPermissions) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewProjectsDataPermissions(c ...interface{}) (m *ProjectsDataPermissions, err error) {
	m = &ProjectsDataPermissions{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *ProjectsDataPermissions) Close() {
	m.Dao.Close()
}

func (m *ProjectsDataPermissions) Begin() error {
	return m.Dao.Begin()
}

func (m *ProjectsDataPermissions) Rollback() error {
	return m.Dao.Rollback()
}

func (m *ProjectsDataPermissions) Commit() error {
	return m.Dao.Commit()
}
