package project

import (
	"bufio"
	"bytes"
	"fmt"
	"gitlab.ifchange.com/bot/hfw/db"
	"ifchange/dhr/models"
	"os"
	"testing"

	excel "github.com/360EntSecGroup-Skylar/excelize/v2"
)

func TestFillTemplate(t *testing.T) {
	_, data, err := GetFile()
	if err != nil {
		t.Fatal(err)
	}

	excelParser, err := excel.OpenReader(bytes.NewReader(data))
	if err != nil {
		t.Fatal(err)
	}
	// 第1列第4行
	err = excelParser.SetCellValue("Sheet1", "A4", "a")
	// 第1列第5行
	err = excelParser.SetCellValue("Sheet1", "A5", "b")
	// 第2列第4行
	err = excelParser.SetCellValue("Sheet1", "z4", "c")

	err = excelParser.SetCellValue("Sheet1", "i4", "i4")
	err = excelParser.SetCellValue("Sheet1", "i5", "i5")
	buffer, err := excelParser.WriteToBuffer()

	rows, err := excelParser.GetRows("Sheet1")
	for k, v := range rows {
		t.Logf("k:%v,v:%v", k, v)
	}

	path := "./test.xlsx"
	f, err := os.Create(path)
	defer f.Close()
	if err != nil {
		panic(err)
	}
	bufferWrite := bufio.NewWriter(f)
	if err != nil {
		panic(err)
	}
	bufferWrite.Write(buffer.Bytes())
	bufferWrite.Flush()
}

func TestGetLatestStaff(t *testing.T) {
	pfs, err := models.ProjectsPerformancesModel.Search(db.Cond{
		"sql": fmt.Sprint(`
	SELECT
		* 
	FROM
		projects_performances 
	WHERE
		id IN ( SELECT max( id ) id FROM projects_performances WHERE company_id = 88 AND staff_id IN ( 162 ) GROUP BY staff_id );
		`, ),
	})
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range pfs {
		t.Log(v.Id)
	}
}
