package controllers

import (
	"bytes"
	"net/http"
	"strconv"
	time2 "time"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/project"
	"ifchange/dhr/models"

	excel "github.com/360EntSecGroup-Skylar/excelize/v2"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/db"
)

type TalentExcelDownload struct {
	core.Controller
}

/**
 * @api {get} /talent_excel/download?session=abc&project_id=12&report_id=1  人才盘点分布表下载
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 人才盘点分布表下载
 * * @apiParam {string} session session
 * @apiParam {int} project_id 项目ID (下载实时报告时使用)
 * @apiParam {int} report_id 项目ID  (下载历史版本时使用)
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
	}
 **/

func (c *TalentExcelDownload) Download(httpCtx *hfw.HTTPContext) {
	params := httpCtx.Request.URL.Query()

	session := params.Get("session")
	projectID := params.Get("project_id")
	ReportID := params.Get("report_id")
	if session == "" {
		httpCtx.ThrowCheck(20144001, "session or projectID not empty")
	}
	httpCtx.ThrowCheck(20144001, VerifyRequestSession(httpCtx, &Session{
		SessionID: session,
	}))
	// 校验两个参数必存在之一
	if projectID == "" && ReportID == "" {
		httpCtx.ThrowCheck(20304001, "参数错误")
	}

	var projectId, reportID int
	var err error
	if projectID != "" {
		projectId, err = strconv.Atoi(projectID)
		httpCtx.ThrowCheck(20305000, err)
		// 存在的参数合法有效
		list, err := models.ProjectsModel.Search(db.Cond{"id": projectId})
		httpCtx.ThrowCheck(20305000, err)
		if len(list) == 0 {
			httpCtx.ThrowCheck(20304001, "projectId参数错误")
		}
	}
	if ReportID != "" {
		reportID, err = strconv.Atoi(ReportID)
		httpCtx.ThrowCheck(20305000, err)
		// 存在的参数合法有效
		list, err := models.ProjectsModel.Search(db.Cond{"id": projectId})
		httpCtx.ThrowCheck(20305000, err)
		if len(list) == 0 {
			httpCtx.ThrowCheck(20304001, "reportID参数错误")
		}
	}

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	// 拿到模板
	_, data, err := project.GetTalentExcel()
	httpCtx.ThrowCheck(20305008, err)
	// 往模板里添加内容
	excelParser, err := excel.OpenReader(bytes.NewReader(data))
	httpCtx.ThrowCheck(20305022, err)
	if reportID == 0 {
		// 调用实时版本 往excel表格里添加内容  如果错误，就下载空模板
		err = project.Project(curUser.CompanyId, projectId, excelParser)
		// httpCtx.ThrowCheck(20305009, err)
	} else {
		// 调用历史版本 往excel表格里添加内容 如果错误，就下载空模板
		err = project.TalentReport(curUser.CompanyId, projectId, reportID, excelParser)
		// httpCtx.ThrowCheck(20305009, err)
	}

	// excel表格名字
	project, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectID, "is_deleted": 0})
	httpCtx.ThrowCheck(20305000, err)
	excelName := project.Name + "_盘点数据"

	buffer, err := excelParser.WriteToBuffer()
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.ReturnFileContent("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelName, buffer)

}

/**
 * @api {get} /talent_excel/users_download?session=abc&plan_id=12  采集对象详情列表下载 - todo by zzj 包含离职人员
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 采集对象详情列表下载
 * * @apiParam {string} session session
 * @apiParam {int} plan_id 采集计划ID
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
	}
 **/
func (c *TalentExcelDownload) UsersDownload(httpCtx *hfw.HTTPContext) {
	params := httpCtx.Request.URL.Query()
	session := params.Get("session")
	planID := params.Get("plan_id")
	if session == "" {
		httpCtx.ThrowCheck(20144001, "session or projectID not empty")
	}
	httpCtx.ThrowCheck(20144001, VerifyRequestSession(httpCtx, &Session{
		SessionID: session,
	}))
	// 校验参数必存
	if planID == "" {
		httpCtx.ThrowCheck(20304001, "参数错误")
	}

	planId, err := strconv.Atoi(planID)
	httpCtx.ThrowCheck(20305000, err)
	// 存在的参数合法有效
	list, err := models.DataCollectPlansModel.Search(db.Cond{"id": planId})
	httpCtx.ThrowCheck(20305000, err)
	if len(list) == 0 {
		httpCtx.ThrowCheck(20304001, "planId参数错误")
	}
	// excel表格名字
	time := time2.Now().Format("20060102")
	excelName := list[0].Name + "_进度详情_" + time + ".xlsx"

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	// 拿到模板
	_, data, err := project.GetCollectUsersExcel()
	httpCtx.ThrowCheck(20305008, err)
	// 往模板里添加内容
	excelParser, err := excel.OpenReader(bytes.NewReader(data))
	httpCtx.ThrowCheck(20305022, err)

	// 往excel表格里添加内容  如果错误，就下载空模板
	err = project.CollectUsersDetails(curUser.CompanyId, planId, excelParser)
	// httpCtx.ThrowCheck(20305009, err)

	buffer, err := excelParser.WriteToBuffer()
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.ReturnFileContent("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelName, buffer)

}

func (c *TalentExcelDownload) After(httpCtx *hfw.HTTPContext) {
	if httpCtx.ErrNo > 0 {
		httpCtx.ResponseWriter.WriteHeader(http.StatusInternalServerError)
	}
	c.Controller.After(httpCtx)
}
