package controllers

import (
	"fmt"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/dhr/kit/session"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/company"
	v2_project "ifchange/dhr/logics/v2/project"
)

type V2Project struct {
	core.Controller
}

/**
 * @api {post} /v2_project/check_interview_mode 项目相关 - 检查项目使用的评测模型
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 检查项目使用的评测模型
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "",
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.interview_mode 测评模型编号 1: BEI+选择排序, 2: 素质能力, 3: 360, 4: BEI+选择排序+360测评, 5: 素质能力+360测评
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"interview_mode": 1
	}
 *
*/
func (p *V2Project) CheckInterviewMode(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
	}{}
	err := api.RequestUnmarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	sess, ok := httpCtx.Ctx.Value("session").(*session.Session)
	if !ok {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("参数错误"))
	}
	res, err := company.Get(sess.CompanyID)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = map[string]int8{
		"interview_mode": res.InterviewMode,
	}
}

/**
 * @api {post} /v2_project/check_bei_open_interview 项目相关 - 检查选择的素质维度而开启的测评
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 检查选择的素质维度而开启的测评
 *
 * @apiParam {String} session session
 * @apiParam {Object[]} subitems 选择的子维度列表
 * @apiParam {Number} subitems.id 选择的子维度ID
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "",
		"subitems": [
			{
				"id": 1
			},
			{
				"id": 2
			}
		]
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object} results.practical_intelligence 管理实践能力测评
 * @apiSuccess {Boolean} results.practical_intelligence.is_check 管理实践能力测评是否开启
 * @apiSuccess {Object} results.occupational_personality 职业人格测评
 * @apiSuccess {Boolean} results.occupational_personality.is_check 职业人格测评是否开启
 * @apiSuccess {Object} results.critical_thinking 批判思维测评
 * @apiSuccess {Boolean} results.critical_thinking.is_check 批判思维测评是否开启
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"practical_intelligence": {
			"is_check": true
		},
		"occupational_personality": {
			"is_check": true
		},
		"critical_thinking": {
			"is_check": true
		}
	}
 *
*/
func (p *V2Project) CheckBeiOpenInterview(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		*v2_project.CheckBeiOpenInterviewsReq
	}{}
	err := api.RequestUnmarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	res, err := v2_project.ProjectLogic.CheckBeiOpenInterviews(params.SubItems)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.Results = res
}

/**
 * @api {post} /v2_project/check_draft 项目相关 - 检查草稿项目
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 检查是否有草稿项目
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Boolean} results.exist 是否存在
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"exist": true
	}
 *
*/
func (p *V2Project) CheckDraft(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	result, err := v2_project.ProjectLogic.CheckDraft(sess.CompanyID, sess.UserID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/clean_draft 项目相关 - 清空草稿项目
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 清空草稿项目
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{

	}
 *
*/
func (p *V2Project) CleanDraft(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	err := v2_project.ProjectLogic.CleanDraft(sess.CompanyID, sess.UserID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
}

/**
 * @api {post} /v2_project/draft 项目相关 - 草稿项目
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 草稿项目
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.step 步骤
 * @apiSuccess {Number} results.scenes_id 场景 ID（当 step=1,2,3,4 时该返回值有效）
 * @apiSuccess {Number} results.scenes_template_id 场景模版 ID（当 step=1,2,3,4 时该返回值有效）

 * @apiSuccess {String} results.name 项目名称（当 step=2,3,4 时该返回值有效）
 * @apiSuccess {Number} results.position_id 岗位 ID（当 step=2,3,4 时该返回值有效）
 * @apiSuccess {Number} results.start_at 项目开始时间（当 step=2,3,4 时该返回值有效）
 * @apiSuccess {Number} results.industries_id 行业 ID（当 step=2,3,4 时该返回值有效）
 * @apiSuccess {Number} results.functions_id 职能 ID（当 step=2,3,4 时该返回值有效）
 * @apiSuccess {Number} results.level_id 层级 ID（当 step=2,3,4 时该返回值有效）
 * @apiSuccess {Boolean} results.is_manager 是否为管理岗（当 step=2,3,4 时该返回值有效）

 * @apiSuccess {Object} results.interview 测评维度（当 step=3,4 时该返回值有效）

 * @apiSuccess {Object} results.interview.bei 素质测评
 * @apiSuccess {Boolean} results.interview.bei.is_check 是否勾选素质测评
 * @apiSuccess {Object[]} results.interview.bei.check_items 选中的素质测评维度列表
 * @apiSuccess {Number} results.interview.bei.check_items.id 选中的素质测评维度 ID
 * @apiSuccess {Number} results.interview.bei.check_items.score 选中的素质测评维度分数

 * @apiSuccess {Object} results.interview.personality 性格测评
 * @apiSuccess {Boolean} results.interview.personality.is_check 是否勾选性格测评

 * @apiSuccess {Object} results.interview.skill 专业技能测评
 * @apiSuccess {Boolean} results.interview.skill.is_check 是否勾选专业技能测评
 * @apiSuccess {Number[]} results.interview.skill.ids 选中的专业技能测评维度 ID

 * @apiSuccess {Object} results.interview.knowledge 专业知识测评
 * @apiSuccess {Boolean} results.interview.knowledge.is_check 是否勾选专业知识测评
 * @apiSuccess {Number[]} results.interview.knowledge.ids 选中的专业知识测评维度 ID

 * @apiSuccess {Object} results.interview.potential 潜力测评
 * @apiSuccess {Boolean} results.interview.potential.is_check 是否勾选潜力测评

 * @apiSuccess {Object} results.interview.work_values 工作选择价值观测评
 * @apiSuccess {Boolean} results.interview.work_values.is_check 是否勾选工作选择价值观测评
 * @apiSuccess {Number[]} results.interview.work_values.ids 选中的工作选择价值观测评维度 ID

 * @apiSuccess {Object} results.interview.key_expr 关键经历测评
 * @apiSuccess {Boolean} results.interview.key_expr.is_check 是否勾选关键经历测评
 * @apiSuccess {Number} results.interview.key_expr.manage_expr_id 选中的管理经历 ID
 * @apiSuccess {Number[]} results.interview.key_expr.business_expr_ids 选中的业务经历 ID

 * @apiSuccess {Object} results.interview.emotional_intelligence 情绪智力测评
 * @apiSuccess {Boolean} results.interview.emotional_intelligence.is_check 是否勾选情绪智力测评

 * @apiSuccess {Object} results.interview.critical_thinking 批判思维测评
 * @apiSuccess {Boolean} results.interview.critical_thinking.is_check 是否勾选批判思维测评

 * @apiSuccess {Object} results.interview.practical_intelligence 管理实践能力测评
 * @apiSuccess {Boolean} results.interview.practical_intelligence.is_check 是否勾选管理实践能力测评

 * @apiSuccess {Object} results.interview.occupational_personality 职业人格测评
 * @apiSuccess {Boolean} results.interview.occupational_personality.is_check 是否勾选职业人格测评

 * @apiSuccess {Object} results.interview.personality_disorder 性格风险测评
 * @apiSuccess {Boolean} results.interview.personality_disorder.is_check 是否勾选性格风险测评

 * @apiSuccess {Object} results.interview.leadership_style 领导风格测评
 * @apiSuccess {Boolean} results.interview.leadership_style.is_check 是否勾选领导风格测评

 * @apiSuccess {Object} results.interview.org_commitment 组织忠诚度测评
 * @apiSuccess {Boolean} results.interview.org_commitment.is_check 是否勾选组织忠诚度测评

 * @apiSuccess {String} results.remark 备注（当 step=3,4 时该返回值有效）

 * @apiParam {Object[]} [staffs] 选中的员工 列表（当 step=4 时该参数必填，当 step=4 时校返回值有效）
 * @apiParam {Number} [staffs.id] 选中的员工ID
 * @apiParam {String} [staffs.name] 选中的员工名称
 * @apiParam {Number} [staffs.department_id] 选中员工的部门ID
 * @apiParam {String} [staffs.department_name] 选中员工的部门名称
 * @apiParam {Number} [staffs.position_id] 选中员工的岗位ID
 * @apiParam {String} [staffs.position_name] 选中员工的岗位名称
 * @apiParam {Number} [staffs.parent_id] 选中员工的直属上级ID
 * @apiParam {String} [staffs.parent_name] 选中员工的直属上级名称
 * @apiParam {Number} [staffs.status] 选中员工的状态
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"step": 4,
		"scene_id": 1,
		"scene_template_id": 1,
		"name": "我是项目名称",
		"position_id": 1,
		"start_at": 1571819530,
		"industry_id": 1,
		"function_id": 1,
		"level_id": 1,
		"is_manager": true,
		"interview": {
			"bei": {
				"is_check": true,
				"check_items": [
					{
						"id": 1,
						"score": 2
					},
					{
						"id": 9,
						"score": 3
					},
					{
						"id": 11,
						"score": 4
					}
				]
			},
			"personality": {
				"is_check": true
			},
			"skill": {
				"is_check": true,
				"ids": [
					527,
					492,
					491
				]
			},
			"knowledge": {
				"is_check": true,
				"ids": [
					526,
					525,
					524
				]
			},
			"potential": {
				"is_check": true
			},
			"work_values": {
				"is_check": true,
				"ids": [
					1,
					2,
					3
				]
			},
			"key_expr": {
				"is_check": true,
				"manage_expr_id": 1,
				"business_expr_ids": [
					8,
					9,
					10
				]
			},
            "emotional_intelligence": {
				"is_check": true
            },
            "critical_thinking": {
				"is_check": true
            },
            "practical_intelligence": {
				"is_check": true
            },
            "occupational_personality": {
				"is_check": true
            },
            "personality_disorder": {
				"is_check": true
            },
            "leadership_style": {
				"is_check": true
            },
            "org_commitment": {
				"is_check": true
            }
		},
		"remark": "我是备注",
		"staffs": [
			{
				"id": 1,
				"name": "",
				"department_id": 1,
				"department_name": "部门",
				"position_id": 2,
				"position_name": "岗位",
				"parent_id": 3,
				"parent_name": "直属上级",
				"status": 2
			},
			{
				"id": 2,
				"name": "",
				"department_id": 1,
				"department_name": "部门",
				"position_id": 2,
				"position_name": "岗位",
				"parent_id": 3,
				"parent_name": "直属上级",
				"status": 2
			},
			{
				"id": 3,
				"name": "",
				"department_id": 1,
				"department_name": "部门",
				"position_id": 2,
				"position_name": "岗位",
				"parent_id": 3,
				"parent_name": "直属上级",
				"status": 2
			}
		]
	}
 *
*/
func (p *V2Project) Draft(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	result, err := v2_project.ProjectLogic.GetDraft(sess.CompanyID, sess.UserID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/create 项目相关 - 创建项目
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 创建项目
 *
 * @apiParam {String} session session
 * @apiParam {Number{1-4}} step 步骤
 * @apiParam {Number} [scene_id] 场景 ID（当 step=1 时该参数必填，当 step=1,2,3,4 时校验该参数）
 * @apiParam {Number} [scene_template_id] 场景模版 ID（当 step=1 时该参数必填，当 step=1,2,3,4 时校验该参数）

 * @apiParam {String{1..20}} [name] 项目名称（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）
 * @apiParam {Number} [position_id] 岗位 ID（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）
 * @apiParam {Number} [start_at] 项目开始时间（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）
 * @apiParam {Number} [industry_id] 行业 ID（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）
 * @apiParam {Number} [function_id] 职能 ID（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）
 * @apiParam {Number} [level_id] 层级 ID（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）
 * @apiParam {Boolean} [is_manager] 是否为管理岗（当 step=2 时该参数必填，当 step=2,3,4 时校验该参数）

 * @apiParam {Object} [interview] 测评维度（当 step=3 时该参数必填，当 step=3,4 时校验该参数）

 * @apiParam {Object} interview.bei 素质测评
 * @apiParam {Boolean} interview.bei.is_check 是否勾选素质测评
 * @apiParam {Object[]} interview.bei.check_items 选中的素质测评维度列表
 * @apiParam {Number} interview.bei.check_items.id 选中的素质测评维度 ID
 * @apiParam {Number} interview.bei.check_items.score 选中的素质测评维度分数

 * @apiParam {Object} interview.personality 性格测评
 * @apiParam {Boolean} interview.personality.is_check 是否勾选性格测评
 * @apiParam {Number} interview.personality.function_id 选择的职能ID
 * @apiParam {String} interview.personality.function_name 选择的职能名称
 * @apiParam {String} interview.personality.is_manager_position 是否管理岗
 * @apiParam {Object[]} interview.personality.selected 根据职能选择的维度
 * @apiParam {Object} interview.personality.selected.normstar_id 根据职能选择的维度ID
 * @apiParam {Object} interview.personality.selected.normstar_name 根据职能选择的维度名称

 * @apiParam {Object} interview.skill 专业技能测评
 * @apiParam {Boolean} interview.skill.is_check 是否勾选专业技能测评
 * @apiParam {Number[]} interview.skill.ids 选中的专业技能测评维度 ID

 * @apiParam {Object} interview.knowledge 专业知识测评
 * @apiParam {Boolean} interview.knowledge.is_check 是否勾选专业知识测评
 * @apiParam {Number[]} interview.knowledge.ids 选中的专业知识测评维度 ID

 * @apiParam {Object} interview.potential 潜力测评
 * @apiParam {Boolean} interview.potential.is_check 是否勾选潜力测评

 * @apiParam {Object} interview.work_values 工作选择价值观测评
 * @apiParam {Boolean} interview.work_values.is_check 是否勾选工作选择价值观测评
 * @apiParam {Number[]} interview.work_values.ids 选中的工作选择价值观测评维度 ID

 * @apiParam {Object} interview.key_expr 关键经历测评
 * @apiParam {Boolean} interview.key_expr.is_check 是否勾选关键经历测评
 * @apiParam {Number} interview.key_expr.manage_expr_id 选中的管理经历 ID
 * @apiParam {Number[]} interview.key_expr.business_expr_ids 选中的业务经历 ID

 * @apiParam {Object} interview.emotional_intelligence 情绪智力测评
 * @apiParam {Boolean} interview.emotional_intelligence.is_check 是否勾选情绪智力测评

 * @apiParam {Object} interview.critical_thinking 批判思维测评
 * @apiParam {Boolean} interview.critical_thinking.is_check 是否勾选批判思维测评

 * @apiParam {Object} interview.practical_intelligence 管理实践能力测评
 * @apiParam {Boolean} interview.practical_intelligence.is_check 是否勾选管理实践能力测评

 * @apiParam {Object} interview.occupational_personality 职业人格测评
 * @apiParam {Boolean} interview.occupational_personality.is_check 是否勾选职业人格测评

 * @apiParam {Object} interview.personality_disorder 性格风险测评
 * @apiParam {Boolean} interview.personality_disorder.is_check 是否勾选性格风险测评

 * @apiParam {Object} interview.leadership_style 领导风格测评
 * @apiParam {Boolean} interview.leadership_style.is_check 是否勾选领导风格测评

 * @apiParam {Object} interview.org_commitment 组织忠诚度测评
 * @apiParam {Boolean} interview.org_commitment.is_check 是否勾选组织忠诚度测评

 * @apiParam {String} [remark] 备注（当 step=3 时该参数必填，当 step=3,4 时校验该参数）

 * @apiParam {Object[]} [staffs] 选中的员工 列表（当 step=4 时该参数必填，当 step=4 时校验该参数）
 * @apiParam {Number} [staffs.id] 选中的员工ID
 * @apiParam {string} [staffs.name] 选中的员工名称
 * @apiParam {Number} [staffs.department_id] 选中员工的部门ID
 * @apiParam {String} [staffs.department_name] 选中员工的部门名称
 * @apiParam {Number} [staffs.position_id] 选中员工的岗位ID
 * @apiParam {String} [staffs.position_name] 选中员工的岗位名称
 * @apiParam {Number} [staffs.parent_id] 选中员工的直属上级ID
 * @apiParam {String} [staffs.parent_name] 选中员工的直属上级名称
 * @apiParam {Number} [staffs.status] 选中员工的状态
 *
 * @apiParamExample {json} Request-Example:
	{
		"step": 4,
		"scene_id": 1,
		"scene_template_id": 1,
		"name": "我是项目名称",
		"position_id": 1,
		"start_at": 1571819530,
		"industry_id": 1,
		"function_id": 1,
		"level_id": 1,
		"is_manager": true,
		"interview": {
			"bei": {
				"is_check": true,
				"check_items": [
					{
						"id": 1,
						"score": 2
					},
					{
						"id": 9,
						"score": 3
					},
					{
						"id": 11,
						"score": 4
					}
				]
			},
			"personality": {
				"is_check": true,
				"function_id": 61383,
				"function_name": "应用研发",
				"is_manager_position": true
				"selected": [
					{
						"normstar_id": 4,
						"normstar_name": "品质意识"
					}
  				]
			},
			"skill": {
				"is_check": true,
				"ids": [
					527,
					492,
					491
				]
			},
			"knowledge": {
				"is_check": true,
				"ids": [
					526,
					525,
					524
				]
			},
			"potential": {
				"is_check": true
			},
			"work_values": {
				"is_check": true,
				"ids": [
					1,
					2,
					3
				]
			},
			"key_expr": {
				"is_check": true,
				"manage_expr_id": 1,
				"business_expr_ids": [
					8,
					9,
					10
				]
			},
            "emotional_intelligence": {
				"is_check": true
            },
            "critical_thinking": {
				"is_check": true
            },
            "practical_intelligence": {
				"is_check": true
            },
            "occupational_personality": {
				"is_check": true
            },
            "personality_disorder": {
				"is_check": true
            },
            "leadership_style": {
				"is_check": true
            },
            "org_commitment": {
				"is_check": true
            }
		},
		"remark": "我是备注",
		"staffs": [
			{
				"id": 1,
				"name": "",
				"department_id": 1,
				"department_name": "部门",
				"position_id": 2,
				"position_name": "岗位",
				"parent_id": 3,
				"parent_name": "直属上级",
				"status": 2
			},
			{
				"id": 2,
				"name": "",
				"department_id": 1,
				"department_name": "部门",
				"position_id": 2,
				"position_name": "岗位",
				"parent_id": 3,
				"parent_name": "直属上级",
				"status": 2
			},
			{
				"id": 3,
				"name": "",
				"department_id": 1,
				"department_name": "部门",
				"position_id": 2,
				"position_name": "岗位",
				"parent_id": 3,
				"parent_name": "直属上级",
				"status": 2
			}
		]
		}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.id 项目 ID
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"id": 1
	}
 *
*/
func (p *V2Project) Create(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		*v2_project.CreateParam
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)
	params.CreateParam.CompanyId = sess.CompanyID
	params.CreateParam.AccountId = sess.UserID
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, params.Validate())

	result, err := v2_project.ProjectLogic.Create(params.CreateParam)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/pre_check 项目相关 - 预先检查项目
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 创建/更新项目前检查名称是否重复
 *
 * @apiParam {String} session session

 * @apiParam {String{1..20}} name 项目名称
 *
 * @apiParamExample {json} Request-Example:
	{
		"name": "我是项目名称"
	}
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{

	}
 *
*/
func (p *V2Project) PreCheck(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		Name string `json:"name" validate:"required"`
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	err := v2_project.ProjectLogic.PreCheck(sess.CompanyID, params.Name)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
}

/**
 * @api {post} /v2_project/get_need_interviews_for_project 项目相关 - 获取当前项目开启的测评
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 获取当前项目开启的测评
 * @apiParam {int} id
 *
 * @apiParamExample {json} Request-Example:
	{
		"id": 518
	}
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
		[
            {
                "id": 1,
                "name": "素质"
            },
            {
                "id": 2,
                "name": "性格"
            }
        ]
	}
 *
*/
func (p *V2Project) GetNeedInterviewsForProject(httpCtx *hfw.HTTPContext) {
	var params struct {
		Id int `json:"id" validate:"required"`
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))

	result, err := v2_project.ProjectLogic.GetNeedInterviews(params.Id)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/upload_picture 项目相关 - 上传图片
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 上传图片
 * @apiParam {int} id
 *
 * @apiParamExample {json} Request-Example:
 *	{
 *		"content": "base64编码内容",
 *		"format":"png"
 *	}
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"file_name":"M00/49/13/wKgByV2BxIyAK_ZMAAAzBuSAhkc211.pdf"
	}
 *
*/
func (p *V2Project) UploadPicture(httpCtx *hfw.HTTPContext) {
	var params struct {
		Content string `json:"content" validate:"required"`
		Format  string `json:"format" validate:"required"`
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))

	result, err := v2_project.ProjectLogic.UploadPicture(params.Content, params.Format)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/get_info 项目相关 - 获取盘点维度配置详情
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 获取盘点维度配置详情
 * @apiParam {string} resource_key 权限key:bot_public
 * @apiParam {string} session session
 * @apiParam {int} project_id 项目id
 *
 * @apiParamExample {json} Request-Example:
 *	{
 *		"resource_key": "bot_public",
 *		"session": "",
 *		"project_id": 1,
 *	}
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"name":"",
		"desc": "",
		"scene_name": "人才能力分层",
		"start_at": 1579412975,
		"position_name": "测试岗位",
		"industry_name": "花卉服务",
		"level_name": "高级经理/资深",
		"function_name": "基础研发",
		"is_manager": 1,//1是管理岗 0非管理岗
		"interviews_config": [{
			"id": 1,
			"name": "素质",
			"sub_item": [{
				"name": "追求卓越",
				"score": 1,
			}, {
				"name": "客户导向",
				"score": 2,
			}]
		}, {
			"id": 2,
			"name": "专业技能",
			"sub_item": [{
				"name": "货品管理",
			}, {
				"name": "饲养技术",
			}]
		}],
		"custom_interviews_config": [{
			"id": 7,
			"name": "关键经历",
			"sub_title": [
				{
					"name": "管理经历",
					"sub_item": [
						{
							"name": "产品/服务创新"
						},
						{
							"name": "关键交易/谈判"
						}
					]
				},
				{
					"name": "业务经历",
					"sub_item": [
						{
							"name": "多经营单元负责人管理经历"
						}
					]
				}
			]
		}],
		"staffs": [{
			"id": 1,
			"no": "",
			"name": "",
			"department_id": 1,
			"department_name": "",
			"position_id": 1,
			"position_name": "",
			"parent_id": 1,
			"parent_name": "",
			"parent_status": 3,
			"status": 1,//1: 试用期 2: 在职中 3: 已离职
		}]
	}
 *
*/
func (p *V2Project) GetInfo(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		ProjectId int `json:"project_id" validate:"required"`
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)
	result, err := v2_project.ProjectLogic.GetInfo(sess.CompanyID, params.ProjectId)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/latest_report_id 项目相关 - 获取当前项目最新版本号
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 获取当前项目最新版本号
 *
 * @apiParam {String} session session
 * @apiParam {Number} project_id 项目ID
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
		"project_id": 1
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.report_id 最新的reportID
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"version_id":1
	}
 *
*/
func (p *V2Project) LatestReportId(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		ProjectID int `json:"project_id" validate:"required"`
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))

	result, err := v2_project.ProjectLogic.GetLatestVersionID(params.ProjectID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
	VersionID := struct {
		VersionID int `json:"version_id"`
	}{
		VersionID: result,
	}
	httpCtx.Results = VersionID
}
