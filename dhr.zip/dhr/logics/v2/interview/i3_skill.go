package v2_interview

import (
    "sort"

    "gitlab.ifchange.com/bot/hfwkit/common"
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    SkillRecommend struct {
        Name     string                   `json:"name"`
        Desc     string                   `json:"desc"`
        Index    int                      `json:"index"`
        IsAdvice bool                     `json:"is_advice"`
        IsMust   bool                     `json:"is_must"`
        IsEdit   bool                     `json:"is_edit"`
        MaxCheck int                      `json:"max_check"`
        SubItems []*SkillRecommendSubItem `json:"sub_items"`
    }

    SkillRecommendSubItem struct {
        Id          int    `json:"id"`
        Name        string `json:"name"`
        IsRecommend bool   `json:"is_recommend"`
    }

    SkillSubItem struct {
        Id   int    `json:"id"`
        Name string `json:"name"`
    }
)

func ProcessSkillRecommend(companyId, sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews,
    professionalRecommends []*models.PositionFunctionSkillRecommend) *SkillRecommend {
    interview, ok := interviewsM[kitinterview.Skill]
    if !ok {
        return nil
    }

    result := SkillRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.Skill),
        IsAdvice: GetIsAdvice(kitinterview.Skill, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.Skill, sceneId, sceneTemplateId),
        IsEdit:   GetIsEdit(kitinterview.Skill),
        MaxCheck: GetMaxCheck(kitinterview.Skill),
        SubItems: nil,
    }

    itemM := make(map[int]*SkillRecommendSubItem)

    parseSubItems := ParseSubItems(interview.Config)
    for _, v := range parseSubItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &SkillRecommendSubItem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    // 获取自定义的子维度
    subItems, _ := fetchProfessional(companyId, kitinterview.Skill)
    for _, v := range subItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &SkillRecommendSubItem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    // 处理子维度推荐 Recommend.type (1: 知识 2: 技能)
    var curRecommendCount int
    for _, v := range professionalRecommends {
        if result.MaxCheck > 0 && curRecommendCount == result.MaxCheck {
            break
        }
        if _, ok := itemM[v.SkillId]; ok && v.Type == 2 {
            itemM[v.SkillId].IsRecommend = true
            curRecommendCount += 1
        }
    }

    for _, v := range itemM {
        result.SubItems = append(result.SubItems, v)
    }

    sort.Slice(result.SubItems, func(i, j int) bool {
        return result.SubItems[i].Id > result.SubItems[j].Id
    })

    return &result
}

func ProcessSkillSubItem(companyId int, interviewsM map[kitinterview.Type]*models.Interviews) *common.ListResult {
    interview, ok := interviewsM[kitinterview.Skill]
    if !ok {
        return nil
    }

    itemM := make(map[int]*SkillSubItem)

    parseSubItems := ParseSubItems(interview.Config)
    for _, v := range parseSubItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &SkillSubItem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    subItems, _ := fetchProfessional(companyId, kitinterview.Skill)
    for _, v := range subItems {
        if _, ok := itemM[v.Id]; !ok {
            itemM[v.Id] = &SkillSubItem{
                Id:   v.Id,
                Name: v.Name,
            }
        }
    }

    items := make([]*SkillSubItem, 0, len(itemM))
    for _, v := range itemM {
        items = append(items, v)
    }

    sort.Slice(items, func(i, j int) bool {
        return items[i].Id > items[j].Id
    })

    return &common.ListResult{List: items}
}
