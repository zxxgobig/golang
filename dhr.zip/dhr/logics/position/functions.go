package position

import (
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/hfw/db"
)

type PositionFunctions struct {
}

func NewPositionFunctions() *PositionFunctions {
    return new(PositionFunctions)
}

type PositionFunctionsModel struct {
    Item     *models.PositionFunctions   `json:"item"`
    SubItems []*models.PositionFunctions `json:"sub_items"`
}

func (p *PositionFunctions) List(page, pageSize int) (_models []*PositionFunctionsModel, total int64, err error) {

    cond := db.Cond{
        "is_deleted": 0,
        "page":       page,
        "pagesize":   pageSize,
        "depth":      1,
    }

    total = 0
    positionFunctionsModels, err := models.PositionFunctionsModel.Search(cond)
    if err != nil {
        return nil, 0, err
    }

    for _, positionFunctionsModel := range positionFunctionsModels {
        _PositionFunctionsModel := &PositionFunctionsModel{
            Item:     positionFunctionsModel,
            SubItems: []*models.PositionFunctions{},
        }
        cond["depth"] = 2
        cond["parent_id"] = positionFunctionsModel.FunctionId
        _PositionFunctionsModel.SubItems, err = models.PositionFunctionsModel.Search(cond)
        if err != nil {
            return nil, 0, err
        }

        _models = append(_models, _PositionFunctionsModel)
    }

    return
}
