package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/dashboard", &Dashboard{})
}

func TestDashboard_DistributionStat(t *testing.T) {
    params := &struct {
        *Session
    }{
        Session: &Session{
            SessionID: TestSession,
        },
    }
    _ = test.Do(t, "/dashboard/scene_stat", params)
}

func TestDashboard_SceneStat(t *testing.T) {
    params := &struct {
        *Session
        InterviewID int `json:"interview_id" validate:"gte=0"`
    }{
        Session: &Session{
            SessionID: TestSession,
        },
        InterviewID: 0,
    }
    _ = test.Do(t, "/dashboard/distribution_stat", params)
}
