package tools

import (
    "fmt"
    "testing"
    "time"

    "gitlab.ifchange.com/dhr/kit/dhr_admin"
    "gitlab.ifchange.com/dhr/kit/session"
)

func TestGen(t *testing.T) {
    managerID := 84
    userID := 84
    fmt.Println(session.GenerateSession(session.ConstFromB, 1, managerID, userID, 1, time.Duration(24)*time.Hour*7, dhr_admin.GetSecretKey))
}

func TestTime(t *testing.T) {
    dataTimeStr := time.Unix(time.Unix(1556812800, 0).Unix(), 0).Format("2006-01-02 15:04:05") // 设置时间戳 使用模板格式化为日期字符串
    fmt.Println(dataTimeStr)
}
