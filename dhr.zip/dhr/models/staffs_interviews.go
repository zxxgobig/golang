package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var StaffsInterviewsModel = &StaffsInterviews{}

func init() {
	var err error
	StaffsInterviewsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	StaffsInterviewsModel.Dao.EnableCache(StaffsInterviewsModel)
	//StaffsInterviewsModel.Dao.DisableCache(StaffsInterviewsModel)
	//gob: type not registered for interface
	gob.Register(StaffsInterviewsModel)
}

type StaffsInterviews struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id            int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	EmailUuid     string    `json:"email_uuid" xorm:"not null comment('发送邮件的标示') VARCHAR(64)"`
	Status        int       `json:"status" xorm:"not null default 0 comment('0 创建完成 1正在答题 2完成') TINYINT(11)"`
	CompanyId     int       `json:"company_id" xorm:"not null default 0 comment('公司id') INT(11)"`
	ProjectId     int       `json:"project_id" xorm:"not null default 0 comment('项目') INT(11)"`
	DataCollectId int       `json:"data_collect_id" xorm:"not null default 0 comment('采集id') INT(11)"`
	StaffIds      []int     `json:"staff_ids" xorm:"not null comment('当前采集下的员工id') TEXT"`
	StaffId       int       `json:"staff_id" xorm:"not null default 0 comment('员工 id') INT(11)"`
	Uuid          string    `json:"uuid" xorm:"not null default '' comment('测评试题的id(对应项目的)') VARCHAR(64)"`
	InterviewId   int       `json:"interview_id" xorm:"not null default 0 comment('测评id') INT(11)"`
	Feedback      string    `json:"feedback" xorm:"not null default '' comment('评价') VARCHAR(200)"`
	Result        string    `json:"result" xorm:"not null comment('测评结果') TEXT"`
	IsDeleted     int       `json:"is_deleted" xorm:"not null default 0 comment('是否已删除') INT(1)"`
	CreatedAt     time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created comment('创建时间') TIMESTAMP"`
	UpdatedAt     time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated comment('更新时间') TIMESTAMP"`
}

func (m *StaffsInterviews) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *StaffsInterviews) GetEmailUuid() (val string) {
	if m == nil {
		return
	}
	return m.EmailUuid
}

func (m *StaffsInterviews) GetStatus() (val int) {
	if m == nil {
		return
	}
	return m.Status
}

func (m *StaffsInterviews) GetCompanyId() (val int) {
	if m == nil {
		return
	}
	return m.CompanyId
}

func (m *StaffsInterviews) GetProjectId() (val int) {
	if m == nil {
		return
	}
	return m.ProjectId
}

func (m *StaffsInterviews) GetDataCollectId() (val int) {
	if m == nil {
		return
	}
	return m.DataCollectId
}

func (m *StaffsInterviews) GetStaffIds() (val []int) {
	if m == nil {
		return
	}
	return m.StaffIds
}

func (m *StaffsInterviews) GetStaffId() (val int) {
	if m == nil {
		return
	}
	return m.StaffId
}

func (m *StaffsInterviews) GetUuid() (val string) {
	if m == nil {
		return
	}
	return m.Uuid
}

func (m *StaffsInterviews) GetInterviewId() (val int) {
	if m == nil {
		return
	}
	return m.InterviewId
}

func (m *StaffsInterviews) GetFeedback() (val string) {
	if m == nil {
		return
	}
	return m.Feedback
}

func (m *StaffsInterviews) GetResult() (val string) {
	if m == nil {
		return
	}
	return m.Result
}

func (m *StaffsInterviews) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *StaffsInterviews) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *StaffsInterviews) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *StaffsInterviews) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *StaffsInterviews) TableName() string {
	return "staffs_interviews"
}

func (m *StaffsInterviews) Save(t ...*StaffsInterviews) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *StaffsInterviews
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *StaffsInterviews) Saves(t []*StaffsInterviews) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *StaffsInterviews) Insert(t ...*StaffsInterviews) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *StaffsInterviews
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *StaffsInterviews) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *StaffsInterviews) SearchOne(cond db.Cond) (t *StaffsInterviews, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *StaffsInterviews) Search(cond db.Cond) (t []*StaffsInterviews, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *StaffsInterviews) SearchAndCount(cond db.Cond) (t []*StaffsInterviews, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *StaffsInterviews) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *StaffsInterviews) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *StaffsInterviews) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *StaffsInterviews) GetMulti(ids ...interface{}) (t []*StaffsInterviews, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *StaffsInterviews) GetByIds(ids ...interface{}) (t []*StaffsInterviews, err error) {
	return m.GetMulti(ids...)
}

func (m *StaffsInterviews) GetById(id interface{}) (t *StaffsInterviews, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *StaffsInterviews) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *StaffsInterviews) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *StaffsInterviews) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *StaffsInterviews) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *StaffsInterviews) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewStaffsInterviews(c ...interface{}) (m *StaffsInterviews, err error) {
	m = &StaffsInterviews{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *StaffsInterviews) Close() {
	m.Dao.Close()
}

func (m *StaffsInterviews) Begin() error {
	return m.Dao.Begin()
}

func (m *StaffsInterviews) Rollback() error {
	return m.Dao.Rollback()
}

func (m *StaffsInterviews) Commit() error {
	return m.Dao.Commit()
}
