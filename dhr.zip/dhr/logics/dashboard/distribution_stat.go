package dashboard

import (
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

type (
	DistributionStatResult struct {
		Grid      []*DistributionStatGrid      `json:"grid"`
		Structure []*DistributionStatStructure `json:"structure"`
		Collect   *DistributionStatCollect     `json:"collect"`
	}
	DistributionStatGrid struct {
		X          int `json:"x"`
		Y          int `json:"y"`
		StaffCount int `json:"staff_count"`
	}
	DistributionStatStructure struct {
		Project *DistributionStatProject `json:"project"`
		Class   []*DistributionStatClass `json:"class"`
	}
	DistributionStatCollect struct {
		Class []*DistributionStatClass `json:"class"`
	}
	DistributionStatProject struct {
		Id             int     `json:"id"`
		Name           string  `json:"name"`
		CompletionRate float64 `json:"completion_rate"`
	}
	DistributionStatClass struct {
		Name    string  `json:"name"`
		Percent float64 `json:"percent"`
	}
)

func DistributionStat(companyId, sceneId, interviewId int) (result *DistributionStatResult, err error) {
	result = new(DistributionStatResult)

	data, err := client.GetDistributionStat(nil, &pb.DistributionStatRequest{
		CompanyId:   int64(companyId),
		SceneId:     int64(sceneId),
		InterviewId: int64(interviewId),
	})
	if err != nil {
		return
	}
	if data == nil {
		return
	}

	err = encoding.JSON.Unmarshal(data, &result)
	if err != nil {
		return
	}

	return
}

// InterviewScoreDistributionStat ..
func InterviewScoreDistributionStat(companyID, projectID, interviewID int) (result *DistributionStatResult, err error) {
	result = new(DistributionStatResult)

	data, err := client.GetInterviewsScoreDistributionStat(nil, &pb.DistributionInterviewScoreStatRequest{
		CompanyId:   int64(companyID),
		ProjectId:   int64(projectID),
		InterviewId: int64(interviewID),
	})
	if err != nil {
		return
	}
	if data == nil {
		return
	}

	err = encoding.JSON.Unmarshal(data, &result)
	if err != nil {
		return
	}

	return
}
