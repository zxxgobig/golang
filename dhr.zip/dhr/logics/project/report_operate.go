package project

import (
    "fmt"

    "ifchange/dhr/models"

    common2 "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
)


func Rename(companyId int, projectsReports models.ProjectsReports) (err error) {
    model, err := models.ProjectsDistributionsModel.SearchOne(db.Cond{
        "project_id": projectsReports.ProjectId,
        "is_deleted": 0,
        "name":       projectsReports.Name,
    })
    if err != nil {
        return
    }
    if model != nil {
        err = common2.NewRespErr(20304043, err)
        return
    }

    _, err = GetValidProject(companyId, projectsReports.ProjectId)
    if err != nil {
        return
    }

    r, err := models.ProjectsDistributionsModel.Update(db.Cond{
        "name": projectsReports.Name,
    }, db.Cond{
        "project_id": projectsReports.ProjectId,
        "id":         projectsReports.Id,
        "is_deleted": 0,
    })
    if err != nil {
        return
    }
    if r != 1 {
        err = fmt.Errorf("no record found")
    }

    return
}

func Delete(companyId int, projectId int, reportId int) (err error) {

    project, err := GetValidProject(companyId, projectId)
    if err != nil {
        return
    }
    r, err := models.ProjectsDistributionsModel.Update(db.Cond{
        "is_deleted": 1,
    }, db.Cond{
        "project_id": project.Id,
        "id":         reportId,
    })

    if err != nil {
        return
    }
    if r != 1 {
        return fmt.Errorf("projects reports Delete fail:%d", projectId)
    }
    return
}
