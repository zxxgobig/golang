package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var ProjectsPerformancesStandardModel = &ProjectsPerformancesStandard{}

func init() {
	var err error
	ProjectsPerformancesStandardModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	ProjectsPerformancesStandardModel.Dao.EnableCache(ProjectsPerformancesStandardModel)
	//ProjectsPerformancesStandardModel.Dao.DisableCache(ProjectsPerformancesStandardModel)
	//gob: type not registered for interface
	gob.Register(ProjectsPerformancesStandardModel)
}

type ProjectsPerformancesStandard struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id            int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	Level         string    `json:"level" xorm:"not null default '' comment('绩效级别') VARCHAR(255)"`
	LevelStandard int       `json:"level_standard" xorm:"not null default 0 comment('标准级别') INT(11)"`
	UploadExcelId int       `json:"upload_excel_id" xorm:"not null default 0 comment('上传excelid') INT(11)"`
	IsDeleted     int       `json:"is_deleted" xorm:"not null default 0 INT(11)"`
	CreatedAt     time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
	UpdatedAt     time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
}

func (m *ProjectsPerformancesStandard) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *ProjectsPerformancesStandard) GetLevel() (val string) {
	if m == nil {
		return
	}
	return m.Level
}

func (m *ProjectsPerformancesStandard) GetLevelStandard() (val int) {
	if m == nil {
		return
	}
	return m.LevelStandard
}

func (m *ProjectsPerformancesStandard) GetUploadExcelId() (val int) {
	if m == nil {
		return
	}
	return m.UploadExcelId
}

func (m *ProjectsPerformancesStandard) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *ProjectsPerformancesStandard) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *ProjectsPerformancesStandard) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *ProjectsPerformancesStandard) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *ProjectsPerformancesStandard) TableName() string {
	return "projects_performances_standard"
}

func (m *ProjectsPerformancesStandard) Save(t ...*ProjectsPerformancesStandard) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsPerformancesStandard
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *ProjectsPerformancesStandard) Saves(t []*ProjectsPerformancesStandard) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *ProjectsPerformancesStandard) Insert(t ...*ProjectsPerformancesStandard) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsPerformancesStandard
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *ProjectsPerformancesStandard) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *ProjectsPerformancesStandard) SearchOne(cond db.Cond) (t *ProjectsPerformancesStandard, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *ProjectsPerformancesStandard) Search(cond db.Cond) (t []*ProjectsPerformancesStandard, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *ProjectsPerformancesStandard) SearchAndCount(cond db.Cond) (t []*ProjectsPerformancesStandard, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *ProjectsPerformancesStandard) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *ProjectsPerformancesStandard) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *ProjectsPerformancesStandard) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *ProjectsPerformancesStandard) GetMulti(ids ...interface{}) (t []*ProjectsPerformancesStandard, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *ProjectsPerformancesStandard) GetByIds(ids ...interface{}) (t []*ProjectsPerformancesStandard, err error) {
	return m.GetMulti(ids...)
}

func (m *ProjectsPerformancesStandard) GetById(id interface{}) (t *ProjectsPerformancesStandard, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *ProjectsPerformancesStandard) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *ProjectsPerformancesStandard) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *ProjectsPerformancesStandard) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *ProjectsPerformancesStandard) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *ProjectsPerformancesStandard) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewProjectsPerformancesStandard(c ...interface{}) (m *ProjectsPerformancesStandard, err error) {
	m = &ProjectsPerformancesStandard{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *ProjectsPerformancesStandard) Close() {
	m.Dao.Close()
}

func (m *ProjectsPerformancesStandard) Begin() error {
	return m.Dao.Begin()
}

func (m *ProjectsPerformancesStandard) Rollback() error {
	return m.Dao.Rollback()
}

func (m *ProjectsPerformancesStandard) Commit() error {
	return m.Dao.Commit()
}
