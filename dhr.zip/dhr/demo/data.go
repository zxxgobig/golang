package demo

var r1 = []byte(`[
  {
    "name":"团队优势项",
    "list":[
      "追求卓越",
      "人际影响"
    ]
  },
  {
    "name":"团队待发展项",
    "list":[
      "客户导向",
      "建立关系"
    ]
  },
  {
    "name":"团队发展建议",
    "list":[
      "建议通过以下方式，加强团队成员为客户解决问题的能力：",
      "1. 实践应用：建议整个团队增加与客户互动频次，并在内部设定互动行为标准，同时建立看板实时公布进展、相互检查，每周反馈效果同时对策略进行优化改进。",
      "2. 机制建设：鼓励团队愿意占用个人时间与客户建立工作以外的关系，客户遇到问题时，愿意分享私人资源给客户提供帮助，并在内部设立相应的激励机制。",
      "",      
      "建议通过以下方式，发展团队成员保持广泛社会关系的能力：",
      "1. 实践应用：建议在团队内两两之间互为Buddy（伙伴），除了正式的工作关系，可以互相交流工作中、生活里遇到的挑战或新的想法，或者以伙伴的名义在企业内发起创新的项目等，项目成功立项、实施可以获得组织的奖励。",
      "2. 读书观影：在空余时间可以观看美剧《Friends》、《Big Bang 生活大爆炸》等，在观剧的同时，尝试思考朋友关系的建立。"
    ]
  }
]`)
var r2 = []byte(`[
  {
    "name":"团队优势项",
    "list":[
      "追求卓越",
      "人际影响"
    ]
  },
  {
    "name":"团队待发展项",
    "list":[
      "客户导向",
      "建立关系"
    ]
  },
  {
    "name":"人才结构扫描",
    "list":[
      "盘点群体中员工绩效、能力分布较为分散，未来业绩有一定提升空间。",
      "建议通过进一步分析，找到团队能力短板，进行针对性的培训和发展；同时，通过对员工绩效管理和团队管理机制的不断优化，促进绩效的稳定输出和不断提升。"
    ]
  }
]`)
var r3 = []byte(`[
  {
    "name":"团队优势项",
    "list":[
      "追求卓越",
      "人际影响"
    ]
  },
  {
    "name":"团队待发展项",
    "list":[
      "客户导向",
      "建立关系"
    ]
  },
  {
    "name":"团队潜力发展建议",
    "list":[
      "建议通过以下方式发展跨界思考能力：",
      "反思总结：思考你在工作中可能存在偏见的观点，尝试反思这些偏见的来源？以超越你惯性的视角重新审视并做出决定；",
      "拓展阅读：坚持每日阅读1小时你所在领域外的新闻、行业趋势，了解哪些信息是对你的工作有帮助；",
      "培训课程：参加关于《如何进行跨界思考》的相关培训课程，学习如何通过跨界学习帮助在自己感兴趣/负责的领域得到提升；",
      "探索实践：尝试加入跨团队/部门的项目，并利用这个机会学习其他团队/部门的经营视角，帮助你在未来做决策获得更为广泛的信息来源。"
    ]
  }
]`)
var r4 = []byte(`[
  {
    "name":"团队优势项",
    "list":[
      "追求卓越",
      "人际影响"
    ]
  },
  {
    "name":"团队待发展项",
    "list":[
      "客户导向",
      "建立关系"
    ]
  },
  {
    "name":"人才能力分层",
    "list":[
      "根据综合能力水平，可以将员工分为高级置业顾问、中级置业顾问、初级置业顾问。"
    ],
    "position_levels":[
      {
        "name":"高级置业顾问",
        "count":14,
        "staff_list":[
          {
            "id":28,
            "distribution_id":3,
            "name":"赵峰",
            "department":"销售部"
          },
          {
            "id":40,
            "distribution_id":2,
            "name":"王永杰",
            "department":"销售部"
          },
          {
            "id":30,
            "distribution_id":3,
            "name":"张嘉玲",
            "department":"销售部"
          },
          {
            "id":29,
            "distribution_id":3,
            "name":"张凯",
            "department":"销售部"
          },
          {
            "id":38,
            "distribution_id":2,
            "name":"文玲玲",
            "department":"销售部"
          },
          {
            "id":63,
            "distribution_id":1,
            "name":"郝毅",
            "department":"销售部"
          },
          {
            "id":27,
            "distribution_id":3,
            "name":"左俊",
            "department":"销售部"
          },
          {
            "id":60,
            "distribution_id":1,
            "name":"胡冬",
            "department":"销售部"
          },
          {
            "id":26,
            "distribution_id":3,
            "name":"陈晓晓",
            "department":"销售部"
          },
          {
            "id":59,
            "distribution_id":1,
            "name":"梁军",
            "department":"销售部"
          },
          {
            "id":61,
            "distribution_id":1,
            "name":"侯春建",
            "department":"销售部"
          },
          {
            "id":62,
            "distribution_id":1,
            "name":"洪艳萍",
            "department":"销售部"
          },
          {
            "id":41,
            "distribution_id":2,
            "name":"王豪",
            "department":"销售部"
          },
          {
            "id":39,
            "distribution_id":2,
            "name":"魏超",
            "department":"销售部"
          }
        ],
        "desc":[
          "他们通常熟知法律法规知识与城市规划，精通客户互动话术与技巧。",
          "这群员工能够考虑他人的具体情况施加有针对性的影响，能够基于客户意见提供高价值或超值服务，能够努力实现有挑战性的目标。",
          "他们通常表现出较强的情绪稳定性，将挑战性反馈、挫折和困难看做学习成长的机遇，始终保持积极的心态，展示出很强的好奇心和学习渴望，能够尝试用不同的方法达成目标。"
       ]
      },
      {
        "name":"中级置业顾问",
        "count":4,
        "staff_list":[
          {
            "id":64,
            "distribution_id":4,
            "name":"高智彪",
            "department":"销售部"
          },
          {
            "id":65,
            "distribution_id":4,
            "name":"方超",
            "department":"销售部"
          },
          {
            "id":67,
            "distribution_id":4,
            "name":"董萧萧",
            "department":"销售部"
          },
          {
            "id":66,
            "distribution_id":4,
            "name":"杜明宏",
            "department":"销售部"
          }
        ],
        "desc":[
          "他们通常熟知法律法规知识，精通客户互动话术与技巧。",
          "这群员工能够主动寻求更佳的工作方式、提高绩效水平，能够确保自己和同事及时帮助客户解决问题。",
          "他们通常善于倾听，能够理解和尊重他人，表现出较强的情绪稳定性，将挑战性反馈、挫折和困难看做学习成长的机遇，始终保持积极的心态。"
        ]
      },
      {
        "name":"初级置业顾问",
        "count":27,
        "staff_list":[
          {
            "id":58,
            "distribution_id":8,
            "name":"梁天",
            "department":"销售部"
          },
          {
            "id":48,
            "distribution_id":8,
            "name":"欧颖",
            "department":"销售部"
          },
          {
            "id":52,
            "distribution_id":8,
            "name":"刘波",
            "department":"销售部"
          },
          {
            "id":37,
            "distribution_id":9,
            "name":"徐树人",
            "department":"销售部"
          },
          {
            "id":50,
            "distribution_id":8,
            "name":"刘文雅",
            "department":"销售部"
          },
          {
            "id":53,
            "distribution_id":8,
            "name":"李甜甜",
            "department":"销售部"
          },
          {
            "id":55,
            "distribution_id":8,
            "name":"凌浩",
            "department":"销售部"
          },
          {
            "id":45,
            "distribution_id":8,
            "name":"石飞轩",
            "department":"销售部"
          },
          {
            "id":31,
            "distribution_id":9,
            "name":"张俊",
            "department":"销售部"
          },
          {
            "id":33,
            "distribution_id":9,
            "name":"于洋",
            "department":"销售部"
          },
          {
            "id":43,
            "distribution_id":8,
            "name":"孙嘉宇",
            "department":"销售部"
          },
          {
            "id":35,
            "distribution_id":9,
            "name":"叶小芳",
            "department":"销售部"
          },
          {
            "id":56,
            "distribution_id":8,
            "name":"李林",
            "department":"销售部"
          },
          {
            "id":32,
            "distribution_id":9,
            "name":"张长明",
            "department":"销售部"
          },
          {
            "id":47,
            "distribution_id":8,
            "name":"秦剑阳",
            "department":"销售部"
          },
          {
            "id":51,
            "distribution_id":8,
            "name":"刘萍",
            "department":"销售部"
          },
          {
            "id":46,
            "distribution_id":8,
            "name":"沈瑜",
            "department":"销售部"
          },
          {
            "id":57,
            "distribution_id":8,
            "name":"李佳骏",
            "department":"销售部"
          },
          {
            "id":54,
            "distribution_id":8,
            "name":"李强",
            "department":"销售部"
          },
          {
            "id":68,
            "distribution_id":7,
            "name":"丁羽",
            "department":"销售部"
          },
          {
            "id":42,
            "distribution_id":8,
            "name":"孙志杰",
            "department":"销售部"
          },
          {
            "id":69,
            "distribution_id":8,
            "name":"戴云云",
            "department":"销售部"
          },
          {
            "id":49,
            "distribution_id":8,
            "name":"鲁晓婷",
            "department":"销售部"
          },
          {
            "id":34,
            "distribution_id":9,
            "name":"余建平",
            "department":"销售部"
          },
          {
            "id":70,
            "distribution_id":7,
            "name":"陈向飞",
            "department":"销售部"
          },
          {
            "id":44,
            "distribution_id":8,
            "name":"苏俊林",
            "department":"销售部"
          },
          {
            "id":36,
            "distribution_id":9,
            "name":"杨勇",
            "department":"销售部"
          }
        ],
        "desc":[
          "他们通常基本掌握法律法规知识，掌握客户互动话术与技巧。",
          "这群员工能够与他人建立或保持融洽的关系， 能够基于数据、事实、逻辑进行直接影响。",
          "他们通常善于倾听，能够理解和尊重他人。"
          ]
      }
    ]
  }
]`)

var performance = []byte(`{
  "performance": {
    "props": [{
      "level": "高",
      "percent": 26.7,
      "labels": ["客户导向","追求卓越","创新精神","敏锐学习能力","法律法规知识","客户互动话术与技巧","经验丰富","工作效率高"]
    },{
      "level": "中",
      "percent": 46.7,
      "labels": ["销售","民主精神","建立关系","情感管理能力","人际感知能力"]
    },{
      "level": "低",
      "percent": 26.7,
      "labels": ["人际影响","精力水平","品质意识","工作态度好"]
    }]
  }
}`)

var excellent = []byte(`{
  "main_desc": "唯家置业顾问岗位上绩效表现优秀的员工呈现出一些共同的特征",
  "axes": [{
    "id": 1,
    "name": "专业知识",
    "desc": "他们通常熟知法律法规知识，精通客户互动话术与技巧。（法律法规知识、客户互动话术与技巧）"
  },{
    "id": 1,
    "name": "素质",
    "desc": "这群绩优员工往往能够为自己设定挑战性的目标并努力达成，在工作中努力为客户提供高价值或超值服务。（追求卓越、客户导向）"
  },{
    "id": 1,
    "name": "性格",
    "desc": "他们大多表现出偏好创造前所未有的事物与观念的特征。（创新精神）"
  },{
    "id": 1,
    "name": "潜力",
    "desc": "他们展示出很强的好奇心和学习渴望，能够尝试用不同的方法达成目标。（敏锐学习能力）"
  }
  ],
  "extra_desc": "此外，他们通常还具备一些其他的共同特征：经验丰富，工作效率高，推动力强。",
  "characters": [{
    "id": 1,
    "name": "客户导向",
    "type": 1,
    "excellent_score": 3,
    "avg_score": 2.3
  },{
    "id": 2,
    "type": 1,
    "name": "追求卓越",
    "excellent_score": 5,
    "avg_score": 2.9
  },{
    "id": 3,
    "type": 1,
    "name": "创新精神",
    "excellent_score": 4,
    "avg_score": 2.3
  },{
    "id": 4,
    "type": 1,
    "name": "敏锐学习能力",
    "excellent_score": 4,
    "avg_score": 2.8
  },{
    "id": 5,
    "type": 2,
    "name": "法律法规知识",
    "excellent_score": 5,
    "avg_score": 2.8
  },{
    "id": 6,
    "type": 2,
    "name": "客户互动话术与技巧",
    "excellent_score": 4,
    "avg_score": 2.6
  },{
    "id": 7,
    "type": 2,
    "name": "经验丰富",
    "excellent_score": 3,
    "avg_score": 2.2
  },{
    "id": 8,
    "type": 2,
    "name": "工作效率高",
    "excellent_score": 4,
    "avg_score": 3.2
  },{
    "id": 9,
    "type": 2,
    "name": "推动力强"
  },{
    "id": 10,
    "type": 2,
    "name": "销售"
  },{
    "id": 11,
    "type": 2,
    "name": "比较聪明"
  },{
    "id": 12,
    "type": 2,
    "name": "思考能力较强"
  },{
    "id": 13,
    "type": 2,
    "name": "态度积极"
  },{
    "id": 14,
    "type": 2,
    "name": "工作热情高"
  },{
    "id": 4,
    "type": 2,
    "name": "工作态度较好"
  },{
    "id": 15,
    "type": 2,
    "name": "判断力较好"
  },{
    "id": 16,
    "type": 2,
    "name": "具有潜力"
  },{
    "id": 17,
    "type": 2,
    "name": "情绪管理能力"
  },{
    "id": 18,
    "type": 2,
    "name": "品质意识"
  }
  ]
}`)

var JobChoiceValue = []byte(`
{
	"list": [
		{
			"name": "收入与财富",
			"fraction": 0.82
		},{
			"name": "权力地位",
			"fraction": 0.58
		}
	]
}`)

var KeyExperience = []byte(`
{
	"type": "business_list",
	"business_list": [
		{
			"name": "市场开拓",
			"number": 33
		},{
			"name": "关键交易/谈判",
			"number": 36
		}
	]
}`)

var LeadershipStyle = []byte(`{
    "avg": 1.8,
    "data": {
        "dimension": [
            {
                "id": 1,
                "name": "命令型",
                "selected": true,
                "max": 10
            },
            {
                "id": 2,
                "name": "教练型",
                "selected": true,
                "max": 10
            },
            {
                "id": 3,
                "name": "支持型",
                "selected": true,
                "max": 10
            },
            {
                "id": 4,
                "name": "授权型",
                "selected": true,
                "max": 10
            }
        ],
        "show_measurement": [
            "score"
        ],
        "data": [
            {
                "legend": "员工平均得分",
                "measurement": {
                    "score": [
                        4,
                        3.5,
                        3.5,
                        2.5
                    ],
                    "freq": [
                        4,
                        3,
                        4,
                        3
                    ]
                }
            }
        ],
        "unit": {},
        "rule": ""
    }
}
`)

var EmotionalIntelligence = []byte(`{
    "avg": 4.5,
    "data": {
        "dimension": [
            {
                "id": 1,
                "name": "评价情绪",
                "selected": true,
                "max": 10
            },
            {
                "id": 2,
                "name": "觉知情绪",
                "selected": true,
                "max": 10
            },
            {
                "id": 3,
                "name": "调控情绪",
                "selected": true,
                "max": 10
            },
            {
                "id": 4,
                "name": "表现情绪",
                "selected": true,
                "max": 10
            },
            {
                "id": 5,
                "name": "运用情绪",
                "selected": true,
                "max": 10
            }
        ],
        "show_measurement": [
            "score"
        ],
        "data": [
            {
                "legend": "员工平均得分",
                "measurement": {
                    "score": [
                        5.5,
                        2.3,
                        4.5,
                        4,
                        6
                    ],
                    "freq": null
                }
            }
        ],
        "unit": {},
        "rule": ""
    }
}`)

var PracticalIntelligence = []byte(`{
    "avg":7.5,
    "data":{
        "dimension":[
            {
                "id":1,
                "name":"战略思考",
                "selected":true,
                "max":10
            },
            {
                "id":2,
                "name":"大局意识",
                "selected":true,
                "max":10
            },
            {
                "id":3,
                "name":"关系建立",
                "selected":true,
                "max":10
            },
            {
                "id":4,
                "name":"愿景激励",
                "selected":true,
                "max":10
            },
            {
                "id":5,
                "name":"变革创新",
                "selected":true,
                "max":10
            },
            {
                "id":6,
                "name":"识人用人",
                "selected":true,
                "max":10
            },
            {
                "id":7,
                "name":"组织建设",
                "selected":true,
                "max":10
            },
            {
                "id":8,
                "name":"资源整合",
                "selected":true,
                "max":10
            },
            {
                "id":9,
                "name":"商业敏感",
                "selected":true,
                "max":10
            },
            {
                "id":10,
                "name":"追求卓越",
                "selected":true,
                "max":10
            }
        ],
        "show_measurement":[
            "score"
        ],
        "data":[
            {
                "legend":"员工平均得分",
                "measurement":{
                    "score":[
                        9,
                        9,
                        7,
                        8,
                        10,
                        7,
                        6,
                        8,
                        9,
                        7
                    ],
                    "freq":null
                }
            }
        ],
        "unit":{

        },
        "rule":""
    }
}`)

var OccupationalPersonality = []byte(`{
    "avg": 4,
    "data": {
        "dimension": [
            {
                "id": 1,
                "name": "成就动机",
                "selected": true,
                "max": 10
            },
            {
                "id": 2,
                "name": "责任意识",
                "selected": true,
                "max": 10
            },
            {
                "id": 3,
                "name": "开放创新",
                "selected": true,
                "max": 10
            },
            {
                "id": 4,
                "name": "团结协作",
                "selected": true,
                "max": 10
            },
            {
                "id": 5,
                "name": "外向活跃",
                "selected": true,
                "max": 10
            },
            {
                "id": 6,
                "name": "积极情绪",
                "selected": true,
                "max": 10
            }
        ],
        "show_measurement": [
            "score"
        ],
        "data": [
            {
                "legend": "员工平均得分",
                "measurement": {
                    "score": [
                        2.8,
                        4.9,
                        4.6,
                        2.3,
                        5.2,
                        4.3
                    ],
                    "freq": null
                }
            }
        ],
        "unit": {},
        "rule": ""
    }
}`)

var CriticalThinking = []byte(`{
    "avg": 2,
    "data": {
        "dimension": [
            {
                "id": 1,
                "name": "分析",
                "selected": true,
                "max": 10
            },
            {
                "id": 2,
                "name": "推断",
                "selected": true,
                "max": 10
            },
            {
                "id": 3,
                "name": "解释",
                "selected": true,
                "max": 10
            },
            {
                "id": 4,
                "name": "评价",
                "selected": true,
                "max": 10
            }
        ],
        "show_measurement": [
            "score"
        ],
        "data": [
            {
                "legend": "员工平均得分",
                "measurement": {
                    "score": [
                        1,
                        4,
                        1,
                        2
                    ],
                    "freq": null
                }
            }
        ],
        "unit": {},
        "rule": ""
    }
}`)

var PersonalityDisorder = []byte(`{
    "avg": 6.7,
    "data": {
        "dimension": [
            {
                "id": 1,
                "name": "分裂型",
                "selected": true,
                "max": 10
            },
            {
                "id": 2,
                "name": "边缘型",
                "selected": true,
                "max": 10
            },
            {
                "id": 3,
                "name": "反社会型",
                "selected": true,
                "max": 10
            },
            {
                "id": 4,
                "name": "表演型",
                "selected": true,
                "max": 10
            },
            {
                "id": 5,
                "name": "依赖型",
                "selected": true,
                "max": 10
            },
            {
                "id": 6,
                "name": "偏执型",
                "selected": true,
                "max": 10
            },
            {
                "id": 7,
                "name": "自恋型",
                "selected": true,
                "max": 10
            }
        ],
        "show_measurement": [
            "score"
        ],
        "data": [
            {
                "legend": "员工平均得分",
                "measurement": {
                    "score": [
                        6,
                        9,
                        8,
                        6,
                        5,
                        6,
                        7
                    ],
                    "freq": null
                }
            }
        ],
        "unit": {},
        "rule": ""
    }
}`)

var OrgCommitment = []byte(`{
    "avg": 5.78,
    "data": {
        "dimension": [
            {
                "id": 1,
                "name": "价值认同",
                "selected": true,
                "max": 10
            },
            {
                "id": 2,
                "name": "情感投入",
                "selected": true,
                "max": 10
            },
            {
                "id": 3,
                "name": "理想承诺",
                "selected": true,
                "max": 10
            },
            {
                "id": 4,
                "name": "敬业奉献",
                "selected": true,
                "max": 10
            },
            {
                "id": 5,
                "name": "建言献策",
                "selected": true,
                "max": 10
            },
            {
                "id": 6,
                "name": "团结协助",
                "selected": true,
                "max": 10
            },
            {
                "id": 7,
                "name": "积极配合",
                "selected": true,
                "max": 10
            },
            {
                "id": 8,
                "name": "维护公利",
                "selected": true,
                "max": 10
            }
        ],
        "show_measurement": [
            "score"
        ],
        "data": [
            {
                "legend": "员工平均得分",
                "measurement": {
                    "score": [
                        6,
                        7,
                        6,
                        4,
                        5,
                        6,
                        5,
                        7
                    ],
                    "freq": null
                }
            }
        ],
        "unit": {},
        "rule": ""
    }
}`)
