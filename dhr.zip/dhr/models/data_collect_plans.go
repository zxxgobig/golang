package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var DataCollectPlansModel = &DataCollectPlans{}

func init() {
	var err error
	DataCollectPlansModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	DataCollectPlansModel.Dao.EnableCache(DataCollectPlansModel)
	//DataCollectPlansModel.Dao.DisableCache(DataCollectPlansModel)
	//gob: type not registered for interface
	gob.Register(DataCollectPlansModel)
}

type DataCollectPlans struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id          int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	ProjectId   int       `json:"project_id" xorm:"not null default 0 comment('项目id') INT(11)"`
	PositionId  int       `json:"position_id" xorm:"not null default 0 comment('岗位id') INT(11)"`
	Name        string    `json:"name" xorm:"not null default '' comment('采集任务名称') VARCHAR(128)"`
	StartTime   time.Time `json:"start_time" xorm:"not null default 'CURRENT_TIMESTAMP' comment('开始时间') DATETIME"`
	EndTime     time.Time `json:"end_time" xorm:"not null default 'CURRENT_TIMESTAMP' comment('结束时间') DATETIME"`
	Status      int       `json:"status" xorm:"not null default 0 comment('采集状态(1待采集，2采集中，3已完成，4暂停，5结束，6删除)') TINYINT(1)"`
	VerifyPhone int       `json:"verify_phone" xorm:"not null default 1 comment('验证手机号（1验证，2不需验证）') TINYINT(1)"`
	IsDeleted   int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
	UpdatedAt   time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
	CreatedAt   time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
}

func (m *DataCollectPlans) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *DataCollectPlans) GetProjectId() (val int) {
	if m == nil {
		return
	}
	return m.ProjectId
}

func (m *DataCollectPlans) GetPositionId() (val int) {
	if m == nil {
		return
	}
	return m.PositionId
}

func (m *DataCollectPlans) GetName() (val string) {
	if m == nil {
		return
	}
	return m.Name
}

func (m *DataCollectPlans) GetStartTime() (val time.Time) {
	if m == nil {
		return
	}
	return m.StartTime
}

func (m *DataCollectPlans) GetEndTime() (val time.Time) {
	if m == nil {
		return
	}
	return m.EndTime
}

func (m *DataCollectPlans) GetStatus() (val int) {
	if m == nil {
		return
	}
	return m.Status
}

func (m *DataCollectPlans) GetVerifyPhone() (val int) {
	if m == nil {
		return
	}
	return m.VerifyPhone
}

func (m *DataCollectPlans) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *DataCollectPlans) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *DataCollectPlans) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *DataCollectPlans) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *DataCollectPlans) TableName() string {
	return "data_collect_plans"
}

func (m *DataCollectPlans) Save(t ...*DataCollectPlans) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *DataCollectPlans
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *DataCollectPlans) Saves(t []*DataCollectPlans) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *DataCollectPlans) Insert(t ...*DataCollectPlans) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *DataCollectPlans
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *DataCollectPlans) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *DataCollectPlans) SearchOne(cond db.Cond) (t *DataCollectPlans, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *DataCollectPlans) Search(cond db.Cond) (t []*DataCollectPlans, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *DataCollectPlans) SearchAndCount(cond db.Cond) (t []*DataCollectPlans, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *DataCollectPlans) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *DataCollectPlans) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *DataCollectPlans) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *DataCollectPlans) GetMulti(ids ...interface{}) (t []*DataCollectPlans, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *DataCollectPlans) GetByIds(ids ...interface{}) (t []*DataCollectPlans, err error) {
	return m.GetMulti(ids...)
}

func (m *DataCollectPlans) GetById(id interface{}) (t *DataCollectPlans, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *DataCollectPlans) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *DataCollectPlans) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *DataCollectPlans) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *DataCollectPlans) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *DataCollectPlans) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewDataCollectPlans(c ...interface{}) (m *DataCollectPlans, err error) {
	m = &DataCollectPlans{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *DataCollectPlans) Close() {
	m.Dao.Close()
}

func (m *DataCollectPlans) Begin() error {
	return m.Dao.Begin()
}

func (m *DataCollectPlans) Rollback() error {
	return m.Dao.Rollback()
}

func (m *DataCollectPlans) Commit() error {
	return m.Dao.Commit()
}
