package lambda

const (
    InterviewAll = iota
    InterviewBEI
    InterviewPersonalityEval
    InterviewSkill
    InterviewKnowledge
    InterviewPotential
    InterviewWorkValues
    InterviewKeyExperience
    InterviewNotFound = -1
)

type Level int

const (
    High Level = iota + 1
    Medium
    Low
)

func (this Level) String() string {
    switch this {
    case High:
        return "高"
    case Medium:
        return "中"
    case Low:
        return "低"
    }

    return ""
}


const (
    SceneDevelopmentPersonnel = iota + 1
    ScenePromotion
    ScenePotential
    SceneHierarchy
)



