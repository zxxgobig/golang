package project

import (
	"ifchange/dhr/logics/interview"
	"testing"
	"time"

	"github.com/smartystreets/assertions/should"

	. "github.com/smartystreets/goconvey/convey"
)

func TestProjects_GetNotice(t *testing.T) {
	project := NewProjects()
	Convey("获取提示信息", t, func() {
		_, err := project.GetNotice(109, 94)
		So(err, ShouldBeNil)
	})
}

func TestProjects_ListByStaffId(t *testing.T) {
	project := NewProjects()
	Convey("通过员工列表获取项目列表", t, func() {
		_, _, err := project.ListByStaffId(109, 94, 1, 1)
		So(err, ShouldBeNil)
	})
}

func TestProjects_List(t *testing.T) {
	project := NewProjects()
	Convey("搜索列表获取项目", t, func() {
		data, total, err := project.List(1, "", []int{}, 1, 1)
		So(err, ShouldBeNil)
		So(total, should.BeGreaterThan, 1)
		So(len(data), ShouldEqual, 1)
	})
}

func TestProjects_Create(t *testing.T) {
	project := NewProjects()
	Convey("创建项目", t, func() {
		p, err := GetValidProject(109, 94)
		So(err, ShouldBeNil)
		So(p, ShouldNotBeNil)

		p.Id = 0
		p.CreatedAt = time.Now()

		c := []*interview.ConfigItemParam{
			&interview.ConfigItemParam{
				Id: 3,
				SubItems: []interview.ConfigSubItem{
					interview.ConfigSubItem{
						Id: 182,
					},
				},
			},
			&interview.ConfigItemParam{
				Id: 4,
				SubItems: []interview.ConfigSubItem{
					interview.ConfigSubItem{
						Id: 529,
					},
				},
			},
			&interview.ConfigItemParam{
				Id: 1,
				SubItems: []interview.ConfigSubItem{
					interview.ConfigSubItem{
						Id: 48,
					},
				},
			},
			&interview.ConfigItemParam{
				Id: 5,
			},
			&interview.ConfigItemParam{
				Id: 2,
			},
		}

		err = project.Create(*p, c, nil, []int{86})
		So(err, ShouldBeNil)
	})
}

func TestProjects_Detail(t *testing.T) {
	project := NewProjects()
	Convey("获取项目详情", t, func() {
		_, err := project.Detail(96)
		So(err, ShouldBeNil)
	})
}

func TestProjects_Delete(t *testing.T) {
	project := NewProjects()
	Convey("删除项目", t, func() {
		err := project.Delete(109, 90)
		So(err, ShouldBeNil)
	})
}

func TestProjects_GetFinishedStatusTotal(t *testing.T) {
	project := NewProjects()
	Convey("获取项目状态", t, func() {
		_, err := project.GetFinishedStatus(94)
		So(err, ShouldBeNil)
	})
}
