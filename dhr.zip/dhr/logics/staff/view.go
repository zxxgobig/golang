package staff

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/project/permission"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

const (
	DataSourceTypeOwned = iota + 1
	DataSourceTypeShared
	DataSourceTypeOther
	DataSourceTypeSubordinate // 下级
)

type CollectionPlan struct {
	ID             int       `json:"id"`
	Name           string    `json:"name"`
	CreatedAt      time.Time `json:"created_at"`
	DataSourceType int       `json:"data_source_type"`
	RoleType       int       `json:"role_type"`
	DataPermission int       `json:"data_permission"`
}

func GetDataSourceType(companyID, SessionUserID, planID int, userList []*permission.UserPermission) (dst int, err error) {
	dst = DataSourceTypeOther
	// 1. 从采集计划表中获取项目 id
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{"id": planID, "is_deleted": 0})
	if err != nil {
		return
	}
	if plan == nil {
		return
	}
	// 2. 检查采集计划所在的项目是否属于当前账号创建
	project, err := models.ProjectsModel.SearchOne(db.Cond{"id": plan.ProjectId}) // Notice: 项目删除，采集计划不受影响
	if err != nil {
		return
	}
	if project == nil {
		return
	}
	if project.UserId == SessionUserID {
		logger.Infof("***SessionUserID:%v,project.UserID:%v,project:%v***,plan:%v", SessionUserID, project.UserId, project, plan)
		dst = DataSourceTypeOwned
		return
	}

	// 3. 检查采集计划所在的项目是否属于分享给了当前账号
	perms, err := models.ProjectsPermissionsModel.Search(db.Cond{"company_id": companyID, "project_id": project.Id, "is_deleted": 0})
	if err != nil {
		return
	}
	for _, v := range perms {
		if v.UserId == SessionUserID {
			dst = DataSourceTypeShared
			return
		}
	}

	// 4. 检查采集计划所在的项目是否属于直属下级、虚拟下级创建的 by max
	for _, each := range userList {
		if each.UserId == project.UserId {
			dst = DataSourceTypeSubordinate
			return
		}
	}

	return
}

func CollectionPlanList(SessionUserID, staffID, companyId, roleType int, dataPermission int, roleIDs []int, session string) ([]CollectionPlan, error) {
	logger.Infof("CollectionPlanList Start")
	planStaffs, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"staff_id":   staffID,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, fmt.Errorf("CollectionPlanList models.DataCollectPlanStaffsModel.Search error: %v", err)
	}

	planIDs := make([]string, 0)
	for _, p := range planStaffs {
		planIDs = append(planIDs, strconv.Itoa(p.PlanId))
	}
	if len(planIDs) == 0 {
		return nil, nil
	}

	plans, err := models.DataCollectPlansModel.Search(db.Cond{
		"where":      fmt.Sprintf(" id in (%s)", strings.Join(planIDs, ",")),
		"is_deleted": 0,
	})
	if err != nil {
		return nil, fmt.Errorf("CollectionPlanList models.DataCollectPlansModel.Search error: %v", err)
	}

	projectIDs := make(map[int]int, 0)
	for _, x := range plans {
		projectIDs[x.ProjectId] = x.ProjectId
	}

	cps := make([]CollectionPlan, 0)

	permissionUserList := new(permission.UserListPermission)
	if roleType == 2 && dataPermission == 2 {
		permissionUserList, err = permission.GetPermissionUserList(session)
		if err != nil {
			return nil, fmt.Errorf("call GetPermissionUserList failed. err: %v", err)
		}
	}
	userIds := []int{SessionUserID}
	for _, v := range permissionUserList.UserList {
		userIds = append(userIds, v.UserId)
	}

	projects, err := models.ProjectsModel.Search(db.Cond{"company_id": companyId, "user_id in": userIds, "is_deleted": 0})
	if err != nil {
		return nil, fmt.Errorf("InventoryList models.ProjectsPermissionsModel.Search error: %v", err)
	}

	var (
		userProjectIDs        = make(map[int]int, 0) // 当前账号创建
		permissionsProjectIDs = make(map[int]int, 0) // 下级账号创建
	)
	for _, x := range projects {
		if x.UserId == SessionUserID {
			userProjectIDs[x.Id] = x.Id
		} else {
			permissionsProjectIDs[x.Id] = x.Id
		}
	}

	for _, p := range plans {
		dataSourceType := 0
		if _, ok := userProjectIDs[p.ProjectId]; ok {
			dataSourceType = 1
		} else if _, ok := permissionsProjectIDs[p.ProjectId]; ok {
			dataSourceType = 2
		} else {
			dataSourceType = 3
		}

		cps = append(cps, CollectionPlan{
			ID:             p.Id,
			Name:           p.Name,
			CreatedAt:      p.CreatedAt,
			DataSourceType: dataSourceType,
			RoleType:       roleType,
			DataPermission: dataPermission,
		})
	}
	logger.Infof("***CollectionPlanList result:%v***", cps)
	return cps, nil
}

type Inventory struct {
	ID             int       `json:"id"`
	ProjectID      int       `json:"project_id"`
	ReportID       int       `json:"report_id"`
	SceneID        int       `json:"scene_id"`
	Name           string    `json:"name"`
	CreatedAt      time.Time `json:"created_at"`
	DataSourceType int       `json:"data_source_type"`
	DataPermission int       `json:"data_permission"`
}

func InventoryList(companyId, staffID, userId, roleType, dataPermission int, permittedOnly bool, sess string) (result []Inventory, err error) {
	projStaffs, err := models.ProjectsStaffsModel.Search(db.Cond{
		"staff_id":   staffID,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, fmt.Errorf("InventoryList models.ProjectsStaffsModel.Search error: %v", err)
	}

	projIDs := make([]int, 0, len(projStaffs))
	for _, p := range projStaffs {
		projIDs = append(projIDs, p.ProjectId)
	}

	if len(projIDs) == 0 {
		return nil, nil
	}

	projs, err := models.ProjectsModel.Search(db.Cond{
		"company_id": companyId,
		"id in":      projIDs,
		"is_deleted": 0,
		"orderby":    "created_at desc",
	})
	if err != nil {
		return nil, fmt.Errorf("InventoryList models.ProjectsModel.Search error: %v", err)
	}
	if (projs == nil || len(projs) == 0) && len(projIDs) > 0 {
		return result, common.NewRespErr(core.InvalidParamsErrNo, "参数错误")
	}

	projectsPermissionsMap := make(map[int]int)
	// 这里也要检查，直属下级、虚拟下级创建的项目 todo by zzj
	projectsPermissions, err := models.ProjectsPermissionsModel.Search(db.Cond{"company_id": companyId, "user_id": userId, "is_deleted": 0})
	if err != nil {
		return nil, fmt.Errorf("InventoryList models.ProjectsPermissionsModel.Search error: %v", err)
	}
	for _, v := range projectsPermissions {
		projectsPermissionsMap[v.ProjectId] = v.ProjectId
	}

	permissionUserList := new(permission.UserListPermission)
	if roleType == 2 && dataPermission == 2 {
		permissionUserList, err = permission.GetPermissionUserList(sess)
		if err != nil {
			return nil, fmt.Errorf("call GetPermissionUserList failed. err: %v", err)
		}
	}
	userIds := []int{userId}
	for _, v := range permissionUserList.UserList {
		userIds = append(userIds, v.UserId)
	}

	projects, err := models.ProjectsModel.Search(db.Cond{"company_id": companyId, "user_id in": userIds, "is_deleted": 0})
	if err != nil {
		return nil, fmt.Errorf("InventoryList models.ProjectsPermissionsModel.Search error: %v", err)
	}
	projectsMap := make(map[int]int)
	for _, v := range projects {
		if v.UserId == userId {
			projectsMap[v.Id] = v.Id
		} else {
			projectsPermissionsMap[v.Id] = v.Id
		}
	}

	inventories := make([]Inventory, 0)
	for _, p := range projs {
		dataSourceType := 0
		switch roleType {
		case 1:
			dataSourceType = 1
		case 2:
			if p.Id == projectsMap[p.Id] {
				dataSourceType = 1
				break
			}
			if p.Id == projectsPermissionsMap[p.Id] {
				dataSourceType = 2
				break
			}
			dataSourceType = 3
		}
		inventories = append(inventories, Inventory{
			ID:             trick(0, p.Id),
			ProjectID:      p.Id,
			ReportID:       GetReportID(p.Id),
			SceneID:        p.SceneId,
			Name:           p.Name,
			CreatedAt:      p.CreatedAt,
			DataSourceType: dataSourceType,
			DataPermission: dataPermission,
		})
	}

	sort.Slice(inventories, func(i, j int) bool {
		return inventories[i].CreatedAt.After(inventories[j].CreatedAt)
	})
	return inventories, nil
}

func trick(reportID, projectID int) int { // 前端需要根据 report_id 做唯一标识，但对于多个项目的实时数据，report_id 都为 0 ;-<<<
	if reportID == 0 {
		return 10000000 + projectID
	}
	return reportID
}

func GetReportID(ProjectID int) int {
	report := new(models.ProjectsDistributions)
	_, err := models.ProjectsDistributionsModel.Dao.SearchOne(
		report,
		db.Cond{
			"project_id": ProjectID,
			"is_deleted": 0,
			"orderby":    "created_at desc",
		},
	)
	if err != nil {
		logger.Errorf("isProjectDistributionIsCanAdjust models.ProjectsReportsModel.Search error: %v", err)
	}
	return report.Id
}
