package controllers

import (
	"bytes"
	"encoding/base64"
	"fmt"
	excel "github.com/360EntSecGroup-Skylar/excelize/v2"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"ifchange/dhr/core"
	"ifchange/dhr/logics/project"
	"ifchange/dhr/logics/utils"
	"ifchange/dhr/models"
	"strconv"
	"strings"
)

const (
	fileSize = 10485760 // 10M
)

type ProjectsUsersPerform struct {
	core.Controller
}

/**
 * @api {post} /projects_staffs_perform/upload    绩效表格上传
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 绩效表格上传
 *
 * @apiParam {string} session session
 * @apiParam {string} excel_name 上传文件名(后缀为.xlsx)
 * @apiParam {string} project_id 项目ID
 * @apiParam {string} content 内容
 *
 * @apiParamExample {json} Request-Example:
	{
	 "session":"",
     "excel_name":"",
     "project_id":12,
     "content":"eyJmcm9tIjoiQiIsInNyY19pZCI6MSwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTUxNzE3NDkiLCJzaWduYXR1cmUiOiI4NWY5Y2JiODNlNTFmMWVmNDk0NjUxMDA3MzBkODQwOWMxM2NjOWZkIn0"
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {int} update_count 更新数据条数
 * @apiSuccess {int} insert_count 插入数据条数
 * @apiSuccess {int} failed_count 失败数据条数
 * @apiSuccess {string} result.errmsg 失败的原因
 * @apiSuccess {string[]} result.mistake_site 失败单元格位置
 * @apiSuccess {string} result.mistake_reason 失败单元格原因
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"err_no": 0,
        "err_msg": "",
        "results": {
            "update_count": 2,
            "insert_count": 0,
            "failed_count": 1,
            "mistakes": [
                {
                    "site": "B5",
                    "reason": "员工工号和姓名不匹配"
                }
            ],
            "completion": 0.6666667,
            "url": "M00/48/E9/wKgByV0HBVWACKEpAAAlc39lCaU41.xlsx",
            "upload_id": 8
        }
	}
 *
*/

func (c *ProjectsUsersPerform) Upload(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ExcelName string `json:"excel_name" validate:"required"`
		ProjectID int    `json:"project_id" validate:"required"`
		Content   string `json:"content" validate:"required"`
	}{}
	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, param))
	// 验证session
	httpCtx.ThrowCheck(20304001, validate(param))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	if !strings.HasSuffix(param.ExcelName, ".xlsx") {
		httpCtx.ThrowCheck(20304001, err)
		return
	}

	// 内容base64解码
	s, err := base64.StdEncoding.DecodeString(param.Content)
	// 文件大小不超过10M
	if len(s) > fileSize {
		httpCtx.ThrowCheck(20304031, err)
		return
	}
	httpCtx.ThrowCheck(20304020, err)
	// 读取excel里面的内容，先打开
	// 判断文件格式是否正确
	excelParser, err := excel.OpenReader(bytes.NewReader(s))
	httpCtx.ThrowCheck(20305022, err)

	// 解析excel内容
	parseResult, err := project.ParseExcel(curUser.CompanyId, excelParser)
	httpCtx.ThrowCheck(20305000, err)

	// 获取存入时的upload_id
	uploadID, err := project.GetExcelUploadID(curUser.Id)
	httpCtx.ThrowCheck(20305000, err)
	// 存入数据库
	uploadResult, err := project.SaveResult(curUser.CompanyId, curUser.Id, uploadID, parseResult)
	httpCtx.ThrowCheck(20305000, err)
	// 把excel存入DFS
	uploadResult.Url, err = project.SaveExcel(uploadID, param.ProjectID, param.ExcelName, excelParser)
	httpCtx.ThrowCheck(20305011, err)
	httpCtx.Results = uploadResult
}

/**
 * @api {get} /projects_staffs_perform/download?session=abc&project_id=518 绩效表格下载
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 绩效表格下载
 *
 * @apiParam {string} session session
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
	}
 *
*/
func (c *ProjectsUsersPerform) Download(httpCtx *hfw.HTTPContext) {
	params := httpCtx.Request.URL.Query()

	session := params.Get("session")
	projectID := params.Get("project_id")

	if session == "" || projectID == "" {
		httpCtx.ThrowCheck(20144001, "session or projectID not empty.")
	}
	projectId, err := strconv.Atoi(projectID)
	httpCtx.ThrowCheck(20305001, err)
	p, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectId})
	if p == nil {
		httpCtx.ThrowCheck(20304026, "project not found.")
	}
	httpCtx.ThrowCheck(20144001, VerifyRequestSession(httpCtx, &Session{
		SessionID: session,
	}))

	filename, data, err := project.GetFileName(fmt.Sprintf("绩效数据_%s.xlsx", utils.GetCurrentDateYMDHMS()))
	httpCtx.ThrowCheck(20305001, err)

	excelParser, err := excel.OpenReader(bytes.NewReader(data))
	httpCtx.ThrowCheck(20305022, err)
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	// 填写模板里内容
	err = project.FillTemplateForProject(curUser.CompanyId, projectId, excelParser)
	httpCtx.ThrowCheck(20304028, err)
	buffer, err := excelParser.WriteToBuffer()
	httpCtx.ThrowCheck(20305001, err)
	httpCtx.ReturnFileContent("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename, buffer)
}

/**
 * @api {get} /projects_staffs_perform/download_template?session=abc&project_id=12  绩效表格模板下载 todo by zzj 包含离职员工
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 绩效表格模板下载

 * @apiParam {string} session session
 * @apiParam {int} project_id 项目ID
 *
 * @apiSuccess {Object} results 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
	{
	}
 **/

func (c *ProjectsUsersPerform) DownloadTemplate(httpCtx *hfw.HTTPContext) {
	params := httpCtx.Request.URL.Query()

	session := params.Get("session")
	projectID := params.Get("project_id")

	if session == "" || projectID == "" {
		httpCtx.ThrowCheck(20144001, "session or projectID not empty")
	}
	projectId, err := strconv.Atoi(projectID)
	httpCtx.ThrowCheck(20305001, err)
	list, err := models.ProjectsModel.Search(db.Cond{"id": projectId})
	if len(list) == 0 {
		httpCtx.ThrowCheck(20304026, "项目不存在")
	}
	httpCtx.ThrowCheck(20144001, VerifyRequestSession(httpCtx, &Session{
		SessionID: session,
	}))

	filename, data, err := project.GetFile()
	httpCtx.ThrowCheck(20305001, err)

	excelParser, err := excel.OpenReader(bytes.NewReader(data))
	httpCtx.ThrowCheck(20305022, err)
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	// 填写模板里内容
	err = project.FillTemplate(curUser.CompanyId, projectId, excelParser)
	httpCtx.ThrowCheck(20304028, err)
	buffer, err := excelParser.WriteToBuffer()
	httpCtx.ThrowCheck(20305001, err)
	httpCtx.ReturnFileContent("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename, buffer)
}

/**
 * @api {post} /projects_staffs_perform/level    提供等级评价级别
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 提供等级评价级别
 *
 * @apiParam {string} session session
 * @apiParam {int} upload_id 公司ID （上传Excel时返回）
 *
 * @apiParamExample {json} Request-Example:
	{
     "session":"",
     "upload_id":123,
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {[]string} level 等级列表
 *
 * @apiSuccessExample {json} Response-Example:
	{
   		"err_no": 0,
        "err_msg": "",
        "results": {
            "level": [
                "B",
                "S"
            ]
        }
	}
 *
*/

func (c *ProjectsUsersPerform) Level(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		UploadID int `json:"upload_id" validate:"required"`
	}{}
	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, param))
	// 验证session
	httpCtx.ThrowCheck(20304001, validate(param))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	levelResult, err := project.Level(curUser.CompanyId, curUser.Id, param.UploadID)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.Results = levelResult
}

/**
 * @api {post} /projects_staffs_perform/LevelStandard    等级映射关系
 * @apiVersion 0.1.0
 * @apiGroup Perform
 * @apiDescription 等级映射关系
 *
 * @apiParam {string} session session
 * @apiParam {string} url       上传excel时存在url
 * @apiParam {string} upload_id 上传excel时存在upload_id
 * @apiParam {[]map} level_relationship  级别映射表  从level接口获取所有该公司等级如（s,a,b）/1,2,3分别代表：高，中，低
 * @apiParam {string} level           Excel表中获得的级别
 * @apiParam {string} level_standard  标准级别
 *
 * @apiParamExample {json} Request-Example:
	{
      "session":"",
       "url":"",
		"upload_id":123,
       "level_relationship":

             [ {
                "level":"s",
				"level_standard":1
              },{
              	"level":"a",
				"level_standard":2
              }
              ]
}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {bool} success 保存成功
 * @apiSuccessExample {json} Response-Example:
	{
     "err_no":0,
	 "err_msg":"",
 	 "results":true,
	}
 *
*/

func (c *ProjectsUsersPerform) LevelStandard(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		Url               string                      `json:"url" validate:"required"`
		UploadID          int                         `json:"upload_id" validate:"required"`
		LevelRelationship []project.LevelRelationship `json:"level_relationship" validate:"required"`
	}{}
	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, param))
	// 验证session
	httpCtx.ThrowCheck(20304001, validate(param))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))
	//
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	// 更新绩效表
	updateResult, err := project.UpdatePerformance(curUser.CompanyId, curUser.Id, param.UploadID, param.LevelRelationship, param.Url)
	httpCtx.ThrowCheck(20305000, err)
	// 更新标准记录表
	updateResult, err = project.Record(curUser.CompanyId, curUser.Id, param.LevelRelationship, param.Url)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = updateResult
}
