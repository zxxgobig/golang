package interview_test

import (
    "gitlab.ifchange.com/bot/hfw/encoding"
    "ifchange/dhr/logics/interview"
    "testing"
)

func TestNormStarCallback(t *testing.T) {
    kk := map[string]float32{"领导支配": 2, "工作个性": 3.14, "情绪控制": 6, "亲和力": 4, "个性": 3.14, "掩饰性": 1, "内归因": 4, "客户导向": 2, "合作精神": 2, "辅助指标": 1, "坚韧不拔": 2}
    data, err := encoding.JSON.Marshal(kk)
    if err != nil {
        t.Error(err)
    }
    params := &interview.NormStarCallbackParams{
        DimScore: string(data),
    }
    err = interview.NormStarCallback(params)
    if err != nil {
        t.Error(err)
    }
}
