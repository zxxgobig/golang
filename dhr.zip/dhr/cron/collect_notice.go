package cron

import (
    "gitlab.ifchange.com/bot/logger"
    "ifchange/dhr/logics/data_collect"
    "time"
)

func init() {
    go func() {
        dct := &DataCollectTimer{}
        dct.startCollectPlan()
    }()
}

type DataCollectTimer struct {
    // 间隔一天
    durationOneDay time.Duration
    // 间隔数小时
    durationFewHours time.Duration
    // 定时器执行时间
    execHourTime int
}

func (dct *DataCollectTimer) startCollectPlan() {
    dct.initTimerParam()

    switch dct.isPastTenClock() {
    case true:
        dct.createTimer(dct.durationOneDay)
    case false:
        dct.createTimer(dct.durationFewHours)
    }
}

func (dct *DataCollectTimer) initTimerParam() {
    // 间隔24小时，明天执行任务
    dct.durationOneDay = time.Hour * 24
    // 今天执行任务
    dct.durationFewHours = 0
    // 当天10点执行任务
    dct.execHourTime = 10
}

func (dct *DataCollectTimer) createTimer(duration time.Duration) {
    for {
        logger.Infof("createTimer start to work")
        now := time.Now()
        // ten o'clock today or tomorrow
        next := now.Add(duration)
        // reset rotate every 24 hours if duration is 0
        if duration == dct.durationFewHours {
            duration = dct.durationOneDay
        }
        // ten o'clock
        next = time.Date(next.Year(), next.Month(), next.Day(), dct.execHourTime, 0, 0, 0, next.Location())
        t := time.NewTimer(next.Sub(now))
        // set timer
        <-t.C
        sendNotice()
        logger.Infof("createTimer finish work this round")
    }
}

// 是否过了今天10点
func (dct *DataCollectTimer) isPastTenClock() bool {
    now := time.Now()
    // today, ten o'clock
    todayClock := time.Date(now.Year(), now.Month(), now.Day(), dct.execHourTime, 0, 0, 0, now.Location())
    // is past ten o'clock
    return now.After(todayClock)
}

// 发送提醒邮件、结束采集任务
// 每天10点给start_time为今天的采集任务，发送通知邮件
// 每天10点把end_time为今天的采集任务，置为"已完成"
func sendNotice() {
    // 发送测评邮件
    noticeLog := data_collect.NewDataCollectNoticeLog()
    err := noticeLog.NoticeMailWhenTiming()
    if err != nil {
        logger.Warnf("sendNotice, NoticeMailWhenTiming err ", err)
    }
    // 置为已完成
    plan := data_collect.NewDataCollectPlan()
    _, err = plan.CompletedPlans()
    if err != nil {
        logger.Warnf("sendNotice, CompletedPlans err ", err)
    }
}
