package region

import "testing"

func TestGetRegionInfos(t *testing.T) {
	result, err := GetRegionInfos()
	if err != nil {
		t.Logf("call GetRegionInfos failed. err:%v", err)
	}

	for _, each := range result {
		t.Logf("id:%v - name:%v\n", each.Id, each.Name)
	}
}
