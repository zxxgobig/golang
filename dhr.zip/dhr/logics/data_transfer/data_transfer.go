package data_transfer

import (
	"fmt"
	corn "github.com/robfig/cron/v3"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/signal"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/logger"
	"ifchange/dhr/models"
	"time"
)

type DataOne struct {
	Id       int       `json:"id"`
	Name     string    `json:"name"`
	Gender   int       `json:"gender"`
	UpdateAt time.Time `json:"updated_at"`
}

type DataParams struct {
	TopId     int         `json:"top_id"`
	TableName string      `json:"table_name"`
	Records   interface{} `json:"records"`
}

type HumanResourcesResult struct {
	TotalNum   int      `json:"total_num"`
	SuccessNum int      `json:"success_num"`
	FailNum    int      `json:"fail_num"`
	FailInfos  []string `json:"fail_infos"`
}

var signalContext = signal.GetSignalContext()
var c = corn.New(corn.WithSeconds())

var interviewNameMap = make(map[int]string)

func init() {
	interviewNameMap = map[int]string{
		1: "素质",
		2: "性格类型",
		5: "潜力",
		6: "工作选择价值观",
	}
	go func() {
		//err := InterviewsOne(1)
		//logger.Error(err)
		err := ProjectsPerformancesOne(1)
		logger.Error(err)
		err = StaffsInterviewsDetailsOne(1)
		logger.Error(err)
	}()

	id, _ := c.AddFunc("0 0 0 * * *", func() {

		//err := InterviewsOne(2)
		logger.Info("corn starting...")
		err := ProjectsPerformancesOne(2)
		logger.Error(err)
		err = StaffsInterviewsDetailsOne(2)
		logger.Error(err)
	})
	c.Entry(id)
	c.Start()
}

type StaffsInterviewsDetailsParams struct {
	StaffId     int    `json:"staff_id"`
	CompanyId   int    `json:"company_id"`
	Name        string `json:"name"`
	SubItemName string `json:"sub_item_name"`
	Time        string `json:"time"`
	Score       string `json:"score"`
}

func StaffsInterviewsDetailsOne(cType int) (err error) {
	zero := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
	next := time.Now().Format("2006-01-02 15:04:05")
	staffsInterviews := make([]*models.StaffsInterviews, 0, 100)
	if cType == 1 {
		staffsInterviews, err = models.StaffsInterviewsModel.Search(db.Cond{
			"where":           "id > 0",
			"interview_id in": []int{1, 2, 5, 6},
			"is_deleted":      0,
		})
	} else {
		staffsInterviews, err = models.StaffsInterviewsModel.Search(db.Cond{
			"where":           fmt.Sprintf("updated_at > '%s' and updated_at < '%s'", zero, next),
			"interview_id in": []int{1, 2, 5, 6},
			"is_deleted":      0,
		})
	}
	if err != nil {
		return err
	}
	staffsInterviewsList := make([]*StaffsInterviewsDetailsParams, 0, 100)
	for k, _ := range staffsInterviews {
		interview := staffsInterviews[k]
		staffsInterviewsDetails, err := models.StaffsInterviewsDetailsModel.Search(db.Cond{
			"staff_id":        interview.StaffId,
			"interview_id":    interview.InterviewId,
			"status":          interview.Status,
			"project_id":      interview.ProjectId,
			"data_collect_id": interview.DataCollectId,
			"is_deleted":      0,
		})
		if err != nil {
			return err
		}
		for k, _ := range staffsInterviewsDetails {
			details := staffsInterviewsDetails[k]
			staffsInterviewsList = append(staffsInterviewsList, &StaffsInterviewsDetailsParams{
				StaffId:     details.StaffId,
				CompanyId:   interview.CompanyId,
				Name:        interviewNameMap[details.InterviewId],
				SubItemName: GetName(details.InterviewId, details.SubItem),
				Time:        details.UpdatedAt.Format("2006-01-02 15:04:05"),
				Score:       fmt.Sprintf("%v", details.Score),
			})
		}

	}

	length := len(staffsInterviewsList) / 100
	for i := 0; i <= length; i++ {
		p := api.NewPost("immut_ingest", "batch_append")
		before := i * 100
		after := i*100 + 100
		if i == length {
			after = len(staffsInterviewsList)
		}
		p.P = &DataParams{
			TopId:     1,
			TableName: "staff_evaluation_record",
			Records:   staffsInterviewsList[before:after],
		}
		result := &HumanResourcesResult{}
		for n := 0; n < 3; n++ {
			err := api.SimpleCurl(nil, config.AppConfig.Custom["HumanResources"], p, &result)
			if err != nil {
				logger.Error(err)
				time.Sleep(2)
				continue
			}
			break
		}
	}
	return err
}

type ProjectsPerformancesParams struct {
	StaffId           int    `json:"staff_id"`
	CompanyId         int    `json:"company_id"`
	StartTime         string `json:"start_time"`
	EndTime           string `json:"end_time"`
	Level             string `json:"level"`
	Text              string `json:"text"`
	PerformanceTagIds string `json:"performance_tag_ids"`
	Source            int    `json:"source"`
}

func ProjectsPerformancesOne(cType int) (err error) {
	zero := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
	next := time.Now().Format("2006-01-02 15:04:05")
	var total int64
	if cType == 1 {
		total, err = models.ProjectsPerformancesModel.Count(db.Cond{"where": "id > 0"})
	} else {
		total, err = models.ProjectsPerformancesModel.Count(db.Cond{"where": fmt.Sprintf("updated_at > '%s' and updated_at < '%s'", zero, next)})
	}

	if err != nil {
		return err
	}
	var i int64
	for i = 0; i <= total%100+total; i += 100 {
		logger.Info("ProjectsPerformancesOne")
		var data []*models.ProjectsPerformances
		if cType == 1 {
			data, err = models.ProjectsPerformancesModel.Search(db.Cond{
				"page":     i%100 + 1,
				"pagesize": 100,
			})
		} else {
			where := fmt.Sprintf("updated_at > '%s' and updated_at < '%s'", zero, next)
			data, err = models.ProjectsPerformancesModel.Search(db.Cond{
				"where":    where,
				"page":     i%100 + 1,
				"pagesize": 100,
			})
		}

		if err != nil {
			return err
		}

		projectsPerformancesList := make([]*ProjectsPerformancesParams, 0, 100)
		for k, _ := range data{
			performances := data[k]
			if performances.SelfEval != "" {
				projectsPerformancesList = append(projectsPerformancesList,
					&ProjectsPerformancesParams{
						CompanyId: performances.CompanyId,
						StaffId: performances.StaffId,
						StartTime: performances.CreatedAt.Format("2006-01-02 15:04:05"),
						EndTime: performances.UpdatedAt.Format("2006-01-02 15:04:05"),
						Level: performances.Level,
						Text: performances.SelfEval,
						PerformanceTagIds: "",
						Source: 1,
					})
			}
			if performances.OthersEval1 != "" {
				projectsPerformancesList = append(projectsPerformancesList,
					&ProjectsPerformancesParams{
						CompanyId: performances.CompanyId,
						StaffId: performances.StaffId,
						StartTime: performances.CreatedAt.Format("2006-01-02 15:04:05"),
						EndTime: performances.UpdatedAt.Format("2006-01-02 15:04:05"),
						Level: performances.Level,
						Text: performances.OthersEval1,
						PerformanceTagIds: "",
						Source: 2,
					})
			}
			if performances.OthersEval2 != "" {
				projectsPerformancesList = append(projectsPerformancesList,
					&ProjectsPerformancesParams{
						CompanyId: performances.CompanyId,
						StaffId: performances.StaffId,
						StartTime: performances.CreatedAt.Format("2006-01-02 15:04:05"),
						EndTime: performances.UpdatedAt.Format("2006-01-02 15:04:05"),
						Level: performances.Level,
						Text: performances.OthersEval2,
						PerformanceTagIds: "",
						Source: 2,
					})
			}
			if performances.OthersEval3 != "" {
				projectsPerformancesList = append(projectsPerformancesList,
					&ProjectsPerformancesParams{
						CompanyId: performances.CompanyId,
						StaffId: performances.StaffId,
						StartTime: performances.CreatedAt.Format("2006-01-02 15:04:05"),
						EndTime: performances.UpdatedAt.Format("2006-01-02 15:04:05"),
						Level: performances.Level,
						Text: performances.OthersEval3,
						PerformanceTagIds: "",
						Source: 2,
					})
			}
			if performances.OthersEval4 != "" {
				projectsPerformancesList = append(projectsPerformancesList,
					&ProjectsPerformancesParams{
						CompanyId: performances.CompanyId,
						StaffId: performances.StaffId,
						StartTime: performances.CreatedAt.Format("2006-01-02 15:04:05"),
						EndTime: performances.UpdatedAt.Format("2006-01-02 15:04:05"),
						Level: performances.Level,
						Text: performances.OthersEval4,
						PerformanceTagIds: "",
						Source: 2,
					})
			}
			if performances.OthersEval5 != "" {
				projectsPerformancesList = append(projectsPerformancesList,
					&ProjectsPerformancesParams{
						CompanyId: performances.CompanyId,
						StaffId: performances.StaffId,
						StartTime: performances.CreatedAt.Format("2006-01-02 15:04:05"),
						EndTime: performances.UpdatedAt.Format("2006-01-02 15:04:05"),
						Level: performances.Level,
						Text: performances.OthersEval5,
						PerformanceTagIds: "",
						Source: 2,
					})
			}

		}
		length := len(projectsPerformancesList) / 100
		for i := 0; i <= length; i++ {
			before := i * 100
			after := i*100 + 100
			if i == length {
				after = len(projectsPerformancesList)
			}
			params := &DataParams{
				TableName: "staff_work_performance",
				Records:   projectsPerformancesList[before: after],
			}

			p := api.NewPost("immut_ingest", "batch_append")

			p.P = params
			result := &HumanResourcesResult{}
			for n := 0; n < 3; n++ {
				err := api.SimpleCurl(nil, config.AppConfig.Custom["HumanResources"], p, &result)
				if err != nil {
					logger.Error(err)
					time.Sleep(2)
					continue
				}
				break
			}
		}


	}
	return err
}

func InterviewsOne(cType int) (err error) {
	zero := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
	next := time.Now().Format("2006-01-02 15:04:05")
	var total int64
	if cType == 1 {
		total, err = models.InterviewsModel.Count(db.Cond{"where": "id > 0"})
	} else {
		total, err = models.InterviewsModel.Count(db.Cond{"where": fmt.Sprintf("updated_at > '%s' and updated_at < '%s'", zero, next)})
	}

	if err != nil {
		return err
	}
	var i int64
	for i = 0; i <= total%100+total; i += 100 {
		logger.Info("InterviewsOne")
		var data []*models.Interviews
		if cType == 1 {
			data, err = models.InterviewsModel.Search(db.Cond{
				"page":     i%100 + 1,
				"pagesize": 100,
			})
		} else {
			where := fmt.Sprintf("updated_at > '%s' and updated_at < '%s'", zero, next)
			data, err = models.InterviewsModel.Search(db.Cond{
				"where":    where,
				"page":     i%100 + 1,
				"pagesize": 100,
			})
		}

		if err != nil {
			return err
		}
		params := &DataParams{
			TopId:     1,
			TableName: "interviews",
			Records:   data,
		}

		p := api.NewPost("immut_ingest", "list_upsert")
		p.P = params
		result := &HumanResourcesResult{}
		for n := 0; n < 3; n++ {
			err := api.SimpleCurl(nil, config.AppConfig.Custom["HumanResources"], p, &result)
			if err != nil {
				logger.Error(err)
				time.Sleep(2)
				continue
			}
			break
		}

	}
	return err
}
