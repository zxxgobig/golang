package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"strconv"

	qrcode "github.com/skip2/go-qrcode"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/hfwkit/utils"

	"ifchange/dhr/core"
	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/data_collect"
	"ifchange/dhr/logics/interview"
	"ifchange/dhr/models"
)

type Interviews struct {
	core.Controller
}

/**
* @api {get} /interviews/qrcode?uuid=xx 二维码获取
* @apiVersion 0.1.0
* @apiGroup Interview
* @apiDescription 项目列表
*
* @apiParam {String} uuid 题目套装id
*
* @apiParamExample {json} Request-Example:
*
{}
*
* @apiSuccessExample {json} Response-Example:
{}
*
*/
// 示例 http://127.0.0.1:63333/interviews/qrcode?uuid=ff458af6-b722-330f-9040-c8742d2825b0
func (c *Interviews) Qrcode(httpCtx *hfw.HTTPContext) {

	emailUuid := httpCtx.Request.FormValue("uuid")
	if libraries.StrLen(emailUuid) == 0 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("uuid unvalid"))
	}
	var png []byte
	staffInterview, err := interview.GetInterviewByEamilUuid(emailUuid)
	httpCtx.ThrowCheck(20304001, err)
	if staffInterview == nil {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("record not found"))
	}
	httpCtx.SetDownloadMode(fmt.Sprintf("答题码.png"))
	staffs, err := dhr_staff.ListStaffByIds(nil, staffInterview.CompanyId, []int{staffInterview.StaffId}, true, nil)
	httpCtx.ThrowCheck(20304001, err)
	if len(staffs) != 1 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("获取员工数量不为1"))
	}
	verifyCode, err := data_collect.GetCollectPlanVerifyCode(staffInterview.DataCollectId)
	if err != nil {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("采集计划查询错误"))
	}

	staff := staffs[0]
	secretKey, err := utils.CreateUuid(staff.Id)
	httpCtx.ThrowCheck(20304001, err)
	qrCodeURL := config.AppConfig.Custom["DhrUrl"] + "interviews/assessment/uuid=" + emailUuid + "&company_id=" +
		strconv.Itoa(staffInterview.CompanyId) + "&src_id=1&name=" + staff.Name + "&secret_key=" + secretKey + "&verify_phone=" +
		strconv.Itoa(verifyCode) + "&product_code=1&staff_id=" + strconv.Itoa(staff.Id)
	png, err = qrcode.Encode(qrCodeURL, qrcode.Medium, 256)
	if err == nil {
		_, _ = httpCtx.ResponseWriter.Write(png)
		return
	}
}

/**
 * @api {post} /interviews/get  获取试题
 * @apiVersion 0.1.0
 * @apiGroup Interviews
 * @apiDescription 获取试题 一套题（uuid）包含多张试卷（interview_uuid），interview_id为试卷的类型
 *
 * @apiParam {String} uuid 套题id
 * @apiParam {Number} interview_id 类型id(1素质测评 2潜力测评)
 * @apiParam {Object} param 参数
 *
 * @apiParamExample {json} Request-Example:
{
	"uuid": "e490d5d8-3967-3a20-8ebb-64c951b2f2c5",
	"interview_id": 1,
	"param":{}
}
*
* @apiSuccess {Bool} result.interviews_info 全部试卷
* @apiSuccess {Bool} result.interviews_info.status 试卷状态 未开始 1已开始 2完成
* @apiSuccess {Bool} result.interviews_info.uuid 测评试卷id
* @apiSuccess {Bool} result.interviews_info.created_at 测评试卷创建时间，10位时间戳
* @apiSuccess {Bool} result.cur_interview_id 当前试卷类型 1性格测评 5潜力测评
* @apiSuccess {Bool} result.cur_interview_uuid 当前试卷id
* @apiSuccess {Bool} result.data 测评数据
* @apiSuccessExample {json} Response-Example:
{
	"interviews_info": [
		{
			"status": 1,
			"uuid": "723",
			"created_at": "1560999235"
		}
	],
	"cur_interview_id": 1,
	"cur_interview_uuid": "723",
	"data": {
		"is_finished": 1
	}
}
 *
*/

type InterviewUuid struct {
	Uuid        string          `json:"uuid"  validate:"required"`
	InterviewId int             `json:"interview_id"  validate:"required"`
	Param       json.RawMessage `json:"param"`
}

func (c *Interviews) Get(httpCtx *hfw.HTTPContext) {
	param := InterviewUuid{}
	if httpCtx.Request.Method == "GET" {
		param.Uuid = httpCtx.Request.FormValue("uuid")
		var err error
		param.InterviewId, err = strconv.Atoi(httpCtx.Request.FormValue("interview_id"))
		httpCtx.ThrowCheck(20304001, err)
	} else {
		err := api.RequestUnmarshal(httpCtx, &param)
		httpCtx.ThrowCheck(20304001, err)
	}

	if param.InterviewId < 1 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("interviewId unvalid"))
	}
	finishStatus, err := interview.Get(param.Uuid, param.InterviewId, param.Param)
	if param.InterviewId == interview.IntvNormstar {
		if err != nil {
			var respErr *common.RespErr
			var ok bool
			respErr, ok = err.(*common.RespErr)
			if ok {
				httpCtx.Redirect(config.AppConfig.Custom["TalentReviewURL"] + fmt.Sprintf("404?err_no=%v&err_msg=%v", respErr.ErrNo(), respErr.ErrMsg()))
			}
		} else {
			httpCtx.Redirect(config.AppConfig.Custom["NormstartUrl"] + finishStatus.CurInterviewUuid)
		}
	} else {
		httpCtx.ThrowCheck(20304001, err)
		httpCtx.Results = finishStatus
	}
}

/**
* @api {post} /interviews/commit  提交试题
* @apiVersion 0.1.0
* @apiGroup Interviews
* @apiDescription 当题目类型（interview_id）是bei（1）是提交不返回下一题，如果是potential(5)则返回下一题内容 请求的post数据以相应的测评文档为准
 * @apiParam {Object} param 参数
*
* @apiParam {String} uuid 套题id
* @apiParam {Number} interview_id 类型id(1素质测评 2潜力测评)
*
* @apiParamExample {json} Request-Example:
{
	"uuid": "e490d5d8-3967-3a20-8ebb-64c951b2f2c5",
	"interview_id": 1,
	"param":{}
}
*
* @apiSuccess {Bool} result.interviews_info 全部试卷
* @apiSuccess {Bool} result.interviews_info.status 试卷状态 未开始 1已开始 2完成
* @apiSuccess {Bool} result.interviews_info.uuid 测评试卷id
* @apiSuccess {Bool} result.interviews_info.created_at 测评试卷创建时间，10位时间戳
* @apiSuccess {Bool} result.cur_interview_id 当前试卷类型 1性格测评 5潜力测评
* @apiSuccess {Bool} result.cur_interview_uuid 当前试卷id
* @apiSuccess {Bool} result.data 测评数据
* @apiSuccessExample {json} Response-Example:
{
	"interviews_info": [
		{
			"status": 1,
			"uuid": "723",
			"created_at": "1560999235"
		}
	],
	"cur_interview_id": 1,
	"cur_interview_uuid": "723",
	"data": {
		"is_finished": 1
	}
}
*
*/
func (c *Interviews) Commit(httpCtx *hfw.HTTPContext) {
	param := InterviewUuid{}
	err := api.RequestUnmarshal(httpCtx, &param)
	httpCtx.ThrowCheck(20304001, err)

	if param.InterviewId < 1 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("interviewId unvalid"))
	}
	result, err := interview.Commit(param.Uuid, param.InterviewId, param.Param)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.Results = result
}

/**
// 保存答案
func (c *Interviews) SaveResult(httpCtx *hfw.HTTPContext) {
	uuid := httpCtx.Request.FormValue("uuid")
	interviewId := httpCtx.Request.FormValue("interview_id")
	if libraries.StrLen(uuid) == 0 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("uuid unvalid"))
	}
	_interviewId, err := strconv.Atoi(interviewId)
	httpCtx.ThrowCheck(20304001, err)

	param := json.RawMessage{}
	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))
	httpCtx.ThrowCheck(20304001, interview.ResultCommit(_interviewId, uuid, param))
}
*/

/**
* @api {post} /interviews/save_voice  保存语音
* @apiVersion 0.1.0
* @apiGroup Interviews
* @apiDescription 当题目类型（interview_id）是bei（1）是提交不返回下一题，如果是potential(5)则返回下一题内容 请求的post数据以相应的测评文档为准
 * @apiParam {Object} param 参数
*
* @apiParam {String} uuid 套题id
* @apiParam {Number} interview_id 类型id(1素质测评 2潜力测评)
*
* @apiParamExample {json} Request-Example:
{
	"uuid": "e490d5d8-3967-3a20-8ebb-64c951b2f2c5",
	"interview_id": 1,
	"param":{}
}
*
* @apiSuccessExample {json} Response-Example:
{
}
*
*/
// func (c *Interviews) SaveVoice(httpCtx *hfw.HTTPContext) {
// 	param := InterviewUuid{}
// 	err := api.RequestUnmarshal(httpCtx, &param)
// 	httpCtx.ThrowCheck(20304001, err)
//
// 	if param.InterviewId < 1 {
// 		httpCtx.ThrowCheck(20304001, fmt.Errorf("interviewId unvalid"))
// 	}
// 	result, err := interview.SaveVoice(param.Uuid, param.InterviewId, param.Param)
// 	httpCtx.ThrowCheck(20304001, err)
// 	httpCtx.Results = result
// }

type (
	InterviewSaveVoiceRequest struct {
		Uuid        string                 `json:"uuid"  validate:"required"`
		InterviewID int                    `json:"interview_id"  validate:"required"`
		Param       interview.BeiSaveVoice `json:"param"`
	}
)

func (c *Interviews) SaveVoice(httpCtx *hfw.HTTPContext) {
	request := InterviewSaveVoiceRequest{}
	err := api.RequestUnmarshal(httpCtx, &request)
	httpCtx.ThrowCheck(20304001, err)

	file, _, err := httpCtx.Request.FormFile("voice")
	if err != nil {
		return
	}
	defer file.Close()
	data, err := ioutil.ReadAll(file)
	if err != nil {
		return
	}

	request.Param.Voice = data

	if request.InterviewID < 1 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("interviewId unvalid"))
	}
	result, err := interview.SaveVoice(request.Uuid, request.InterviewID, &request.Param)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.Results = result
}

type InterviewsListStaffInterviewsParam struct {
	ListStaffsInterviewsResult []*interview.ListStaffsInterviewsResult `json:"interviews"`
	DataCollectPlan            *models.DataCollectPlans                `json:"plan"`
}

/**
* @api {post} /interviews/list_statff_interviews 获取员工试题列表
* @apiVersion 0.1.0
* @apiGroup Interviews
* @apiDescription 获取员工试题列表 for小程序
*
* @apiParam {String} uuid 试题套装id（包含bei potential等多组试题）
*
* @apiParamExample {json} Request-Example:
{}
*
* @apiSuccess {Object[]} interviews 试题组列表
* @apiSuccess {Number} interviews.status 试题组状态 0创建完成 1正在答题 2完成
* @apiSuccess {Number} interviews.take_time 试题组状态 费时s
* @apiSuccess {String} plan.start_time 计划时间开始
* @apiSuccess {String} plan.end_time 计划结束时间
* @apiSuccessExample {json} Response-Example:
 {
	"interviews": [
		{
			"staffs_interviews_id": 3,
			"interview_id": 5,
			"product_id": 13,
			"name": "潜力测评",
			"status": 0,
			"sub_item_count": 30,
			"take_time": 900
		},
		{
			"staffs_interviews_id": 1,
			"interview_id": 1,
			"product_id": 9,
			"name": "素质测评",
			"status": 0,
			"sub_item_count": 27,
			"take_time": 900
		}
	],
	"plan": {
		"id": 1,
		"start_time": "2019-07-01T00:00:00+08:00",
		"end_time": "2019-08-01T00:00:00+08:00",
	}
}
*
*/

// 获取该员工的测评记录
func (c *Interviews) ListStatffInterviews(httpCtx *hfw.HTTPContext) {

	param := InterviewUuid{}
	err := api.RequestUnmarshal(httpCtx, &param)
	httpCtx.ThrowCheck(20304001, err)

	result, dataCollectId, err := interview.ListStaffsInterviews(param.Uuid)
	httpCtx.ThrowCheck(20304001, err)
	if len(result) == 0 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("ListStatffInterviews:no record found "))
	}
	dataCollectPlan, err := data_collect.GetPlanById(dataCollectId)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.Results = InterviewsListStaffInterviewsParam{
		ListStaffsInterviewsResult: result,
		DataCollectPlan:            dataCollectPlan,
	}
}

/**
* @api {post} /interviews/feed_back 测评反馈
* @apiVersion 0.1.0
* @apiGroup Interviews
* @apiDescription 测评反馈
*
* @apiParam {String} uuid 试题套装id（包含bei potential等多组试题）
* @apiParam {String} interview_id 题目类型
* @apiParam {String} content 反馈内容
*
* @apiParamExample {json} Request-Example:
 {
	"content": "xxx"
	"interview_id": 1,
	"uuid": "",
 }
*
* @apiSuccess {Object[]} results 结果
* @apiSuccessExample {json} Response-Example:
 {}
*
*/
func (c *Interviews) FeedBack(httpCtx *hfw.HTTPContext) {
	params := struct {
		InterviewUuid
		Content string `json:"content"`
	}{}

	httpCtx.ThrowCheck(core.RequestError, api.RequestUnmarshal(httpCtx, &params))

	if CountCnWord(params.Content) >= 200 || CountCnWord(params.Content) == 0 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("content len unvalid"))
	}

	if params.InterviewId < 1 {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("interviewId unvalid"))
	}
	// 需要测评反馈
	httpCtx.ThrowCheck(20304001, interview.FeedBack(params.Uuid,
		params.InterviewId, params.Content))

}
