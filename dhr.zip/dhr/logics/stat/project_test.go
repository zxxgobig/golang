package stat

import "testing"

func TestProjectStaffSex(t *testing.T) {
	sex := getStaffSexByID(122927, 145)
	t.Log(sex)
}
