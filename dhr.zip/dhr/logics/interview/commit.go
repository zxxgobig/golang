package interview

import (
	"fmt"
	"ifchange/dhr/libraries"
	common2 "ifchange/dhr/logics/common"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/logger"

	mqKit "gitlab.ifchange.com/bot/commonkit/mq"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"ifchange/dhr/core"
)

func Commit(emailUuid string, interviewId int, param interface{}) (response interface{}, err error) {
	result := FinishStatus{}
	allStaffsInterviews, err := GetStaffsInterviewsByEmailUuid(emailUuid)

	if err != nil {
		return
	}
	result.setInterviewsInfo(allStaffsInterviews)

	if len(allStaffsInterviews) == 0 {
		err = fmt.Errorf("no record found")
		return
	}

	CurStaffsInterviews, err := models.StaffsInterviewsModel.Search(db.Cond{
		"email_uuid": emailUuid,
		"interview_id": interviewId,
		"is_deleted": 0,
	})

	if err != nil {
		return result, common.NewRespErr(core.RequestError, "请求错误")
	}
	if len(CurStaffsInterviews) == 0 {
		return result, common.NewRespErr(core.Completed, "测评不存在")
	}
	logger.Debugf("^^^^^^^^^:%#v", CurStaffsInterviews[0])

	//CurStaffsInterviews := []*models.StaffsInterviews{}
	//finishFlag := true
	//
	//for _, x := range allStaffsInterviews {
	//	if x.Status < 2 {
	//		finishFlag = false
	//		break
	//	}
	//}
	//// 全部完成
	//if finishFlag == true {
	//	return result, nil
	//}

	//// 正在进行的题目
	//for _, x := range allStaffsInterviews {
	//	if x.Status == 1 {
	//		CurStaffsInterviews = append(CurStaffsInterviews, x)
	//	}
	//}
	//// 多道题正在进行中
	//if len(CurStaffsInterviews) > 1 {
	//	err = fmt.Errorf("expect 1 staffsInterview %d", len(CurStaffsInterviews))
	//	return
	//}

	// 获取需要做的题目
	//if len(CurStaffsInterviews) == 0 {
	//	for _, x := range allStaffsInterviews {
	//		if x.InterviewId == interviewId {
	//			CurStaffsInterviews = append(CurStaffsInterviews, x)
	//		}
	//	}
	//	if len(CurStaffsInterviews) != 1 {
	//		err = fmt.Errorf("expect 1 staffsInterview %d", len(CurStaffsInterviews))
	//		return
	//	}
	//}
	//CurStaffsInterviewsMap := make(map[int]*models.StaffsInterviews)
	//for i := 0; i < len(CurStaffsInterviews); i ++ {
	//	CurStaffsInterviewsMap[CurStaffsInterviews[i].InterviewId] = CurStaffsInterviews[i]
	//}
	//// 当前的答题
	//staffsInterview := CurStaffsInterviewsMap[interviewId]
	//if staffsInterview.InterviewId != interviewId {
	//	err = fmt.Errorf("interviewId not equal ")
	//	return
	//}
	staffsInterview := CurStaffsInterviews[0]
	plan, err := common2.GetPlanById(staffsInterview.DataCollectId)
	if err != nil {
		return
	}
	// 题目状态异常
	if plan.Status >= 4 {
		err = common.NewRespErr(6001, "greetingInfo error not exist")
		return
	}
	logger.Debugf("=========%v", staffsInterview.Status)
	if staffsInterview.Status == 2 {
		return result, nil
	} else if staffsInterview.Status == 0 {
		_, err = models.StaffsInterviewsModel.Update(db.Cond{
			"status": 1,
		}, db.Cond{
			"id": staffsInterview.Id,
		})
		if err != nil {
			return
		}
	} else if staffsInterview.Status != 1 {
		err = common.NewRespErr(6001, "staffsInterview status unvalid")
		return
	}

	interview := CreateInterview(staffsInterview.InterviewId)
	response, err = interview.Commit(staffsInterview.Uuid, param)
	if err != nil {
		return
	}
	if staffsInterview.InterviewId <= 7 {
		finished, err := interview.CheckFinished(response)
		if err != nil {
			return nil, err
		}

		if finished == true {
			err = StaffsInterviewsFinish(staffsInterview.Id)
			if err != nil {
				return nil, err
			}
			err = FinishEvent(libraries.GetMqPub(), staffsInterview.Uuid)
			if err != nil {
				return nil, err
			}
		}
	}
	// 重新获取
	allStaffsInterviews, err = GetStaffsInterviewsByEmailUuid(emailUuid)
	if err != nil {
		return
	}
	result.setInterviewsInfo(allStaffsInterviews)

	result.Data = response
	result.CurInterviewId = staffsInterview.InterviewId
	result.CurInterviewUuid = staffsInterview.Uuid
	return result, nil
}

func StaffsInterviewsFinish(id int) (err error) {
	_, err = models.StaffsInterviewsModel.Update(db.Cond{
		"status": 2,
	}, db.Cond{
		"id": id,
	})
	return
}

// 当答题结束后 写入nsq写入的是试题记录uuid
func FinishEvent(mqPub mqKit.Pub, staffsInterviewsId string) (err error) {
	err = mqPub.Init("hdr_interview_finish_event")
	if err != nil {
		return
	}

	//content, err := json.Marshal(staffsInterviewsId)
	//if err != nil {
	//	return
	//}
	content := []byte(staffsInterviewsId)

	message := &mqKit.Message{
		Content: content,
	}
	err = mqPub.Publish(message)
	return
}
