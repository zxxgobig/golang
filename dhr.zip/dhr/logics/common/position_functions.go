package common

import (
    "fmt"
    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
    "ifchange/dhr/core"
    "ifchange/dhr/models"
)

func GetPositionFunctionById(id int) (
    positionFunction *models.PositionFunctions, err error) {

    positionFunction, err = models.PositionFunctionsModel.SearchOne(db.Cond{
        "id":         id,
        "is_deleted": 0,
    })

    if err != nil {
        return positionFunction, common.NewRespErr(core.SystemErrNo, err)
    }

    if positionFunction == nil {
        err = common.NewRespErr(core.SystemErrNo, fmt.Sprintf("PositionFunction not found: %d", id))
    }
    return
}
