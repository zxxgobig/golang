package libraries

import (
	"testing"
)

func TestToCVerifyPhone(t *testing.T) {
	isVerify, err := ToCVerifyPhone(2497768)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(isVerify)
}
