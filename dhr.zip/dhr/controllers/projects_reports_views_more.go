package controllers

import (
	"ifchange/dhr/demo"
	"ifchange/dhr/logics/stat"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
)

/**
 * @api {post} /projects_reports/emotional_intelligence 项目详情-情绪智力
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-情绪智力
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 情绪智力
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {Number} result.data.dimension.max 最大值
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 * 		"avg": 3.4,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "表现情绪",
 *              "selected": true,
 *				"max": 10
 *          }, {
 *              "id": 2,
 *              "name": "控制情绪",
 *              "selected": true,
 *				"max": 10
 *          }, {
 *              "id": 3,
 *              "name": "觉知情绪",
 *              "selected": true,
 *				"max": 10
 *          }, {
 *              "id": 20,
 *              "name": "评价情绪",
 *              "selected": true,
 *				"max": 10
 *          }, {
 *              "id": 4,
 *              "name": "运用情绪",
 *              "selected": true,
 *				"max": 10
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "员工综合得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) EmotionalIntelligence(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetEmotionalIntelligence(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.EmotionalIntelligence)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/critical_thinking 项目详情-批判思维
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-批判思维
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 批判思维
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 * 		"avg": 3.4,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "表现情绪",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "控制情绪",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "觉知情绪",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "评价情绪",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "运用情绪",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "员工综合得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) CriticalThinking(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetCriticalThinking(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.CriticalThinking)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/practical_intelligence 项目详情-管理实践能力
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-管理实践能力
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 管理实践能力
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 * 		"avg": 3.4,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "分析",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "推断",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "解释",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "评价",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "员工综合得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) PracticalIntelligence(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)
	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetPracticalIntelligence(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.PracticalIntelligence)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/occupational_personality 项目详情-职业人格
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-职业人格
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 职业人格
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 * 		"avg": 3.4,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "表现情绪",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "控制情绪",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "觉知情绪",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "评价情绪",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "运用情绪",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "员工综合得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) OccupationalPersonality(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetOccupationalPersonality(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.OccupationalPersonality)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/personality_disorder 项目详情-性格风险
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-性格风险
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 性格风险
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 * 		"avg": 3.4,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "表现情绪",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "控制情绪",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "觉知情绪",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "评价情绪",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "运用情绪",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "员工综合得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) PersonalityDisorder(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetPersonalityDisorder(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.PersonalityDisorder)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/leadership_style 项目详情-领导风格
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-领导风格
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 领导风格
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"avg": 3.5,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "命令型",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "教练型",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "支持型",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "授权型",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score", "freq"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [2,3,5,4],
 *						"freq": [3,4,5,2]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) LeadershipStyle(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetLeadershipStyle(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.LeadershipStyle)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/org_commitment 项目详情-组织忠诚度
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-组织忠诚度
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
* @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 组织忠诚度
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 * 		"avg": 3.4,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "表现情绪",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "控制情绪",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "觉知情绪",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "评价情绪",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "运用情绪",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "员工综合得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
*/
func (c *ProjectsReport) OrgCommitment(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetOrgCommitment(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}
	result, err = stat.GetProjectInterviewData(companyID, req.ProjectID, interview.OrgCommitment)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}
