package interview

import (
    "encoding/json"
    "fmt"
    "ifchange/dhr/core"
    logicsCommon "ifchange/dhr/logics/common"
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfw/encoding"
    "gitlab.ifchange.com/bot/hfwkit/career_assessment"
    "gitlab.ifchange.com/bot/hfwkit/utils"
    career_assessment_pb "gitlab.ifchange.com/bot/proto/career_assessment"
)

type KeyExp struct {
    Config *Config
}

func (n *KeyExp) SaveVoice(param interface{}) (err error) {
	return nil
}

func (n *KeyExp) SetConfig(config interface{}) (err error) {
    var ok bool
    n.Config, ok = config.(*Config)
    if !ok {
        n.Config = nil
    }
    if n.Config.EmailUuid == "" {
        n.Config.EmailUuid, err = utils.CreateUuid(n.Config)
        if err != nil {
            return common.NewRespErr(20305000, err)
        }
    }
    //n.Config.EmailUuid, err = utils.CreateUuid(n.Config)
    n.Config.Uuid = n.Config.EmailUuid
    n.Config.Uuid, err = utils.CreateUuid(n.Config)
    if err != nil {
        return err
    }
    return err
}

func (n *KeyExp) Create(c []ConfigSubItem) (result interface{}, err error) {

    projectData, err := logicsCommon.GetValidProject(n.Config.CompanyID, n.Config.ProjectID)
    if err != nil {
        return result, err
    }
    if projectData == nil {
        return result, fmt.Errorf("项目不存在")
    }

    params := &career_assessment_pb.KeyExperienceCreateRequest{
        UniqueId: n.Config.Uuid,
    }

    result, err = career_assessment.KeyExperienceCreate(n.Config.HttpCtx, params)
    return result, err
}

func (n *KeyExp) Get(uuid string, param interface{}) (t interface{}, err error) {
    params := &career_assessment_pb.KeyExperienceGetRequest{
        UniqueId: uuid,
    }
    t, err = career_assessment.KeyExperienceGet(nil, params)
    return t, err
}

func (n *KeyExp) Commit(uuid string, p interface{}) (t interface{}, err error) {

    _param := p.(json.RawMessage)
    str, err := _param.MarshalJSON()
    if err != nil {
        return t, err
    }
    params := &career_assessment_pb.KeyExperienceCommitRequest{}
    err = json.Unmarshal(str, params)
    if err != nil {
        return t, err
    }

    params.UniqueId = uuid
    t, err = career_assessment.KeyExperienceCommit(nil, params)
    return t, err
}

type CommitKeyExp struct {
    EmailUuid  string `json:"email_uuid"`
    Feedback   string `json:"feedback"`
    OrginScore string `json:"orgin_score"`
    Score      int    `json:"score"`
}

func (n *KeyExp) ResultCommit(interviewID int, emailUuid string, params interface{}) (err error) {
    param := params.([]*career_assessment_pb.Result)
    paramsBytes, err := encoding.JSON.Marshal(param)
    if err != nil {
        return err
    }
    err = logicsCommon.UpdateStaffsInterview(emailUuid, string(paramsBytes), param, interviewID)
    if err != nil {
        return err
    }
    return
}

func (n *KeyExp) CheckFinished(response interface{}) (isFinished bool, err error) {
    return
}

// GetIsMust 是否必须, 1 必须； 0 非必须
func (n *KeyExp) GetIsMust() int {
    return 0
}

// KeyExprItems 关键经历--> 管理经历/业务经历
type KeyExprItems struct {
    IsMust            int              `json:"is_must"`
    SubItems          []*ConfigSubItem `json:"sub_items"`
    RecommendSubItems []*ConfigSubItem `json:"recommend_sub_items"`
}

// GetAllSubItems 获取全部维度
func (n *KeyExp) GetAllSubItems(industryID, functionID, positionLevelID,
    sceneID int) (manageExpr *KeyExprItems, businessExpr *KeyExprItems,
    err error) {
    manageExpr = &KeyExprItems{
        IsMust:            1,
        SubItems:          []*ConfigSubItem{},
        RecommendSubItems: []*ConfigSubItem{},
    }
    businessExpr = &KeyExprItems{
        IsMust:            0,
        SubItems:          []*ConfigSubItem{},
        RecommendSubItems: []*ConfigSubItem{},
    }

    ke, err := models.InterviewsModel.SearchOne(db.Cond{
        "is_deleted": 0,
        "id":         IntvKeyExp,
    })
    if err != nil {
        return
    }
    if ke == nil {
        err = common.NewRespErr(core.DbQueryNotExist,
            fmt.Sprintf("the interview: <%+v> not exist", IntvKeyExp))
        return
    }

    subItems := []*ConfigSubItem{}
    err = encoding.JSON.UnmarshalFromString(ke.Config, &subItems)
    if err != nil {
        return
    }

    for _, i := range subItems {
        switch i.Class {
        case 0:
            businessExpr.SubItems = append(businessExpr.SubItems, i)
        case 1:
            manageExpr.SubItems = append(manageExpr.SubItems, i)
        default:
            logger.Warnf("unknown sub_item class: <%+v>", i.Class)
        }
    }

    return
}
