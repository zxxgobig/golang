package v2_interview

import (
	kitbei "gitlab.ifchange.com/bot/hfwkit/bei"
	kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

	"ifchange/dhr/models"
)

type (
	// OccupationalPersonalityRecommend ..
	OccupationalPersonalityRecommend struct {
		Name     string `json:"name"`
		Desc     string `json:"desc"`
		Index    int    `json:"index"`
		IsAdvice bool   `json:"is_advice"`
		IsMust   bool   `json:"is_must"`
	}
)

// ProcessOccupationalPersonalityRecommend ..
func ProcessOccupationalPersonalityRecommend(
	sceneID, sceneTemplateID int,
	interviewsM map[kitinterview.Type]*models.Interviews,
	useNewBEIMode bool,
	beiRecommend *BeiRecommend,
) *OccupationalPersonalityRecommend {

	interview, ok := interviewsM[kitinterview.OccupationalPersonality]
	if !ok {
		return nil
	}

	var (
		isAdvice = GetIsAdvice(kitinterview.PracticalIntelligence, sceneTemplateID)
	)
	if useNewBEIMode {
		for _, subitem := range beiRecommend.SubItems {
			if _, ok := kitbei.BeiSubitem2InterviewSubitems[subitem.Id]; ok {
				isAdvice = true
				break
			}
		}
	}

	return &OccupationalPersonalityRecommend{
		Name:     interview.Name,
		Desc:     interview.Desc,
		Index:    GetIndex(kitinterview.OccupationalPersonality),
		IsAdvice: isAdvice,
		IsMust:   GetIsMust(kitinterview.PracticalIntelligence, sceneID, sceneTemplateID),
	}
}
