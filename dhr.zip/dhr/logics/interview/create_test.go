package interview_test

import (
	"ifchange/dhr/logics/interview"
	"testing"
	// "gitlab.ifchange.com/bot/logger"
)

func TestCreate(t *testing.T) {
	err := interview.Create(nil, 54, 109, 109)
	if err != nil {
		t.Error(err)
	}
}

/*
go test ./logics/interview -run TestGetDataCollectDemandStaffs -v
*/

func TestGetDataCollectDemandStaffs(t *testing.T) {
	testcompanyid := 109
	testprojectid := 45
	staffs, err := interview.
		GetDataCollectDemandStaffs(testcompanyid, testprojectid, nil)
	if err != nil {
		t.Fatal(err)
	}

	for _, s := range staffs {
		t.Logf("staff: <%+v>\n", s)
		for _, i := range s.NoCompletedConfigItemParams {
			t.Logf("staff: <%+v>, interview_config: <%+v>", s.Id, i.Id)
			for _, subi := range i.SubItems {
				t.Logf("staff: <%+v>, interview_config: <%+v>, interview_sub_item: <%+v>\n",
					s.Id, i.Id, subi.Id)
			}
		}
		t.Logf("leader_id: <%+v>, leader_name: <%+v>\n", s.ParentId, s.ParentName)
	}
}
