package position

import (
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/hfw/db"
)

type PositionLevels struct {
}

func NewPositionLevels() *PositionLevels {
    return new(PositionLevels)
}

type PositionLevelsModel struct {
}

func (p *PositionLevels) List(page, pageSize int) (_models []*models.PositionLevels, total int64, err error) {

    cond := db.Cond{
        "is_deleted": 0,
        "page":       page,
        "pagesize":   pageSize,
        "orderby":    "id",
    }

    total, err = models.PositionLevelsModel.Count(db.Cond{
        "is_deleted": 0,
    })
    if err != nil {
        return
    }
    _models, err = models.PositionLevelsModel.Search(cond)

    return
}
