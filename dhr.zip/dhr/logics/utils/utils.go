package utils

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

func FloatToString(f float64) string {
	if f == -1 {
		return "-"
	}
	return strconv.FormatFloat(f, 'f', -1, 32)
}

// format: yyyyMMddHHmmss
func GetCurrentDateYMDHMS() string {
	return time.Now().Format("20060102150405")
}

// slice转逗号分割字符串
func SliceToArray(i interface{}) string {
	return strings.Replace(strings.Trim(fmt.Sprint(i), "]["), " ", ",", -1)
}
