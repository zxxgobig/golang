package v2_interview

import (
	"gitlab.ifchange.com/bot/hfwkit/common"

	"ifchange/dhr/models"
)

var InterviewLogic *Interview

func init() {
	InterviewLogic = new(Interview)
}

type (
	Interview struct {
	}

	InterviewModel struct {
		*models.Interviews
		IsDeleted    common.Omitempty    `json:"is_deleted,omitempty"`
		CreatedAt    common.Omitempty    `json:"created_at,omitempty"`
		UpdatedAt    common.Omitempty    `json:"updated_at,omitempty"`
		TakeTime     common.Omitempty    `json:"take_time,omitempty"`
		SubitemCount common.Omitempty    `json:"subitem_count,omitempty"`
		ProductId    common.Omitempty    `json:"product_id,omitempty"`
		Config       common.Omitempty    `json:"config,omitempty"`
		SubItems     []*InterviewSubItem `json:"sub_items"`
	}

	InterviewSubItem struct {
		Id      int    `json:"id"`
		Name    string `json:"name"`    // 名称
		Enname  string `json:"enname"`  // 英文名称
		Class   int    `json:"class"`   // 分类（仅关键经历测评的管理经历用）
		Content string `json:"content"` // 描述（仅素质测评用）
		Score   int    `json:"score"`   // 分数（仅素质测评用）
	}

	PersonalityInterviewItem struct {
		FunctionID        int    `json:"function_id"`
		FunctionName      string `json:"function_name"`
		IsManagerPosition bool   `json:"is_manager_position"`
		Selected          []*struct {
			NormstarID   int    `json:"normstar_id"`
			NormstarName string `json:"normstar_name"`
		}
	}
)
