package models

import (
    "database/sql"
    "encoding/gob"
    "errors"
    "fmt"
    "time"

    "github.com/go-xorm/xorm"
    logger "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfw/configs"
    "gitlab.ifchange.com/bot/hfw/db"
)

var SkillsModel = &Skills{}

func init() {
    var err error
    SkillsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
    if err != nil {
        logger.Fatal(err)
        panic(err)
    }
    SkillsModel.Dao.EnableCache(SkillsModel)
    // SkillsModel.Dao.DisableCache(SkillsModel)
    // gob: type not registered for interface
    gob.Register(SkillsModel)
}

type Skills struct {
    Dao *db.XormDao `json:"-" xorm:"-"`

    Id        int       `json:"id" xorm:"not null pk autoincr INT(11)"`
    CompanyId int       `json:"company_id" xorm:"not null unique(udx_company_id_type_name) INT(11)"`
    Name      string    `json:"name" xorm:"not null default '' unique(udx_company_id_type_name) VARCHAR(64)"`
    Type      int       `json:"type" xorm:"not null default 0 comment('1知识 2技能') unique(udx_company_id_type_name) TINYINT(1)"`
    IsDeleted int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
    UpdatedAt time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
    CreatedAt time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
}

func (m *Skills) GetId() (val int) {
    if m == nil {
        return
    }
    return m.Id
}

func (m *Skills) GetCompanyId() (val int) {
    if m == nil {
        return
    }
    return m.CompanyId
}

func (m *Skills) GetName() (val string) {
    if m == nil {
        return
    }
    return m.Name
}

func (m *Skills) GetType() (val int) {
    if m == nil {
        return
    }
    return m.Type
}

func (m *Skills) GetIsDeleted() (val int) {
    if m == nil {
        return
    }
    return m.IsDeleted
}

func (m *Skills) GetUpdatedAt() (val time.Time) {
    if m == nil {
        return
    }
    return m.UpdatedAt
}

func (m *Skills) GetCreatedAt() (val time.Time) {
    if m == nil {
        return
    }
    return m.CreatedAt
}

func (m *Skills) TableName() string {
    return "skills"
}

func (m *Skills) Save(t ...*Skills) (affected int64, err error) {
    if len(t) > 1 {
        return m.Dao.Insert(t)
    } else {
        var i *Skills
        if len(t) == 0 {
            if m.Dao == nil {
                panic("dao not init")
            }
            i = m
        } else if len(t) == 1 {
            i = t[0]
        }
        if i.Id > 0 {
            return m.Dao.UpdateById(i)
        } else {
            return m.Dao.Insert(i)
        }
    }
}

func (m *Skills) Saves(t []*Skills) (affected int64, err error) {
    return m.Dao.Insert(t)
}

func (m *Skills) Insert(t ...*Skills) (affected int64, err error) {
    if len(t) > 1 {
        return m.Dao.Insert(t)
    } else {
        var i *Skills
        if len(t) == 0 {
            if m.Dao == nil {
                panic("dao not init")
            }
            i = m
        } else if len(t) == 1 {
            i = t[0]
        }
        return m.Dao.Insert(i)
    }
}

func (m *Skills) Update(params db.Cond,
    where db.Cond) (affected int64, err error) {
    return m.Dao.UpdateByWhere(m, params, where)
}

func (m *Skills) SearchOne(cond db.Cond) (t *Skills, err error) {
    if cond == nil {
        cond = db.Cond{}
    }
    cond["page"] = 1
    cond["pagesize"] = 1

    rs, err := m.Search(cond)
    if err != nil {
        return
    }
    if len(rs) > 0 {
        t = rs[0]
    }

    return
}

func (m *Skills) Search(cond db.Cond) (t []*Skills, err error) {
    err = m.Dao.Search(&t, cond)
    return
}

func (m *Skills) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
    return m.Dao.Rows(m, cond)
}

func (m *Skills) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
    return m.Dao.Iterate(m, cond, f)
}

func (m *Skills) Count(cond db.Cond) (total int64, err error) {
    return m.Dao.Count(m, cond)
}

func (m *Skills) GetMulti(ids ...interface{}) (t []*Skills, err error) {
    err = m.Dao.GetMulti(&t, ids...)
    return
}

func (m *Skills) GetByIds(ids ...interface{}) (t []*Skills, err error) {
    return m.GetMulti(ids...)
}

func (m *Skills) GetById(id interface{}) (t *Skills, err error) {
    rs, err := m.GetMulti(id)
    if err != nil {
        return
    }
    if len(rs) > 0 {
        t = rs[0]
    }
    return
}

func (m *Skills) Replace(cond db.Cond) (int64, error) {
    defer m.Dao.ClearCache(m)
    return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *Skills) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
    defer m.Dao.ClearCache(m)
    return m.Dao.Exec(sqlState, args...)
}

func (m *Skills) Query(args ...interface{}) ([]map[string][]byte, error) {
    return m.Dao.Query(args...)
}

func (m *Skills) QueryString(args ...interface{}) ([]map[string]string, error) {
    return m.Dao.QueryString(args...)
}

func (m *Skills) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
    return m.Dao.QueryInterface(args...)
}

// 以下用于事务，注意同个实例不能在多个goroutine同时使用
// 使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
// 参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewSkills(c ...interface{}) (m *Skills, err error) {
    m = &Skills{}
    var dbConfig configs.DbConfig
    if len(c) == 0 {
        dbConfig = hfw.Config.Db
    } else if len(c) == 1 {
        switch c[0].(type) {
        case configs.DbConfig:
            dbConfig = c[0].(configs.DbConfig)
        case *db.XormDao:
            m.Dao = c[0].(*db.XormDao)
            if m.Dao == nil {
                return nil, errors.New("nil dao")
            }
            return
        default:
            return nil, errors.New("error configs")
        }
    } else {
        return nil, errors.New("too many configs")
    }

    m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
    if err != nil {
        return nil, err
    }
    m.Dao.NewSession()

    return
}

func (m *Skills) Close() {
    m.Dao.Close()
}

func (m *Skills) Begin() error {
    return m.Dao.Begin()
}

func (m *Skills) Rollback() error {
    return m.Dao.Rollback()
}

func (m *Skills) Commit() error {
    return m.Dao.Commit()
}
