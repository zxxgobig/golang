package data_collect

import (
	"encoding/json"
	"fmt"
	"gitlab.ifchange.com/bot/hfw/db"
	"ifchange/dhr/libraries"
	"ifchange/dhr/models"
	"testing"
	"time"
)

func TestRemoveRepeatedElement(t *testing.T) {
	var arr = []int{1, 1, 2, 3, 3, 3}
	newArr := RemoveRepeatedElement(arr)
	t.Log(newArr)
}

func TestGetLast7DaysStaffsData(t *testing.T) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"project_id": 599,
		"is_deleted": 0,
	})
	if err != nil {
		t.Fatal(err)
	}
	if plan == nil {
		return
	}

	date := time.Now().AddDate(0, 0, -7).Format(libraries.DateFormat)
	pstaffs, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"sql": fmt.Sprintf("select * from data_collect_plan_staffs where plan_id = %d and (skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) "+
			"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (emotional_intelligence = 2 or emotional_intelligence = 3) "+
			"and (critical_thinking = 2 or critical_thinking = 3) and (practical_intelligence = 2 or practical_intelligence = 3) "+
			"and (occupational_personality = 2 or occupational_personality = 3) and (personality_disorder = 2 or personality_disorder = 3) "+
			"and (leadership_style = 2 or leadership_style = 3) and (org_commitment = 2 or org_commitment = 3) "+
			"and (work_values = 2 or work_values = 3) and (key_expr = 2 or key_expr = 3) and updated_at > '%s'", plan.Id, date),
	})
	if err != nil {
		t.Log(err)
	}
	if len(pstaffs) == 0 {
		t.Log("result is nil")
		return
	}
	b, _ := json.Marshal(pstaffs)
	t.Log(string(b))
}
