package interview

import (
	"context"
	"encoding/json"
	"fmt"
	"gitlab.ifchange.com/bot/logger"
	"time"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/grpc/client"
	pb "gitlab.ifchange.com/bot/proto/professional_skills"
	"google.golang.org/grpc"
)

var (
	expireTime time.Duration = time.Duration(5) * time.Second
)

type IInterviews interface {
	SetConfig(interface{}) (err error)
	Create(c []ConfigSubItem) (result interface{}, err error)
	Get(uuid string, p interface{}) (t interface{}, err error)
	Commit(uuid string, p interface{}) (t interface{}, err error)
	ResultCommit(interviewId int, uuid string, param interface{}) (err error)
	CheckFinished(response interface{}) (b bool, err error)
	SaveVoice(param interface{}) (err error)
}

type StaffsInterviewsInfo struct {
	Status      int       `json:"status"`
	Uuid        string    `json:"uuid"`
	InterviewId int       `json:"interview_id"`
	CreatedAt   time.Time `json:"created_at"`
}

type FinishStatus struct {
	InterviewsInfo   []*StaffsInterviewsInfo `json:"interviews_info"`
	CurInterviewId   int                     `json:"cur_interview_id"`
	CurInterviewUuid string                  `json:"cur_interview_uuid"`
	Data             interface{}             `json:"data"`
}

func (f *FinishStatus) setInterviewsInfo(infos []*models.StaffsInterviews) {
	var _infos []*StaffsInterviewsInfo
	for _, x := range infos {
		_infos = append(_infos, &StaffsInterviewsInfo{
			Status:      x.Status,
			InterviewId: x.InterviewId,
			Uuid:        x.Uuid,
			CreatedAt:   x.CreatedAt,
		})
	}
	f.InterviewsInfo = _infos
}

type Interviews struct {
}

func CreateInterview(id int) IInterviews {
	switch id {
	case IntvBei:
		return new(Bei)
	case IntvNormstar:
		return new(NormStart)
	case IntvKnowlege:
		return new(ProfessionalSkill)
	case IntvSkill:
		return new(ProfessionalSkill)
	case IntvPotential:
		return new(Potential)
	case IntvWorkValues:
		return new(WorkValues)
	case IntvKeyExp:
		return new(KeyExp)
	case IntvEmotionalIntelligence:
		return new(ThirdEvaluation)
	case IntvCriticalThinking:
		return new(ThirdEvaluation)
	case IntvPracticalIntelligence:
		return new(ThirdEvaluation)
	case IntvOccupationalPersonality:
		return new(ThirdEvaluation)
	case IntvPersonalityDisorder:
		return new(ThirdEvaluation)
	case IntvLeadershipStyle:
		return new(ThirdEvaluation)
	case IntvOrgCommitment:
		return new(ThirdEvaluation)
	case ManagementQuality:
		return new(ThirdEvaluation)
	}

	return nil
}

// 子维度 如bei下的积极性测评等
type ConfigSubItem struct {
	Id     int    `json:"id"`
	EnName string `json:"enname"`
	Name   string `json:"name"`
	Class  int    `json:"class"` // 分类。1 关键经历中的管理经历。目前其他都是0
}

// ConfigItemParam 测评相关参数
type ConfigItemParam struct {
	Id          int             `json:"id"`
	Name        string          `json:"name"`
	NeedSubItem int             `json:"need_subitem"`
	Desc        string          `json:"desc"`
	SubItems    []ConfigSubItem `json:"sub_items"`
	Editable    int             `json:"editable"`
}

func NewInterviews() *Interviews {
	return new(Interviews)
}

// 获取员工题目
func GetInterviewByEamilUuid(emailUuid string) (staffsInterview *models.StaffsInterviews, err error) {
	return models.StaffsInterviewsModel.SearchOne(db.Cond{
		"is_deleted": 0,
		"email_uuid": emailUuid,
	})
}

type ListStaffsInterviewsResult struct {
	StaffsInterviewsId int    `json:"staffs_interviews_id"`
	InterviewId        int    `json:"interview_id"`
	ProductId          int    `json:"product_id"`
	Name               string `json:"name"`
	Status             int    `json:"status"`
	SubItemCount       int    `json:"sub_item_count"`
	TakeTime           int    `json:"take_time"`
}

func GetInterview(Id int) (interview *models.Interviews, err error) {
	interview, err = models.InterviewsModel.SearchOne(db.Cond{
		"id": Id,
		//"is_deleted": 0,
	})
	if err != nil {
		return
	}
	if interview == nil {
		return nil, fmt.Errorf("ListStaffsInterviews:interview not found")
	}
	return
}

func ListStaffsInterviews(emailUuid string) (listStaffsInterviewsResult []*ListStaffsInterviewsResult, dataCollectId int, err error) {

	staffsInterviews, err := models.StaffsInterviewsModel.Search(db.Cond{
		"is_deleted": 0,
		"email_uuid": emailUuid,
		"orderby":    "interview_id",
	})
	if err != nil {
		return
	}
	if len(staffsInterviews) == 0 {
		err = fmt.Errorf("ListStaffsInterviews:no record found")
		return
	}
	//
	//staffsInterviews, err = models.StaffsInterviewsModel.Search(db.Cond{
	//	"is_deleted":      0,
	//	"project_id":      staffsInterviews[0].ProjectId,
	//	"data_collect_id": staffsInterviews[0].DataCollectId,
	//	"interview_id in": []int{1, 5, 6, 7},
	//	"staff_id":        staffsInterviews[0].StaffId,
	//	"orderby":         "id desc",
	//})
	//if err != nil {
	//	return
	//}
	//if len(staffsInterviews) == 0 {
	//	err = fmt.Errorf("ListStaffsInterviews:no record found")
	//	return
	//}

	dataCollectId = staffsInterviews[0].DataCollectId
	projectID := staffsInterviews[0].ProjectId
	for _, staffsInterview := range staffsInterviews {
		if staffsInterview.InterviewId == 1 && isModeTwoByProjectID(projectID) {
			continue
		}
		_interview, err := GetInterview(staffsInterview.InterviewId)
		if err != nil {
			return nil, 0, err
		}

		if staffsInterview.InterviewId == IntvBei {
			count, err := GetSubItemCountByStaffId(dataCollectId, staffsInterview.StaffId, staffsInterview.InterviewId)
			if err != nil {
				return nil, 0, err
			}
			_interview.TakeTime = _interview.TakeTime * int(count)
			_interview.SubitemCount = int(count)
			logger.Debugf("^^^^^^^^^^^^^^TakeTime: %#v", _interview.TakeTime)
			logger.Debugf("^^^^^^^^^^^^^^SubitemCount: %#v", _interview.SubitemCount)
		}

		listStaffsInterviewsResult = append(listStaffsInterviewsResult, &ListStaffsInterviewsResult{
			StaffsInterviewsId: staffsInterview.Id,
			InterviewId:        staffsInterview.InterviewId,
			ProductId:          _interview.ProductId, //无用途 仅参考
			Name:               _interview.Name,
			Status:             staffsInterview.Status,
			SubItemCount:       _interview.SubitemCount,
			TakeTime:           _interview.TakeTime,
		})
	}
	return
}

func GetSubItemCountByStaffId(dataCollectId, staffId, interviewId int) (count int64, err error) {
	return models.StaffsInterviewsDetailsModel.Count(db.Cond{
		"data_collect_id": dataCollectId,
		"interview_id":    interviewId,
		"staff_id":        staffId,
		"is_deleted":      0,
	})
}

// 全部维度
func (p *Interviews) AddSkill(companyId int, typeId int, name string) (result interface{}, err error) {
	params := pb.EvaluateSkillAddRequest{
		CompanyId: int64(companyId),
		Type:      pb.SkillType(typeId),
		Name:      name,
	}
	resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
		res, err := pb.NewEvaluateClient(conn).SkillsAdd(ctx, &params)
		if err != nil {
			return nil, err
		}
		if res.GetErrNo() != 0 {
			return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
		}
		return res.GetResults(), nil
	}, expireTime)
	if err != nil {
		return result, err
	}
	_ = resp.(*pb.EvaluateSkillAddResult)

	//UpdateSkillCache(companyId, typeId)
	return result, err
}

// fetchSkillList  更新缓存：1知识  2技能
func fetchSkillList(companyID, typeID int) (configSubItemList []ConfigSubItem, err error) {
	params := pb.EvaluateSkillListRequest{
		CompanyId: int64(companyID),
		Type:      pb.SkillType(typeID),
		PageSize:  100000,
	}
	resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
		res, err := pb.NewEvaluateClient(conn).SkillsList(ctx, &params)
		if err != nil {
			return nil, err
		}
		if res.GetErrNo() != 0 {
			return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
		}
		return res.GetResults(), nil
	}, expireTime)
	if err != nil {
		return
	}
	result := resp.(*pb.EvaluateSkillsListResult)
	configSubItemList = []ConfigSubItem{}
	for _, x := range result.List {
		configSubItemList = append(configSubItemList, ConfigSubItem{
			Id:   int(x.Id),
			Name: x.Name,
		})
	}

	return
}

// ConfigItems 获取测评维度列表
func (p *Interviews) ConfigItems(companyID, interviewID int) (interviewConfigItemParams []ConfigItemParam, err error) {
	var interviewsConfigs []*models.Interviews
	if interviewID == 0 {
		interviewsConfigs, err = models.InterviewsModel.Search(db.Cond{
			"is_deleted": 0,
		})
		if err != nil {
			return
		}
	} else {
		interviewsConfigs, err = models.InterviewsModel.Search(db.Cond{
			"id": interviewID, "is_deleted": 0,
		})
		if err != nil {
			return
		}
	}
	if len(interviewsConfigs) <= 0 {
		return
	}

	for _, interviewsConfig := range interviewsConfigs {
		subItems := []ConfigSubItem{}
		err = json.Unmarshal([]byte(interviewsConfig.Config), &subItems)
		if err != nil {
			return interviewConfigItemParams, err
		}
		if interviewsConfig.Id == 3 || interviewsConfig.Id == 4 {
			typeId := 1
			if interviewsConfig.Id == 3 {
				typeId = 2
			}

			subItems, err := fetchSkillList(companyID, typeId)
			if err != nil {
				return interviewConfigItemParams, err
			}
			interviewConfigItemParams = append(interviewConfigItemParams, ConfigItemParam{
				Id:          interviewsConfig.Id,
				Name:        interviewsConfig.Name,
				NeedSubItem: interviewsConfig.NeedSubitem,
				Desc:        interviewsConfig.Desc,
				SubItems:    subItems,
				Editable:    interviewsConfig.Editable,
			})
		} else {
			interviewConfigItemParams = append(interviewConfigItemParams, ConfigItemParam{
				Id:          interviewsConfig.Id,
				Name:        interviewsConfig.Name,
				NeedSubItem: interviewsConfig.NeedSubitem,
				Desc:        interviewsConfig.Desc,
				SubItems:    subItems,
				Editable:    interviewsConfig.Editable,
			})
		}

	}

	return
}

// 推荐维度
func (p *Interviews) ConfigItemsRecommend(positionFunctionId, positionLevelId int) (interviewConfigItemParams []ConfigItemParam, err error) {
	// 推荐 bei
	beis, err := models.PositionFunctionBeiRecommendModel.Search(db.Cond{
		"function_id": positionFunctionId,
		"level_id":    positionLevelId,
		"is_deleted":  0,
	})
	if err != nil {
		return
	}
	beiItem := ConfigItemParam{
		Id:       1,
		Name:     "bei",
		SubItems: []ConfigSubItem{},
	}

	for _, bei := range beis {
		beiItem.SubItems = append(beiItem.SubItems, ConfigSubItem{
			Id:   bei.GroupId,
			Name: bei.GroupName,
		})
	}

	if len(beiItem.SubItems) > 0 {
		interviewConfigItemParams = append(interviewConfigItemParams, beiItem)
	}

	//推荐 技能/知识
	skills, err := models.PositionFunctionSkillRecommendModel.Search(db.Cond{
		"function_id": positionFunctionId,
		"is_deleted":  0,
	})
	if err != nil {
		return
	}

	var skillsRecommend []*models.PositionFunctionSkillRecommend
	var knowledgeRecommend []*models.PositionFunctionSkillRecommend
	for _, skill := range skills {
		if skill.Type == 1 {
			knowledgeRecommend = append(knowledgeRecommend, skill)
		} else if skill.Type == 2 {
			skillsRecommend = append(skillsRecommend, skill)
		}

	}
	knowledgeItem := ConfigItemParam{
		Id:       4,
		Name:     "专业知识",
		SubItems: []ConfigSubItem{},
	}
	for _, knowledge := range knowledgeRecommend {
		knowledgeItem.SubItems = append(knowledgeItem.SubItems, ConfigSubItem{
			Id:   knowledge.SkillId,
			Name: knowledge.Name,
		})
	}

	if len(knowledgeItem.SubItems) >= 3 {
		knowledgeItem.SubItems = knowledgeItem.SubItems[:3]
	}

	if len(knowledgeItem.SubItems) > 0 {
		interviewConfigItemParams = append(interviewConfigItemParams, knowledgeItem)
	}

	skillItem := ConfigItemParam{
		Id:       3,
		Name:     "专业技能",
		SubItems: []ConfigSubItem{},
	}

	for _, skill := range skillsRecommend {
		skillItem.SubItems = append(skillItem.SubItems, ConfigSubItem{
			Id:   skill.SkillId,
			Name: skill.Name,
		})
	}

	if len(skillItem.SubItems) >= 3 {
		skillItem.SubItems = skillItem.SubItems[:3]
	}

	if len(skillItem.SubItems) > 0 {
		interviewConfigItemParams = append(interviewConfigItemParams, skillItem)
	}

	return
}

func FeedBack(EmailUuid string, interviewId int, content string) (err error) {
	_, err = models.StaffsInterviewsModel.Update(db.Cond{
		"feedback": content,
	}, db.Cond{
		"email_uuid":   EmailUuid,
		"interview_id": interviewId,
		"is_deleted":   0,
	})
	return
}
