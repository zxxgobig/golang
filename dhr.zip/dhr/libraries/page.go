package libraries

import (
    "math"
    "reflect"
)

const (
    MaxPageSize     = 200
    DefaultPageSize = 10
)

func ComputePage(page, pageSize int, recordCount int64) (limit, offset int) {
    maxPage := int(math.Ceil(float64(recordCount) / float64(pageSize)))

    if page <= 0 {
        page = 1
    } else if page > maxPage {
        page = maxPage
    }

    if pageSize <= 0 {
        limit = DefaultPageSize
    } else if pageSize > MaxPageSize {
        limit = MaxPageSize
    } else {
        limit = pageSize
    }

    offset = (page - 1) * limit

    return
}

func ProcessPage(page, pageSize int, recordCount int64, recordList interface{}) (result interface{}) {
    if recordCount <= 0 {
        return nil
    }

    valueOf := reflect.ValueOf(recordList)
    if valueOf.Kind() != reflect.Slice {
        return nil
    }

    limit, offset := ComputePage(page, pageSize, recordCount)

    if int64(offset+limit) > recordCount {
        result = valueOf.Slice(offset, int(recordCount)).Interface()
    } else {
        result = valueOf.Slice(offset, offset+limit).Interface()
    }

    return
}
