package controllers

import (
    "testing"
)

const TestSession = "eyJmcm9tIjoiQiIsInNyY19pZCI6MSwibWFuYWdlcl9pZCI6ODQsImNvbXBhbnlfaWQiOjg0LCJ1c2VyX2lkIjo4NCwiZXhwaXJlIjoxNTY1NjA5NTcwLCJzaWduYXR1cmUiOiJmZTEwNTdjNzY2YjhhZDI0Y2FkYTYyZGIzNGVlZDkwMTIwM2M3ZjNlIiwidXNlcl90eXBlIjoxfQ=="

/*
go test ./controllers -run TestDecodeSession -v
*/
func TestDecodeSession(t *testing.T) {
    session := &Session{
        SessionID: TestSession,
    }
    VerifyRequestSession(nil, session)
}
