package v2_project

import (
	"fmt"
	"ifchange/dhr/logics/company"
	"ifchange/dhr/logics/interview"
	"strconv"
	"strings"
	"time"

	"gitlab.ifchange.com/bot/hfw"
	hfwcommon "gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfw/redis"
	kitbei "gitlab.ifchange.com/bot/hfwkit/bei"
	kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	kitAdminConstant "gitlab.ifchange.com/bot/hfwkit/dhr_admin"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/hfwkit/utils"
	"gitlab.ifchange.com/bot/logger"

	"ifchange/dhr/core"
	v2_interview "ifchange/dhr/logics/v2/interview"
	"ifchange/dhr/models"
)

type (
	CreateParam struct {
		CompanyId       int              `json:"-"`
		AccountId       int              `json:"-"`
		Step            int              `json:"step"`
		SceneId         int              `json:"scene_id"`
		SceneTemplateId int              `json:"scene_template_id"`
		Name            string           `json:"name"`
		PositionId      int              `json:"position_id"`
		StartAt         time.Time        `json:"start_at"`
		IndustryId      int              `json:"industry_id"`
		FunctionId      int              `json:"function_id"`
		LevelId         int              `json:"level_id"`
		IsManager       bool             `json:"is_manager"`
		Remark          string           `json:"remark"`
		Interview       *CreateInterview `json:"interview"`
		Staffs          []*Staffs        `json:"staffs"`
	}

	Staffs struct {
		ID             int    `json:"id"`
		Name           string `json:"name"`
		DepartmentID   int    `json:"department_id"`
		DepartmentName string `json:"department_name"`
		PositionID     int    `json:"position_id"`
		PositionName   string `json:"position_name"`
		ParentID       int    `json:"parent_id"`
		ParentName     string `json:"parent_name"`
		Status         int    `json:"status"`
	}

	CreateInterview struct {
		Bei *struct {
			IsCheck    bool `json:"is_check"`
			CheckItems []*struct {
				Id    int `json:"id"`
				Score int `json:"score"`
			} `json:"check_items"`
		} `json:"bei"`
		Personality *struct {
			IsCheck           bool   `json:"is_check"`
			FunctionID        int    `json:"function_id"`
			FunctionName      string `json:"function_name"`
			IsManagerPosition bool   `json:"is_manager_position"`
			Selected          []*struct {
				NormstarID   int    `json:"normstar_id"`
				NormstarName string `json:"normstar_name"`
			}
		} `json:"personality"`
		Skill *struct {
			IsCheck bool  `json:"is_check"`
			Ids     []int `json:"ids"`
		} `json:"skill"`
		Knowledge *struct {
			IsCheck bool  `json:"is_check"`
			Ids     []int `json:"ids"`
		} `json:"knowledge"`
		Potential *struct {
			IsCheck bool `json:"is_check"`
		} `json:"potential"`
		WorkValues *struct {
			IsCheck bool  `json:"is_check"`
			Ids     []int `json:"ids"`
		} `json:"work_values"`
		KeyExpr *struct {
			IsCheck         bool  `json:"is_check"`
			ManageExprId    int   `json:"manage_expr_id"`
			BusinessExprIds []int `json:"business_expr_ids"`
		} `json:"key_expr"`
		EmotionalIntelligence *struct {
			IsCheck bool `json:"is_check"`
		} `json:"emotional_intelligence"`
		CriticalThinking *struct {
			IsCheck bool `json:"is_check"`
		} `json:"critical_thinking"`
		PracticalIntelligence *struct {
			IsCheck bool `json:"is_check"`
		} `json:"practical_intelligence"`
		OccupationalPersonality *struct {
			IsCheck bool `json:"is_check"`
		} `json:"occupational_personality"`
		PersonalityDisorder *struct {
			IsCheck bool `json:"is_check"`
		} `json:"personality_disorder"`
		LeadershipStyle *struct {
			IsCheck bool `json:"is_check"`
		} `json:"leadership_style"`
		OrgCommitment *struct {
			IsCheck bool `json:"is_check"`
		} `json:"org_commitment"`
	}
)

func (f *Project) Create(param *CreateParam) (result interface{}, err error) {
	key := genDraftProjectCacheKey(param.CompanyId, param.AccountId)
	val, err := redis.Get(key)
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "call redis service error")
		return
	}

	var draft CreateParam

	if val != nil {
		err = encoding.JSON.Unmarshal(val.([]byte), &draft)
		if err != nil {
			err = hfwcommon.NewRespErr(core.SystemErrNo, "exec encoding.JSON.Unmarshal error")
			return
		}
	}

	switch param.Step {
	case 1:
		err = param.ProcessStep1(key, &draft)
	case 2:
		err = param.ProcessStep2(key, &draft)
	case 3:
		err = param.ProcessStep3(key, &draft)
	case 4:
		result, err = param.ProcessStep4(key)
	}
	return
}

func (c *CreateParam) ProcessStep1(key string, draft *CreateParam) (err error) {
	draft.Step = c.Step
	draft.SceneId = c.SceneId
	draft.SceneTemplateId = c.SceneTemplateId
	return saveDraft(key, draft)
}

func (c *CreateParam) ProcessStep2(key string, draft *CreateParam) (err error) {
	draft.Step = c.Step
	draft.Name = c.Name
	draft.PositionId = c.PositionId
	draft.StartAt = c.StartAt
	draft.IndustryId = c.IndustryId
	draft.FunctionId = c.FunctionId
	draft.LevelId = c.LevelId
	draft.IsManager = c.IsManager
	return saveDraft(key, draft)
}

func (c *CreateParam) ProcessStep3(key string, draft *CreateParam) (err error) {
	draft.Step = c.Step
	draft.Interview = c.Interview
	draft.Remark = c.Remark
	return saveDraft(key, draft)
}

func (c *CreateParam) ProcessStep4(key string) (result interface{}, err error) {
	// 开启事务
	dao, err := db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec db.NewXormDao error")
	}
	dao.NewSession()
	defer dao.Close()
	err = dao.Begin()
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec dao.Begin() error")
	}

	// 项目表
	txProjects, err := models.NewProjects(dao)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.NewProjects error")
	}
	// 是否管理岗
	var isManager int
	if c.IsManager {
		isManager = 1
	}
	// 场景
	scenes, err := models.ProjectsScenesModel.GetById(c.SceneId)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.ProjectsScenesModel.GetById error")
	}
	if scenes == nil || scenes.IsDeleted == 1 {
		return nil, hfwcommon.NewRespErr(core.InvalidParamsErrNo, fmt.Sprintf("not found scene, sceneId = %d", c.SceneId))
	}
	companyConfigs, err := company.Get(c.CompanyId)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.DbQueryNotExist, fmt.Sprintf("search company configs error, id: %d", c.CompanyId))
	}
	projects := models.Projects{
		CompanyId:           c.CompanyId,
		UserId:              c.AccountId,
		Name:                c.Name,
		SceneId:             c.SceneId,
		SceneTemplateId:     c.SceneTemplateId,
		PositionId:          c.PositionId,
		PositionIndustryId:  c.IndustryId,
		PositionFunctionId:  c.FunctionId,
		PositionLevelId:     c.LevelId,
		IsManagerPosition:   isManager,
		InterviewUsersCount: len(c.Staffs),
		ComplateRate:        0,
		GoalDesc:            scenes.Name,
		Desc:                c.Remark,
		StartAt:             c.StartAt,
		InterviewMode:       int(companyConfigs.InterviewMode),
	}
	_, err = txProjects.Insert(&projects)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.NewProjects.Insert error")
	}

	// 项目员工关联表
	txProjectsStaffs, err := models.NewProjectsStaffs(dao)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.NewProjectsStaffs error")
	}

	var pss []*models.ProjectsStaffs
	for _, v := range c.Staffs {
		pss = append(pss, &models.ProjectsStaffs{
			ProjectId: projects.Id,
			StaffId:   v.ID,
		})
	}
	_, err = txProjectsStaffs.Insert(pss...)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.NewProjects.Insert error")
	}

	// 项目配置表
	txProjectsInterviewsConfigs, err := models.NewProjectsInterviewsConfigs(dao)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.NewProjectsInterviewsConfigs error")
	}
	var configs []*models.ProjectsInterviewsConfigs
	// 是否开启管理素质测评
	var isCheckManagementQuality bool
	// 素质
	if c.Interview.Bei.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.Bei.Value(),
			IsShow:      models.SHOW,
		}

		var items []*v2_interview.InterviewSubItem
		for _, v := range c.Interview.Bei.CheckItems {
			if hitInterview, ok := kitbei.BeiSubitem2InterviewSubitems[v.Id]; ok && hitInterview.InterviewID == kitbei.ManagementQualityInterviewID && !isCheckManagementQuality && companyConfigs.InterviewMode == kitAdminConstant.MODENEWBEI {
				isCheckManagementQuality = true
			}
			items = append(items, &v2_interview.InterviewSubItem{
				Id:    v.Id,
				Score: v.Score,
			})
			/*
				1.用bei选择排序题id获取选择排序题id并存入配置(前端只选择要做的问答题)
				2.只有老版bei会同时存储选择排序题和问答题ID
			*/
			if mappingID, check := kitinterview.GetMappingCheck(v.Id); check && mappingID > 0 && companyConfigs.InterviewMode == kitAdminConstant.MODEBEI {
				items = append(items, &v2_interview.InterviewSubItem{
					Id:    mappingID,
					Score: v.Score,
				})
			}
		}
		config.InterviewConfigs = utils.MustMarshalToString(items)

		configs = append(configs, &config)
	}
	// 性格
	if c.Interview.Personality.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.Personality.Value(),
			IsShow:      models.SHOW,
		}

		positionFunction, err := models.PositionFunctionsModel.SearchOne(db.Cond{
			"id": c.FunctionId,
		})
		if err != nil {
			return result, fmt.Errorf("search position_function error, id:{%d}", c.Interview.Personality.FunctionID)
		}
		normStarDimensionResult, err := interview.NormStarDimension(&interview.NormStarDimensionParams{
			FunctionID:        positionFunction.FunctionId,
			IsManagerPosition: c.IsManager,
		})
		if err != nil {
			return nil, err
		}
		selected := make([]*struct {
			NormstarID   int    `json:"normstar_id"`
			NormstarName string `json:"normstar_name"`
		}, len(normStarDimensionResult))

		for i, norm := range normStarDimensionResult {
			selected[i] = &struct {
				NormstarID   int    `json:"normstar_id"`
				NormstarName string `json:"normstar_name"`
			}{
				NormstarID:   norm.ID,
				NormstarName: norm.Name,
			}
		}
		item := &v2_interview.PersonalityInterviewItem{
			FunctionID:        positionFunction.FunctionId,
			FunctionName:      c.Interview.Personality.FunctionName,
			IsManagerPosition: c.IsManager,
			Selected:          selected,
		}
		config.InterviewConfigs = utils.MustMarshalToString(item)

		configs = append(configs, &config)
	}
	// 技能
	if c.Interview.Skill.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.Skill.Value(),
			IsShow:      models.SHOW,
		}

		var items []*v2_interview.InterviewSubItem
		for _, v := range c.Interview.Skill.Ids {
			items = append(items, &v2_interview.InterviewSubItem{
				Id: v,
			})
		}
		config.InterviewConfigs = utils.MustMarshalToString(items)

		configs = append(configs, &config)
	}
	// 知识
	if c.Interview.Knowledge.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.Knowledge.Value(),
			IsShow:      models.SHOW,
		}

		var items []*v2_interview.InterviewSubItem
		for _, v := range c.Interview.Knowledge.Ids {
			items = append(items, &v2_interview.InterviewSubItem{
				Id: v,
			})
		}
		config.InterviewConfigs = utils.MustMarshalToString(items)

		configs = append(configs, &config)
	}
	// 潜力
	if c.Interview.Potential.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.Potential.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 工作选择价值观
	if c.Interview.WorkValues.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.WorkValues.Value(),
			IsShow:      models.SHOW,
		}

		var items []*v2_interview.InterviewSubItem
		for _, v := range c.Interview.WorkValues.Ids {
			items = append(items, &v2_interview.InterviewSubItem{
				Id: v,
			})
		}
		config.InterviewConfigs = utils.MustMarshalToString(items)

		configs = append(configs, &config)
	}
	// 关键经历
	if c.Interview.KeyExpr.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.KeyExp.Value(),
			IsShow:      models.SHOW,
		}

		var items []*v2_interview.InterviewSubItem
		items = append(items, &v2_interview.InterviewSubItem{
			Id: c.Interview.KeyExpr.ManageExprId,
		})
		for _, v := range c.Interview.KeyExpr.BusinessExprIds {
			items = append(items, &v2_interview.InterviewSubItem{
				Id: v,
			})
		}
		config.InterviewConfigs = utils.MustMarshalToString(items)

		configs = append(configs, &config)
	}
	// 情绪智力
	if c.Interview.EmotionalIntelligence.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.EmotionalIntelligence.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 批判思维
	if c.Interview.CriticalThinking.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.CriticalThinking.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 管理实践能力
	if c.Interview.PracticalIntelligence.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.PracticalIntelligence.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 职业人格
	if c.Interview.OccupationalPersonality.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.OccupationalPersonality.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 性格风险
	if c.Interview.PersonalityDisorder.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.PersonalityDisorder.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 领导风格
	if c.Interview.LeadershipStyle.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.LeadershipStyle.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}
	// 组织忠诚度
	if c.Interview.OrgCommitment.IsCheck {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.OrgCommitment.Value(),
			IsShow:      models.SHOW,
		}
		configs = append(configs, &config)
	}

	// 管理素质
	if isCheckManagementQuality {
		config := models.ProjectsInterviewsConfigs{
			ProjectId:   projects.Id,
			InterviewId: kitinterview.ManagementQuality.Value(),
			IsShow:      models.HIDE,
		}
		configs = append(configs, &config)
	}

	_, err = txProjectsInterviewsConfigs.Insert(configs...)
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec models.NewProjects.Insert error")
	}

	// 提交事务
	err = dao.Commit()
	if err != nil {
		return nil, hfwcommon.NewRespErr(core.SystemErrNo, "exec dao.Begin() error")
	}

	// 清理草稿
	err = cleanDraft(key)
	if err != nil {
		logger.Errorf("exec cleanDraft error, err:%v", err)
	}

	return map[string]int{"id": projects.Id}, nil
}

func (c *CreateParam) Validate() error {
	// 校验步骤
	switch c.Step {
	case 1, 2, 3, 4:
	default:
		return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "illegal step")
	}

	// 校验场景 ID、场景模版 ID
	if c.Step == 1 || c.Step == 2 || c.Step == 3 || c.Step == 4 {
		// 场景
		if c.SceneId <= 0 {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "sceneId must > 0")
		}
		scenes, err := models.ProjectsScenesModel.GetById(c.SceneId)
		if err != nil {
			return hfwcommon.NewRespErr(core.SystemErrNo, "exec models.ProjectsScenesModel.GetById error")
		}
		if scenes == nil || scenes.IsDeleted == 1 {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, fmt.Sprintf("not found scene, sceneId = %d", c.SceneId))
		}
		// 场景模版
		if c.SceneTemplateId > 0 {
			projectsScenesTemplate, err := models.ProjectsScenesTemplateModel.SearchOne(db.Cond{"is_deleted": 0, "id": c.SceneTemplateId})
			if err != nil {
				return err
			}
			if projectsScenesTemplate == nil {
				return hfwcommon.NewRespErr(20304053, fmt.Sprintf("not found projectsScenesTemplate, scenesTemplateId = %d", c.SceneTemplateId))
			}
		}
	}

	// 校验场景模版 ID、项目名、岗位 ID、项目开始时间、行业 ID、职能 ID、层级 ID、是否为管理岗
	if c.Step == 2 || c.Step == 3 || c.Step == 4 {
		// 场景模版
		if c.SceneTemplateId > 0 {
			projectsScenesTemplate, err := models.ProjectsScenesTemplateModel.SearchOne(db.Cond{"is_deleted": 0, "id": c.SceneTemplateId})
			if err != nil {
				return err
			}
			if projectsScenesTemplate == nil {
				return hfwcommon.NewRespErr(20304053, fmt.Sprintf("not found projectsScenesTemplate, scenesTemplateId = %d", c.SceneTemplateId))
			}
			b, _ := strconv.ParseBool(strconv.Itoa(projectsScenesTemplate.IsManager))
			if projectsScenesTemplate.FunctionId != c.FunctionId ||
				projectsScenesTemplate.LevelId != c.LevelId ||
				b != c.IsManager {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "illegal industryId or functionId or levelId or isManager")
			}
		}
		// 项目名
		err := CheckProjectName(c.CompanyId, c.Name)
		if err != nil {
			return err
		}
		// 岗位 ID
		if c.PositionId <= 0 {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "positionId must > 0")
		}
		position, err := dhr_staff.GetPositionById(nil, c.CompanyId, c.PositionId, false)
		if err != nil {
			return hfwcommon.NewRespErr(core.SystemErrNo, "exec dhr_staff.GetPositionById error")
		}
		if position == nil {
			return hfwcommon.NewRespErr(20304047, fmt.Sprintf("not found position, positionId = %d", c.PositionId))
		}
		// 项目开始时间，暂未用到，无需校验

		//行业 ID
		if c.IndustryId <= 0 {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "industryId must > 0")
		}
		industry, err := models.PositionIndustriesModel.GetById(c.IndustryId)
		if err != nil {
			return hfwcommon.NewRespErr(core.SystemErrNo, "exec models.PositionIndustriesModel.GetById error")
		}
		if industry == nil || industry.IsDeleted == 1 {
			return hfwcommon.NewRespErr(20304048, fmt.Sprintf("not found industry, industryId = %d", c.IndustryId))
		}
		//职能 ID
		if c.FunctionId <= 0 {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "functionId must > 0")
		}
		function, err := models.PositionFunctionsModel.GetById(c.FunctionId)
		if err != nil {
			return hfwcommon.NewRespErr(core.SystemErrNo, "exec models.PositionFunctionsModel.GetById error")
		}
		if function == nil || function.IsDeleted == 1 {
			return hfwcommon.NewRespErr(20304049, fmt.Sprintf("not found function, functionId = %d", c.FunctionId))
		}
		//层级 ID
		if c.LevelId <= 0 {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "levelId must > 0")
		}
		level, err := models.PositionLevelsModel.GetById(c.LevelId)
		if err != nil {
			return hfwcommon.NewRespErr(core.SystemErrNo, "exec models.PositionLevelsModel.GetById error")
		}
		if level == nil || level.IsDeleted == 1 {
			return hfwcommon.NewRespErr(20304050, fmt.Sprintf("not found level, levelId = %d", c.LevelId))
		}
	}

	// 校验测评维度、备注
	if c.Step == 3 || c.Step == 4 {
		// 测评维度
		if c.Interview == nil ||
			c.Interview.Bei == nil ||
			c.Interview.Personality == nil ||
			c.Interview.Skill == nil ||
			c.Interview.Knowledge == nil ||
			c.Interview.Potential == nil ||
			c.Interview.WorkValues == nil ||
			c.Interview.KeyExpr == nil ||
			c.Interview.EmotionalIntelligence == nil ||
			c.Interview.CriticalThinking == nil ||
			c.Interview.PracticalIntelligence == nil ||
			c.Interview.OccupationalPersonality == nil ||
			c.Interview.PersonalityDisorder == nil ||
			c.Interview.LeadershipStyle == nil ||
			c.Interview.OrgCommitment == nil {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview is nil")
		}
		// 暂未实现子维度 ID 数据库层校验
		//interviews, err := v2_interview.List()
		//if err != nil {
		//    return err
		//}
		//for _, item := range interviews {
		//}
		// 素质，不需要限制子维度勾选数量
		if v2_interview.GetIsMust(kitinterview.Bei, c.SceneId, c.SceneTemplateId) {
			if !c.Interview.Bei.IsCheck {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.bei is must check")
			}
			for _, v := range c.Interview.Bei.CheckItems {
				if !(v.Id >= 1 && v.Id <= 59) {
					return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.bei.itemId must > 0")
				}
				if !(v.Score >= 0 && v.Score <= 5) {
					return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.bei.score must [1,5]")
				}
			}
		}
		// 性格
		if v2_interview.GetIsMust(kitinterview.Personality, c.SceneId, c.SceneTemplateId) && !c.Interview.Personality.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.personality is must check")
		}
		// 技能
		if v2_interview.GetIsMust(kitinterview.Skill, c.SceneId, c.SceneTemplateId) {
			if !c.Interview.Skill.IsCheck {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.skill is must check")
			}
			if len(c.Interview.Skill.Ids) > v2_interview.GetMaxCheck(kitinterview.Skill) {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.skill item length exceed limit")
			}
			for _, v := range c.Interview.Skill.Ids {
				if v <= 0 {
					return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.skill.itemId must > 0")
				}
			}
		}
		// 知识
		if v2_interview.GetIsMust(kitinterview.Knowledge, c.SceneId, c.SceneTemplateId) {
			if !c.Interview.Knowledge.IsCheck {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.knowledge is must check")
			}
			if len(c.Interview.Knowledge.Ids) > v2_interview.GetMaxCheck(kitinterview.Knowledge) {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.knowledge item length exceed limit")
			}
		}
		// 潜力
		if v2_interview.GetIsMust(kitinterview.Potential, c.SceneId, c.SceneTemplateId) && !c.Interview.Potential.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.potential is must check")
		}
		// 工作选择价值观
		if v2_interview.GetIsMust(kitinterview.WorkValues, c.SceneId, c.SceneTemplateId) {
			if !c.Interview.WorkValues.IsCheck {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.workValues is must check")
			}
			if len(c.Interview.WorkValues.Ids) > v2_interview.GetMaxCheck(kitinterview.WorkValues) {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.workValues item length exceed limit")
			}
		}
		// 关键经历
		if v2_interview.GetIsMust(kitinterview.KeyExp, c.SceneId, c.SceneTemplateId) {
			if !c.Interview.KeyExpr.IsCheck {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.keyExpr is must check")
			}
			// 管理经历
			if c.Interview.KeyExpr.ManageExprId <= 0 {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.keyExpr.manageExprId must > 0")
			}
			// 业务经历
			if len(c.Interview.KeyExpr.BusinessExprIds) > v2_interview.GetMaxCheck(kitinterview.KeyExp) &&
				len(c.Interview.KeyExpr.BusinessExprIds) < 1 {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.keyExpr.businessExpr item length exceed limit")
			}
			for _, v := range c.Interview.KeyExpr.BusinessExprIds {
				if v <= 0 {
					return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.keyExpr.businessExpr.itemId must > 0")
				}
			}
		}
		// 情绪智力
		if v2_interview.GetIsMust(kitinterview.EmotionalIntelligence, c.SceneId, c.SceneTemplateId) && !c.Interview.EmotionalIntelligence.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.emotionalIntelligence is must check")
		}
		// 批判思维
		if v2_interview.GetIsMust(kitinterview.CriticalThinking, c.SceneId, c.SceneTemplateId) && !c.Interview.CriticalThinking.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.criticalThinking is must check")
		}
		// 管理实践能力
		if v2_interview.GetIsMust(kitinterview.PracticalIntelligence, c.SceneId, c.SceneTemplateId) && !c.Interview.PracticalIntelligence.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.practicalIntelligence is must check")
		}
		// 职业人格
		if v2_interview.GetIsMust(kitinterview.OccupationalPersonality, c.SceneId, c.SceneTemplateId) && !c.Interview.OccupationalPersonality.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.occupationalPersonality is must check")
		}
		// 性格风险
		if v2_interview.GetIsMust(kitinterview.PersonalityDisorder, c.SceneId, c.SceneTemplateId) && !c.Interview.PersonalityDisorder.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.personalityDisorder is must check")
		}
		// 领导风格
		if v2_interview.GetIsMust(kitinterview.LeadershipStyle, c.SceneId, c.SceneTemplateId) && !c.Interview.LeadershipStyle.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.leadershipStyle is must check")
		}
		// 组织忠诚度
		if v2_interview.GetIsMust(kitinterview.OrgCommitment, c.SceneId, c.SceneTemplateId) && !c.Interview.OrgCommitment.IsCheck {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "interview.orgCommitment is must check")
		}
		// 备注
		if (strings.Count(c.Remark, "") - 1) > ProjectRemarkLengthLimit {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "remark length exceed limit")
		}
	}

	// 校验员工 ID 列表
	if c.Step == 4 {
		staffIds := make([]int, 0, len(c.Staffs))
		for _, staff := range c.Staffs {
			if staff.ID <= 0 {
				return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "staff.id must > 0")
			}
			staffIds = append(staffIds, staff.ID)
		}
		staffs, err := dhr_staff.ListStaffByIds(nil, c.CompanyId, staffIds, true, nil)
		if err != nil {
			return hfwcommon.NewRespErr(core.SystemErrNo, "exec models.ProjectsScenesModel.GetById error")
		}
		if staffs == nil {
			return hfwcommon.NewRespErr(20304051, fmt.Sprintf("not found staffs, staffIds = %v", staffIds))
		}
		for _, staff := range staffs {
			for _, cStaff := range c.Staffs {
				if staff.Id == cStaff.ID {
					cStaff.Name = staff.Name
					cStaff.DepartmentID = staff.DepartmentId
					cStaff.DepartmentName = staff.DepartmentName
					cStaff.PositionID = staff.PositionId
					cStaff.PositionName = staff.PositionName
					cStaff.ParentID = staff.ParentId
					cStaff.ParentName = staff.ParentName
					cStaff.Status = staff.Status
				}
			}
		}
	}

	return nil
}
