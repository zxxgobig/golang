package libraries

import (
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/logger"
)

const (
	userStatusDeleted  = iota // 账号删除
	userStatusEnabled         // 账号启用
	userStatusDisabled        // 账号停用
)

type GetUserInfoParams struct {
	Ids       []int `json:"ids"`
	CompanyId int   `json:"company_id"`
}

type GetUserInfoResult struct {
	Id             int    `json:"id"`
	UserName       string `json:"user_name"`
	LoginEmail     string `json:"login_mail"`
	Status         int    `json:"status"`
	RoleType       int    `json:"role_type"`
	DataPermission int    `json:"data_permission"`
}

func GetUserInfo(httpCtx *hfw.HTTPContext, params *GetUserInfoParams) (result map[int]*GetUserInfoResult, err error) {
	userInfos := make([]*GetUserInfoResult, 0, len(params.Ids))
	p := api.NewPost("", "")
	p.P = params
	err = api.SimpleCurl(httpCtx, config.AppConfig.Custom["RBACAccountURL"]+"account/getAccountInfo", p, &userInfos)
	if err != nil {
		return result, err
	}
	result = make(map[int]*GetUserInfoResult)
	for _, v := range userInfos {
		result[v.Id] = v
		logger.Infof("******GetUserInfo  userId:%v,userName:%v***", v.Id, v.UserName)
	}
	return result, err
}

type UserListResponse struct {
	Total int                  `json:"total"`
	Pages int                  `json:"pages"`
	Pager int                  `json:"pager"`
	Size  int                  `json:"size"`
	List  []*GetUserInfoResult `json:"list"`
}

func GetUserListByCompanyID(companyID int) (result map[int]GetUserInfoResult, err error) {
	var response *UserListResponse
	p := api.NewPost("", "")
	p.P = &struct {
		ResourceKey string `json:"resource_key"`
		CompanyID   int    `json:"company_id"`
		Pager       int    `json:"pager"`
		Size        int    `json:"size"`
	}{
		"bot_public",
		companyID,
		1,
		100,
	}
	err = api.SimpleCurl(nil, config.AppConfig.Custom["RBACAccountURL"]+"account/currentAccountList", p, &response)
	if err != nil {
		return result, err
	}
	result = make(map[int]GetUserInfoResult)
	for _, u := range response.List {
		if u.Status != userStatusEnabled {
			continue
		}
		result[u.Id] = *u
	}
	return result, nil
}

type GetUserNamesByUserIdsResult struct {
	ID       int    `json:"id"`
	UserName string `json:"user_name"`
}

//调Java中台数据
func GetUserNamesByUserIds(companyId int, userIds []int) (userData map[int]string, err error) {
	p := api.Post{}
	p.P = &struct {
		ResourceKey string `json:"resource_key"`
		Ids         []int  `json:"ids"`
		CompanyId   int    `json:"company_id"`
	}{
		ResourceKey: "bot_public",
		Ids:         userIds,
		CompanyId:   companyId,
	}

	var results []GetUserNamesByUserIdsResult
	err = api.SimpleCurl(nil, config.AppConfig.Custom["RBACAccountURL"]+"account/getAccountInfo", p, &results)
	if err != nil {
		logger.Errorf("GetUserNamesByUserIds get Java account/getAccountInfo err:%v", err)
		return nil, common.NewRespErr(20305028, "调用 Java 接口 account/getAccountInfo 报错")
	}

	userData = make(map[int]string)
	for _, v := range results {
		userData[v.ID] = v.UserName
		logger.Infof("******GetUserNamesByUserIds  userId:%v,userName:%v***", v.ID, v.UserName)
	}
	return
}
