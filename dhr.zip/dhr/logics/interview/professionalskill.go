package interview

import (
    "context"
    "encoding/json"
    "fmt"
    "gitlab.ifchange.com/bot/hfwkit/utils"

    "gitlab.ifchange.com/bot/logger"

    "gitlab.ifchange.com/bot/hfw/encoding"

    "ifchange/dhr/core"
    logicsCommon "ifchange/dhr/logics/common"

    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfwkit/config"
    "gitlab.ifchange.com/bot/hfwkit/grpc/client"
    pb "gitlab.ifchange.com/bot/proto/professional_skills"
    "google.golang.org/grpc"
)

type ProfessionalSkillConfig struct {
    DataCollectPlansUsers []*DataCollectDemandStaff
    *Config
}

type ProfessionalSkill struct {
    Config *ProfessionalSkillConfig
}

func (p *ProfessionalSkill) SaveVoice(param interface{}) (err error) {
	return nil
}

func (p *ProfessionalSkill) SetConfig(config interface{}) (err error) {
    var ok bool
    p.Config, ok = config.(*ProfessionalSkillConfig)
    if !ok {
        p.Config.DataCollectPlansUsers = nil
        return fmt.Errorf("ProfessionalSkillConfig assert fail")
    }
    p.Config.Config.EmailUuid, err = utils.CreateUuid(p.Config.Config)
    p.Config.Config.Uuid = p.Config.Config.EmailUuid
    p.Config.Config.Uuid, err = utils.CreateUuid(p.Config.Config)
    if err != nil {
        return err
    }
    return err
}

// 类型转换
func (p *ProfessionalSkill) ParseConfig() (assessors []*pb.Assessor, err error) {
    if p.Config.DataCollectPlansUsers == nil {
        err = fmt.Errorf("config is nil")
    }
    if err != nil {
        return
    }
    assessors = []*pb.Assessor{}

    for _, u := range p.Config.DataCollectPlansUsers {
        skills := make([]*pb.Skill, 0)
        for _, c := range u.NoCompletedConfigItemParams {
            // 获取类型
            var typeId pb.SkillType
            if c.Id == IntvKnowlege {
                typeId = pb.SkillType_KNOWLEDGE
            } else if c.Id == IntvSkill {
                typeId = pb.SkillType_SKILL
            } else {
                continue
            }

            for _, x := range c.SubItems {
                skills = append(skills, &pb.Skill{
                    Id:   int64(x.Id),
                    Name: "",
                    Type: typeId,
                })
            }
        }

        assessors = append(assessors, &pb.Assessor{
            UserId: int64(u.Id),
            Skills: skills,
        })
    }
    return
}

func (p *ProfessionalSkill) Create(c []ConfigSubItem) (result interface{}, err error) {
    assessor, err := p.ParseConfig()
    if err != nil {
        return result, err
    }
    params := pb.EvaluateCreateRequest{
        UniqueId:  p.Config.Config.Uuid,
        Assessors: assessor,
    }

    resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewEvaluateClient(conn).Create(ctx, &params)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        logger.Errorf("ProfessionalSkills %v", err)
        return result, err
    }

    r, ok := resp.(bool)
    if !ok || !r {
        return result, common.NewRespErr(core.SystemErrNo, "ProfessionalSkills result is error")
    }

    return result, err
}

func (p *ProfessionalSkill) Get(uuid string, param interface{}) (t interface{}, err error) {
    request := &pb.EvaluateGetRequest{
        UniqueId: uuid,
    }

    resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewEvaluateClient(conn).Get(ctx, request)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }

    return resp, nil
}

type _EvaluateGetResultUser struct {
    Id   int    `json:"id"`
    Name string `json:"name"`
    No   string `json:"no"`
}
type _EvaluateGetResult struct {
    *pb.EvaluateGetResult
    Users []_EvaluateGetResultUser `json:"users"`
}

func (p *ProfessionalSkill) Commit(uuid string, param interface{}) (t interface{}, err error) {
    commitRequest := pb.EvaluateCommitRequest{}
    if param != nil {
        _param := param.(json.RawMessage)
        str, err := _param.MarshalJSON()

        err = json.Unmarshal(str, &commitRequest)
        if err != nil {
            return nil, err
        }
        fmt.Println("============", commitRequest, string(str), "============")
    } else {
        commitRequest.UniqueId = uuid
    }

    resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewEvaluateClient(conn).Commit(ctx, &commitRequest)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }
    result := resp.(*pb.EvaluateCommitResult)
    return result, nil
}

type commitProfessionalSkillParams struct {
    EmailUuid  string `json:"email_uuid"`
    Feedback   string `json:"feedback"`
    OrginScore string `json:"orgin_score"`
    Score      int    `json:"score"`
}

func (p *ProfessionalSkill) ResultCommit(interviewID int, emailUuid string, params interface{}) (err error) {
    paramStr, err := encoding.JSON.Marshal(params)
    if err != nil {
        return common.NewRespErr(core.SystemErrNo, err)
    }
    err = logicsCommon.UpdateStaffsInterview(emailUuid, string(paramStr), params, interviewID)
    if err != nil {
        return err
    }
    return
}

func (p *ProfessionalSkill) CheckFinished(response interface{}) (isFinished bool, err error) {
    if response == nil {
        err = fmt.Errorf("bei response unvalid")
        return
    }
    res := response.(*pb.EvaluateCommitResult)
    return res.IsFinish == true, nil
}
