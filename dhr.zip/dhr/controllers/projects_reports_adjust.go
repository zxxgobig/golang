package controllers

import (
	"ifchange/dhr/logics/project"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
)

/**
* @api {post} /projects_reports/adjust 项目详情-调整九宫格数据
* @apiVersion 0.1.0
* @apiGroup ProjectsReport
* @apiDescription 项目详情-调整九宫格数据
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} project_id 项目 ID
* @apiParam {Number} scene_id 场景 ID
* @apiParam {Number} interview_id 九宫格维度 id，0 表示综合能力，其它情况与测评维度 id 对应
* @apiParam {Number} name 盘点记录名称
* @apiParam {Object[]} adjust_staffs 要调整的员工列表
* @apiParam {Number} adjust_staffs.id 员工 ID
* @apiParam {Number} adjust_staffs.original 初始位置（0-8）
* @apiParam {Number} adjust_staffs.target 目标位置（0-8）
*
* @apiParamExample {json} Request-Example:
* {
*     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
*	   "project_id": 3,
*	   "scene_id": 1,
*	   "interview_id": 1,
*	   "name": "hahah",
*	   "adjust_staffs": [{
*			"id": 23,
*			"original": 0,
*			"target": 8,
*		},{
*			"id": 43,
*			"original": 3,
*			"target": 8,
*		}]
* }
*
* @apiSuccess {Object} result 返回结果
* @apiSuccess {Boolean} success 是否保存成功
* @apiSuccess {Boolean} is_first_dump 是否为项目的第一次保存
*
* @apiSuccessExample {json} Response-Example:
*		{
*			"success": true,
*			"is_first_dump": true
*		}
*
*/
func (c *ProjectsReport) Adjust(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectID    int                    `json:"project_id" validate:"required"`
		SceneID      int                    `json:"scene_id" validate:"required"`
		InterviewID  int                    `json:"interview_id"`
		Name         string                 `json:"name" validate:"required"`
		AdjustStaffs []*project.AdjustStaff `json:"adjust_staffs" validate:"required"`
	}{}

	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	httpCtx.ThrowCheck(20304001, validate(param))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	reportID, err := project.Adjust(curUser.CompanyId, param.ProjectID, param.SceneID, param.InterviewID, param.Name, param.AdjustStaffs)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = &struct {
		Success  bool `json:"success"`
		ReportID int  `json:"report_id,omitempty"`
	}{true, reportID}
}
