package project

import (
    "fmt"
    "ifchange/dhr/core"
    "ifchange/dhr/logics/interview"
    "time"
    "unicode/utf8"

    "gitlab.ifchange.com/bot/hfw/common"
)

type ProjectCreateRequestParam struct {
    Name                      string                       `json:"name" validate:"required"`
    SceneId                   int                          `json:"scene_id" validate:"required"`
    PositionId                int                          `json:"position_id" validate:"required"`
    IndustryId                int                          `json:"industry_id" validate:"required"`
    PositionFunctionId        int                          `json:"position_function_id" validate:"required"`
    IsManagerPosition         int                          `json:"is_manager_position"`
    PositionLevelId           int                          `json:"position_level_id" validate:"required"`
    Desc                      string                       `json:"desc"`
    StartAt                   time.Time                    `json:"start_at" validate:"required"`
    InterviewConfigItemParams []*interview.ConfigItemParam `json:"interview_config_item_params" validate:"required"`
    StaffIds                  []int                        `json:"staff_ids" validate:"required"`
    InterviewConfigs          *interview.InterviewsConfigs `json:"interviews_configs"`
}

// Validate 创建项目验证，业务要求验证
func (p *ProjectCreateRequestParam) Validate(companyID int) (err error) {
    count, err := GetCountByProjectName(companyID, p.Name)
    if count > 0 {
        err = common.NewRespErr(core.SystemErrNo, "和已有项目重名")
        return
    }

    if len(p.InterviewConfigItemParams) == 0 {
        err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Sprint("config not set"))
        return
    }

    if utf8.RuneCountInString(p.Name) > 20 {
        err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Sprint("name too long"))
        return
    }

    for _, x := range p.InterviewConfigItemParams {
        if x.Id != interview.IntvPotential && x.Id != interview.IntvNormstar {
            if len(x.SubItems) == 0 {
                err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Errorf("subItems len unvalid:%d", x.Id))
                return
            }
        }
        if x.Id == interview.IntvSkill || x.Id == interview.IntvKnowlege {
            if len(x.SubItems) > 3 {
                err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Errorf("skill knowlege config len unvalid"))
                return
            }
        }
    }

    // 关键经历中，业务经历必须存在
    if p.InterviewConfigs != nil && p.InterviewConfigs.KeyExpr != nil {
        if len(p.InterviewConfigs.KeyExpr.ManageExpr) != 1 && len(p.InterviewConfigs.KeyExpr.BusinessExpr) > 0 {
            err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Sprint("关键经历中的管理经历有且必须只有1个子维度"))
            return
        }
        if len(p.InterviewConfigs.KeyExpr.BusinessExpr) > 5 {
            err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Sprint("关键经历中的业务经历做多5个子维度"))
            return
        }

    }

    if p.InterviewConfigs != nil && p.InterviewConfigs.WorkValues != nil {
        if len(p.InterviewConfigs.WorkValues) > 2 {
            err = common.NewRespErr(core.InvalidParamsErrNo, fmt.Sprint("工作选择价值观最多2个子维度"))
            return
        }
    }

    return
}
