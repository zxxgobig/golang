#! /bin/bash
databaseName=dhr
projectName=dhr
$GOPATH/bin/xorm reverse \
  mysql devuser:devuser@tcp\(192.168.1.174:3306\)/${databaseName}?charset=utf8mb4 \
  $GOPATH/pkg/mod/gitlab.ifchange.com/bot/hfw@v1.0.1/xorm \
  $GOPATH/src/gitlab.ifchange.com/${projectName}/models $1
