package libraries

import (
	"fmt"
	"strconv"
)

func FixedZeroDigit(f float64) float64 {
	fixed, _ := strconv.ParseFloat(fmt.Sprintf("%.0f", f), 64)
	return fixed
}

func FixedOneDigit(f float64) float64 {
	fixed, _ := strconv.ParseFloat(fmt.Sprintf("%.1f", f), 64)
	return fixed
}

func FixedTwoDigit(f float64) float64 {
	fixed, _ := strconv.ParseFloat(fmt.Sprintf("%.2f", f), 64)
	return fixed
}

func FixedThreeDigit(f float64) float64 {
	fixed, _ := strconv.ParseFloat(fmt.Sprintf("%.3f", f), 64)
	return fixed
}
