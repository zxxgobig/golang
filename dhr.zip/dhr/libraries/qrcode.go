package libraries

import (
    "encoding/base64"
    "fmt"

    "github.com/skip2/go-qrcode"
)

type QrCode int8

// PNG picture byte stream after base64
// usually used in emails
func (q *QrCode) EncodeBase64(content string) (base64Str string, err error) {
    b, err := q.Encode(content)
    if err != nil {
        return "", err
    }
    enc := encode(b)
    out := format(enc, "image/png")
    return out, nil
}

// 字符串编码为QrCode流
func (_ *QrCode) Encode(content string) (png []byte, err error) {
    png, err = qrcode.Encode(content, qrcode.Medium, 256)
    return png, err
}

// format is an abstraction of the mime switch to create the
// acceptable base64 string needed for browsers.
func format(enc []byte, mime string) string {
    switch mime {
    case "image/gif", "image/jpeg", "image/pjpeg", "image/png", "image/tiff":
        return fmt.Sprintf("data:%s;base64,%s", mime, enc)
    default:
    }

    return fmt.Sprintf("data:image/png;base64,%s", enc)
}

// encode is our main function for
// base64 encoding a passed []byte
func encode(bin []byte) []byte {
    e64 := base64.StdEncoding

    maxEncLen := e64.EncodedLen(len(bin))
    encBuf := make([]byte, maxEncLen)

    e64.Encode(encBuf, bin)
    return encBuf
}
