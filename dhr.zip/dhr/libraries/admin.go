package libraries

import (
	"encoding/json"
	"fmt"

	"gitlab.ifchange.com/bot/hfwkit/dhr_admin"
	"gitlab.ifchange.com/bot/logger"
)

// C端是否需要验证手机号
// verifyCode=1 需要
// verifyCode=2 不需要
func ToCVerifyPhone(companyID int) (verifyCode int, err error) {
	result, err := dhr_admin.GetCompanyConfigs(companyID, "")
	if err != nil {
		return 1, err
	}
	configsMap := make(map[string]interface{})
	err = json.Unmarshal(*result, &configsMap)
	if err != nil {
		return 1, err
	}
	if verifyPhone, ok := configsMap["verify_phone"]; ok {
		if int(verifyPhone.(float64)) == 1 {
			verifyCode = 1
		} else if int(verifyPhone.(float64)) == 2 {
			verifyCode = 2
		} else {
			logger.Warnf("ToCVerifyPhone alarm call dhr_admin.GetCompanyConfigs response verifyPhone [%f]", verifyPhone.(float64))
			verifyCode = 1
		}
	} else {
		return 1, fmt.Errorf("verifyPhone dhr_admin.GetCompanyConfigs not found key [%s]", "verify_phone")
	}
	return verifyCode, nil
}
