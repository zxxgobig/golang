package company

import (
	"encoding/json"
	"fmt"

	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
)

type updateConfigsRequest struct {
	ID            int    `json:"id"`
	Token         string `json:"token"`
	VerifyPhone   int    `json:"verify_phone"`
	InterviewMode int8   `json:"interview_mode"`
	ELearns       int16  `json:"e_learns"`
}

type getConfigsRequest struct {
	ID int `json:"id"`
}

// Set ..
func Set(token string, verifyPhone, id int, interviewMode int8, eLearns int16) error {
	p := api.NewPost("", "")
	p.P = &updateConfigsRequest{
		ID:            id,
		Token:         token,
		VerifyPhone:   verifyPhone,
		InterviewMode: interviewMode,
		ELearns:       eLearns,
	}
	if id == 0 || (token == "" && verifyPhone == 0 && eLearns == 0) {
		return fmt.Errorf("wrong params id: %d, token: %s, verify_phone: %d", id, token, verifyPhone)
	}
	var path = "/configs/update_configs"
	r, err := api.NormalCurl(nil, config.GetServers().BotDhrAdmin+path, p)
	if err != nil {
		return fmt.Errorf("Get dhr_admin recieve error %v", err)
	}
	if r.Response.ErrNo != 0 {
		return fmt.Errorf("Get dhr_admin recieve error %v", r.Response.ErrMsg)
	}
	return nil
}

// SearchByIDResponse ..
type SearchByIDResponse struct {
	ID            int64  `json:"id"`
	Token         string `json:"token"`
	VerifyPhone   int    `json:"verify_phone"`
	InterviewMode int8   `json:"interview_mode"`
}

// Get ..
func Get(id int) (rsp SearchByIDResponse, err error) {
	p := api.NewPost("", "")
	p.P = &getConfigsRequest{
		ID: id,
	}
	var path = "/configs/search_by_id"
	res, err := api.NormalCurl(nil, config.GetServers().BotDhrAdmin+path, p)
	if err != nil {
		return rsp, fmt.Errorf("Get dhr_admin recieve error %v", err)
	}
	if res.ErrNo != 0 {
		return rsp, fmt.Errorf(res.Response.ErrMsg)
	}
	rsp = SearchByIDResponse{}
	err = json.Unmarshal(res.Results, &rsp)
	if err != nil {
		return rsp, err
	}
	return rsp, nil
}
