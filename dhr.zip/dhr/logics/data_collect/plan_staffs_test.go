package data_collect

import (
    "testing"
)

func TestDataCollectPlanStaffsNoCompleteCountByPlanId(t *testing.T) {
    noComplete, err := new(DataCollectPlanStaffs).NoCompletedCountByProjectId(1)
    if err != nil {
        t.Error(err)
        return
    }
    t.Logf("noComplete count is: %d", noComplete)
}

func TestDataCollectPlanStaffsCompletedCountByProjectId(t *testing.T) {
    completedCount, err := new(DataCollectPlanStaffs).CompletedCountByProjectId(1)
    if err != nil {
        t.Error(err)
        return
    }
    t.Log(completedCount)
}
