package interview

import (
	"encoding/json"
	"fmt"
	"testing"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	hfwutil "gitlab.ifchange.com/bot/hfwkit/utils"
	"gitlab.ifchange.com/bot/logger"
	"xorm.io/builder"

	"ifchange/dhr/libraries"
	"ifchange/dhr/models"
)

type StaffsInterviewsDetailsExt struct {
	*models.StaffsInterviewsDetails
	IsFinished bool
}

func TestGetValidStaffsInterviewDetails(t *testing.T) {
	where := builder.NewCond()
	interviewConfigMapping := make(map[int]ConfigSubItemsIdGetter, 0)
	interviewConfigMapping[10] = ConfigSubItemsIdGetter{}
	interviewConfigMapping[11] = ConfigSubItemsIdGetter{}
	for id, item := range interviewConfigMapping {
		switch interview.Type(id) {
		// 素质 1
		case interview.Bei:
			where = where.Or(
				builder.Eq{"interview_id": interview.Bei}.
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Bei).BeforeTime())}),
			)
		// 性格 2，没有子维度，特殊处理
		case interview.Personality:
			where = where.Or(
				builder.Eq{"interview_id": interview.Personality}.
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Personality).BeforeTime())}),
			)
		// 专业技能 3
		case interview.Skill:
			where = where.Or(
				builder.Eq{"interview_id": interview.Skill}.
					And(builder.In("sub_item", hfwutil.GetIds(item))).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Skill).BeforeTime())}),
			)
		// 专业知识 4
		case interview.Knowledge:
			where = where.Or(
				builder.Eq{"interview_id": interview.Knowledge}.
					And(builder.In("sub_item", hfwutil.GetIds(item))).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Knowledge).BeforeTime())}),
			)
		// 潜力 5，没有子维度，特殊处理
		case interview.Potential:
			where = where.Or(
				builder.Eq{"interview_id": interview.Potential}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Potential).BeforeTime())}),
			)
		// 工作选择价值观 6
		case interview.WorkValues:
			where = where.Or(
				builder.Eq{"interview_id": interview.WorkValues}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.WorkValues).BeforeTime())}),
			)
		// 关键经历 7
		case interview.KeyExp:
			where = where.Or(
				builder.Eq{"interview_id": interview.KeyExp}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.KeyExp).BeforeTime())}),
			)
		// 情绪智力 8，没有子维度，特殊处理
		case interview.EmotionalIntelligence:
			where = where.Or(
				builder.Eq{"interview_id": interview.EmotionalIntelligence}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.EmotionalIntelligence).BeforeTime())}),
			)
		// 批判思维 9，没有子维度，特殊处理
		case interview.CriticalThinking:
			where = where.Or(
				builder.Eq{"interview_id": interview.CriticalThinking}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.CriticalThinking).BeforeTime())}),
			)
		// 管理实践能力 10，没有子维度，特殊处理
		case interview.PracticalIntelligence:
			where = where.Or(
				builder.Eq{"interview_id": interview.PracticalIntelligence}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.PracticalIntelligence).BeforeTime())}),
			)
		// 职业人格 11，没有子维度，特殊处理
		case interview.OccupationalPersonality:
			where = where.Or(
				builder.Eq{"interview_id": interview.OccupationalPersonality}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.OccupationalPersonality).BeforeTime())}),
			)
		// 性格风险 12，没有子维度，特殊处理
		case interview.PersonalityDisorder:
			where = where.Or(
				builder.Eq{"interview_id": interview.PersonalityDisorder}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.PersonalityDisorder).BeforeTime())}),
			)
		// 领导风格 13，没有子维度，特殊处理
		case interview.LeadershipStyle:
			where = where.Or(
				builder.Eq{"interview_id": interview.LeadershipStyle}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.LeadershipStyle).BeforeTime())}),
			)
		// 组织忠诚 14，没有子维度，特殊处理
		case interview.OrgCommitment:
			where = where.Or(
				builder.Eq{"interview_id": interview.OrgCommitment}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.OrgCommitment).BeforeTime())}),
			)
		}
	}

	/*
		SELECT
			*
		FROM
			`staffs_interviews_details`
		WHERE
			`staff_id` IN ( 283 )
			AND (
				( ( interview_id = 10 AND sub_item > 0 AND updated_at > '2019-06-19 17:53:02' ) OR ( interview_id = 11 AND sub_item > 0 AND updated_at > '2019-06-19 17:53:02' ))
				AND `status` = 2
				AND `is_deleted` = 0
			)
		ORDER BY
			updated_at DESC
	*/
	staffsInterviewDetails, err := models.StaffsInterviewsDetailsModel.Search(db.Cond{
		"is_deleted":  0,
		"nolimit":     struct{}{},
		"staff_id in": []int{283},
		"status":      2,
		"where":       libraries.MustToBoundSQL(where),
		"orderby":     "updated_at DESC",
	})
	if err != nil {
		logger.Error(err)
		return
	}

	newStaffsInterviewDetails := testFilterOldPAndO(staffsInterviewDetails)
	result := make([]*models.StaffsInterviewsDetails, 0, len(staffsInterviewDetails))
	tmp := make(map[string]struct{})
	for k, v := range newStaffsInterviewDetails {
		key := fmt.Sprintf("%d:%d:%d", v.StaffId, v.InterviewId, v.SubItem)
		if _, ok := tmp[key]; !ok {
			tmp[key] = struct{}{}
			//TestGetValidStaffsInterviewDetails: create_demand_test.go:201: 283:11:3
			//TestGetValidStaffsInterviewDetails: create_demand_test.go:201: 283:11:2
			//TestGetValidStaffsInterviewDetails: create_demand_test.go:201: 283:11:6
			//TestGetValidStaffsInterviewDetails: create_demand_test.go:201: 283:11:1
			//TestGetValidStaffsInterviewDetails: create_demand_test.go:201: 283:11:4
			//TestGetValidStaffsInterviewDetails: create_demand_test.go:201: 283:11:5
			t.Log(key)
			result = append(result, staffsInterviewDetails[k])
		}
	}

	/*[
	    {
	        "id":5503,
	        "project_id":615,
	        "staff_id":283,
	        "interview_id":11,
	        "data_collect_id":251,
	        "sub_item":3,
	        "secondary_sub_item":6,
	        "orgin_score":"",
	        "tag":"想象",
	        "score":6,
	        "frequency":0,
	        "status":2,
	        "is_deleted":0,
	        "updated_at":"2020-04-15T16:15:14+08:00",
	        "created_at":"2020-04-08T15:24:50+08:00"
	    },
	    {
	        "id":5467,
	        "project_id":615,
	        "staff_id":283,
	        "interview_id":10,
	        "data_collect_id":251,
	        "sub_item":3,
	        "secondary_sub_item":1,
	        "orgin_score":"",
	        "tag":"组织建设",
	        "score":4,
	        "frequency":0,
	        "status":2,
	        "is_deleted":1,
	        "updated_at":"2020-04-15T16:14:25+08:00",
	        "created_at":"2020-04-08T15:24:50+08:00"
	    },
	    {
	        "id":5463,
	        "project_id":615,
	        "staff_id":283,
	        "interview_id":10,
	        "data_collect_id":251,
	        "sub_item":1,
	        "secondary_sub_item":0,
	        "orgin_score":"",
	        "tag":"战略能力",
	        "score":2.2,
	        "frequency":0,
	        "status":2,
	        "is_deleted":1,
	        "updated_at":"2020-04-08T15:24:50+08:00",
	        "created_at":"2020-04-08T15:24:50+08:00"
	    },
	    {
	        "id":5499,
	        "project_id":615,
	        "staff_id":283,
	        "interview_id":11,
	        "data_collect_id":251,
	        "sub_item":2,
	        "secondary_sub_item":1,
	        "orgin_score":"",
	        "tag":"负责",
	        "score":4,
	        "frequency":0,
	        "status":2,
	        "is_deleted":0,
	        "updated_at":"2020-04-08T15:24:50+08:00",
	        "created_at":"2020-04-08T15:24:50+08:00"
	    },
	    {
	        "id":5504,
	        "project_id":615,
	        "staff_id":283,
	        "interview_id":11,
	        "data_collect_id":251,
	        "sub_item":3,
	        "secondary_sub_item":4,
	        "orgin_score":"",
	        "tag":"灵活",
	        "score":6,
	        "frequency":0,
	        "status":2,
	        "is_deleted":0,
	        "updated_at":"2020-04-08T15:24:50+08:00",
	        "created_at":"2020-04-08T15:24:50+08:00"
	    },
	    {
	        "id":5510,
	        "project_id":615,
	        "staff_id":283,
	        "interview_id":11,
	        "data_collect_id":251,
	        "sub_item":6,
	        "secondary_sub_item":3,
	        "orgin_score":"",
	        "tag":"希望",
	        "score":7,
	        "frequency":0,
	        "status":2,
	        "is_deleted":0,
	        "updated_at":"2020-04-08T15:24:50+08:00",
	        "created_at":"2020-04-08T15:24:50+08:00"
	    }
	]*/
	b, _ := json.Marshal(result)
	t.Log(string(b))
}

// 对10号测评和11号测评进行过滤
func testFilterOldPAndO(details []*models.StaffsInterviewsDetails) (newDetails []*models.StaffsInterviewsDetails) {
	// 10号测评和11号测评的结果可能不可信，
	// 先置为不可信
	for k, v := range details {
		if v.InterviewId == 10 || v.InterviewId == 11 {
			details[k].IsDeleted = 1
		}
	}
	// 对满足条件的测评，
	// 重置为可信状态
	for _, v := range details {
		if (v.InterviewId == 10 && v.SubItem == 3 && v.SecondarySubItem == 4) ||
			v.InterviewId == 11 && v.SubItem == 3 && v.SecondarySubItem == 6 {
			for kk, vv := range details {
				if vv.StaffId == v.StaffId && vv.InterviewId == v.InterviewId {
					details[kk].IsDeleted = 0
				}
			}
		}
	}

	// 对模式1下的BEI完成率进行过滤，
	// 模式1下的BEI数据在模式2下无效
	for k, v := range details {
		if v.InterviewId == 1 && testIsModeOneByProjectID(v.ProjectId) {
			details[k].IsDeleted = 1
		}
	}

	// 过滤掉失信数据，
	// 构建新集合
	for _, v := range details {
		if v.IsDeleted == 0 {
			newDetails = append(newDetails, v)
		}
	}
	return newDetails
}

// 判断该项目是否处于BEI模式1
func testIsModeOneByProjectID(projectID int) bool {
	mode := getProjectInterviewModeByID(projectID)
	if mode == 1 {
		return true
	}
	return false
}

func TestCreateDemandTime(t *testing.T) {
	time := hfwutil.FormatDateTime(interview.GetPeriodDay(interview.ManagementQuality).BeforeTime())
	t.Log(time)
}
