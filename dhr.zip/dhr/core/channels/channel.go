package channels

import (
	"fmt"
	"sync"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/signal"
	"gitlab.ifchange.com/bot/logger"
)

var (
	signalContext = signal.GetSignalContext()
	chs           = &channels{
		dataCollectNoticeLogCh: make(chan *models.DataCollectNoticeLog, 1000),
	}
)

func GetCh() *channels {
	return chs
}

type channels struct {
	dataCollectNoticeLogCh chan *models.DataCollectNoticeLog // 采集计划提醒队列
	once                   sync.Once
}

func init() {
	go func() {
		logger.Info("start dhr own channels server")
		for {
			select {
			case l, ok := <-GetCh().dataCollectNoticeLogCh:
				if ok {
					noticeLog(l)
				}
			case <-signalContext.Ctx.Done():
				GetCh().once.Do(func() {
					close(GetCh().dataCollectNoticeLogCh)
				})
				logger.Info("server shutdown, stop dhr own channels server")
				return
			}
		}
	}()
}

////////// 采集计划提醒
func (c *channels) PushDataCollectNoticeLog(l *models.DataCollectNoticeLog) error {
	if c.dataCollectNoticeLogCh == nil {
		return fmt.Errorf("channels dataCollectNoticeLogCh is nil")
	}
	c.dataCollectNoticeLogCh <- l
	return nil
}

func noticeLog(noticeLog *models.DataCollectNoticeLog) {
	_, err := models.DataCollectNoticeLogModel.Insert(noticeLog)
	if err != nil {
		logger.Errorf("channels DataCollectNoticeLogModel.Insert err:%v", err)
	}
}
