package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/projects_staffs", &ProjectsStaffs{})
}

/*
go test ./controllers -run TestPorjectsStaffsList -e local -v
*/
func TestPorjectsStaffsList(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }

    params := struct {
        Session
        ProjectID int `json:"project_id"`
    }{
        Session: Session{
            SessionID: session,
        },
        ProjectID: 27,
    }

    rsp := test.Do(t, "/projects_staffs/list", &params)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_staffs/list results: <%+s>", b)
}
