package controllers

import (
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"ifchange/dhr/logics/staff"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/interview"
)

type ProjectsStaffs struct {
	core.Controller
}

/**
 * @api {post} /projects_staffs/list 员工详情列表
 * @apiVersion 0.1.0
 * @apiGroup CollectionPlan
 * @apiDescription 采集计划页面下的员工详情列表
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} project_id 项目 id
 *
 * @apiParamExample {json} Request-Example:
  {
      "p": {
		  "session": ""
		  "project_id": 2,
	  }
  }
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object[]} results.list 员工列表
 * @apiSuccess {Number} results.list.id 员工 id
 * @apiSuccess {Number} results.list.company_id 员工所在公司id
 * @apiSuccess {Number} results.list.name 员工姓名
 * @apiSuccess {String} results.list.no 员工工号
 * @apiSuccess {Number} results.list.sex 员工性别: 0未知，1男，2女
 * @apiSuccess {Number} results.list.age 员工年龄
 * @apiSuccess {Number} results.list.phone 员工手机号
 * @apiSuccess {String} results.list.email 员工邮箱
 * @apiSuccess {Number} results.list.department_id 员工部门id
 * @apiSuccess {Number} results.list.department_name 部门名称
 * @apiSuccess {Number} results.list.position_id 职位id
 * @apiSuccess {Number} results.list.position_name 职位名称
 * @apiSuccess {Number} results.list.parent_id 直属上级的员工id
 * @apiSuccess {Number} results.list.parent_name 直属上级的员工名称
 * @apiSuccess {Number} results.list.status 状态：1试用期，2在职，3离职
 * @apiSuccess {Number} results.list.education 学历：0未知，1小学，2初中，3中专，4高中，5大专，6本科，7硕士，8博士
 * @apiSuccess {String} results.list.worked_at 工作时间
 * @apiSuccess {String} results.list.hired_at 入职时间
 * @apiSuccess {String} results.list.product_ids 入职时间
 * @apiSuccess {String} results.list.is_deleted 0未删除, 1已删除
 * @apiSuccess {String} results.list.created_at 创建时间
 * @apiSuccess {String} results.list.updated_at 更新时间
 * @apiSuccess {Number} results.list.created_at_unix 创建时间戳
 * @apiSuccess {Number} results.list.updated_at_unix 更新时间戳

 *
 * @apiSuccessExample {json} Response-Example:
 *   {
		 "results": {
			 "list": [
				{
					"id": 899,
					"company_id": 899,
					"name": "解忧51",
					"no": "00001"
					"sex": 1,
					"birthday": "2019-06-06T00:00:00+08:00",
					"phone": "15800000511",
					"email": "qinhao@ifchange.com",
					"department_id": 11,
					"department_name": "lp测试部门",
					"position_id": 39,
					"position_name": "123123",
					"parent_id": 39,
					"parent_name": "123123"
					"status": 1,
					"education": 1,
					"worked_at": "2019-06-06T00:00:00+08:00",
					"hired_at": "2019-06-06T00:00:00+08:00",
					"product_ids": [
						1
					],
					"is_deleted": 0,
					"created_at": "2019-06-06T00:00:00+08:00",
					"updated_at": "2019-06-06T00:00:00+08:00",
					"created_at_unix": 1560239603,
					"updated_at_unix": 1560239603
				}
			 ]
		 }
 *   }
 *
*/
func (ctl *ProjectsStaffs) List(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectId int `json:"project_id" validate:"required"`
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)

	staffs, err := interview.GetDataCollectDemandStaffs(curUser.CompanyId, params.ProjectId, nil)
	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = map[string]interface{}{
		"list": staffs,
	}

}

/**
 * @api {post} /projects_staffs/drop_list 员工列表
 * @apiVersion 0.1.0
 * @apiGroup CollectionPlan
 * @apiDescription 采集计划页面下的员工详情列表
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} project_id 项目 id
 *
 * @apiParamExample {json} Request-Example:
  {
      "p": {
		  "project_id": 2,
	  }
  }
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.id 员工 id
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
		 "results": [
			 1,2,3
		 ]
 *   }
 *
*/
func (ctl *ProjectsStaffs) DropList(httpCtx *hfw.HTTPContext) {
	params := &struct {
		ProjectId int `json:"project_id" validate:"required"`
	}{}
	httpCtx.ThrowCheck(core.RequestError, api.RequestUnmarshal(httpCtx, params))

	staffs, err := staff.GetStaffIDsByProjectID(params.ProjectId)
	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = staffs
}
