package common

import (
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

// Update status of collect plan after dimension test
func UpdateCollectPlanStaff(staffID, interviewID, planID int) (err error) {
	logger.Infof("UpdateCollectPlanStaff staffID: %d, interviewID: %d, planID: %d",
		staffID, interviewID, planID)

	var completed = 2
	cond := db.Cond{}
	if interviewID == 1 {
		cond["bei"] = completed
	} else if interviewID == 2 {
		cond["normstar"] = completed
	} else if interviewID == 3 || interviewID == 4 {
		cond["skill"] = completed
		cond["knowledge"] = completed
	} else if interviewID == 5 {
		cond["potential"] = completed
	} else if interviewID == 8 {
		cond["emotional_intelligence"] = completed
	} else if interviewID == 9 {
		cond["critical_thinking"] = completed
	} else if interviewID == 10 {
		cond["practical_intelligence"] = completed
	} else if interviewID == 11 {
		cond["occupational_personality"] = completed
	} else if interviewID == 12 {
		cond["personality_disorder"] = completed
	} else if interviewID == 13 {
		cond["leadership_style"] = completed
	} else if interviewID == 14 {
		cond["org_commitment"] = completed
	} else if interviewID == 6 {
		cond["work_values"] = completed
	} else if interviewID == 7 {
		cond["key_expr"] = completed
	}
	// TODO logical problems roll back
	_, err = models.DataCollectPlanStaffsModel.Update(cond, db.Cond{
		"plan_id":  planID,
		"staff_id": staffID,
	})
	if err != nil {
		return err
	}

	// 此采集计划是否完成
	planStaffL, err := models.DataCollectPlanStaffsModel.Search(db.Cond{"plan_id": planID})
	if err != nil {
		return err
	}
	if planStaffL == nil || len(planStaffL) == 0 {
		logger.Warnf("UpdateCollectPlanStaff, DataCollectPlanStaffsModel Search is null by plan_id %d", planID)
		return nil
	}

	var planIsCompleted = true
	for _, planStaff := range planStaffL {
		// 此采集计划中只要有一个员工的一项测评没有完成,
		// 此采集计划就没有完成,
		// 相反, 此采集计划完成
		if planStaff.Bei != 2 && planStaff.Bei != 3 {
			planIsCompleted = false
		} else if planStaff.Normstar != 2 && planStaff.Normstar != 3 {
			planIsCompleted = false
		} else if planStaff.Skill != 2 && planStaff.Skill != 3 {
			planIsCompleted = false
		} else if planStaff.Knowledge != 2 && planStaff.Knowledge != 3 {
			planIsCompleted = false
		} else if planStaff.Potential != 2 && planStaff.Potential != 3 {
			planIsCompleted = false
		} else if planStaff.EmotionalIntelligence != 2 && planStaff.EmotionalIntelligence != 3 {
			planIsCompleted = false
		} else if planStaff.CriticalThinking != 2 && planStaff.CriticalThinking != 3 {
			planIsCompleted = false
		} else if planStaff.PracticalIntelligence != 2 && planStaff.PracticalIntelligence != 3 {
			planIsCompleted = false
		} else if planStaff.OccupationalPersonality != 2 && planStaff.OccupationalPersonality != 3 {
			planIsCompleted = false
		} else if planStaff.PersonalityDisorder != 2 && planStaff.PersonalityDisorder != 3 {
			planIsCompleted = false
		} else if planStaff.LeadershipStyle != 2 && planStaff.LeadershipStyle != 3 {
			planIsCompleted = false
		} else if planStaff.OrgCommitment != 2 && planStaff.OrgCommitment != 3 {
			planIsCompleted = false
		} else if planStaff.KeyExpr != 2 && planStaff.KeyExpr != 3 {
			planIsCompleted = false
		} else if planStaff.WorkValues != 2 && planStaff.WorkValues != 3 {
			planIsCompleted = false
		}
		// TODO logical problems roll back
	}
	logger.Infof("UpdateCollectPlanStaff planIsCompleted is: %v", planIsCompleted)
	if planIsCompleted {
		// 此采集计划全部已经完成
		_, err = models.DataCollectPlansModel.Update(db.Cond{
			"status": 3,
		}, db.Cond{
			"id": planID,
		})
	}
	return nil
}

// InterviewMapping ..
var InterviewMapping = map[int]string{
	1:  "bei",
	2:  "normstar",
	3:  "skill",
	4:  "knowledge",
	5:  "potential",
	6:  "work_values",
	7:  "key_expr",
	8:  "emotional_intelligence",
	9:  "critical_thinking",
	10: "practical_intelligence",
	11: "occupational_personality",
	12: "personality_disorder",
	13: "leadership_style",
	14: "org_commitment",
	21: "management_quality",
}

const (
	CollectPlanFinished   = 2
	CollectPlanUnfinished = 1
)
