package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var ProjectsDistributionsDataModel = &ProjectsDistributionsData{}

func init() {
	var err error
	ProjectsDistributionsDataModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	ProjectsDistributionsDataModel.Dao.EnableCache(ProjectsDistributionsDataModel)
	//ProjectsDistributionsDataModel.Dao.DisableCache(ProjectsDistributionsDataModel)
	//gob: type not registered for interface
	gob.Register(ProjectsDistributionsDataModel)
}

type ProjectsDistributionsData struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id             int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	ProjectId      int       `json:"project_id" xorm:"not null default 0 comment('项目id') INT(11)"`
	DistributionId int       `json:"distribution_id" xorm:"not null default 0 comment('分布记录 id') INT(11)"`
	InterviewId    int       `json:"interview_id" xorm:"not null comment('九宫格维度 id，综合为 0，其它情况与测评 id 对应') INT(11)"`
	Data           string    `json:"data" xorm:"not null comment('盘点分布数据') TEXT"`
	List           string    `json:"list" xorm:"not null comment('盘点分布列表数据') TEXT"`
	StaffsData     string    `json:"staffs_data" xorm:"not null comment('员工的盘点分布映射关系数据') TEXT"`
	Adjust         string    `json:"adjust" xorm:"comment('调整的员工数据') TEXT"`
	IsDeleted      int       `json:"is_deleted" xorm:"not null default 0 TINYINT(1)"`
	UpdatedAt      time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
	CreatedAt      time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
}

func (m *ProjectsDistributionsData) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *ProjectsDistributionsData) GetProjectId() (val int) {
	if m == nil {
		return
	}
	return m.ProjectId
}

func (m *ProjectsDistributionsData) GetDistributionId() (val int) {
	if m == nil {
		return
	}
	return m.DistributionId
}

func (m *ProjectsDistributionsData) GetInterviewId() (val int) {
	if m == nil {
		return
	}
	return m.InterviewId
}

func (m *ProjectsDistributionsData) GetData() (val string) {
	if m == nil {
		return
	}
	return m.Data
}

func (m *ProjectsDistributionsData) GetList() (val string) {
	if m == nil {
		return
	}
	return m.List
}

func (m *ProjectsDistributionsData) GetStaffsData() (val string) {
	if m == nil {
		return
	}
	return m.StaffsData
}

func (m *ProjectsDistributionsData) GetAdjust() (val string) {
	if m == nil {
		return
	}
	return m.Adjust
}

func (m *ProjectsDistributionsData) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *ProjectsDistributionsData) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *ProjectsDistributionsData) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *ProjectsDistributionsData) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *ProjectsDistributionsData) TableName() string {
	return "projects_distributions_data"
}

func (m *ProjectsDistributionsData) Save(t ...*ProjectsDistributionsData) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsDistributionsData
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *ProjectsDistributionsData) Saves(t []*ProjectsDistributionsData) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *ProjectsDistributionsData) Insert(t ...*ProjectsDistributionsData) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsDistributionsData
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *ProjectsDistributionsData) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *ProjectsDistributionsData) SearchOne(cond db.Cond) (t *ProjectsDistributionsData, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *ProjectsDistributionsData) Search(cond db.Cond) (t []*ProjectsDistributionsData, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *ProjectsDistributionsData) SearchAndCount(cond db.Cond) (t []*ProjectsDistributionsData, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *ProjectsDistributionsData) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *ProjectsDistributionsData) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *ProjectsDistributionsData) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *ProjectsDistributionsData) GetMulti(ids ...interface{}) (t []*ProjectsDistributionsData, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *ProjectsDistributionsData) GetByIds(ids ...interface{}) (t []*ProjectsDistributionsData, err error) {
	return m.GetMulti(ids...)
}

func (m *ProjectsDistributionsData) GetById(id interface{}) (t *ProjectsDistributionsData, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *ProjectsDistributionsData) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *ProjectsDistributionsData) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *ProjectsDistributionsData) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *ProjectsDistributionsData) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *ProjectsDistributionsData) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewProjectsDistributionsData(c ...interface{}) (m *ProjectsDistributionsData, err error) {
	m = &ProjectsDistributionsData{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *ProjectsDistributionsData) Close() {
	m.Dao.Close()
}

func (m *ProjectsDistributionsData) Begin() error {
	return m.Dao.Begin()
}

func (m *ProjectsDistributionsData) Rollback() error {
	return m.Dao.Rollback()
}

func (m *ProjectsDistributionsData) Commit() error {
	return m.Dao.Commit()
}
