package controllers

import (
	"fmt"
	"ifchange/dhr/core"
	"ifchange/dhr/logics/staff"
	"ifchange/dhr/logics/stat"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/dhr/kit/session"
)

type StaffViewRequest struct {
	*Session
	StaffID       int  `json:"staff_id" validate:"gte=1"`
	ReportID      int  `json:"report_id" validate:"gte=0"`
	ProjectID     int  `json:"project_id" validate:"gte=0"`
	PermittedOnly bool `json:"permitted_only"`
	InterviewID   int  `json:"interview_id"`
}

type StaffsView struct {
	core.Controller
}

func (v *StaffsView) Before(httpCtx *hfw.HTTPContext) {
	v.Controller.Before(httpCtx)
}

/**
 * @api {post} /staffs_view/collection_plan_list 员工详情-采集记录列表
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-采集记录列表
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} staff_id 员工 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "staff_id": 3,
		"resource_key":"bot_public"
 * }
 *
 * @apiSuccess {Object[]} result 返回结果，为数组
 * @apiSuccess {Number} result.id 采集计划的 ID
 * @apiSuccess {String} result.name 采集计划的名称
 * @apiSuccess {String} result.created_at 采集计划创建时间
 * @apiSuccess {Number} result.list.data_source_type 数据所属账号的类型：1，当前账号创建；2，被分享给当前账号；3，其他
 * @apiSuccess {Number} result.list.role_type 用户账号的类型：1，超级管理员；2，普通用户
 * @apiSuccess {Number} result.list.data_permission 数据权限的类型：1：所有数据权限；2：无所有数据权限
 *
 * @apiSuccessExample {json} Response-Example:
 * [
 *		{
 *			"id": 1,
 *			"name": "采集计划-1",
 *			"created_at": "1560999235",
 *			"data_source_type": 1
            "role_type":1
			"data_permission":1
 *		}
 * ]
 *
*/
func (v *StaffsView) CollectionPlanList(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)
	plans, err := staff.CollectionPlanList(
		curUser.Id,
		req.StaffID,
		curUser.CompanyId,
		curUser.RoleType,
		curUser.DataPermission,
		curUser.RoleIds,
		req.GetSessionID(),
	)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = plans
}

/**
 * @api {post} /staffs_view/inventory_list 员工详情-盘点记录列表
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-盘点记录列表
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Boolean} [permitted_only=false] 只返回运行查看的数据（即当前账号创建的和被分享的数据）
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "staff_id": 3,
 *		"permitted_only": false
 * }
 *
 * @apiSuccess {Object[]} result 返回结果，为数组
 * @apiSuccess {Number} result.id 盘点记录的 ID
 * @apiSuccess {Number} result.scene_id 盘点记录对应的场景 ID
 * @apiSuccess {Number} result.project_id 盘点记录对应的项目 ID
 * @apiSuccess {String} result.name 盘点记录的名称
 * @apiSuccess {String} result.created_at 盘点记录建时间
 * @apiSuccess {Number} result.list.data_source_type 数据所属账号的类型：1.当前账号创建; 2.被分享给当前账号; 3.其他
 * @apiSuccess {Number} result.data_permission 数据权限的类型：1：所有数据权限；2：无所有数据权限
 *
 * @apiSuccessExample {json} Response-Example:
 *
 *  [
 *			{
 *				"id": 1,
 *          	"project_id": 1,
 *				"name": "盘点记录-1",
 *				"created_at": "1560999235",
 *				"data_source_type": 1,
 *				"data_permission": 1
 *			},
 *   ]
 */

func (v *StaffsView) InventoryList(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))
	sess, ok := httpCtx.Ctx.Value("session").(*session.Session)
	if !ok {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("参数错误"))
	}
	inventories, err := staff.InventoryList(
		sess.CompanyID,
		req.StaffID,
		sess.UserID,
		sess.RoleType,
		sess.DataPermission,
		req.PermittedOnly,
		req.GetSessionID(),
	)
	httpCtx.ThrowCheck(20305001, err)
	httpCtx.Results = inventories
}

/**
 * @api {post} /staffs_view/inventory_distribution 员工详情-盘点分布
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-盘点分布
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
  {
      "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 	   "staff_id": 3,
 	   "project_id": 1,
 	   "report_id": 1
  }
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {String} result.staff_avatar_url 员工头像 URL
 * @apiSuccess {Object[]} result.distributions 员工盘点分布列表
 * @apiSuccess {Number} result.distributions.interview_id 0 表示【综合能力】
 * @apiSuccess {Object[]} result.distributions.grids 九宫格
 * @apiSuccess {Number} result.distributions.grid.record_at 年月
 * @apiSuccess {Number} result.distributions.grid.axis_x 分布位置坐标 x 轴
 * @apiSuccess {Number} result.distributions.grid.axis_y 分布位置坐标 y 轴
 * @apiSuccess {String} result.distributions.grid.name 分布位置名称
 * @apiSuccess {String[]} result.pros 个人优势
 * @apiSuccess {String[]} result.cons 个人劣势
 * @apiSuccess {Object[]} result.advice 个人发展建议，两项
 * @apiSuccess {Number} result.advice.axis_id 维度 ID
 * @apiSuccess {String} result.advice.axis_name 维度名称
 * @apiSuccess {String[]} result.advice.advice 具体建议内容
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"staff_id": 3,
		"staff_avatar_url": "http://xxxx.png",
		"distributions": [
			{
				"interview_id": 1,
				"grids": [
					{
						"axis_x": 1,
						"axis_y": 1,
						"name": "明星员工初级"
						"record_at": 1565162520
					},
					{
						"axis_x": 2,
						"axis_y": 3,
						"name": "明星员工进阶",
						"record_at": 1557590400
					},
					{
						"axis_x": 3,
						"axis_y": 3,
						"name": "高级明星员工"
						"record_at": 1566354969
					}
				]
			},
			{
				"interview_id": 1,
				"grids": [
					{
						"record_at": 1565162520,
						"axis_x": 1,
						"axis_y": 1,
						"name": "明星员工"
					}
				]
			}
		],
		"pros": [
			"Go语言开发",
			"结果导向",
			"哈哈"
		],
		"cons": [
			"沟通影响",
			"关系建立",
			"呵呵"
		],
		"advice": [
			{
				"axis_id": 1,
				"axis_name": "分析思维",
				"advice": [
					"可以",
					"不行"
				]
			},
			{
				"axis_id": 2,
				"axis_name": "搜索信息",
				"advice": [
					"呵呵",
					"哈哈哈",
					"棒棒哒"
				]
			}
		]
	}
*/
func (v *StaffsView) InventoryDistribution(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	if httpCtx.Ctx.Value("session") == nil {
		httpCtx.ThrowCheck(20304002, fmt.Errorf("nil session"))
	}
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.InventoryDistribution(httpCtx, sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/performance 员工详情-绩效
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-绩效
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.performance 员工绩效
 * @apiSuccess {String} result.performance.level 绩效评级
 * @apiSuccess {String[]} result.performance.labels 标签列表
 * @apiSuccess {String} result.performance.desc 绩效描述
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"performance": {
 *			"level": "S",
 *			"labels": ["标签1"，"标签2"，"标签3"],
 *			"desc": "这个人不错哦"
 *		}
 *   }
 *
 */
func (v *StaffsView) Performance(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.Performance(sess.CompanyID, req.StaffID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/labels 员工详情-标签
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-标签
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 * @apiParamExample {json} Request-Example:
  {
     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
	   "project_id": 3,
	   "staff_id": 3,
	   "report_id": 1
  }
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {String[]} result.job_choice_value_labels 工作选择价值观标签
 * @apiSuccess {String[]} result.key_experience_labels 关键经历标签
* @apiSuccess {String[]} result.labels 工作选择价值观标签 + 关键经历标签
 * @apiSuccessExample {json} Response-Example:
  {
       "results": {
           "staff_id": 109,
           "job_choice_value_labels": ["危机处理", "业务轮岗", "行业转换"],
           "key_experience_labels": ["自我实现", "兴趣特长", "财富"],
           "labels": ["危机处理", "业务轮岗", "行业转换","自我实现", "兴趣特长", "财富"]
        }
  }
 *
*/
func (v *StaffsView) Labels(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, validate(req))

	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.StaffLabels(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/quality 员工详情-I01-素质
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-素质
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.quality 员工专业技能结果
 * @apiSuccess {Object[]} result.quality.dimension 统计的维度列表
 * @apiSuccess {String} result.quality.dimension.name 统计的维度名称
 * @apiSuccess {String} result.quality.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.quality.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.quality.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.quality.rule 统计规则
 * @apiSuccess {Object[]} result.quality.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.quality.data 统计数据
 * @apiSuccess {String} result.quality.data.legend 图例
 * @apiSuccess {Object} result.quality.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"quality": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *				"desc": "",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *				"desc": "",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *				"desc": "",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *				"desc": "",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *				"desc": "",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *				"desc": "",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) Quality(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.Quality(sess.CompanyID, req.ProjectID, req.StaffID)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/personality_eval 员工详情-I02-性格
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-性格
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI03YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工组织忠诚度结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "性格1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "性格2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "性格3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "性格4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "性格5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) PersonalityEval(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.Personality)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/professional_skills 员工详情-I03/04-专业知识技能
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-专业知识技能
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.professional_skills 员工专业技能结果
 * @apiSuccess {Object[]} result.professional_skills.dimension 统计的维度列表
 * @apiSuccess {String} result.professional_skills.dimension.name 统计的维度名称
 * @apiSuccess {String} result.professional_skills.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.professional_skills.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.professional_skills.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.professional_skills.rule 统计规则
 * @apiSuccess {Object[]} result.professional_skills.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.professional_skills.data 统计数据
 * @apiSuccess {String} result.professional_skills.data.legend 图例
 * @apiSuccess {Object} result.professional_skills.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"professional_skills": {
 *          "dimension": [{
 *              "id": 17,
 *              "name": "灵活度",
 *              "selected": true
 *          }, {
 *              "id": 18,
 *              "name": "负责度",
 *              "selected": true
 *          }, {
 *              "id": 19,
 *              "name": "工作标准",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 21,
 *              "name": "明确性",
 *              "selected": true
 *          }, {
 *              "id": 22,
 *              "name": "团队承诺",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) ProfessionalSkills(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.ProfessionalSkills(sess.CompanyID, req.ProjectID, req.StaffID)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/potential 员工详情-I05-潜力
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-潜力
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI06MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object[]} result.potential 员工潜力关键项列表
 * @apiSuccess {String} result.potential.id 潜力项目 id
 * @apiSuccess {String} result.potential.name 潜力项目名称
 * @apiSuccess {String} result.potential.score 潜力项目得分
 * @apiSuccess {String} result.potential.total 潜力项目总分
 * @apiSuccess {String} result.potential.desc 潜力项目得分说明
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"potential": [{
 *			"id": 1,
 *			"name": "好奇心和优秀的自我学习能力",
 *			"score": 8,
 *			"total": 24,
 *			"desc": ""
 *		},
 *		{
 *			"id": 11,
 *			"name": "跨领域的思考能力",
 *			"score": 23,
 *			"total": 24,
 *			"desc": ""
 *		}]
 *   }
 *
 */
func (v *StaffsView) Potential(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.Potential(sess.CompanyID, req.ProjectID, req.StaffID)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/emotional_intelligence 员工详情-I08-情绪智力
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-情绪智力
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工情绪智力结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) EmotionalIntelligence(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.EmotionalIntelligence)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/critical_thinking 员工详情-I09-批判思维
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-批判思维
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工批判思维结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) CriticalThinking(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.CriticalThinking)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/practical_intelligence 员工详情-I10-管理实践能力
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-管理实践能力
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工管理实践能力结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) PracticalIntelligence(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.PracticalIntelligence)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/occupational_personality 员工详情-I11-职业人格
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-职业人格
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工职业人格结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) OccupationalPersonality(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.OccupationalPersonality)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/personality_disorder 员工详情-I12-性格风险
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-性格风险
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工性格风险结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) PersonalityDisorder(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.PersonalityDisorder)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/leadership_style 员工详情-I13-领导风格
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-领导风格
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工领导风格结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Number} result.data.dimension.score 统计的维度得分
 * @apiSuccess {String[]} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 * @apiSuccess {String[]} result.data.top_freq  频次最高的几项
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "命令型",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "教练型",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "支持型",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "授权型",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score", "freq"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [2,3,5,4],
 *						"freq": [3,4,5,2]
 *                  }
 *              }
 *          ],
 *          "top_freq": ["命令式", "教练式"]
 *      }
 *   }
 *
 */
func (v *StaffsView) LeadershipStyle(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.LeadershipStyle)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/org_commitment 员工详情-I14-组织忠诚度
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-组织忠诚度
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "staff_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.staff_id 员工 ID
 * @apiSuccess {Object} result.data 员工组织忠诚度结果
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *      "staff_id": 3,
 *		"data": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "xxx的得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "平均得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (v *StaffsView) OrgCommitment(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	sess := httpCtx.Ctx.Value("session").(*session.Session)
	results, err := stat.GetStaffInterviewData(sess.CompanyID, req.ProjectID, req.StaffID, req.ReportID, interview.OrgCommitment)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}

/**
 * @api {post} /staffs_view/inventory_switch_scene 员工详情-盘点分布 九宫格视角切换
 * @apiVersion 0.1.0
 * @apiGroup StaffView
 * @apiDescription 员工详情-盘点分布 九宫格视角切换
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} staff_id 员工 ID
 * @apiParam {Number} interview_id 测评视角ID
 *
 * @apiParamExample {json} Request-Example:
  {
       "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6N0=",
 	   "staff_id": 3,
 	   "project_id": 1,
 	   "interview_id": 1
  }
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object[]} result.grids 九宫格
 * @apiSuccess {Number} result.grid.record_at 年月
 * @apiSuccess {Number} result.grid.axis_x 分布位置坐标 x 轴
 * @apiSuccess {Number} result.grid.axis_y 分布位置坐标 y 轴
 * @apiSuccess {String} result.grid.name 分布位置名称
 * @apiSuccess {String} result.grid.project_id 九宫格所属项目
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"grids": [
			{
				"axis_x": 1,
				"axis_y": 1,
				"name": "明星员工初级"
				"record_at": 1565162520,
				"project_id": 823
			},
			{
				"axis_x": 2,
				"axis_y": 3,
				"name": "明星员工进阶",
				"record_at": 1557590400,
				"project_id": 824
			},
			{
				"axis_x": 3,
				"axis_y": 3,
				"name": "高级明星员工"
				"record_at": 1566354969,
				"project_id": 825
			}
		]
	}
*/
func (v *StaffsView) InventorySwitchScene(httpCtx *hfw.HTTPContext) {
	req := &StaffViewRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	if httpCtx.Ctx.Value("session") == nil {
		httpCtx.ThrowCheck(20304002, fmt.Errorf("nil session"))
	}
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	results, err := stat.InventorySwitchScene(httpCtx, sess.CompanyID, req.ProjectID, req.StaffID, req.InterviewID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = results
}
