package controllers

import (
    "encoding/json"
    "net/http"
    "net/http/httptest"
    "testing"

    qrt "github.com/Baozisoftware/qrcode-terminal-go"
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/interviews", &Interviews{})
}

/*
go test ./controllers -run TestInterviewQrcode -v
*/
func TestInterviewQrcode(t *testing.T) {
    url := "http://localhost:63333/interviews/qrcode?uuid=ff458af6-b722-330f-9040-c8742d2825b0"
    req := httptest.NewRequest(http.MethodGet, url, nil)
    req.Header.Set("X", "SUu5V7NPXQXzI8wCL95LYV9IkZdnzGfQ")

    w := httptest.NewRecorder()
    hfw.Router(w, req)

    t.Logf("%+v", w.Body)

    obj := qrt.New()
    obj.Get(w.Body.Bytes()).Print()
}

/*
go test ./controllers -run TestInterviewGet -v
*/
func TestInterviewGet(t *testing.T) {
    params := struct {
        Uuid        string          `json:"uuid"  validate:"required"`
        InterviewId int             `json:"interview_id"  validate:"required"`
        Param       json.RawMessage `json:"param"`
    }{
        Uuid:        "198942ab-551e-3fee-92e3-9ab3af576154",
        InterviewId: 1,
        Param:       nil,
    }

    rsp := test.Do(t, "/interviews/get", params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/interview/get res: <%s>", b)
}

/*
go test ./controllers -run TestInterviewCommit -v
*/
func TestInterviewCommit(t *testing.T) {
    params := struct {
        Uuid        string          `json:"uuid"  validate:"required"`
        InterviewId int             `json:"Interview_id"  validate:"required"`
        Param       json.RawMessage `json:"param"`
    }{
        Uuid:        "198942ab-551e-3fee-92e3-9ab3af576154",
        InterviewId: 1,
        Param:       nil,
    }

    rsp := test.Do(t, "/interviews/commit", params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/interview/get res: <%s>", b)
}

/*
go test ./controllers -run TestListStatffInterviews -v
*/
func TestListStatffInterviews(t *testing.T) {
    params := struct {
        Uuid        string          `json:"uuid"  validate:"required"`
        InterviewId int             `json:"Interview_id"  validate:"required"`
        Param       json.RawMessage `json:"param"`
    }{
        Uuid:        "198942ab-551e-3fee-92e3-9ab3af576154",
        InterviewId: 1,
        Param:       nil,
    }
    rsp := test.Do(t, "/interviews/list_statff_interviews", params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/interview/list_statff_interviews res: <%s>", b)
}

/*
go test ./controllers -run TestInterviewFeedBack -v
*/
func TestInterviewFeedBack(t *testing.T) {
    session, _ := GetSession()
    params := struct {
        *Session
        InterviewUuid
        Content string `json:"content"`
    }{
        Session: &Session{
            SessionID: session,
        },
        InterviewUuid: InterviewUuid{
            Uuid:        "198942ab-551e-3fee-92e3-9ab3af576154",
            InterviewId: 3,
            Param:       nil,
        },
        Content: "ok",
    }

    resp := test.Do(t, "/interviews/feedback", &params)
    t.Logf("/interviews/feedback res: <%+v>", resp)
    b, _ := resp.Results.MarshalJSON()
    t.Logf("/interviews/feedback res: <%+v>", b)
}
