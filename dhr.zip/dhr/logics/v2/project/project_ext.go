package v2_project

import (
    "fmt"
)

const ProjectNameLengthLimit = 20
const ProjectRemarkLengthLimit = 500

// 模块:业务名:公司ID:帐号ID project:draft:company_id:account_id
func genDraftProjectCacheKey(companyId, accountId int) string {
    return fmt.Sprintf("project:draft:%d:%d", companyId, accountId)
}
