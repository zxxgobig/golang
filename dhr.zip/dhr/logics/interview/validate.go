package interview

type KeyExprConfigs struct {
    ManageExpr   []int `json:"manage_expr"`
    BusinessExpr []int `json:"business_expr"`
}

// InterviewsConfigs 创建项目时候测评的传入参数
type InterviewsConfigs struct {
    WorkValues []int           `json:"work_values"`
    KeyExpr    *KeyExprConfigs `json:"key_expr"`
}

type Validater struct {
    InterviewConfigItemParams []*ConfigItemParam
    InterviewConfigs          *InterviewsConfigs
}

func (p *Validater) Validate() (err error) {
    return
}
