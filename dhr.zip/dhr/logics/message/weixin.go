package message

import (
    "encoding/json"

    mqKit "gitlab.ifchange.com/bot/commonkit/mq"
)

type WeixinNotifyData struct {
    UserId     int             `json:"user_id"`
    Url        string          `json:"url"`
    TemplateID string          `json:"template_id"`
    Data       json.RawMessage `json:"data"`
}

func SendWeixinNotify(mqPub mqKit.Pub, data WeixinNotifyData) (err error) {
    err = mqPub.Init("wechat")
    if err != nil {
        return
    }
    content, err := json.Marshal(data)
    if err != nil {
        return
    }
    message := &mqKit.Message{
        Content: content,
    }
    err = mqPub.Publish(message)
    if err != nil {
        return
    }
    return
}
