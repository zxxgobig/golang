package data_collect

import (
    "bytes"
    "fmt"
    "math"
    "runtime"
    "strconv"
    "time"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfwkit/config"

    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/commonkit/mq"
    "gitlab.ifchange.com/bot/commonkit/mq/sub"
    "gitlab.ifchange.com/bot/hfw/signal"
    "gitlab.ifchange.com/bot/logger"
)

var (
    signalContext    = signal.GetSignalContext()
    nsqCommitTopic   string
    nsqCommitChannel string
    nsqServers       []string
)

func init() {
    nsqCommitTopic = "dhr_staff.staff.status.3"
    nsqCommitChannel = "dhr_data_collect"
    nsqServers = config.GetServers().BotNsqLookupds
    if len(nsqServers) == 0 {
        panic("no nsqServers")
    }
}

func StaffDimission() {
    server(nsqCommitTopic, nsqCommitChannel)
}

func server(topic, channel string) error {
    defer recoverPanic()

    signalContext.WgAdd()
    defer signalContext.WgDone()

    cfg := map[string]interface{}{
        "max_attempts":          4,
        "default_requeue_delay": 60 * time.Second,
        "msg_timeout":           60 * time.Second,
        "lookupds_address":      nsqServers,
        "concurrency":           1,
    }
    sub, err := sub.New(mq.NSQ, func(log string) error {
        logger.Warnf("NSQ err,%v", log)
        return nil
    }, cfg)

    sub.Init(topic, channel)

    err = sub.Subscribe(func(msg *mq.Message) error {
        signalContext.WgAdd()
        defer signalContext.WgDone()
        startTime := time.Now()
        err := consume(msg.Content)
        if err != nil {
            logger.Debugf("data collect staff dimission consume error nsqAttempts:%d costTime:%s,err:%s,nsqContent:%s",
                msg.Attempts, time.Now().Sub(startTime), err, string(msg.Content))
            delayTime := math.Pow(2, float64(msg.Attempts))*30 + 60
            msg.Delay = time.Duration(delayTime) * time.Second
            return fmt.Errorf("%s consumer %s", topic, err)
        }
        logger.Infof("data collect staff dimission consume success nsqAttempts:%d costTime:%s,nsqContent:%s",
            msg.Attempts, time.Now().Sub(startTime), string(msg.Content))
        return nil
    })
    if err != nil {
        logger.Warnf("%s consumer %s", topic, err)
        return err
    }
    for {
        select {
        case <-signalContext.Ctx.Done():
            sub.Stop()
            logger.Warnf("server shutdown, stop data collect staff dimission consumer server")
            return nil
        }
    }
}

func consume(b []byte) error {
    logger.Debugf("data collect staff dimission consume content, staff id:%v", string(b))
    staffID, err := strconv.Atoi(string(b))
    if err != nil {
        return err
    }

    dao, err := db.NewXormDao(hfw.Config, hfw.Config.Db)
    dao.NewSession()
    defer dao.Close()

    err = dao.Begin()
    if err != nil {
        return err
    }

    // 相关采集计划人数减1
    txDataCollectPlanStaffs, err := models.NewDataCollectPlanStaffs(dao)
    if err != nil {
        return err
    }
    _, err = txDataCollectPlanStaffs.Update(db.Cond{
        "is_deleted": 1,
    }, db.Cond{
        "staff_id": staffID,
    })
    if err != nil {
        return err
    }

    // 盘点项目人数减1
    txProjectsStaffs, err := models.NewProjectsStaffs(dao)
    if err != nil {
        return err
    }

    projectsStaffs, err := txProjectsStaffs.Search(db.Cond{"is_deleted": 0, "staff_id": staffID})
    if err != nil {
        return err
    }
    if len(projectsStaffs) > 0 {
        var buf bytes.Buffer
        for _, v := range projectsStaffs {
            buf.WriteString(strconv.Itoa(v.ProjectId))
            buf.WriteString(",")
        }

        txProjects, err := models.NewProjects(dao)
        if err != nil {
            return err
        }
        _, err = txProjects.Exec("UPDATE `projects` SET `interview_users_count` = `interview_users_count` - 1 WHERE `id` IN (" + string(buf.Next(buf.Len()-1)) + ")")
        if err != nil {
            return err
        }
    }

    _, err = txProjectsStaffs.Update(db.Cond{
        "is_deleted": 1,
    }, db.Cond{
        "staff_id": staffID,
    })
    if err != nil {
        return err
    }

    staffsInterviewsModel, err := models.NewStaffsInterviews(dao)
    if err != nil {
        return err
    }
    _, err = staffsInterviewsModel.Update(db.Cond{
        "is_deleted": 1,
    }, db.Cond{
        "staff_id": staffID,
    })
    if err != nil {
        return err
    }

    staffsInterviewsDetailsModel, err := models.NewStaffsInterviewsDetails(dao)
    if err != nil {
        return err
    }
    _, err = staffsInterviewsDetailsModel.Update(db.Cond{
        "is_deleted": 1,
    }, db.Cond{
        "staff_id": staffID,
    })
    if err != nil {
        return err
    }
    err = dao.Commit()
    if err != nil {
        return err
    }

    return nil
}

func recoverPanic() {
    if err := recover(); err != nil {
        buf := make([]byte, 1<<20)
        num := runtime.Stack(buf, false)
        logger.Fatal(err, num, string(buf))
    }
}
