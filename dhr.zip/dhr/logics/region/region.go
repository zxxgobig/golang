package region

import (
	"encoding/json"
	"strings"

	"github.com/mozillazg/go-pinyin"
	"github.com/pkg/errors"
	"gitlab.ifchange.com/bot/hfw/redis"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
)

const PROVINCE2CITYKey = "Province2City"

type AllRegionInfos struct {
	Id       int64              `json:"id"`
	Name     string             `json:"name"`
	PinYin   string             `json:"pin_yin"`
	Children []*RegionBasicInfo `json:"children"`
}

type RegionBasicInfo struct {
	Id     int64  `json:"id"`
	Name   string `json:"name"`
	PinYin string `json:"pin_yin"`
}

func GetRegionInfos() (province2City []*AllRegionInfos, err error) {
	// 从redis中获取
	fromRedis, _ := redis.Get(PROVINCE2CITYKey)
	if str, ok := fromRedis.([]byte); ok {
		err = json.Unmarshal(str, &province2City)
		if err != nil {
			return nil, errors.Wrap(err, "type assert failed")
		}
		return
	}

	// 获取所有省份
	var infos []*RegionBasicInfo
	{
		p := api.NewPost("logic_region", "get_province")
		p.P = []int64{}
		infos = make([]*RegionBasicInfo, 0)
		err = api.SimpleCurl(nil, config.AppConfig.Custom["GSystemBasic"], p, &infos)
		if err != nil {
			return nil, errors.Wrap(err, "call gSystem province's failed")
		}
	}

	// 保存省份下的所有城市
	province2City = make([]*AllRegionInfos, 0)
	for _, each := range infos {
		type P struct {
			ProvinceId int64 `json:"province_id"`
		}
		_p := &P{
			ProvinceId: each.Id,
		}
		p := api.NewPost("logic_region", "get_city")
		p.P = _p
		children := make([]*RegionBasicInfo, 0)
		err = api.SimpleCurl(nil, config.AppConfig.Custom["GSystemBasic"], p, &children)
		if err != nil {
			return nil, errors.Wrap(err, "call gSystem city's failed")
		}

		for i := range children {
			children[i].PinYin = strings.Join(pinyin.LazyConvert(children[i].Name, nil), "")
		}

		province2City = append(province2City, &AllRegionInfos{
			Id:       each.Id,
			Name:     each.Name,
			PinYin:   strings.Join(pinyin.LazyConvert(each.Name, nil), ""),
			Children: children,
		})
	}

	// 保存redis
	data, _ := json.Marshal(province2City)
	_, err = redis.Set(PROVINCE2CITYKey, data)
	if err != nil {
		return nil, errors.Wrap(err, "redis set failed")
	}

	return
}
