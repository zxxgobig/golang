package data_collect

import (
	"encoding/json"
	"ifchange/dhr/models"
	"testing"

	"gitlab.ifchange.com/bot/hfw/db"
)

func TestDataCollectNoticeLogIsNotice(t *testing.T) {
	noticeLog := NewDataCollectNoticeLog()
	bool, err := noticeLog.TodayIsNotice(1)
	if err != nil {
		t.Logf("TestDataCollectNoticeLogIsNotice err: %v", err)
		return
	}
	t.Logf("TestDataCollectNoticeLogIsNotice success,IsNotice %v", bool)
}

func TestDataCollectNoticeLogSendEmail(t *testing.T) {
	noticeLog := NewDataCollectNoticeLog()
	noticeLog.NoticeMailWhenTiming()
}

func TestDataCollectNoticeLogOnceRemind(t *testing.T) {
	noticeLog := NewDataCollectNoticeLog()
	noticeLog.OnceRemind(2)
}

func TestDataCollectNoticeLogStartMail(t *testing.T) {
	mailDatas, err := GeneraGroupMailData(247, notice_type_invite, nil)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log("mail num is ", len(mailDatas))
	for _, data := range mailDatas {
		t.Logf("plan id %d", data.MailMetaData.planId)
	}
}

func TestDataCollectRemindSendMail(t *testing.T) {
	groupMailData, err := GeneraGroupMailData(247, notice_type_remind, nil)
	if err != nil {
		t.Fatal(err)
	}
	err = new(MailComponent).SendEmail(groupMailData)
	if err != nil {
		t.Fatal(err)
	}
	t.Log("TestDataCollectSendMail success")
}

func TestGetStaffById(t *testing.T) {
	var staffIDC = 3
	staffsInterviews, err := models.StaffsInterviewsModel.Search(db.Cond{
		"data_collect_id": 247,
		"interview_id":    3,
	})
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range staffsInterviews {
		for _, staffId := range v.StaffIds {
			if staffId == staffIDC {
				
			}
		}
	}
	s, _ := json.Marshal(staffsInterviews)
	t.Logf("TestGetStaffById success: %s", string(s))
}
