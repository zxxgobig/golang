package libraries

import (
    "strconv"
    "strings"
    "unicode/utf8"

    "gitlab.ifchange.com/bot/hfw/encoding"
)

func ContainNumber(a []int, x int) int {
    for i, n := range a {
        if x == n {
            return i
        }
    }
    return -1
}

func UniqueNumbers(input []int) []int {
    u := make([]int, 0, len(input))
    m := make(map[int]struct{}) // 空 struct 不占用内容空间

    for _, val := range input {
        if _, ok := m[val]; !ok {
            m[val] = struct{}{}
            u = append(u, val)
        }
    }
    return u
}

func IntListToStringList(ps []int) (result []string) {
    for _, p := range ps {
        result = append(result, strconv.Itoa(p))
    }
    return result
}

func StrLen(s string) int {
    return utf8.RuneCountInString(strings.TrimSpace(s))
}

func MustJSONMarshal(v interface{}) []byte {
    if v == nil {
        return nil
    }
    bytes, _ := encoding.JSON.Marshal(v)
    return bytes
}
