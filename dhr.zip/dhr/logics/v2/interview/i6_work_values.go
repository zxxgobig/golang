package v2_interview

import (
    "sort"

    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    WorkValuesRecommend struct {
        Name     string                        `json:"name"`
        Desc     string                        `json:"desc"`
        Index    int                           `json:"index"`
        IsAdvice bool                          `json:"is_advice"`
        IsMust   bool                          `json:"is_must"`
        IsEdit   bool                          `json:"is_edit"`
        MaxCheck int                           `json:"max_check"`
        SubItems []*WorkValuesRecommendSubItem `json:"sub_items"`
    }

    WorkValuesRecommendSubItem struct {
        Id          int    `json:"id"`
        Name        string `json:"name"`
        IsRecommend bool   `json:"is_recommend"`
    }
)

func ProcessWorkValuesRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *WorkValuesRecommend {
    interview, ok := interviewsM[kitinterview.WorkValues]
    if !ok {
        return nil
    }

    result := WorkValuesRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.WorkValues),
        IsAdvice: GetIsAdvice(kitinterview.WorkValues, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.WorkValues, sceneId, sceneTemplateId),
        IsEdit:   GetIsEdit(kitinterview.WorkValues),
        MaxCheck: GetMaxCheck(kitinterview.WorkValues),
        SubItems: nil,
    }

    parseSubItems := ParseSubItems(interview.Config)
    for _, item := range parseSubItems {
        result.SubItems = append(result.SubItems, &WorkValuesRecommendSubItem{
            Id:   item.Id,
            Name: item.Name,
        })
    }

    sort.Slice(result.SubItems, func(i, j int) bool {
        return result.SubItems[i].Id > result.SubItems[j].Id
    })

    return &result
}
