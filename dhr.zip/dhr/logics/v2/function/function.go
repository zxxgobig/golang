package v2_function

import (
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfwkit/common"

    "ifchange/dhr/models"
)

var FunctionLogic *Function

func init() {
    FunctionLogic = new(Function)
}

type (
    Function struct {
    }

    FunctionTree struct {
        *FunctionModel
        Children []*FunctionTree `json:"children"`
    }

    FunctionModel struct {
        *models.PositionFunctions
        IsDeleted common.Omitempty `json:"is_deleted,omitempty"`
        CreatedAt common.Omitempty `json:"created_at,omitempty"`
        UpdatedAt common.Omitempty `json:"updated_at,omitempty"`
    }
)

func (f *Function) ProjectCreateUsedList() (result *common.ListResult, err error) {
    functions, err := models.PositionFunctionsModel.Search(db.Cond{
        "is_deleted": 0,
        "depth in":   []int{1, 2},
        "orderby":    "id asc",
    })
    if err != nil {
        return nil, err
    }

    result = &common.ListResult{
        List: ConvertTree(ConvertFunctionModels(functions)),
    }

    return
}
