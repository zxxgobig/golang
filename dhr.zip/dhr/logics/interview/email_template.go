package interview

var (
    LeaderInviteContent = `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>邮件模板</title>
  </head>

  <body>
    <table
      width="600"
      align="center"
      cellspacing="0"
      cellpadding="0"
      style='border-collapse: collapse;font-size: 16px; color: #333;font-family:"PingFang SC","sans-serif";background: #ffffff;'
    >
      <tr>
        <td
          style="font-size:30px;color:#000000;text-align:center;letter-spacing: 0px;padding-top: 60px;padding-bottom: 60px;"
        >
          <!-- <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 0px;margin-bottom: 10px;"
          ></p> -->
          <p style="display:inline-table;margin: 0px;">{{.ProjectName}}    
          </p>
          <p style="display:inline-table;margin: 0px;">员工专业知识技能评价邀请函     
            </p>
          <!-- <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 22px;margin-right: 0px;margin-bottom: 10px;"
          ></p> -->
        </td>
      </tr>
      <tr>
        <td
          valign="middle"
          style="font-size: 20px;line-height: 20px;padding-bottom: 45px;"
        >
        亲爱的 {{.StaffName}}，您好：
        </td>
      </tr>
      <tr>
        <td
          style="padding-bottom:20px;font-size: 14px;color: #000000;line-height: 24px;"
        >
        您的下属已被邀请参加{{.ProjectName}}。为实现对他们的准确全面评估，需要您基于日常工作中的观察，对下属员工的专业知识技能提供评价。您的评价对于您下属员工的自我提升与发展将起到重要作用。

        </td>
      </tr>
      <tr>
        <td
          style="padding-bottom:20px;font-size: 14px;color: #000000;"
        >
        请在{{.PlanEndTime}}之前完成评价，谢谢。


        </td>
      </tr>
      <tr>
          <td
            style="padding-bottom:10px;font-size: 14px;color: #666;"
          >
            <p>链接地址：<a href="{{.Address}}">{{.Address}}</a></p>   
          </td>
        </tr>
      

        
     <tr>
        <td
          style="padding-bottom:40px;font-size: 14px;color: #000000;"
        >
          <p>请注意：</p>
            <p>您可以选择一次完成所有员工的评价，也可以分批次完成员工的评价
              </p>
            <p> 进行评价时，请找一个安静、不受打扰的环境
              </p>
            <p>进行评价期间请保持您的网络环境稳定
              </p>
           
        </td>
      </tr>
      <tr>
        <td style="padding-top: 60px;">
          <p
            style="font-size: 12px;color: #999999;text-align: center;line-height: 12px;border-top: 1px #EEEEEE solid;padding-top: 10px;padding-bottom: 0px;margin: 0px;"
          >
            义橙网络科技(上海)有限公司 Copyright © 2012 - 2020沪ICP备12043691号-1 沪公网安备 31010102002040 号
            Reserved
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>`

    LeaderRemindContent = `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>邮件模板</title>
  </head>

  <body>
    <table
      width="600"
      align="center"
      cellspacing="0"
      cellpadding="0"
      style='border-collapse: collapse;font-size: 16px; color: #333;font-family:"PingFang SC","sans-serif";background: #ffffff;'
    >
      <tr>
        <td
          style="font-size:30px;color:#000000;text-align:center;letter-spacing: 0px;padding-top: 60px;padding-bottom: 60px;"
        >
          <!-- <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 0px;margin-bottom: 10px;"
          ></p> -->
          <p style="display:inline-table;margin: 0px;">{{.ProjectName}}    
          </p>
          <p style="display:inline-table;margin: 0px;">员工专业知识技能评价提醒函     
            </p>
          <!-- <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 22px;margin-right: 0px;margin-bottom: 10px;"
          ></p> -->
        </td>
      </tr>
      <tr>
        <td
          valign="middle"
          style="font-size: 20px;line-height: 20px;padding-bottom: 45px;"
        >
        亲爱的 {{.StaffName}}，您好：
        </td>
      </tr>
      <tr>
        <td
          style="padding-bottom:20px;font-size: 14px;color: #000000;line-height: 24px;"
        >
        您的下属已被邀请参加{{.ProjectName}}。为实现对他们的准确全面评估，需要您基于日常工作中的观察，对下属员工的专业知识技能提供评价。您的评价对于您下属员工的自我提升与发展将起到重要作用。

        </td>
      </tr>
      <tr>
        <td
          style="padding-bottom:20px;font-size: 14px;color: #000000;"
        >
        您尚未完成全部下属员工的评价，请在{{.PlanEndTime}}之前完成，谢谢。



        </td>
      </tr>
      <tr>
          <td
            style="padding-bottom:10px;font-size: 14px;color: #666;"
          >
            <p>链接地址：<a href="{{.Address}}">{{.Address}}</a></p>   
          </td>
        </tr>
     
     <tr>
        <td
          style="padding-bottom:40px;font-size: 14px;color: #000000;"
        >
          <p>请注意：</p>
            <p>您可以选择一次完成所有员工的评价，也可以分批次完成员工的评价
              </p>
            <p> 进行评价时，请找一个安静、不受打扰的环境
              </p>
            <p>进行评价期间请保持您的网络环境稳定
              </p>
           
        </td>
      </tr>
      <tr>
        <td style="padding-top: 60px;">
          <p
            style="font-size: 12px;color: #999999;text-align: center;line-height: 12px;border-top: 1px #EEEEEE solid;padding-top: 10px;padding-bottom: 0px;margin: 0px;"
          >
            义橙网络科技(上海)有限公司 Copyright © 2012 - 2020沪ICP备12043691号-1 沪公网安备 31010102002040 号
            Reserved
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>`

    EmployeeInviteContent = `<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>邮件模板</title>
</head>

<body>
  <table width="600" align="center" cellspacing="0" cellpadding="0"
    style='border-collapse: collapse;font-size: 16px; color: #333;font-family:"PingFang SC","sans-serif";background: #ffffff;'>
    <tr>
      <td
        style="font-size:30px;color:#000000;text-align:center;letter-spacing: 0px;padding-top: 50px;padding-bottom: 60px;">
        <p
          style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 0px;margin-bottom: 10px;">
        </p>
        <p style="display:inline-table;margin: 0px;">测评邀请
          <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 22px;margin-right: 0px;margin-bottom: 10px;">
          </p>
      </td>
    </tr>
    <tr>
      <td valign="middle" style="font-size: 20px;line-height: 20px;padding-bottom: 15px;color: #111;">
        {{.StaffName}}，你好：
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;">
        特邀你参加「{{.ProjectName}}」测评项目，测评结果将作为人才盘点结果的重要依据，请在有效时间内尽快完成，谢谢！
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #2775FF;padding-bottom: 30px;">
        有效时间：{{.PlanStartTime}}～{{.PlanEndTime}}
      </td>
    </tr>

    <tr>
      <td style="font-size: 16px;color: #111;line-height: 24px;font-weight: 600;padding-bottom: 12px;">
        测评内容包含两部分
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;font-weight:500;">
        1.测评平台
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 24px;">
        请使用微信扫描以下二维码进入小程序测评
      </td>
    </tr>
    <tr>
      <td style="text-align: center;">
        <p style="margin-top:15px;margin-bottom:30px;width:180px;height:180px;display: inline-block;box-shadow:rgba(0,0,0,0.06);
               border-radius: 4px;">
          <img style="margin-top:20px;width:180px;height:180px;border:1px solid #eee;"
            src="{QrCodeImg}" alt=""
            title="rr"></img>
        </p>
      </td>
    </tr>
    <tr>
      <td style="text-align: center;font-size:16px;color:#111">微信扫描二维码，开始测评</td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;line-height: 24px;text-align: center;">
        若二维码无法显示，<a style="color:#2775FF;text-decoration: none;" href="{{.QrCodeJumpLink}}" target="_blank">请点击这里</a> , 然后使用微信扫描链接中的二维码
      </td>
    </tr>

    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;font-weight:500;padding-top: 25px;">
        2. 性格测评
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 20px;">
        请点击按钮或链接进入测评
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 20px;">
        <a style="color:#2775FF"
           target="_blank"
           href="{{.Address}}">{{.Address}}</a>
      </td>
    </tr>

    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 20px;">
        <a href="{{.Address}}"
        target="_blank"
        style="width:124px;
        margin-top: 20px;
        height:34px;
        display: block;
        background:rgba(39,117,255,1);
        text-decoration: none;
        border-radius:17px;color:#fff;font-size: 14px;line-height: 34px;text-align: center;">开始性格测评</a>
      </td>
    </tr>
    <tr>
      <td style="padding-top: 60px;">
        <p
          style="font-size: 12px;color: #999999;text-align: center;line-height: 12px;border-top: 1px #EEEEEE solid;padding-top: 20px;padding-bottom: 0px;margin: 0px;">
          义橙网络科技(上海)有限公司 Copyright © 2012 - 2020沪ICP备12043691号-1 沪公网安备 31010102002040 号
        </p>
      </td>
    </tr>
  </table>
</body>

</html>`

    EmployeeRemindContent = `<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>邮件模板</title>
</head>

<body>
  <table width="600" align="center" cellspacing="0" cellpadding="0"
    style='border-collapse: collapse;font-size: 16px; color: #333;font-family:"PingFang SC","sans-serif";background: #ffffff;'>
    <tr>
      <td
        style="font-size:30px;color:#000000;text-align:center;letter-spacing: 0px;padding-top: 50px;padding-bottom: 60px;">
        <p
          style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 0px;margin-bottom: 10px;">
        </p>
        <p style="display:inline-table;margin: 0px;">测评提醒
          <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 22px;margin-right: 0px;margin-bottom: 10px;">
          </p>
      </td>
    </tr>
    <tr>
      <td valign="middle" style="font-size: 20px;line-height: 20px;padding-bottom: 15px;color: #111;">
        {{.StaffName}}，你好：
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;">
        你目前尚未完成「{{.ProjectName}}」项目的全部测评，测评结果将作为人才盘点结果的重要依据，请在有效时间内尽快完成，谢谢！
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #2775FF;padding-bottom: 30px;">
        有效时间：{{.PlanStartTime}}～{{.PlanEndTime}}
      </td>
    </tr>

    <tr>
      <td style="font-size: 16px;color: #111;line-height: 24px;font-weight: 600;padding-bottom: 12px;">
        测评内容包含两部分
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;font-weight:500;">
        1.测评平台
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 24px;">
        请使用微信扫描以下二维码进入小程序测评
      </td>
    </tr>
    <tr>
      <td style="text-align: center;">
        <p style="margin-top:15px;margin-bottom:30px;width:180px;height:180px;display: inline-block;box-shadow:rgba(0,0,0,0.06);
               border-radius: 4px;">
          <img style="margin-top:20px;width:180px;height:180px;border:1px solid #eee;"
            src="{QrCodeImg}" alt=""
            title="rr"></img>
        </p>
      </td>
    </tr>
    <tr>
      <td style="text-align: center;font-size:16px;color:#111">微信扫描二维码，开始测评</td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;line-height: 24px;text-align: center;">
        若二维码无法显示，<a style="color:#2775FF;text-decoration: none;" target="_blank" href="{{.QrCodeJumpLink}}">请点击这里</a> , 然后使用微信扫描链接中的二维码
      </td>
    </tr>

    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;font-weight:500;padding-top: 25px;">
        2. 性格测评
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 20px;">
        请点击按钮或链接进入测评
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 20px;">
        <a style="color:#2775FF"
           target="_blank"
          href="{{.Address}}">{{.Address}}</a>
      </td>
    </tr>

    <tr>
      <td style="font-size: 12px;color: #666;padding-left:10px;line-height: 20px;">
        <a href="{{.Address}}"
        target="_blank"
        style="width:124px;
        margin-top: 20px;
        height:34px;
        display: block;
        background:rgba(39,117,255,1);
        text-decoration: none;
        border-radius:17px;color:#fff;font-size: 14px;line-height: 34px;text-align: center;">开始性格测评</a>
      </td>
    </tr>
    <tr>
      <td style="padding-top: 60px;">
        <p
          style="font-size: 12px;color: #999999;text-align: center;line-height: 12px;border-top: 1px #EEEEEE solid;padding-top: 20px;padding-bottom: 0px;margin: 0px;">
          义橙网络科技(上海)有限公司 Copyright © 2012 - 2020沪ICP备12043691号-1 沪公网安备 31010102002040 号
        </p>
      </td>
    </tr>
  </table>
</body>

</html>`

    EmployeeInviteNoNormstarContent = `<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>邮件模板</title>
</head>

<body>
  <table width="600" align="center" cellspacing="0" cellpadding="0"
    style='border-collapse: collapse;font-size: 16px; color: #333;font-family:"PingFang SC","sans-serif";background: #ffffff;'>
    <tr>
      <td
        style="font-size:30px;color:#000000;text-align:center;letter-spacing: 0px;padding-top: 50px;padding-bottom: 60px;">
        <p
          style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 0px;margin-bottom: 10px;">
        </p>
        <p style="display:inline-table;margin: 0px;">测评邀请
          <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 22px;margin-right: 0px;margin-bottom: 10px;">
          </p>
      </td>
    </tr>
    <tr>
      <td valign="middle" style="font-size: 20px;line-height: 20px;padding-bottom: 15px;color: #111;">
        {{.StaffName}}，你好：
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;">
        特邀你参加「{{.ProjectName}}」测评项目，测评结果将作为人才盘点结果的重要依据，请在有效时间内尽快完成，谢谢！
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #2775FF;padding-bottom: 30px;">
        有效时间：{{.PlanStartTime}}～{{.PlanEndTime}}
      </td>
    </tr>

    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;font-weight:500;">
        测评平台
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;line-height: 24px;">
        请使用微信扫描以下二维码进入小程序测评
      </td>
    </tr>
    <tr>
      <td style="text-align: center;">
        <p style="margin-top:15px;margin-bottom:30px;width:180px;height:180px;border:1px solid #eee;display: inline-block;box-shadow:rgba(0,0,0,0.06);
               border-radius: 4px;">
          <img style="margin-top:20px;width:180px;height:180px;"
            src="{QrCodeImg}" alt=""
            title="rr"></img>
        </p>
      </td>
    </tr>
    <tr>
      <td style="text-align: center;font-size:16px;color:#111">微信扫描二维码，开始测评</td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;line-height: 24px;text-align: center;">
        若二维码无法显示，<a style="color:#2775FF;text-decoration: none;" target="_blank" href="{{.QrCodeJumpLink}}">请点击这里</a> , 然后使用微信扫描链接中的二维码
      </td>
    </tr>

    <tr>
      <td style="padding-top: 60px;">
        <p
          style="font-size: 12px;color: #999999;text-align: center;line-height: 12px;border-top: 1px #EEEEEE solid;padding-top: 20px;padding-bottom: 0px;margin: 0px;">
          义橙网络科技(上海)有限公司 Copyright © 2012 - 2020沪ICP备12043691号-1 沪公网安备 31010102002040 号
        </p>
      </td>
    </tr>
    <tr>
    </tr>
  </table>
</body>

</html>`

    EmployeeRemindNoNormstarContent = `<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>邮件模板</title>
</head>

<body>
  <table width="600" align="center" cellspacing="0" cellpadding="0"
    style='border-collapse: collapse;font-size: 16px; color: #333;font-family:"PingFang SC","sans-serif";background: #ffffff;'>
    <tr>
      <td
        style="font-size:30px;color:#000000;text-align:center;letter-spacing: 0px;padding-top: 50px;padding-bottom: 60px;">
        <p
          style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 0px;margin-bottom: 10px;">
        </p>
        <p style="display:inline-table;margin: 0px;">测评提醒
          <p
            style="width:84px;height:1px;background:#DDDDDD;display: inline-table;margin-top: 10px;margin-left: 22px;margin-right: 0px;margin-bottom: 10px;">
          </p>
      </td>
    </tr>
    <tr>
      <td valign="middle" style="font-size: 20px;line-height: 20px;padding-bottom: 15px;color: #111;">
        {{.StaffName}}，你好：
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;">
        你目前尚未完成「{{.ProjectName}}」项目的全部测评，测评结果将作为人才盘点结果的重要依据，请在有效时间内尽快完成，谢谢！
      </td>
    </tr>
    <tr>
      <td style="font-size: 14px;color: #2775FF;padding-bottom: 30px;">
        有效时间：{{.PlanStartTime}}～{{.PlanEndTime}}
      </td>
    </tr>

    <tr>
      <td style="font-size: 14px;color: #111;line-height: 24px;font-weight:500;">
        测评平台
      </td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;line-height: 24px;">
        请使用微信扫描以下二维码进入小程序测评
      </td>
    </tr>
    <tr>
      <td style="text-align: center;">
        <p style="margin-top:15px;margin-bottom:30px;width:180px;height:180px;border:1px solid #eee;display: inline-block;box-shadow:rgba(0,0,0,0.06);
               border-radius: 4px;">
          <img style="margin-top:20px;width:180px;height:180px;"
            src="{QrCodeImg}" alt=""
            title="rr"></img>
        </p>
      </td>
    </tr>
    <tr>
      <td style="text-align: center;font-size:16px;color:#111">微信扫描二维码，开始测评</td>
    </tr>
    <tr>
      <td style="font-size: 12px;color: #666;line-height: 24px;text-align: center;">
        若二维码无法显示，<a style="color:#2775FF;text-decoration: none;" target="_blank" href="{{.QrCodeJumpLink}}">请点击这里</a> , 然后使用微信扫描链接中的二维码
      </td>
    </tr>

    <tr>
      <td style="padding-top: 60px;">
        <p
          style="font-size: 12px;color: #999999;text-align: center;line-height: 12px;border-top: 1px #EEEEEE solid;padding-top: 20px;padding-bottom: 0px;margin: 0px;">
          义橙网络科技(上海)有限公司 Copyright © 2012 - 2020沪ICP备12043691号-1 沪公网安备 31010102002040 号
        </p>
      </td>
    </tr>
  </table>
</body>

</html>`
)
