package v2_project

var ProjectLogic *Project

func init() {
    ProjectLogic = new(Project)
}

type (
    Project struct {
    }
)
