package controllers

import (
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/dhr/kit/session"

	"ifchange/dhr/core"
	v2_interview "ifchange/dhr/logics/v2/interview"
)

/**
 * @api {post} /v2_project/add_professional 测评相关 - 添加专业知识/技能
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 添加专业知识/技能
 *
 * @apiParam {String} session session
 * @apiParam {Number=3,4} interview_id 维度 ID（3：专业技能，4：专业知识）
 * @apiParam {String} name 维度名称
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "",
		"interview_id": 3,
		"name": "我是专业技能"
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object} results.id 专业知识/技能 ID
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"id": 1
	}
 *
*/
func (p *V2Project) AddProfessional(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		InterviewId int    `json:"interview_id" validate:"required"`
		Name        string `json:"name" validate:"required"`
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)

	result, err := v2_interview.InterviewLogic.AddProfessional(sess.CompanyID, params.InterviewId, params.Name)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/interview_recommend_list 测评相关 - 测评全维度列表与推荐
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 测评维度列表
 *
 * @apiParam {String} session session
 * @apiParam {Number} scene_id 场景 ID
 * @apiParam {Number} scene_template_id 场景 ID
 * @apiParam {Number} function_id 职能 ID
 * @apiParam {Number} level_id 层级 ID
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "",
		"scene_id": 1,
		"scene_template_id": 1,
		"function_id": 1,
		"level_id": 1
	}
 *
 * @apiSuccess {Object} results 返回结果

 * @apiSuccess {Object} results.bei 素质测评
 * @apiSuccess {String} results.bei.name 名称
 * @apiSuccess {String} results.bei.desc 描述
 * @apiSuccess {Number} results.bei.index 索引
 * @apiSuccess {Boolean} results.bei.is_advice 是否建议
 * @apiSuccess {Boolean} results.bei.is_must 是否必选
 * @apiSuccess {Boolean} results.bei.is_edit 是否可编辑
 * @apiSuccess {Number} results.bei.max_check 最大勾选数量
 * @apiSuccess {Object[]} results.bei.sub_items 子维度列表
 * @apiSuccess {Number} results.bei.sub_items.id 子维度 ID
 * @apiSuccess {String} results.bei.sub_items.name 子维度名称
 * @apiSuccess {String} results.bei.sub_items.desc 子维度描述
 * @apiSuccess {String} results.bei.sub_items.type_name 分类名称
 * @apiSuccess {String} results.bei.sub_items.initial_score 初始分数
 * @apiSuccess {Boolean} results.bei.sub_items.is_recommend 是否推荐
 * @apiSuccess {Number} results.bei.sub_items.recommend_score 子维度推荐分数
 * @apiSuccess {Object[]} results.bei.sub_items.scores 子维度分数列表
 * @apiSuccess {Number} results.bei.sub_items.scores.score 分数
 * @apiSuccess {String} results.bei.sub_items.scores.desc 描述

 * @apiSuccess {Object} results.personality 性格测评
 * @apiSuccess {String} results.personality.name 名称
 * @apiSuccess {String} results.personality.desc 描述
 * @apiSuccess {Number} results.personality.index 索引
 * @apiSuccess {Boolean} results.personality.is_advice 是否建议
 * @apiSuccess {Boolean} results.personality.is_must 是否必选

 * @apiSuccess {Object} results.skill 专业技能测评
 * @apiSuccess {String} results.skill.name 名称
 * @apiSuccess {String} results.skill.desc 描述
 * @apiSuccess {Number} results.skill.index 索引
 * @apiSuccess {Boolean} results.skill.is_advice 是否建议
 * @apiSuccess {Boolean} results.skill.is_must 是否必选
 * @apiSuccess {Boolean} results.skill.is_edit 是否可编辑
 * @apiSuccess {Number} results.skill.max_check 最大勾选数量
 * @apiSuccess {Object[]} results.skill.sub_items 子维度列表
 * @apiSuccess {Number} results.skill.sub_items.id 子维度 ID
 * @apiSuccess {String} results.skill.sub_items.name 子维度名称
 * @apiSuccess {Boolean} results.skill.sub_items.is_recommend 是否推荐

 * @apiSuccess {Object} results.knowledge 专业知识测评
 * @apiSuccess {String} results.knowledge.name 名称
 * @apiSuccess {String} results.knowledge.desc 描述
 * @apiSuccess {Number} results.knowledge.index 索引
 * @apiSuccess {Boolean} results.knowledge.is_advice 是否建议
 * @apiSuccess {Boolean} results.knowledge.is_must 是否必选
 * @apiSuccess {Boolean} results.knowledge.is_edit 是否可编辑
 * @apiSuccess {Number} results.knowledge.max_check 最大勾选数量
 * @apiSuccess {Object[]} results.knowledge.sub_items 子维度列表
 * @apiSuccess {Number} results.knowledge.sub_items.id 子维度 ID
 * @apiSuccess {String} results.knowledge.sub_items.name 子维度名称
 * @apiSuccess {Boolean} results.knowledge.sub_items.is_recommend 是否推荐

 * @apiSuccess {Object} results.potential 潜力测评
 * @apiSuccess {String} results.potential.name 名称
 * @apiSuccess {String} results.potential.desc 描述
 * @apiSuccess {Number} results.potential.index 索引
 * @apiSuccess {Boolean} results.potential.is_advice 是否建议
 * @apiSuccess {Boolean} results.potential.is_must 是否必选

 * @apiSuccess {Object} results.work_values 工作选择价值观测评
 * @apiSuccess {String} results.work_values.name 名称
 * @apiSuccess {String} results.work_values.desc 描述
 * @apiSuccess {Number} results.work_values.index 索引
 * @apiSuccess {Boolean} results.work_values.is_advice 是否建议
 * @apiSuccess {Boolean} results.work_values.is_must 是否必选
 * @apiSuccess {Boolean} results.work_values.is_edit 是否可编辑
 * @apiSuccess {Number} results.work_values.max_check 最大勾选数量
 * @apiSuccess {Object[]} results.work_values.sub_items 子维度列表
 * @apiSuccess {Number} results.work_values.sub_items.id 子维度 ID
 * @apiSuccess {String} results.work_values.sub_items.name 子维度名称
 * @apiSuccess {Boolean} results.work_values.sub_items.is_recommend 是否推荐

 * @apiSuccess {Object} results.key_expr 关键经历测评
 * @apiSuccess {String} results.key_expr.name 名称
 * @apiSuccess {String} results.key_expr.desc 描述
 * @apiSuccess {Number} results.key_expr.index 索引
 * @apiSuccess {Boolean} results.key_expr.is_advice 是否建议
 * @apiSuccess {Boolean} results.key_expr.is_must 是否必选
 * @apiSuccess {Boolean} results.key_expr.is_edit 是否可编辑
 * @apiSuccess {Number} results.key_expr.max_check 最大勾选数量
 * @apiSuccess {Object[]} results.key_expr.manage_expr 管理经历子维度列表
 * @apiSuccess {Number} results.key_expr.manage_expr.id 子维度 ID
 * @apiSuccess {String} results.key_expr.manage_expr.name 子维度名称
 * @apiSuccess {Boolean} results.key_expr.manage_expr.is_recommend 是否推荐
 * @apiSuccess {Object[]} results.key_expr.business_expr 业务经历子维度列表
 * @apiSuccess {Number} results.key_expr.business_expr.id 子维度 ID
 * @apiSuccess {String} results.key_expr.business_expr.name 子维度名称
 * @apiSuccess {Boolean} results.key_expr.business_expr.is_recommend 是否推荐

 * @apiSuccess {Object} results.emotional_intelligence 情绪智力测评
 * @apiSuccess {String} results.emotional_intelligence.name 名称
 * @apiSuccess {String} results.emotional_intelligence.desc 描述
 * @apiSuccess {Number} results.emotional_intelligence.index 索引
 * @apiSuccess {Boolean} results.emotional_intelligence.is_advice 是否建议
 * @apiSuccess {Boolean} results.emotional_intelligence.is_must 是否必选

 * @apiSuccess {Object} results.critical_thinking 批判思维测评
 * @apiSuccess {String} results.critical_thinking.name 名称
 * @apiSuccess {String} results.critical_thinking.desc 描述
 * @apiSuccess {Number} results.critical_thinking.index 索引
 * @apiSuccess {Boolean} results.critical_thinking.is_advice 是否建议
 * @apiSuccess {Boolean} results.critical_thinking.is_must 是否必选

 * @apiSuccess {Object} results.practical_intelligence 管理实践能力测评
 * @apiSuccess {String} results.practical_intelligence.name 名称
 * @apiSuccess {String} results.practical_intelligence.desc 描述
 * @apiSuccess {Number} results.practical_intelligence.index 索引
 * @apiSuccess {Boolean} results.practical_intelligence.is_advice 是否建议
 * @apiSuccess {Boolean} results.practical_intelligence.is_must 是否必选

 * @apiSuccess {Object} results.occupational_personality 职业人格测评
 * @apiSuccess {String} results.occupational_personality.name 名称
 * @apiSuccess {String} results.occupational_personality.desc 描述
 * @apiSuccess {Number} results.occupational_personality.index 索引
 * @apiSuccess {Boolean} results.occupational_personality.is_advice 是否建议
 * @apiSuccess {Boolean} results.occupational_personality.is_must 是否必选

 * @apiSuccess {Object} results.personality_disorder 性格风险测评
 * @apiSuccess {String} results.personality_disorder.name 名称
 * @apiSuccess {String} results.personality_disorder.desc 描述
 * @apiSuccess {Number} results.personality_disorder.index 索引
 * @apiSuccess {Boolean} results.personality_disorder.is_advice 是否建议
 * @apiSuccess {Boolean} results.personality_disorder.is_must 是否必选

 * @apiSuccess {Object} results.leadership_style 领导风格测评
 * @apiSuccess {String} results.leadership_style.name 名称
 * @apiSuccess {String} results.leadership_style.desc 描述
 * @apiSuccess {Number} results.leadership_style.index 索引
 * @apiSuccess {Boolean} results.leadership_style.is_advice 是否建议
 * @apiSuccess {Boolean} results.leadership_style.is_must 是否必选

 * @apiSuccess {Object} results.org_commitment 组织忠诚度测评
 * @apiSuccess {String} results.org_commitment.name 名称
 * @apiSuccess {String} results.org_commitment.desc 描述
 * @apiSuccess {Number} results.org_commitment.index 索引
 * @apiSuccess {Boolean} results.org_commitment.is_advice 是否建议
 * @apiSuccess {Boolean} results.org_commitment.is_must 是否必选
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"bei": {
			"name": "素质",
			"desc": "素质是驱动员工产生优秀工作绩效的各类特征的集合，它反映的是可以通过不同方式表现出来的员工的知识、技能、性格特质、价值观、内驱力等；<br>如：“战略思维”、“人际影响”、“团队协作”等",
			"index": 5,
			"is_advice": true,
			"is_must": false,
			"is_edit": false,
			"max_check": 0,
			"sub_items": [
				{
					"id": 48,
					"name": "营造客户文化",
					"desc": "让组织关注和发掘客户期望，并设法满足这些期望。",
					"type_name": "领导能力",
					"initial_score": 1,
					"is_recommend": false,
					"recommend_score": 0,
					"scores": [
						{
							"score": 1,
							"desc": "能够确保员工尊重并以正确的接待礼仪、标准与客户互动"
						},
						{
							"score": 2,
							"desc": "能够确保以满足客户需求的流程和体系实现对其意见的高效处理"
						},
						{
							"score": 3,
							"desc": "能够确保他人能基于客户需求的理解作出决策并提供附加价值"
						},
						{
							"score": 4,
							"desc": "能够鼓励员工深入理解客户需求，提供创新的产品或者服务"
						},
						{
							"score": 5,
							"desc": "能够激励员工与客户达成伙伴关系共同探索新的产品和服务"
						}
					]
				}
			]
		},
		"personality": {
			"name": "性格",
			"desc": "性格是个体对待现实世界的独特的、稳定的态度，以及与这种态度相应的行为模式中表现出的个性心理特征；<br>如：“坚忍不拔”、“客观”、“责任性”等",
			"index": 4,
			"is_advice": true,
			"is_must": false
		},
		"skill": {
			"name": "专业技能",
			"desc": "请在推荐的子维度中选择你认为最有用的三个作为盘点项；<br>专业技能是指为完成工作任务所需要掌握的工具操作能力、实践技巧、专业方法等；<br>如：“Java编程”、“财务分析”、“网页设计”",
			"index": 3,
			"is_advice": true,
			"is_must": true,
			"is_edit": true,
			"max_check": 3,
			"sub_items": [
				{
					"id": 527,
					"name": "我的技能",
					"is_recommend": false
				}
			]
		},
		"knowledge": {
			"name": "专业知识",
			"desc": "请在推荐的子维度中选择你认为最有用的三个作为盘点项；<br>专业知识是指为完成工作任务所需要知晓的事实、理论、概念、模型等；<br>如：“数理统计知识”，“经济学基本知识”，“公司产品知识”",
			"index": 2,
			"is_advice": true,
			"is_must": true,
			"is_edit": true,
			"max_check": 3,
			"sub_items": [
				{
					"id": 526,
					"name": "我的测试知识",
					"is_recommend": false
				}
			]
		},
		"potential": {
			"name": "潜力",
			"desc": "潜力是对于员工长期自我发展而言较为重要的核心特质和驱动力；<br>E成认为潜力最核心的四大方面包括：“敏锐学习能力”、“跨界思考能力”、“人际感知能力”和“情感管理能力”",
			"index": 1,
			"is_advice": true,
			"is_must": true
		},
		"work_values": {
			"name": "工作选择价值观",
			"desc": "工作选择价值观体现候选人在择业时的核心关注点，是人生目标在择业方面的具体表现。例如：”追求新意“，”自我实现“，”自由独立“等。",
			"index": 6,
			"is_advice": false,
			"is_must": false,
			"is_edit": false,
			"max_check": 2,
			"sub_items": [
				{
					"id": 11,
					"name": "追求新意",
					"is_recommend": false
				}
			]
		},
		"key_expr": {
			"name": "关键经历",
			"desc": "关键经历是指对于人才成长与发展产生重大作用的管理或业务经历，例如：”市场开拓“，”扭转业绩“，”海外经历“等",
			"index": 7,
			"is_advice": false,
			"is_must": false,
			"is_edit": false,
			"max_check": 5,
			"manage_expr": [
				{
					"id": 1,
					"name": "多经营单元负责人管理经历",
					"is_recommend": false
				}
			],
			"business_expr": [
				{
					"id": 8,
					"name": "组建团队",
					"is_recommend": false
				}
			]
		},
		"emotional_intelligence": {
			"name": "情绪智力",
			"desc": "基于Salove和Mayer情绪智力的概念，结合国内外相关研究成果而开发",
			"index": 8,
			"is_advice": true,
			"is_must": true
		},
		"critical_thinking": {
			"name": "批判思维",
			"desc": "从批判性思维的技能层面，测量对问题分析、推论、评估、解释的能力",
			"index": 9,
			"is_advice": true,
			"is_must": true
		},
		"practical_intelligence": {
			"name": "管理实践能力",
			"desc": "基于中国企业管理者的工作实践，对多种领导实践能力进行测评",
			"index": 10,
			"is_advice": true,
			"is_must": true
		},
		"occupational_personality": {
			"name": "职业人格",
			"desc": "以中国文化为背景，基于大五人格理论，全面衡量个体职业人格的特质",
			"index": 11,
			"is_advice": true,
			"is_must": true
		},
		"personality_disorder": {
			"name": "性格风险",
			"desc": "依据DSM-5人格障碍诊断标准而开发，可有效诊断个体心理风险因素",
			"index": 12,
			"is_advice": true,
			"is_must": true
		},
		"leadership_style": {
			"name": "领导风格",
			"desc": "依据情境领导理论，测量命令型、教练型、支持型、授权型四种领导风格",
			"index": 13,
			"is_advice": true,
			"is_must": true
		},
		"org_commitment": {
			"name": "组织忠诚度",
			"desc": "结合众多组织忠诚度研究成果而开发，测量个体的组织的承诺和忠诚度",
			"index": 14,
			"is_advice": true,
			"is_must": true
		}
	}
 *
*/
func (p *V2Project) InterviewRecommendList(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		*v2_interview.RecommendListParam
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)
	params.RecommendListParam.CompanyID = sess.CompanyID
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, params.Validate())

	result, err := v2_interview.InterviewLogic.RecommendList(params.RecommendListParam)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}

/**
 * @api {post} /v2_project/interview_subitem_list 测评相关 - 测评子维度列表
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 测评维度推荐列表
 *
 * @apiParam {String} session session
 * @apiParam {Number=3,4} [interview_id] 维度 ID（1：素质，2：性格，3：专业技能，4：专业知识，5：潜力，6：工作选择价值观，7：关键经历）
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "",
		"interview_id": 1
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object[]} results.list 列表
 * @apiSuccess {Number} results.list.id 子维度 ID
 * @apiSuccess {String} results.list.name 子维度名称
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"list": [
			{
				"id": 48,
				"name": "营造客户文化"
			},
			{
				"id": 46,
				"name": "组织变革"
			},
			{
				"id": 43,
				"name": "社会责任"
			}
		]
	}
 *
*/
func (p *V2Project) InterviewSubitemList(httpCtx *hfw.HTTPContext) {
	var params struct {
		*Session
		*v2_interview.SubitemListParam
	}
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
	sess := httpCtx.Ctx.Value("session").(*session.Session)
	params.CompanyId = sess.CompanyID
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, params.Validate())

	result, err := v2_interview.InterviewLogic.SubitemList(params.SubitemListParam)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = result
}
