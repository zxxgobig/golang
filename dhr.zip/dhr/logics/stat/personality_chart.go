package stat

type PersonalityMeasurement struct {
	Stack string                 `json:"stack"`
	Value []PersonalityStatValue `json:"value"`
}

type PersonalityStatValue struct {
	Num     int     `json:"num"`
	Percent float64 `json:"percent"`
}

type PersonalityData struct {
	Legend      string                   `json:"legend"`
	Measurement []PersonalityMeasurement `json:"measurement"`
}

type PersonalityResponseData struct {
	Dimension       D                  `json:"dimension"`
	ShowMeasurement []string           `json:"show_measurement"`
	Data            []*PersonalityData `json:"data"`
	Unit            map[string]string  `json:"unit"`
	Rule            string             `json:"rule"`
}

// D ..
type D []Dimension

func (d D) Len() int {
	return len(d)
}

func (d D) Less(i, j int) bool {
	return d[i].ID < d[j].ID
}

func (d D) Swap(i, j int) {
	d[i], d[j] = d[j], d[i]
}
