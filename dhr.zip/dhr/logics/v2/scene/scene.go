package v2_scene

import (
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfwkit/common"

    "ifchange/dhr/models"
)

var SceneLogic *Scene

func init() {
    SceneLogic = new(Scene)
}

type (
    Scene struct {
    }

    SceneModel struct {
        *models.ProjectsScenes
        Templates []*SceneTemplateModel `json:"templates"`
        IsDeleted common.Omitempty      `json:"is_deleted,omitempty"`
        CreatedAt common.Omitempty      `json:"created_at,omitempty"`
        UpdatedAt common.Omitempty      `json:"updated_at,omitempty"`
    }
)

func (f *Scene) ProjectCreateUsedList() (result *common.ListResult, err error) {
    scenes, err := models.ProjectsScenesModel.Search(db.Cond{
        "is_deleted": 0,
        "orderby":    "id asc",
    })
    if err != nil {
        return nil, err
    }

    sceneModels := ConvertSceneModels(scenes)

    scenesTemplates, err := models.ProjectsScenesTemplateModel.Search(db.Cond{
        "is_deleted": 0,
        "orderby":    "id asc",
    })
    if err != nil {
        return nil, err
    }

    sceneTemplateModels := ConvertSceneTemplateModels(scenesTemplates)

    for i, sceneModel := range sceneModels {
        for j, sceneTemplateModel := range sceneTemplateModels {
            if sceneModel.Id == sceneTemplateModel.SceneId {
                sceneModels[i].Templates = append(sceneModels[i].Templates, sceneTemplateModels[j])
            }
        }
    }

    result = &common.ListResult{
        List: sceneModels,
    }

    return
}
