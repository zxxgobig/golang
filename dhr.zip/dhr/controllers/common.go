package controllers

import (
	"context"
	"fmt"
	"ifchange/dhr/core"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/pkg/errors"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/logger"
	"gitlab.ifchange.com/dhr/kit/dhr_admin"
	"gitlab.ifchange.com/dhr/kit/session"
	"gopkg.in/go-playground/validator.v9"
)

var vd *validator.Validate

func init() {
	vd = validator.New()
}

type ListResult struct {
	Total int64       `json:"total"`
	List  interface{} `json:"list"`
}

func validate(req interface{}) (err error) {
	if err = vd.Struct(req); err != nil {
		if _, ok := err.(*validator.InvalidValidationError); ok {
			return errors.New("4998:InvalidValidationError")
		}

		var fields []string
		for _, errF := range err.(validator.ValidationErrors) {
			fields = append(fields, errF.Field())
		}
		return fmt.Errorf("4999:ValidationErrors: [%s]", strings.Join(fields, ","))
	}

	return
}

type SessionI interface {
	GetSessionID() string
}

type Session struct {
	SessionID string `json:"session"`
}

func (s *Session) GetSessionID() string {
	if s == nil {
		return ""
	}

	return s.SessionID
}

func VerifyRequestSession(httpCtx *hfw.HTTPContext, p SessionI) error {
	if len(p.GetSessionID()) <= 0 {
		err := api.RequestUnmarshal(httpCtx, p)
		if err != nil {
			return common.NewRespErr(20304001, err.Error())
		}
	}
	// 验证
	logger.Infof("config.GetServers().BotAccount:%v", config.GetServers().BotAccount)
	sess, err := session.VerifySession(session.ConstFromB, p.GetSessionID(), dhr_admin.GetSecretKey)
	if err != nil {
		return common.NewRespErr(20304002, err.Error())
	}

	httpCtx.Ctx = context.WithValue(httpCtx.Ctx, "session", sess)
	httpCtx.Ctx = context.WithValue(httpCtx.Ctx, "param", p)
	return nil
}

func GetCurUser(param interface{}) (user *User, err error) {
	_session, ok := param.(*session.Session)
	if !ok {
		return nil, fmt.Errorf("session not valid, please VerifyRequestSession")
	}

	user = &User{
		Id:             _session.UserID,
		CompanyId:      _session.CompanyID,
		From:           _session.From,
		RoleType:       _session.RoleType,
		DataPermission: _session.DataPermission,
		RoleIds:        _session.RoleIds,
	}

	logger.Infof("GetCurUser user: <%+v>", user)
	return user, nil
}

//  验证是否拥有产品
type User struct {
	Id             int
	CompanyId      int
	From           string `json:"from"`            // A B C
	SrcID          int    `json:"src_id"`          // 1-是普通用户 2-是其他
	RoleType       int    `json:"role_type"`       // 角色类型 1超级管理员 2普通管理员
	DataPermission int    `json:"data_permission"` // 是否拥有所有的数据权限 1有 2没有
	RoleIds        []int  `json:"role_ids"`
}

// a端用户
func (user *User) IsAdmin() bool {
	return user.From == "A"
}

// b端用户
func (user *User) IsManager() bool {
	return user.From == "B"
}

// b端是用户
func (user *User) IsUser() bool {
	return user.From == "C" && user.Id > 0
}

// 是访客
func (user *User) IsGuest() bool {
	return user.From == "C" && user.Id == 0
}

// ValidateAndUnMarshal 验证和初始化参数
func ValidateAndUnMarshal(httpCtx *hfw.HTTPContext, params SessionI) (curUser *User, err error) {
	err = api.RequestUnmarshal(httpCtx, &params)
	if err != nil {
		logger.Warn(err)
		return
	}
	err = VerifyRequestSession(httpCtx, params)
	if err != nil {
		logger.Warn(err)
		return
	}
	err = validate(params)
	if err != nil {
		logger.Warn(err)
		return
	}
	curUser, err = GetCurUser(httpCtx.Ctx.Value("session"))
	if err != nil {
		logger.Warn(err)
		return
	}
	return
}

func CountCnWord(str string) int {
	return utf8.RuneCountInString(str)
}

func GetSession() (string, error) {
	managerID := 84
	userID := 84
	return session.GenerateSession(session.ConstFromB, "", 1, managerID,
		userID, 1, time.Duration(24)*time.Hour*7, dhr_admin.GetSecretKey)
}

func CheckToken(req ProjectsReportRequest, httpCtx *hfw.HTTPContext) (companyID int, err error) {
	if req.Token == "" {
		// 验证session
		err = VerifyRequestSession(httpCtx, req)
		if err != nil {
			return
		}

		sess := httpCtx.Ctx.Value("session").(*session.Session)
		companyID = sess.CompanyID
	} else {
		if req.CompanyId == 0 {
			err = fmt.Errorf("company id can not be 0")
			logger.Infof("%v", err)
			return
		}
		//验证token
		if !core.IsValidToken(req.Token) {
			err = fmt.Errorf("invalid token %s", req.Token)
			return
		}
		companyID = req.CompanyId
	}

	return
}

func CheckToken2(req ProjectListParams, httpCtx *hfw.HTTPContext) (companyID int, err error) {
	if req.Token == "" {
		// 验证session
		err = VerifyRequestSession(httpCtx, req)
		if err != nil {
			return
		}

		sess := httpCtx.Ctx.Value("session").(*session.Session)
		companyID = sess.CompanyID
	} else {
		if req.CompanyID == 0 {
			err = fmt.Errorf("company id can not be 0")
			logger.Infof("%v", err)
			return
		}
		//验证token
		if !core.IsValidToken(req.Token) {
			err = fmt.Errorf("invalid token %s", req.Token)
			return
		}
		companyID = req.CompanyID
	}

	return
}
