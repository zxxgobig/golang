package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/position"

    "gitlab.ifchange.com/bot/hfwkit/api"

    "gitlab.ifchange.com/bot/hfw"
)

type PositionLevels struct {
    core.Controller
}

/**
 * @api {post} /position_levels/list 层级列表
 * @apiVersion 0.1.0
 * @apiGroup Position
 * @apiDescription 层级列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
 {
	"session":""
 }
 *
 * @apiSuccess {Number} results.id 结果id
 * @apiSuccess {Number} results.name 名称
 *
 * @apiSuccessExample {json} Response-Example:
 [
	{
		"id": 5,
		"name": "专业大学生/专员/初级",
		"is_deleted": 0,
		"updated_at": "1560999235",
		"created_at": "1560999235"
	}
 ]
 *
*/

func (c *PositionLevels) List(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        Page     int `json:"page"`
        PageSize int `json:"page_size"`
    }{}
    err := api.RequestUnmarshal(httpCtx, &param)
    httpCtx.ThrowCheck(20304001, err)
    result, total, err := position.NewPositionLevels().List(param.Page, param.PageSize)
    httpCtx.ThrowCheck(20304001, err)

    httpCtx.Results = ListResult{
        Total: total,
        List:  result,
    }
}
