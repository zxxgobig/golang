package v2_interview

import (
	"encoding/json"
	"fmt"

	hfwcommon "gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"

	"ifchange/dhr/core"
	"ifchange/dhr/models"

	kitadmin "gitlab.ifchange.com/bot/hfwkit/dhr_admin"
)

type (
	// RecommendListParam ..
	RecommendListParam struct {
		CompanyID       int `json:"-"`
		SceneID         int `json:"scene_id"`
		SceneTemplateID int `json:"scene_template_id"`
		FunctionID      int `json:"function_id"`
		LevelID         int `json:"level_id"`
	}

	// RecommendListResult ..
	RecommendListResult struct {
		Bei                     *BeiRecommend                     `json:"bei"`
		Personality             *PersonalityRecommend             `json:"personality"`
		Skill                   *SkillRecommend                   `json:"skill"`
		Knowledge               *KnowledgeRecommend               `json:"knowledge"`
		Potential               *PotentialRecommend               `json:"potential"`
		WorkValues              *WorkValuesRecommend              `json:"work_values"`
		KeyExpr                 *KeyExprRecommend                 `json:"key_expr"`
		EmotionalIntelligence   *EmotionalIntelligenceRecommend   `json:"emotional_intelligence"`
		CriticalThinking        *CriticalThinkingRecommend        `json:"critical_thinking"`
		PracticalIntelligence   *PracticalIntelligenceRecommend   `json:"practical_intelligence"`
		OccupationalPersonality *OccupationalPersonalityRecommend `json:"occupational_personality"`
		PersonalityDisorder     *PersonalityDisorderRecommend     `json:"personality_disorder"`
		LeadershipStyle         *LeadershipStyleRecommend         `json:"leadership_style"`
		OrgCommitment           *OrgCommitmentRecommend           `json:"org_commitment"`
	}
)

// RecommendList 测评全维度列表与推荐
func (i *Interview) RecommendList(params *RecommendListParam) (result *RecommendListResult, err error) {
	res, err := kitadmin.GetCompanyConfigs(params.CompanyID, "")
	if err != nil {
		return nil, err
	}
	companyConfigs := kitadmin.Result{}
	err = json.Unmarshal(*res, &companyConfigs)
	if err != nil {
		return nil, err
	}
	useNewBEIMode := false
	if companyConfigs.InterviewMode == kitadmin.MODENEWBEI {
		useNewBEIMode = true
	}

	cond := db.Cond{
		"is_deleted": 0,
		"orderby":    "id ASC",
	}

	interviews, err := models.InterviewsModel.Search(cond)
	if err != nil {
		return
	}
	if len(interviews) == 0 {
		return
	}

	interviewsM := ConvertInterviews2Map(interviews)

	// 获取专业知识/技能推荐
	professionalRecommends, _ := models.PositionFunctionSkillRecommendModel.Search(db.Cond{
		"is_deleted":  0,
		"function_id": params.FunctionID,
	})

	beiRecommend := ProcessBeiRecommend(params.SceneID, params.SceneTemplateID, params.FunctionID, params.LevelID, interviewsM)
	result = &RecommendListResult{
		// 素质
		Bei: beiRecommend,
		// 性格
		Personality: ProcessPersonalityRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
		// 专业技能
		Skill: ProcessSkillRecommend(params.CompanyID, params.SceneID, params.SceneTemplateID, interviewsM, professionalRecommends),
		// 专业知识
		Knowledge: ProcessKnowledgeRecommend(params.CompanyID, params.SceneID, params.SceneTemplateID, interviewsM, professionalRecommends),
		// 潜力
		Potential: ProcessPotentialRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
		// 工作选择价值观
		WorkValues: ProcessWorkValuesRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
		// 关键经历
		KeyExpr: ProcessKeyExprRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
		// 情绪智力
		EmotionalIntelligence: ProcessEmotionalIntelligenceRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
		// 批判思维(check new bei mode)
		CriticalThinking: ProcessCriticalThinkingRecommend(
			params.SceneID, params.SceneTemplateID,
			interviewsM, useNewBEIMode, beiRecommend,
		),
		// 管理实践能力(check new bei mode)
		PracticalIntelligence: ProcessPracticalIntelligenceRecommend(
			params.SceneID, params.SceneTemplateID,
			interviewsM, useNewBEIMode, beiRecommend,
		),
		// 职业人格(check new bei mode)
		OccupationalPersonality: ProcessOccupationalPersonalityRecommend(
			params.SceneID, params.SceneTemplateID,
			interviewsM, useNewBEIMode, beiRecommend,
		),
		// 性格风险
		PersonalityDisorder: ProcessPersonalityDisorderRecommend(
			params.SceneID, params.SceneTemplateID,
			interviewsM,
		),
		// 领导风格
		LeadershipStyle: ProcessLeadershipStyleRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
		// 组织忠诚度
		OrgCommitment: ProcessOrgCommitmentRecommend(params.SceneID, params.SceneTemplateID, interviewsM),
	}
	return
}

// Validate check sceneID、sceneTemplateID、functionID
func (c *RecommendListParam) Validate() error {
	if c.SceneID <= 0 {
		return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "sceneId must > 0")
	}
	if c.SceneTemplateID < 0 {
		return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "sceneId must >= 0")
	}
	if c.FunctionID <= 0 {
		return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "functionId must > 0")
	}
	if c.LevelID <= 0 {
		return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "levelId must > 0")
	}
	// 校验项目模版 ID 是否存在
	if c.SceneTemplateID > 0 {
		projectsScenesTemplate, err := models.ProjectsScenesTemplateModel.SearchOne(db.Cond{
			"is_deleted": 0,
			"id":         c.SceneTemplateID,
		})
		if err != nil {
			return err
		}
		if projectsScenesTemplate == nil {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, fmt.Sprintf("get ProjectsScenesTemplate by sceneId is nil, sceneId = [%d]", c.SceneTemplateID))
		}
		// 校验职能 ID、层级 ID 是否与项目模版中的匹配
		if c.FunctionID != projectsScenesTemplate.FunctionId ||
			c.LevelID != projectsScenesTemplate.LevelId {
			return hfwcommon.NewRespErr(core.InvalidParamsErrNo, "illegal industryId or functionId or levelId")
		}
	}
	return nil
}
