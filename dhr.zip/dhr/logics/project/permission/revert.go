package permission

import (
    "ifchange/dhr/libraries"
    "ifchange/dhr/models"

    "gitlab.ifchange.com/bot/hfw/db"
)

func RevertShareFrom(companyID, accountID, projectID int, accountIDList []int) error {
    _, err := models.ProjectsPermissionsModel.Update(db.Cond{
        "is_deleted": 1,
        "updated_by": accountID,
    }, db.Cond{
        "company_id":  companyID,
        "project_id":  projectID,
        "user_id in ": accountIDList,
    })

    return err
}

func CanRevertFrom(companyID, projectID int) (result []SimpleAccountInfo, err error) {
    accounts, err := libraries.GetUserListByCompanyID(companyID)
    if err != nil {
        return nil, err
    }

    perms, err := models.ProjectsPermissionsModel.Search(db.Cond{
        "company_id": companyID,
        "project_id": projectID,
        "is_deleted": 0,
    })
    if err != nil {
        return nil, err
    }

    result = make([]SimpleAccountInfo, 0)
    for _, p := range perms {
        // 过滤不存在的账号
        a, exist := accounts[p.UserId]
        if !exist {
            continue
        }
        result = append(result, SimpleAccountInfo{
            ID:    p.UserId,
            Name:  a.UserName,
            Email: a.LoginEmail,
        })
    }

    return result, nil
}
