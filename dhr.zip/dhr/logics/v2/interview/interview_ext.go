package v2_interview

import (
	hfwcommon "gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/encoding"
	kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

	"ifchange/dhr/core"
	v2_scene "ifchange/dhr/logics/v2/scene"
	"ifchange/dhr/models"
)

// List ..
func List() (interviews []*models.Interviews, err error) {
	interviews, err = models.InterviewsModel.Search(db.Cond{"is_deleted": 0})
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "exec models.PositionLevelsModel.GetById error")
		return
	}

	return
}

// ConvertInterviews ..
func ConvertInterviews(src []*models.Interviews) []*InterviewModel {
	if len(src) == 0 {
		return nil
	}

	dst := make([]*InterviewModel, 0, len(src))

	for _, v := range src {
		parseSubItems := ParseSubItems(v.Config)

		model := &InterviewModel{
			Interviews: v,
			SubItems:   parseSubItems,
		}

		dst = append(dst, model)
	}

	return dst
}

// ParseSubItems ..
func ParseSubItems(rawStr string) []*InterviewSubItem {
	var data []*InterviewSubItem
	err := encoding.JSON.Unmarshal([]byte(rawStr), &data)
	if err != nil {
		return nil
	}

	return data
}

// ConvertInterviews2Map ..
func ConvertInterviews2Map(src []*models.Interviews) map[kitinterview.Type]*models.Interviews {
	if len(src) == 0 {
		return nil
	}

	dst := make(map[kitinterview.Type]*models.Interviews)

	for _, v := range src {
		if _, ok := dst[kitinterview.Type(v.Id)]; !ok {
			dst[kitinterview.Type(v.Id)] = v
		}
	}

	return dst
}

// GetIndex 测评顺序
func GetIndex(interviewID kitinterview.Type) int {
	switch interviewID {
	case kitinterview.Bei:
		return 4
	case kitinterview.Personality:
		return 14
	case kitinterview.Skill:
		return 3
	case kitinterview.Knowledge:
		return 2
	case kitinterview.Potential:
		return 1
	case kitinterview.WorkValues:
		return 8
	case kitinterview.KeyExp:
		return 9
	case kitinterview.EmotionalIntelligence:
		return 10
	case kitinterview.CriticalThinking:
		return 5
	case kitinterview.PracticalIntelligence:
		return 6
	case kitinterview.OccupationalPersonality:
		return 7
	case kitinterview.PersonalityDisorder:
		return 11
	case kitinterview.LeadershipStyle:
		return 12
	case kitinterview.OrgCommitment:
		return 13
	}

	return -1
}

// GetIsAdvice 测评是否建议
func GetIsAdvice(interviewID kitinterview.Type, sceneTemplateID int) bool {
	switch interviewID {
	case kitinterview.Bei, kitinterview.OccupationalPersonality, kitinterview.PracticalIntelligence, kitinterview.CriticalThinking:
		return true
	case kitinterview.Skill, kitinterview.Knowledge, kitinterview.Potential:
		if sceneTemplateID == 0 {
			return true
		}
	case kitinterview.WorkValues, kitinterview.LeadershipStyle:
		if sceneTemplateID > 0 {
			return true
		}
	}

	return false
}

// GetIsMust 测评是否必选
func GetIsMust(interviewID kitinterview.Type, sceneID int, sceneTemplateID int) bool {
	switch interviewID {
	case kitinterview.Bei, kitinterview.Skill, kitinterview.Knowledge:
		if sceneTemplateID == 0 {
			return true
		}
	case kitinterview.Potential:
		if sceneID == v2_scene.Scene3 && sceneTemplateID == 0 {
			return true
		}
	}

	return false
}

// GetIsEdit 测评是否可以编辑子维度
func GetIsEdit(interviewID kitinterview.Type) bool {
	switch interviewID {
	case kitinterview.Skill, kitinterview.Knowledge:
		return true
	}

	return false
}

// GetMaxCheck 测评最大可勾选子维度数量 0表示不限制
func GetMaxCheck(interviewID kitinterview.Type) int {
	switch interviewID {
	case kitinterview.Bei:
		return 0
	case kitinterview.Skill:
		return 3
	case kitinterview.Knowledge:
		return 3
	case kitinterview.WorkValues:
		return 2
	case kitinterview.KeyExp:
		return 5
	}

	return -1
}
