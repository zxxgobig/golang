package algo

import (
    "encoding/json"
    "testing"
)

func TestPerformanceExtract(t *testing.T) {
    req := &PerformanceExtractRequest{}
    err := json.Unmarshal([]byte(requstData), req)
    if err != nil {
        t.Fatal(err)
    }

    response, err := PerformanceExtract(req)
    if err != nil {
        t.Fatal(err)
    }

    t.Logf("get: %+v", response)
}

var requstData = `{
    "performance_data":[
        {
            "staff_id":0,
            "level":"S",
            "standard_level":"高",
            "evaluation":"有上进心，勤奋努力。"
        },
        {
            "staff_id":1,
            "level":"A",
            "standard_level":"高",
            "evaluation":"工作态度积极热心，责任心比较强，在技术上需要有更多的提升。"
        },
        {
            "staff_id":2,
            "level":"B",
            "standard_level":"中",
            "evaluation":"工作能力没有问题，希望加强工作专注度"
        },
        {
            "staff_id":3,
            "level":"C",
            "standard_level":"低",
            "evaluation":"有一定的产品思维，能从用户角度思考合理性并优化代码"
        }
    ]
}`
