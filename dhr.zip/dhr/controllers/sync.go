package controllers

import (
	"fmt"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/curl"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"ifchange/dhr/core"
)

type Sync struct {
	core.Controller
}

type CompanyInfoParams struct {
	CompanyId   int    `json:"company_id"`
	CompanyName string `json:"company_name"`
}

func (v *Sync) CompanyInfo(httpCtx *hfw.HTTPContext) {
	req := &CompanyInfoParams{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)
	data, err := encoding.JSON.Marshal(req)
	httpCtx.ThrowCheck(20305000, err)
	url := "https://" + config.GetGrpcServers().DhrStaff.Address[0] + "/sync/company_info"
	pa := curl.Curl{
		Headers:   map[string]string{"X": "SUu5V7NPXQXzI8wCL95LYV9IkZdnzGfQ"},
		PostBytes: data,
		PostFields: map[string][]string{"CompanyId": []string{fmt.Sprintf("%d", req.CompanyId)},
			"CompanyName": []string{req.CompanyName}},
		Url:       url,
	}
	pa.SetMethod("POST")
	_, err = pa.Request()
	httpCtx.ThrowCheck(20305000, err)
}
