package data_collect

import (
	"fmt"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
)

type DataCollectPlanStaffsI interface {
	// //////////////////////////对内接口
	// 通过采集id获取采集总人数
	GetCollectPlanTotalCountByPlanId(planId int) (totalCount int64, err error)
	// 通过采集id获取采集完成人数
	GetCollectPlanCompletedCountByPlanId(planId int) (completedCount int64, err error)
	NoCompletedCountByProjectId(projectId int) (NoCompleteCount int, err error)
	CompletedCountByProjectId(projectId int) (CompleteCount int, err error)
	GetCollectPlanSkillCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanKnowledgeCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanBeiCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanPotentialCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanNormstarCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanKeyExprCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanWorkValuesCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanEmotionalIntelligenceCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanCriticalThinkingCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanPracticalIntelligenceCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanOccupationalPersonalityCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanPersonalityDisorderCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanLeadershipStyleCompletedCountByPlanId(planId int) (completedCount int64, err error)
	GetCollectPlanOrgCommitmentCompletedCountByPlanId(planId int) (completedCount int64, err error)
	NotCollectDimensionsByPlanId(planId int) (notCollectDimension map[string]bool, err error)
}

type DataCollectPlanStaffs struct {
}

func NewDataCollectPlanStaffs() DataCollectPlanStaffsI {
	return &DataCollectPlanStaffs{}
}

func (_ *DataCollectPlanStaffs) GetCollectPlanTotalCountByPlanId(planId int) (totalCount int64, err error) {
	// 此计划总人数
	totalCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return totalCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 计划完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"is_deleted": 0,
		// TODO logical problems roll back
		//"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
		//	"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (work_values = 2 or work_values = 3) " +
		//	"and (key_expr = 2 or key_expr = 3)")})
		"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
			"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (emotional_intelligence = 2 or emotional_intelligence = 3) " +
			"and (critical_thinking = 2 or critical_thinking = 3) and (practical_intelligence = 2 or practical_intelligence = 3) " +
			"and (occupational_personality = 2 or occupational_personality = 3) and (personality_disorder = 2 or personality_disorder = 3) " +
			"and (leadership_style = 2 or leadership_style = 3) and (org_commitment = 2 or org_commitment = 3) " +
			"and (work_values = 2 or work_values = 3) and (key_expr = 2 or key_expr = 3)")})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanSkillCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 技能完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"skill":      2,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanKnowledgeCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 知识完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"knowledge":  2,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanBeiCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 素质完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"bei":        2,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanPotentialCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 潜力完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"potential":  2,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanNormstarCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 性格完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"normstar":   2,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanKeyExprCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 关键经历完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":    planId,
		"key_expr":   2,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanWorkValuesCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 工作价值观完成人数
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":     planId,
		"work_values": 2,
		"is_deleted":  0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanEmotionalIntelligenceCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 情绪智力
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":                planId,
		"emotional_intelligence": 2,
		"is_deleted":             0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanCriticalThinkingCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 批判思维
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":           planId,
		"critical_thinking": 2,
		"is_deleted":        0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanPracticalIntelligenceCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 管理实践能力
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":                planId,
		"practical_intelligence": 2,
		"is_deleted":             0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanOccupationalPersonalityCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 职业人格
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":                  planId,
		"occupational_personality": 2,
		"is_deleted":               0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanPersonalityDisorderCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 性格风险
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":              planId,
		"personality_disorder": 2,
		"is_deleted":           0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanLeadershipStyleCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 领导风格
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":          planId,
		"leadership_style": 2,
		"is_deleted":       0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) GetCollectPlanOrgCommitmentCompletedCountByPlanId(planId int) (completedCount int64, err error) {
	// 组织忠诚度
	completedCount, err = models.DataCollectPlanStaffsModel.Count(db.Cond{
		"plan_id":        planId,
		"org_commitment": 2,
		"is_deleted":     0,
	})
	if err != nil {
		return -1, err
	}
	return completedCount, nil
}

func (_ *DataCollectPlanStaffs) NotCollectDimensionsByPlanId(planId int) (notCollectDimension map[string]bool, err error) {
	// 为什么是需要只找出一条员工数据，就可以判断此计划的某维度是否需要采集？
	// 因为现在只要项目中没有勾选某个维度，采集计划中所有待采集员工此维度都是不需要采集的
	planStaff, err := models.DataCollectPlanStaffsModel.SearchOne(db.Cond{
		"plan_id":    planId,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}
	if planStaff == nil {
		return nil, fmt.Errorf("IsNeedCollectByPlanId DataCollectPlanStaffsModel.SearchOne is null"+
			" by planId:%d", planId)
	}
	notCollectDimension = make(map[string]bool)
	// 不需要采集状态
	if planStaff.Bei == 3 {
		notCollectDimension["bei"] = true
	}
	if planStaff.Skill == 3 {
		notCollectDimension["skill"] = true
	}
	if planStaff.Normstar == 3 {
		notCollectDimension["normstar"] = true
	}
	if planStaff.Knowledge == 3 {
		notCollectDimension["knowledge"] = true
	}
	if planStaff.Potential == 3 {
		notCollectDimension["potential"] = true
	}
	if planStaff.EmotionalIntelligence == 3 {
		notCollectDimension["emotional_intelligence"] = true
	}
	if planStaff.CriticalThinking == 3 {
		notCollectDimension["critical_thinking"] = true
	}
	if planStaff.PracticalIntelligence == 3 {
		notCollectDimension["practical_intelligence"] = true
	}
	if planStaff.OccupationalPersonality == 3 {
		notCollectDimension["occupational_personality"] = true
	}
	if planStaff.PersonalityDisorder == 3 {
		notCollectDimension["personality_disorder"] = true
	}
	if planStaff.LeadershipStyle == 3 {
		notCollectDimension["leadership_style"] = true
	}
	if planStaff.OrgCommitment == 3 {
		notCollectDimension["org_commitment"] = true
	}
	// TODO logical problems roll back
	if planStaff.KeyExpr == 3 {
		notCollectDimension["key_expr"] = true
	}
	if planStaff.WorkValues == 3 {
		notCollectDimension["work_values"] = true
	}
	return notCollectDimension, nil
}

func (_ *DataCollectPlanStaffs) NoCompletedCountByProjectId(projectId int) (NoCompleteCount int, err error) {
	planL, err := models.DataCollectPlansModel.Search(db.Cond{
		"project_id": projectId,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	if len(planL) == 0 {
		return 0, nil
	}
	planIds := make([]int, 0)
	for _, plan := range planL {
		planIds = append(planIds, plan.Id)
	}

	completedStaffLMap := make(map[int]int)
	noCompletedStaffLMap := make(map[int]int)
	// 为什么要查出已经完成的？
	// 因为在一个项目中，可能出现某个员工两次采集计划，
	// 一次采集完成，一次采集没有完成情况，
	// 所以需要在查出所有未完成的数据中，再次去掉可能已经完成的数据
	completedStaffL, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"plan_id in": planIds,
		"is_deleted": 0,
		// TODO logical problems roll back
		//"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
		//	"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (work_values = 2 or work_values = 3) " +
		//	"and (key_expr = 2 or key_expr = 3)")})
		"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
			"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (emotional_intelligence = 2 or emotional_intelligence = 3) " +
			"and (critical_thinking = 2 or critical_thinking = 3) and (practical_intelligence = 2 or practical_intelligence = 3) " +
			"and (occupational_personality = 2 or occupational_personality = 3) and (personality_disorder = 2 or personality_disorder = 3) " +
			"and (leadership_style = 2 or leadership_style = 3) and (org_commitment = 2 or org_commitment = 3) " +
			"and (work_values = 2 or work_values = 3) and (key_expr = 2 or key_expr = 3)")})
	if err != nil {
		return -1, err
	}
	noCompletedStaffL, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"plan_id in": planIds,
		"is_deleted": 0,
		// TODO logical problems roll back
		//"where":      fmt.Sprint("skill = 1 or knowledge = 1 or bei = 1 or potential = 1 or normstar = 1 or work_values = 1 or key_expr = 1")})
		"where": fmt.Sprint("skill = 1 or knowledge = 1 or bei = 1 or potential = 1 or normstar = 1 or emotional_intelligence = 1 " +
			"or critical_thinking = 1 or practical_intelligence = 1 or occupational_personality = 1 or personality_disorder = 1 " +
			"or leadership_style = 1 or org_commitment = 1 or work_values = 1 or key_expr = 1")})
	if err != nil {
		return -1, err
	}

	// 所有完成采集的员工，去重
	for _, completedStaff := range completedStaffL {
		if _, ok := completedStaffLMap[completedStaff.StaffId]; !ok {
			completedStaffLMap[completedStaff.StaffId] = completedStaff.StaffId
		}
	}
	// 所有未完成采集的员工，去重
	for _, noCompletedStaff := range noCompletedStaffL {
		if _, ok := noCompletedStaffLMap[noCompletedStaff.StaffId]; !ok {
			noCompletedStaffLMap[noCompletedStaff.StaffId] = noCompletedStaff.StaffId
		}
	}
	// 从未完成的数据中剔除已完成的
	for k := range completedStaffLMap {
		for noK := range noCompletedStaffLMap {
			if k == noK {
				delete(noCompletedStaffLMap, k)
			}
		}
	}

	noCompleteCount := len(noCompletedStaffLMap)
	return noCompleteCount, nil
}

func (_ *DataCollectPlanStaffs) CompletedCountByProjectId(projectId int) (CompleteCount int, err error) {
	planL, err := models.DataCollectPlansModel.Search(db.Cond{
		"project_id": projectId,
		"is_deleted": 0,
	})
	if err != nil {
		return -1, err
	}
	if len(planL) == 0 {
		return 0, nil
	}
	planIds := make([]int, 0)
	for _, plan := range planL {
		planIds = append(planIds, plan.Id)
	}

	completedStaffL, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"plan_id in": planIds,
		"is_deleted": 0,
		// TODO logical problems roll back
		//"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
		//	"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (work_values = 2 or work_values = 3) " +
		//	"and (key_expr = 2 or key_expr = 3)")})
		"where": fmt.Sprint("(skill = 2 or skill = 3) and (knowledge = 2 or knowledge = 3) and (bei = 2 or bei = 3) " +
			"and (potential = 2 or potential = 3) and (normstar = 2 or normstar = 3) and (emotional_intelligence = 2 or emotional_intelligence = 3) " +
			"and (critical_thinking = 2 or critical_thinking = 3) and (practical_intelligence = 2 or practical_intelligence = 3) " +
			"and (occupational_personality = 2 or occupational_personality = 3) and (personality_disorder = 2 or personality_disorder = 3) " +
			"and (leadership_style = 2 or leadership_style = 3) and (org_commitment = 2 or org_commitment = 3) " +
			"and (work_values = 2 or work_values = 3) and (key_expr = 2 or key_expr = 3)")})
	if err != nil {
		return -1, err
	}

	completedStaffLMap := make(map[int]int)
	// 所有完成采集的员工，去重
	for _, completedStaff := range completedStaffL {
		if _, ok := completedStaffLMap[completedStaff.StaffId]; !ok {
			completedStaffLMap[completedStaff.StaffId] = completedStaff.StaffId
		}
	}
	return len(completedStaffLMap), nil
}
