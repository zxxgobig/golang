package interview_test

import (
    career_assessment_pb "gitlab.ifchange.com/bot/proto/career_assessment"
    "ifchange/dhr/logics/interview"
    "testing"
)

//func TestGetResult(t *testing.T) {
//    err := interview.GetResult(0, "dc0d2d5a-485b-34b1-8d03-24d0f2763db8")
//    if err != nil {
//        t.Error(err)
//    }
//
//}

func TestResultCommit(t *testing.T) {
    //so := &common.Score{
    //	DataGroupID: 1,
    //	EnName:      "active",
    //	Level:       2,
    //}
    //params := &common.CommitBeiParams{
    //	Scores: []*common.Score{so},
    //}
    params := []*career_assessment_pb.WorkValuesResults{
        &career_assessment_pb.WorkValuesResults{Id: 10, Values: "组织需要"},
        &career_assessment_pb.WorkValuesResults{Id: 7, Values: "身心健康"},
    }
    // s := `{"is_finished":1,"scores":[{"data_group_id":1,"en_name":"active","level":2}],"infos":[{"data_group_id":1,"title":"-","description":"-"}]}`
    err := interview.ResultCommit(6, "dc0d2d5a-485b-34b1-8d03-24d0f2763db8", params)
    if err != nil {
        t.Error(err)
    }
}
