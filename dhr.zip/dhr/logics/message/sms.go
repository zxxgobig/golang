package message

import (
    "encoding/json"

    mqKit "gitlab.ifchange.com/bot/commonkit/mq"
)

type SmsData struct {
    Phone   string `json:"phone"`
    Content string `json:"content"`
}

func SendSms(mqPub mqKit.Pub, data SmsData) (err error) {
    err = mqPub.Init("sms")
    if err != nil {
        return
    }
    content, err := json.Marshal(data)
    if err != nil {
        return
    }
    message := &mqKit.Message{
        Content: content,
    }
    err = mqPub.Publish(message)
    if err != nil {
        return
    }
    return
}
