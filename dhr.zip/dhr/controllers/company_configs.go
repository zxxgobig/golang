package controllers

import (
	"fmt"
	"ifchange/dhr/core"
	"ifchange/dhr/logics/company"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/dhr/kit/session"
)

type CompanyConfigs struct {
	core.Controller
}

/**
 * @api {post} /company_configs/set 设置企业配置信息
 * @apiVersion 1.0.0
 * @apiGroup CompanyConfigs
 * @apiDescription 设置企业配置信息
 *
 * @apiParam {String} session session信息
 * @apiParam {String} token 企业外部调用校验key
 * @apiParam {Number} verify_phone 1 c端需要验证, 2 c端不需要验证
 * @apiParam {Number} interview_mode 1: BEI+选择排序, 2: 素质能力, 3: 360, 4: BEI+选择排序+360测评, 5: 素质能力+360测评
 * @apiParam {Number} e_learns 公司开通的培训系统:use 2 byte configuration 00000000 00000001 = times glory 00000000 00000010 = ...

 * @apiParamExample {json} Request-Example:
   {
		"session": "",
		"token": "企业外部调用校验key",
		"verify_phone" 1,
		"interview_mode": 1
		"e_learns": 1,
   }
 * @apiSuccess {Object} results 返回结果
  {

  }
 *
*/
func (*CompanyConfigs) Set(httpCtx *hfw.HTTPContext) {
	params := &struct {
		ID            int    `json:"id"`
		Token         string `json:"token"`
		VerifyPhone   int    `json:"verify_phone"`
		InterviewMode int8   `json:"interview_mode"`
		ELearns       int16  `json:"e_learns"`
		*Session
	}{}
	err := api.RequestUnmarshal(httpCtx, &params)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	sess, ok := httpCtx.Ctx.Value("session").(*session.Session)
	if !ok {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("参数错误"))
	}
	httpCtx.ThrowCheck(20304001, err)
	err = company.Set(params.Token, params.VerifyPhone, sess.CompanyID, params.InterviewMode, params.ELearns)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = true
}

/**
 * @api {post} /company_configs/get 查询企业配置信息
 * @apiVersion 1.0.0
 * @apiGroup CompanyConfigs
 * @apiDescription 查询企业配置信息
 *
 * @apiParam {String} session session信息

 * @apiParamExample {json} Request-Example:
   {
		"session": "",
   }
 * @apiSuccess {Object} results 返回结果
  {
		"verify_phone": 1 (1 c端需要验证, 2 c端不需要验证)
  }
 *
*/
func (*CompanyConfigs) Get(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
	}{}
	err := api.RequestUnmarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	sess, ok := httpCtx.Ctx.Value("session").(*session.Session)
	if !ok {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("参数错误"))
	}
	res, err := company.Get(sess.CompanyID)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = map[string]int{
		"verify_phone": res.VerifyPhone,
	}
}
