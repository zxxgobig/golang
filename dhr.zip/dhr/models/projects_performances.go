package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var ProjectsPerformancesModel = &ProjectsPerformances{}

func init() {
	var err error
	ProjectsPerformancesModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	ProjectsPerformancesModel.Dao.EnableCache(ProjectsPerformancesModel)
	//ProjectsPerformancesModel.Dao.DisableCache(ProjectsPerformancesModel)
	//gob: type not registered for interface
	gob.Register(ProjectsPerformancesModel)
}

type ProjectsPerformances struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id            int       `json:"id" xorm:"not null pk autoincr INT(11)"`
	UploadId      int       `json:"upload_id" xorm:"not null default 0 comment('上传ID') INT(11)"`
	CompanyId     int       `json:"company_id" xorm:"not null default 0 comment('公司ID') unique(udx_company_id_staff_no_period) INT(11)"`
	UserId        int       `json:"user_id" xorm:"not null default 0 comment('账号ID') INT(11)"`
	StaffId       int       `json:"staff_id" xorm:"not null default 0 comment('员工ID') INT(11)"`
	StaffNo       string    `json:"staff_no" xorm:"not null default '' comment('工号') unique(udx_company_id_staff_no_period) VARCHAR(64)"`
	StaffName     string    `json:"staff_name" xorm:"not null default '' comment('员工名字') VARCHAR(32)"`
	Level         string    `json:"level" xorm:"not null default '' comment('绩效等级') VARCHAR(32)"`
	LevelStandard int       `json:"level_standard" xorm:"not null default 0 comment('标准级别（1：高，2：中，3：低）') INT(11)"`
	SelfEval      string    `json:"self_eval" xorm:"not null comment('自评') TEXT"`
	OthersEval1   string    `json:"others_eval1" xorm:"not null comment('他评1') TEXT"`
	OthersEval2   string    `json:"others_eval2" xorm:"not null comment('他评2') TEXT"`
	OthersEval3   string    `json:"others_eval3" xorm:"not null comment('他评3') TEXT"`
	OthersEval4   string    `json:"others_eval4" xorm:"not null comment('他评4') TEXT"`
	OthersEval5   string    `json:"others_eval5" xorm:"not null comment('他评5') TEXT"`
	Period        string    `json:"period" xorm:"not null default '' comment('目前为上传绩效月份') unique(udx_company_id_staff_no_period) VARCHAR(32)"`
	IsDeleted     int       `json:"is_deleted" xorm:"not null default 0 comment('1已经删除0未删除') TINYINT(1)"`
	UpdatedAt     time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated comment('更新时间') TIMESTAMP"`
	CreatedAt     time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created comment('创建时间') TIMESTAMP"`
}

func (m *ProjectsPerformances) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *ProjectsPerformances) GetUploadId() (val int) {
	if m == nil {
		return
	}
	return m.UploadId
}

func (m *ProjectsPerformances) GetCompanyId() (val int) {
	if m == nil {
		return
	}
	return m.CompanyId
}

func (m *ProjectsPerformances) GetUserId() (val int) {
	if m == nil {
		return
	}
	return m.UserId
}

func (m *ProjectsPerformances) GetStaffId() (val int) {
	if m == nil {
		return
	}
	return m.StaffId
}

func (m *ProjectsPerformances) GetStaffNo() (val string) {
	if m == nil {
		return
	}
	return m.StaffNo
}

func (m *ProjectsPerformances) GetStaffName() (val string) {
	if m == nil {
		return
	}
	return m.StaffName
}

func (m *ProjectsPerformances) GetLevel() (val string) {
	if m == nil {
		return
	}
	return m.Level
}

func (m *ProjectsPerformances) GetLevelStandard() (val int) {
	if m == nil {
		return
	}
	return m.LevelStandard
}

func (m *ProjectsPerformances) GetSelfEval() (val string) {
	if m == nil {
		return
	}
	return m.SelfEval
}

func (m *ProjectsPerformances) GetOthersEval1() (val string) {
	if m == nil {
		return
	}
	return m.OthersEval1
}

func (m *ProjectsPerformances) GetOthersEval2() (val string) {
	if m == nil {
		return
	}
	return m.OthersEval2
}

func (m *ProjectsPerformances) GetOthersEval3() (val string) {
	if m == nil {
		return
	}
	return m.OthersEval3
}

func (m *ProjectsPerformances) GetOthersEval4() (val string) {
	if m == nil {
		return
	}
	return m.OthersEval4
}

func (m *ProjectsPerformances) GetOthersEval5() (val string) {
	if m == nil {
		return
	}
	return m.OthersEval5
}

func (m *ProjectsPerformances) GetPeriod() (val string) {
	if m == nil {
		return
	}
	return m.Period
}

func (m *ProjectsPerformances) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *ProjectsPerformances) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *ProjectsPerformances) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *ProjectsPerformances) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *ProjectsPerformances) TableName() string {
	return "projects_performances"
}

func (m *ProjectsPerformances) Save(t ...*ProjectsPerformances) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsPerformances
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *ProjectsPerformances) Saves(t []*ProjectsPerformances) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *ProjectsPerformances) Insert(t ...*ProjectsPerformances) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *ProjectsPerformances
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *ProjectsPerformances) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *ProjectsPerformances) SearchOne(cond db.Cond) (t *ProjectsPerformances, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *ProjectsPerformances) Search(cond db.Cond) (t []*ProjectsPerformances, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *ProjectsPerformances) SearchAndCount(cond db.Cond) (t []*ProjectsPerformances, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *ProjectsPerformances) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *ProjectsPerformances) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *ProjectsPerformances) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *ProjectsPerformances) GetMulti(ids ...interface{}) (t []*ProjectsPerformances, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *ProjectsPerformances) GetByIds(ids ...interface{}) (t []*ProjectsPerformances, err error) {
	return m.GetMulti(ids...)
}

func (m *ProjectsPerformances) GetById(id interface{}) (t *ProjectsPerformances, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *ProjectsPerformances) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *ProjectsPerformances) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *ProjectsPerformances) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *ProjectsPerformances) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *ProjectsPerformances) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewProjectsPerformances(c ...interface{}) (m *ProjectsPerformances, err error) {
	m = &ProjectsPerformances{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *ProjectsPerformances) Close() {
	m.Dao.Close()
}

func (m *ProjectsPerformances) Begin() error {
	return m.Dao.Begin()
}

func (m *ProjectsPerformances) Rollback() error {
	return m.Dao.Rollback()
}

func (m *ProjectsPerformances) Commit() error {
	return m.Dao.Commit()
}
