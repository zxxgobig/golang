package controllers

import (
	"gitlab.ifchange.com/bot/hfw"
	"ifchange/dhr/core"
	"ifchange/dhr/logics/common"
)

type Update struct {
	core.Controller
}

func (_ *Update) Index(httpCtx *hfw.HTTPContext) {
	err := common.SelectStaffsInterviewDetails()
	httpCtx.ThrowCheck(core.SystemErrNo, err)
}
