package cron

import (
    "ifchange/dhr/logics/commit"
    "ifchange/dhr/logics/data_collect"
)

func init() {
    // about mq, consume email
    commit.ConsumerServer()
    // about mq, consume staff dimission of collect
    go data_collect.StaffDimission()
}
