package project

import (
	"encoding/base64"
	"fmt"
	"html"
	"ifchange/dhr/logics/utils"

	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	pb "gitlab.ifchange.com/bot/proto/dhr_staff/staff"

	"ifchange/dhr/models"
	"io/ioutil"
	"os"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/dfs"

	excel "github.com/360EntSecGroup-Skylar/excelize/v2"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

const (
	MaxRows          = 5000
	fixedRows        = 3
	ErrMessageColumn = 10
)

type UploadResult struct {
	UpdateCount int       `json:"update_count"`
	InsertCount int       `json:"insert_count"`
	FailedCount int       `json:"failed_count"`
	Mistakes    []Mistake `json:"mistakes"`
	Completion  float32   `json:"completion"`
	Url         string    `json:"url"`
	UploadID    int       `json:"upload_id"`
}
type ParseResult struct {
	Rows     []Row     `json:"rows"`
	Success  bool      `json:"success"`
	ErrMsg   string    `json:"err_msg"`
	Mistakes []Mistake `json:"mistakes"`
}
type Mistake struct {
	Site   string `json:"site"`
	Reason string `json:"reason"`
}
type Row struct {
	CompanyID     int    `json:"company_id"`
	UserID        int    `json:"user_id"`
	StaffID       int    `json:"staff_id"`
	StaffNO       string `json:"staff_no"`
	StaffName     string `json:"staff_name"`
	Level         string `json:"level"`
	LevelStandard int    `json:"level_standard"`
	SelfEval      string `json:"self_eval"`
	OthersEval1   string `json:"others_eval1"`
	OthersEval2   string `json:"others_eval2"`
	OthersEval3   string `json:"others_eval3"`
	OthersEval4   string `json:"others_eval4"`
	OthersEval5   string `json:"others_eval5"`
}

type LevelRes struct {
	Level []string `json:"level"`
}

type Upload struct {
	Filename string `json:"filename"`
}
type LevelRelationship struct {
	Level         string `json:"level"`
	LevelStandard int    `json:"level_standard"`
}

var excelMap = map[int]string{
	1:  "A",
	2:  "B",
	3:  "C",
	4:  "D",
	5:  "E",
	6:  "F",
	7:  "G",
	8:  "H",
	9:  "I",
	10: "J",
	11: "K",
	12: "L",
	13: "M",
	14: "N",
	15: "O",
	16: "P",
	17: "Q",
	18: "R",
	19: "S",
	20: "T",
	21: "U",
	22: "V",
	23: "W",
	24: "X",
	25: "Y",
	26: "Z",
}

// 项目上传总人数/未完成人数
func PerformStatffCount(projectId int) (PerformStaffCount, PerformStaffLackCount int, err error) {
	// 根据项目id拿到公司id和用户id --在project的表里查询
	data, err := models.ProjectsModel.SearchOne(db.Cond{"id": projectId, "is_deleted": 0})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return 0, 0, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}

	// 拿项目所有员工信息，查出对应人数
	staffList, err := models.ProjectsStaffsModel.Search(db.Cond{"project_id": projectId, "is_deleted": 0})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return 0, 0, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}
	PerformStaffCount = len(staffList)
	// 在performance里查出所有完成的人数 把存在的人数一个个查是否存在，不存在的计数
	PerformStaffLackCount = 0
	for _, staff := range staffList {
		staffPerformanceDatas, err := models.ProjectsPerformancesModel.Search(db.Cond{"company_id": data.CompanyId, "staff_id": staff.StaffId, "is_deleted": 0})
		if err != nil {
			errMassage := fmt.Sprint(err)
			return 0, 0, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
		}
		logger.Infof("***company_id:%v,staff_id：%v,staffPerformanceDatas num:%d***/n", data.CompanyId, staff.Id, len(staffPerformanceDatas))
		if len(staffPerformanceDatas) == 0 {
			PerformStaffLackCount++
		}
	}
	logger.Infof("PerformStaffCount:%d,PerformStaffLackCount:%d\n", PerformStaffCount, PerformStaffLackCount)
	return
}

// k代表行1 i代表列A
func getMistakeSite(k, i int) (site string) {
	num := strconv.Itoa(k + 4)
	char := excelMap[i]

	site = char + num
	return
}
func getMistakeSiteeval(k, i int) (site string) {
	num := strconv.Itoa(k + 4)
	char := excelMap[i]

	site = char + num
	return
}
func countCnWord(str string) int {
	return utf8.RuneCountInString(str)
}
func staffCheck(companyID int, staffName, staffno string) (result bool, staffID int, err error) {
	staffNos := make([]string, 0)
	staffNos = append(staffNos, staffno)
	staffs, err := dhr_staff.ListStaffByNos(nil, companyID, staffNos, true, []pb.Status{pb.Status_DIMISSION}) // todo by zzj 离职员工也能上传绩效
	if err != nil {
		logger.Infof("***GetStaffsByIDsAndNos err:%v***", err)
		errMassage := fmt.Sprint(err)
		return false, 0, common.NewRespErr(20305001, "调用staff信息错误:"+errMassage)
	}
	logger.Infof("***staff info:%v***", staffs)
	if staffs == nil || len(staffs) == 0 {
		return false, 0, common.NewRespErr(20305002, "没有符合要求的staff信息")
	}
	if staffs[0].Name != staffName {
		result = false
		return
	}
	result = true
	logger.Infof("***staffID:%v***", staffs[0].Id)
	staffID = staffs[0].Id
	return
}

func ParseExcel(companyID int, excelParser *excel.File) (parseRes *ParseResult, err error) {
	stringFormat := func(str string) string { return strings.TrimSpace(html.EscapeString(str)) }
	// 读取行里的内容
	rows, err := excelParser.GetRows("Sheet1")
	if err != nil {
		return nil, common.NewRespErr(20305022, "读取表格内容错误:"+err.Error())
	}
	// 限定上传5000行  默认示例不能修改为3行
	var endIndex int
	if len(rows) > MaxRows+fixedRows {
		endIndex = MaxRows + fixedRows
	} else {
		endIndex = len(rows)
	}
	parseRes = &ParseResult{}
	// 检验表格内容是否为空
	if len(rows) < 4 {
		return nil, common.NewRespErr(20304032, "excel表不符合要求")
	}
	if len(rows[1]) < 9 {
		return nil, common.NewRespErr(20304032, "excel表头不符合要求")
	}
	// 校验表头
	if !strings.Contains(rows[1][0], "员工ID") || !strings.Contains(rows[1][1], "员工姓名") ||
		!strings.Contains(rows[1][2], "绩效等级") || !strings.Contains(rows[1][3], "自评") ||
		!strings.Contains(rows[1][4], "他评1") || !strings.Contains(rows[1][5], "他评2") ||
		!strings.Contains(rows[1][6], "他评3") || !strings.Contains(rows[1][7], "他评4") ||
		!strings.Contains(rows[1][8], "他评5") {
		return nil, common.NewRespErr(20304032, "excel表头不符合要求")
	}
	checkValue := func(rowNum, celNum int, r string) {
		s := getMistakeSite(rowNum, celNum)
		mistake := Mistake{
			Site:   s,
			Reason: r,
		}
		parseRes.Mistakes = append(parseRes.Mistakes, mistake)
		errSite := getMistakeSite(rowNum, ErrMessageColumn)
		excelParser.SetCellValue("Sheet1", errSite, s+r)
	}

	for k, row := range rows[3:endIndex] {
		celStaffID := stringFormat(row[0])

		// 校验必填项是否缺失
		if celStaffID == "" {
			checkValue(k, 1, "员工号不能为空")
			continue
		}
		celStaffName := stringFormat(row[1])
		if celStaffName == "" {
			checkValue(k, 2, "员工姓名不能为空")
			continue
		}
		// 检验员工工号和姓名是否匹配
		ok, staffID, err := staffCheck(companyID, celStaffName, celStaffID)

		if err != nil {
			checkValue(k, 2, "员工工号和姓名校验失败")
			continue
		}
		if !ok {
			checkValue(k, 2, "员工工号和姓名校验失败")
			continue
		}

		// 绩效评级
		celLevel := stringFormat(row[2])
		if celLevel == "" {
			checkValue(k, 3, "绩效评级不能为空")
			continue
		}
		celSelfEval := stringFormat(row[3])
		if countCnWord(celSelfEval) > 1000 {
			checkValue(k, 4, "自评限制1000字")
			continue
		}
		for i := range row[4:9] {
			row[i] = stringFormat(row[i])
			if countCnWord(row[i]) > 1000 {
				checkValue(k, 5+i, "他评限制1000字")
				continue
			}
		}

		row := Row{
			CompanyID:   companyID,
			StaffNO:     celStaffID,
			StaffID:     staffID,
			StaffName:   celStaffName,
			Level:       celLevel,
			SelfEval:    celSelfEval,
			OthersEval1: row[4],
			OthersEval2: row[5],
			OthersEval3: row[6],
			OthersEval4: row[7],
			OthersEval5: row[8],
		}
		// 把每行内容加入结果中,对于发生了错误的单元格所在行不加入到result里，也不加入到数据库
		parseRes.Rows = append(parseRes.Rows, row)
	}

	logger.Infof("***错误内容个数：%d***", len(parseRes.Mistakes))
	if len(parseRes.Mistakes) != 0 {
		excelParser.SetCellValue("Sheet1", "J2", "错误原因")
	}
	return
}

func SaveResult(companyID, userID, uploadID int, parseRes *ParseResult) (uploadRes *UploadResult, err error) {
	uploadRes = &UploadResult{
		FailedCount: len(parseRes.Mistakes),
	}
	uploadRes.Mistakes = append(uploadRes.Mistakes, parseRes.Mistakes...)

	var updatecount, insertcount int

	// 遍历result里的内容
	for _, r := range parseRes.Rows {
		// 根据唯一索引判断是更新还是添加  某一条查库错误不会影响，只要记录错误
		// 生成上传时间字段作为period
		period := time.Now().Format("200601")
		performance, err := models.ProjectsPerformancesModel.SearchOne(db.Cond{
			"company_id": companyID,
			"staff_no":   r.StaffNO,
			"period":     period,
		})
		if err != nil {
			return nil, common.NewRespErr(20305024, "查数据库失败:"+err.Error())
		}
		// 新增
		if performance == nil {
			performancedate := &models.ProjectsPerformances{
				UploadId:    uploadID,
				CompanyId:   companyID,
				UserId:      userID,
				StaffId:     r.StaffID,
				StaffNo:     r.StaffNO,
				StaffName:   r.StaffName,
				Level:       r.Level,
				SelfEval:    r.SelfEval,
				OthersEval1: r.OthersEval1,
				OthersEval2: r.OthersEval2,
				OthersEval3: r.OthersEval3,
				OthersEval4: r.OthersEval4,
				OthersEval5: r.OthersEval5,
				Period:      period,
				IsDeleted:   1,
			}
			_, err = models.ProjectsPerformancesModel.Insert(performancedate)
			if err != nil {
				return nil, common.NewRespErr(20305025, "插入数据库失败:"+err.Error())
			}
			// 插入成功 insert count ++
			insertcount++
		} else {
			_, err = models.ProjectsPerformancesModel.Update(db.Cond{
				"upload_id":    uploadID,
				"staff_name":   r.StaffName,
				"staff_id":     r.StaffID,
				"level":        r.Level,
				"self_eval":    r.SelfEval,
				"others_eval1": r.OthersEval1,
				"others_eval2": r.OthersEval2,
				"others_eval3": r.OthersEval3,
				"others_eval4": r.OthersEval4,
				"others_eval5": r.OthersEval5,
				"is_deleted":   1,
			}, db.Cond{
				"company_id": companyID,
				"staff_no":   r.StaffNO,
			})

			if err != nil {
				return nil, common.NewRespErr(20305027, "更新数据库失败:"+err.Error())
			}
			// 更新成功，新增更新数量
			updatecount++

		}

	}

	// 组织返回给前端的数据(除url以外)
	failedCount := len(parseRes.Mistakes)
	var completion float32
	if (updatecount + insertcount + failedCount) != 0 {
		completion = float32((updatecount + insertcount)) / float32((updatecount + insertcount + failedCount))
	} else {
		completion = 0
	}
	uploadRes = &UploadResult{
		Mistakes:    parseRes.Mistakes,
		UpdateCount: updatecount,
		InsertCount: insertcount,
		FailedCount: failedCount,
		UploadID:    uploadID,
		Completion:  completion,
	}
	return
}

func GetExcelUploadID(userID int) (uploadID int, err error) {
	excelUpload := &models.Uploads{
		UserId: userID,
	}
	_, err = models.UploadsModel.Insert(excelUpload)
	if err != nil {
		return 0, common.NewRespErr(20305025, "插入数据库失败:"+err.Error())
	}
	data, err := models.UploadsModel.SearchOne(db.Cond{"user_id": userID, "orderby": "id desc"})
	return data.Id, err
}

// 将excel存入DFS
func SaveExcel(uploadID, projectID int, excelname string, excelParser *excel.File) (url string, err error) {
	buffer, err := excelParser.WriteToBuffer()
	content := base64.StdEncoding.EncodeToString(buffer.Bytes())

	dfs := &dfs.Dfs{
		Content:     content,
		ContentType: "json",
		Ext:         "xlsx",
	}
	_, err = dfs.Write()
	if err != nil {
		return "", common.NewRespErr(20305011, "存入DFS错误:"+err.Error())
	}
	// logger.Info("dfs:%v/n", dfs)
	// 将filename保存到数据库upload里
	if dfs.FileName == "" {
		return "", common.NewRespErr(20305011, "未能将excel成功存入DFS")
	}

	_, err = models.UploadsModel.Update(db.Cond{"project_id": projectID, "type_id": 1, "file_name": dfs.FileName, "group_name": dfs.GroupName, "excel_name": excelname},
		db.Cond{"id": uploadID})
	if err != nil {
		return "", common.NewRespErr(20305027, "更新数据库失败:"+err.Error())
	}
	return dfs.FileName, nil
}

// 提供所有等级
func Level(companyID, userID, uploadID int) (levelResult *LevelRes, err error) {
	// 根据公司id，项目id和user_id 来查询数据库把符合要求的全取出
	datas, err := models.ProjectsPerformancesModel.Search(db.Cond{
		"company_id": companyID,
		"user_id":    userID,
		"upload_id":  uploadID,
	})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return nil, common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}
	// logger.Info("proform datas %v:/n", datas)
	// 便利取出数据的level字段，取出并且去重的所有级别
	if len(datas) == 0 {
		return nil, common.NewRespErr(20304028, "没有符合条件数据")
	}
	levels := make([]string, 0)
	for i := 0; i < len(datas); i++ {
		repeat := false
		for j := i + 1; j < len(datas); j++ {
			if datas[i].Level == datas[j].Level {
				repeat = true
				break
			}
		}
		if !repeat {
			levels = append(levels, datas[i].Level)
		}
	}
	// logger.Info("proform levels %v:/n", levels)
	// 讲其组织成string列表返回给前段
	levelResult = &LevelRes{
		Level: levels,
	}
	return
}

// 对应等级更新到数据库
func UpdatePerformance(companyID, userID, uploadID int, levelRelationships []LevelRelationship, url string) (updateResult bool, err error) {
	// 检查url和upload_id是否匹配
	data, err := models.UploadsModel.SearchOne(db.Cond{"file_name": url, "id": uploadID})
	if err != nil {
		return false, common.NewRespErr(20305024, "查数据库失败:"+err.Error())
	}
	if data == nil {
		return false, common.NewRespErr(20304030, "查询不存在:"+err.Error())
	}
	// 判断上传的级别是否完全匹配
	performanceList, err := models.ProjectsPerformancesModel.Search(db.Cond{
		"upload_id": uploadID,
		"groupby":   "level",
	})
	if err != nil {
		return false, common.NewRespErr(20305024, "查数据库失败:"+err.Error())
	}
	if len(levelRelationships) != len(performanceList) {
		return false, common.NewRespErr(20304034, "级别对应关系不匹配")
	}

	performanceStandard := make(map[string]int)
	for _, performance := range performanceList {
		performanceStandard[performance.Level] = 1
	}
	for _, levelRelationship := range levelRelationships {
		if performanceStandard[levelRelationship.Level] != 1 {
			return false, common.NewRespErr(20304034, "级别对应关系不匹配")
		}
	}
	// 更新插入等级关系
	datas, err := models.ProjectsPerformancesModel.Search(db.Cond{"company_id": companyID, "user_id": userID, "upload_id": uploadID})
	if err != nil {
		return false, common.NewRespErr(20305024, "查数据库失败:"+err.Error())
	}
	r := make(map[string]int)
	// 像等级对应关系变成map
	for _, relationship := range levelRelationships {
		// 入参检验LevelRelationship.Standardlevel只能为1,2，3
		if relationship.LevelStandard != 1 && relationship.LevelStandard != 2 && relationship.LevelStandard != 3 {
			return false, common.NewRespErr(20304033, "标准等级只有1，2，3")
		}
		r[relationship.Level] = relationship.LevelStandard
	}
	logger.Infof("***r:%v,data len:%d ***\n", r, len(datas))
	// 把相应等级的标准值更新到ProjectsPerformances表中
	for _, data := range datas {
		ls := r[data.Level]
		// logger.Infof("***data.ID,data.Level:%s,performance level:%d***\n", data.Id, data.Level, ls)
		_, err = models.ProjectsPerformancesModel.Update(db.Cond{"level_standard": ls, "is_deleted": 0}, db.Cond{"id": data.Id})
		if err != nil {
			return false, common.NewRespErr(20305027, "更新数据库失败:"+err.Error())
		}
	}
	return
}

// 更新等级记录表
func Record(companyID, userID int, levelRelationships []LevelRelationship, url string) (matchResult bool, err error) {
	// 判断levelRelationship长度
	if len(levelRelationships) == 0 {
		return false, common.NewRespErr(20304029, "没有要插入数据库的内容")
	}
	data, err := models.UploadsModel.SearchOne(db.Cond{"file_name": url})
	if err != nil {
		return false, common.NewRespErr(20305024, "查数据库失败:"+err.Error())
	}
	if data == nil {
		return false, common.NewRespErr(20304030, "查询url不存在")
	}
	// 循环遍历LevelRelationship，在数据库中插入对应关系
	for _, relationship := range levelRelationships {
		levelrelationship := &models.ProjectsPerformancesStandard{
			Level:         relationship.Level,
			LevelStandard: relationship.LevelStandard,
			UploadExcelId: data.Id,
		}
		_, err := models.ProjectsPerformancesStandardModel.Insert(levelrelationship)
		if err != nil {
			return false, common.NewRespErr(20305025, "插入数据库失败:"+err.Error())
		}
	}
	matchResult = true
	return
}

// 下载最近一期的内容
func Donwload(userID int) (excelName string, data []byte, err error) {
	// 找url
	databaseData, err := models.UploadsModel.SearchOne(db.Cond{"user_id": userID, "is_deleted": 0, "orderby": "id desc"})
	if err != nil {
		return
	}
	if databaseData == nil {
		common.NewRespErr(20304030, "查询不存在")
		return
	}
	logger.Infof("***databaseData :%v***\n", databaseData)
	// 获取dfs里数据
	dfs := &dfs.Dfs{
		FileName:    databaseData.FileName,
		GroupName:   databaseData.GroupName,
		OffSet:      0,
		Length:      0,
		ContentType: "json",
	}
	dataString, err := dfs.Read()
	logger.Infof("***DFS READ data:%v***/n", dataString)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return "", nil, common.NewRespErr(20305013, "获取DFS上的历史excel失败:"+errMassage)
	}
	if dataString == "" {
		// logger.Infof("***DFS nil:%v***\n")
		return "", nil, common.NewRespErr(20305015, "获取DFS上的内容为空")
	}
	decodeString, err := base64.StdEncoding.DecodeString(dataString)
	logger.Infof("***DFS READ data:%v***/n", dataString)
	if err != nil {
		errMassage := fmt.Sprint(err)
		return "", nil, common.NewRespErr(20305014, "Base64解码失败:"+errMassage)
	}

	// 返回
	return databaseData.ExcelName, []byte(decodeString), nil
}

func GetFile() (filename string, data []byte, err error) {
	return GetFileName("绩效导入模板.xlsx")
}
func GetFileName(fName string) (filename string, data []byte, err error) {
	// 如果是开发环境需要读取目录  如果不是 则是在docker里面 关联Dockerfile里面的项目路径  ???
	path := hfw.GetAppPath() + "/"
	file := fmt.Sprintf("%sexample/import/绩效导入模板.xlsx", path)
	filename = fName
	data, err = ReadAll(file)
	if err != nil {
		return
	}
	return
}

func GetTalentExcel() (filename string, data []byte, err error) {
	path := hfw.GetAppPath() + "/"
	file := fmt.Sprintf("%sexample/import/人才盘点员工详情.xlsx", path)
	filename = "人才盘点员工详情.xlsx"
	data, err = ReadAll(file)
	if err != nil {
		return
	}
	return
}
func GetCollectUsersExcel() (filename string, data []byte, err error) {
	path := hfw.GetAppPath() + "/"
	file := fmt.Sprintf("%sexample/import/采集计划进度详情.xlsx", path)
	filename = "采集计划进度详情.xlsx"
	data, err = ReadAll(file)
	if err != nil {
		return
	}
	return
}
func ReadAll(filePth string) ([]byte, error) {
	f, err := os.Open(filePth)
	if err != nil {
		return nil, err
	}
	return ioutil.ReadAll(f)
}

func FillTemplate(companyID, projectID int, excelParser *excel.File) (err error) {
	// 用projectID获取staffIDs
	staffs, err := models.ProjectsStaffsModel.Search(db.Cond{"project_id": projectID, "is_deleted": 0})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return common.NewRespErr(20305024, "查数据库失败:"+errMassage)
	}
	if staffs == nil {
		return common.NewRespErr(20304028, "没有符合条件数据")
	}
	staffList := make([]int, 0)
	for _, staff := range staffs {
		staffList = append(staffList, staff.StaffId)
	}
	staffInfoList, err := dhr_staff.ListStaffByIds(nil, companyID, staffList, true, []pb.Status{pb.Status_DIMISSION})
	if err != nil {
		errMassage := fmt.Sprint(err)
		return common.NewRespErr(20305001, "调用staff信息错误:"+errMassage)
	}
	if staffInfoList == nil {
		return common.NewRespErr(20305002, "没有符合要求的staff信息")
	}

	// 根据staffIDs获取staffNo和staffName,将读出来的结果循环写入excel里
	var StaffIDSite, StaffNameSite string
	for k := range staffs {
		StaffIDSite = "A" + strconv.Itoa(k+4)
		err = excelParser.SetCellValue("Sheet1", StaffIDSite, staffInfoList[k].No)
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误")
		}
		StaffNameSite = "B" + strconv.Itoa(k+4)
		err = excelParser.SetCellValue("Sheet1", StaffNameSite, staffInfoList[k].Name)
		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误")
		}
	}
	return
}

func FillTemplateForProject(companyID, projectID int, excelParser *excel.File) (err error) {
	// 项目所有人员
	staffs, err := models.ProjectsStaffsModel.Search(db.Cond{"project_id": projectID, "is_deleted": 0})
	if err != nil {
		return common.NewRespErr(20305024, "查数据库失败:"+err.Error())
	}
	if staffs == nil {
		return common.NewRespErr(20304028, "没有符合条件数据")
	}
	// 项目所有人员IDs
	staffIds := make([]int, 0)
	for _, staff := range staffs {
		staffIds = append(staffIds, staff.StaffId)
	}
	// 项目所有人员详情
	staffInfoList, err := dhr_staff.ListStaffByIds(nil, companyID, staffIds, true, []pb.Status{pb.Status_DIMISSION})
	if err != nil {
		return common.NewRespErr(20305001, "调用staff信息错误:"+err.Error())
	}
	if len(staffInfoList) == 0 {
		return common.NewRespErr(20305002, "没有符合要求的staff信息")
	}

	// 有绩效的员工详情
	ppf, err := models.ProjectsPerformancesModel.Search(db.Cond{
		"sql": fmt.Sprintf(`
	SELECT
		* 
	FROM
		projects_performances 
	WHERE
		id IN ( SELECT max( id ) id FROM projects_performances WHERE company_id = %d AND staff_id IN ( %s ) GROUP BY staff_id );
		`, companyID, utils.SliceToArray(staffIds)),
	})
	if err != nil {
		return common.NewRespErr(20305001, "调用项目绩效错误:"+err.Error())
	}

	// 项目中绩效人员ID map
	performStaffMap := make(map[int]int)
	for _, pf := range ppf {
		performStaffMap[pf.StaffId] = pf.StaffId
	}
	// 遍历项目中人员列表
	for _, staff := range staffInfoList {
		// 项目中人员不在绩效员工列表中，
		// 表示该项目中此员工未上传绩效
		if _, ok := performStaffMap[staff.Id]; !ok {
			pf := new(models.ProjectsPerformances)
			pf.StaffId = staff.Id
			pf.StaffNo = staff.No
			pf.StaffName = staff.Name
			ppf = append(ppf, pf)
		}
	}

	// 写入excel
	for k, v := range ppf {
		aCell := "A" + strconv.Itoa(k+4)
		err = excelParser.SetCellValue("Sheet1", aCell, v.StaffNo)
		bCell := "B" + strconv.Itoa(k+4)
		err = excelParser.SetCellValue("Sheet1", bCell, v.StaffName)
		if v.Level != "" {
			cCell := "C" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", cCell, v.Level)
		}
		if v.SelfEval != "" {
			dCell := "D" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", dCell, v.SelfEval)
		}
		if v.OthersEval1 != "" {
			eCell := "E" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", eCell, v.OthersEval1)
		}
		if v.OthersEval2 != "" {
			fCell := "F" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", fCell, v.OthersEval1)
		}
		if v.OthersEval3 != "" {
			gCell := "G" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", gCell, v.OthersEval1)
		}
		if v.OthersEval4 != "" {
			hCell := "H" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", hCell, v.OthersEval1)
		}
		if v.OthersEval5 != "" {
			iCell := "I" + strconv.Itoa(k+4)
			err = excelParser.SetCellValue("Sheet1", iCell, v.OthersEval1)
		}

		if err != nil {
			return common.NewRespErr(20305004, "填写excel内容错误")
		}
	}
	return
}
