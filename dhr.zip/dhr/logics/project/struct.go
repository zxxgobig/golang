package project

// 返回盘点数据
type InventoryData struct {
	ProjectId   int          `json:"project_id"`
	ProjectName string       `json:"project_name"`
	Inventories []*Inventory `json:"inventories"`
}

type Inventory struct {
	StaffNo       string        `json:"staff_no"`
	StaffName     string        `json:"staff_name"`
	InterviewId   int           `json:"interview_id"`
	InterviewName string        `json:"interview_name"`
	FinishTime    string        `json:"finish_time"`
	FirstList     []*FirstLevel `json:"first_list"`
}

type FirstLevel struct {
	Name        string         `json:"name"`
	Score       float64        `json:"score"`
	Explain     string         `json:"explain"`
	SelfExplain string         `json:"self_explain"`
	SecondList  []*SecondLevel `json:"second_list"`
}

type SecondLevel struct {
	Name    string `json:"name"`
	Score   int    `json:"score"`
	Explain string `json:"explain"`
}

// 第三方测评处理
type ThirdInterviewResult struct {
	Details *DetailModel `json:"details"` // 详情
}

type DetailModel struct {
	InterviewId   int           `json:"interview_id"`
	InterviewName string        `json:"interview_name"`
	FinishTime    string        `json:"finish_time"`
	Axis1         []*ChartAxis1 `json:"axis1"` // 一级指标雷达图
	Axis2         []*ChartAxis2 `json:"axis2"` // 二级指标曲线图
}

type ChartAxis1 struct {
	Id    int64   `json:"id"`
	Name  string  `json:"name"`
	Score float64 `json:"score"`
}

type ChartAxis2 struct {
	ParentId    int64         `json:"parent_id"`
	ParentName  string        `json:"parent_name"`
	ParentScore float64       `json:"parent_score"`
	Data        []*ChartChild `json:"data"`
}

type ChartChild struct {
	Id    int64   `json:"id"`
	Name  string  `json:"name"`
	Score float64 `json:"score"`
	Desc  string  `json:"desc"`
}

var InterviewId2Name = map[int]string{
	1:  "素质",
	2:  "性格",
	3:  "专业技能",
	4:  "专业知识",
	5:  "潜力",
	6:  "驱动力",
	7:  "关键经历",
	8:  "情绪智力",
	9:  "批判思维",
	10: "管理实践能力",
	11: "职业人格",
	12: "性格风险",
	13: "领导风格",
	14: "组织忠诚度",
}

var PotentialDescriptions = map[int]map[int]string{
	1: {
		1: "学习状态较为被动，主观能动性发挥不足，更为依赖个人经验和过往成功事例",
		2: "学习状态较为被动，主观能动性发挥不足，更为依赖个人经验和过往成功事例",
		3: "具备接受和学习新知识的开放心态，能够对不同的方法进行评估与选择，并开展实践",
		4: "展示出很强的好奇心和学习渴望，能够尝试用不同的方法达成目标",
		5: "展示出很强的好奇心和学习渴望，能够尝试用不同的方法达成目标",
	},
	2: {
		1: "比起多视角多维度地思考问题，更倾向于运用过往成功经验或者向他人寻求解决的办法",
		2: "比起多视角多维度地思考问题，更倾向于运用过往成功经验或者向他人寻求解决的办法",
		3: "具备找到问题关键突破点的能力，并通过跨行业的标杆案例搜索找到最佳的解决办法",
		4: "善于从更广泛的视角和领域收集信息，并能洞悉复杂表象下的内在逻辑，找到突破性的解决方案",
		5: "善于从更广泛的视角和领域收集信息，并能洞悉复杂表象下的内在逻辑，找到突破性的解决方案",
	},
	3: {
		1: "较以自我为中心，对他人的情绪感知不敏锐",
		2: "较以自我为中心，对他人的情绪感知不敏锐",
		3: "具有同理他人的意愿，初步掌握感知他人情绪的能力",
		4: "善于倾听，能够理解和尊重他人",
		5: "善于倾听，能够理解和尊重他人",
	},
	4: {
		1: "情感成熟度不足，固执己见，较难正面地消化负面情绪",
		2: "情感成熟度不足，固执己见，较难正面地消化负面情绪",
		3: "易于接受负面反馈，并能及时调整情绪，以目标达成为导向",
		4: "表现出较强的情绪稳定性，将挑战性反馈、挫折和困难看做学习成长的机遇，始终保持积极的心态",
		5: "表现出较强的情绪稳定性，将挑战性反馈、挫折和困难看做学习成长的机遇，始终保持积极的心态",
	},
}

// 关键经历
type KeyExperienceOption struct {
	Id          int    `json:"id"`
	QuestionId  int    `json:"question_id"`
	Name        string `json:"name"`
	Description string `json:"description"`
}

var KeyExperienceDescriptions = map[int64]*KeyExperienceOption{
	1: {
		Id:          1,
		QuestionId:  1,
		Name:        "多经营单元负责人管理经历",
		Description: "作为最高负责人（一把手）管理多个独立核算业绩的经营单元（如多条产品线，多个业务等）",
	},
	2: {
		Id:          2,
		QuestionId:  1,
		Name:        "单一经营单元负责人管理经历",
		Description: "作为最高负责人（一把手）管理一个独立核算业绩的经营单元（如某条产品线，某个业务等）",
	},
	3: {
		Id:          3,
		QuestionId:  1,
		Name:        "多部门分管领导经历",
		Description: "作为分管领导，同时管理多个部门，直接下属通常为部门负责人",
	},
	4: {
		Id:          4,
		QuestionId:  1,
		Name:        "单一部门负责人管理经历",
		Description: "担任单一部门的负责人（正职）",
	},
	5: {
		Id:          5,
		QuestionId:  1,
		Name:        "不同部门管理经历",
		Description: "在不同时间点上担任不同部门的管理者（正副职）",
	},
	6: {
		Id:          6,
		QuestionId:  1,
		Name:        "团队主管经历",
		Description: "担任部门内某个团队的管理者",
	},
	7: {
		Id:          7,
		QuestionId:  1,
		Name:        "无管理经历",
		Description: "",
	},
	8: {
		Id:          8,
		QuestionId:  2,
		Name:        "组建团队",
		Description: "从无到有搭建一个新的团队，既包括外部人员的引进，也包括内部人员的调动",
	},
	9: {
		Id:          9,
		QuestionId:  2,
		Name:        "扭转士气",
		Description: "当组织或团队员工士气低落时，提振员工士气，重新凝聚战斗力",
	},
	10: {
		Id:          10,
		QuestionId:  2,
		Name:        "市场开拓",
		Description: "新地区、新行业、新客户等的销售开拓",
	},
	11: {
		Id:          11,
		QuestionId:  2,
		Name:        "多业态管理",
		Description: "作为业务主要负责人，同时管理跨行业的多个业务",
	},
	12: {
		Id:          12,
		QuestionId:  2,
		Name:        "新业务孵化",
		Description: "从无到有开拓某个新业务，搭建该业务的主要价值链环节和核心业务团队",
	},
	13: {
		Id:          13,
		QuestionId:  2,
		Name:        "产品/服务创新",
		Description: "开发或设计某个全新产品/服务，或是对产品/服务中的某项关键功能进行重大创新",
	},
	14: {
		Id:          14,
		QuestionId:  2,
		Name:        "关键交易/谈判",
		Description: "谈妥某个大型、关键的交易、合同或劳务协议",
	},
	15: {
		Id:          15,
		QuestionId:  2,
		Name:        "危机处理",
		Description: "处理突发、重大、困难的危机事件",
	},
	16: {
		Id:          16,
		QuestionId:  2,
		Name:        "扭转业绩",
		Description: "扭转一个表现不佳的组织、整体业务、某项业务或某个区域的业绩",
	},
	17: {
		Id:          17,
		QuestionId:  2,
		Name:        "收购兼并",
		Description: "作为主要参与人，参与本公司兼并或收购其他组织或企业的过程",
	},
	18: {
		Id:          18,
		QuestionId:  2,
		Name:        "海外经历",
		Description: "在中国大陆以及港澳台之外的地区工作超过3个月",
	},
	19: {
		Id:          19,
		QuestionId:  2,
		Name:        "业务轮岗",
		Description: "拥有在不同业务/区域/职能线任职的经历",
	},
	20: {
		Id:          20,
		QuestionId:  2,
		Name:        "重大项目",
		Description: "主导难度高、复杂度高、对公司影响重大的项目",
	},
	21: {
		Id:          21,
		QuestionId:  2,
		Name:        "承担盈亏",
		Description: "作为业务单元负责人，负责某一业务的财务盈亏",
	},
	22: {
		Id:          22,
		QuestionId:  2,
		Name:        "技术/专业突破",
		Description: "取得对公司业务有重大影响的技术/专业成果",
	},
	23: {
		Id:          23,
		QuestionId:  2,
		Name:        "行业转换",
		Description: "成功实现跨行业的工作转换",
	},
	24: {
		Id:          24,
		QuestionId:  2,
		Name:        "职能建设",
		Description: "顺应公司业务成长要求，实现职能领域内功能的丰富、完善与升级",
	},
	25: {
		Id:          25,
		QuestionId:  2,
		Name:        "推动组织变革",
		Description: "推动组织架构、流程、管理方式、文化等的重大变革",
	},
	26: {
		Id:          26,
		QuestionId:  2,
		Name:        "关停并转",
		Description: "处理因关停或放弃某个组织、业务、区域产生的业务调整、人员安置等工作",
	},
	27: {
		Id:          27,
		QuestionId:  2,
		Name:        "经历重大组织变革",
		Description: "经历公司业务、文化价值观、组织等重大变革",
	},
}

type WorkValueOption struct {
	Id                 int    `json:"id"`
	WorkValues         string `json:"work_values"`
	WorkValuesDescribe string `json:"work_values_describe"`
}

var WorkValueDescriptions = map[int64]*WorkValueOption{
	1: {
		Id:                 1,
		WorkValues:         "收入与财富",
		WorkValuesDescribe: "工作的目的或动力主要来源于对收入和财富的追求，并以此改善生活质量，显示自己的身份和地位。",
	},
	2: {
		Id:                 2,
		WorkValues:         "兴趣特长",
		WorkValuesDescribe: "以自己的兴趣和特长作为选择职业最重要的因素，期望从工作中找到乐趣与成就感。",
	},
	3: {
		Id:                 3,
		WorkValues:         "权力地位",
		WorkValuesDescribe: "希望获得较高的权力地位，能够影响或控制他人，使他人遵从自己的意愿行动，并从中获得成就感。",
	},
	4: {
		Id:                 4,
		WorkValues:         "自由独立",
		WorkValuesDescribe: "希望工作能有弹性，不想受太多的约束，可以充分掌握自己的时间，自由度高，既不想治人也不想役于人。",
	},
	5: {
		Id:                 5,
		WorkValues:         "自我实现",
		WorkValuesDescribe: "工作能够提供平台和机会，使自己的专业和能力得以全面运用和施展，创造价值。",
	},
	6: {
		Id:                 6,
		WorkValues:         "人际关系",
		WorkValuesDescribe: "重视工作单位的人际关系，渴望能够在一个和谐、友好甚至被关爱的环境工作。",
	},
	7: {
		Id:                 7,
		WorkValues:         "身心健康",
		WorkValuesDescribe: "注重工作环境的舒适度，能够免于危险、过度劳累、焦虑紧张的工作环境，使自己的身心健康不受影响。",
	},
	8: {
		Id:                 8,
		WorkValues:         "组织稳定",
		WorkValuesDescribe: "注重组织的形态稳定，有清晰的流程与明确的规则，不必担心经常出现职权不明或变动的情况。",
	},
	9: {
		Id:                 9,
		WorkValues:         "工作稳定",
		WorkValuesDescribe: "工作相对稳定，不必担心经常出现裁员和辞退现象，免于经常奔波找工作。",
	},
	10: {
		Id:                 10,
		WorkValues:         "组织需要",
		WorkValuesDescribe: "能够根据组织的需要响应组织的号召，愿意为组织的发展做出必要的个人牺牲与贡献。",
	},
	11: {
		Id:                 11,
		WorkValues:         "追求新意",
		WorkValuesDescribe: "希望工作的内容有较大的空间发挥，使工作和生活显得丰富多彩，不单调枯燥。",
	},
}
