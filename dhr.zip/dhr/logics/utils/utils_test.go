package utils

import (
	"testing"
)

func TestUtils(t *testing.T) {
	IDs := make([]int, 0)
	IDs = append(IDs, 1)
	IDs = append(IDs, 2)
	s := SliceToArray(IDs)
	t.Log(s)
}
