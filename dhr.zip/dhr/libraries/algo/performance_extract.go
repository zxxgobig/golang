package algo

import (
    "sort"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"
)

type PerformanceExtractRequest struct {
    PerformanceData []Performance `json:"performance_data"`
}

type Performance struct {
    StaffID       int    `json:"staff_id"`
    Level         string `json:"level"`
    StandardLevel string `json:"standard_level"`
    Evaluation    string `json:"evaluation"`
}

type PerformanceExtractResponse struct {
    Others []PerformanceResult `json:"others"`
}

type PerformanceResult struct {
    StaffID int   `json:"staff_id"`
    Tags    []Tag `json:"tags"`
}

type Tag struct {
    Name  string  `json:"name"`
    Score float64 `json:"score"`
}

func PerformanceExtract(req *PerformanceExtractRequest) (res *PerformanceExtractResponse, err error) {
    p := api.NewPost("", "")
    p.P = req

    err = api.SimpleCurl(nil, hfw.Config.Custom["AlgoPerformanceExtractURL"], p, &res)

    return
}

func SortTagsByScoreDesc(tags []Tag) {
    if tags == nil {
        return
    }

    sort.Slice(tags, func(i, j int) bool { return tags[i].Score > tags[j].Score })
}
