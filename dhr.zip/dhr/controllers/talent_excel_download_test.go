package controllers

import (
    "gitlab.ifchange.com/bot/hfw"
    "net/http"
    "net/http/httptest"
    "testing"
)

func TestTalentExcelDownload_Download(t *testing.T) {
    url := "http://127.0.0.1:63333/talent_excel/download?session=eyJmcm9tIjoiQyIsInNyY19pZCI6MiwibWFuYWdlcl9pZCI6MCwiY29tcGFueV9pZCI6MCwidXNlcl9pZCI6MCwiZXhwaXJlIjoxNTYwNDIwMDcxLCJzaWduYXR1cmUiOiIwMDg5YzQzM2QwYWFmMWI3ZDczNWNmYjkxZmEwNjkwZTQ0NTI3MDMwIn0=&project_id=49"
    req := httptest.NewRequest(http.MethodGet, url, nil)
    req.Header.Set("X", "SUu5V7NPXQXzI8wCL95LYV9IkZdnzGfQ")

    w := httptest.NewRecorder()
    hfw.Router(w, req)

    t.Logf("%+v", w.Body)
}
func TestTalentExcelDownload_UsersDownload(t *testing.T) {
    url := "http://127.0.0.1:63333/talent_excel/users_download?session=eyJmcm9tIjoiQyIsInNyY19pZCI6MiwibWFuYWdlcl9pZCI6MCwiY29tcGFueV9pZCI6MCwidXNlcl9pZCI6MCwiZXhwaXJlIjoxNTYwNDIwMDcxLCJzaWduYXR1cmUiOiIwMDg5YzQzM2QwYWFmMWI3ZDczNWNmYjkxZmEwNjkwZTQ0NTI3MDMwIn0=&plan_id=247"
    req := httptest.NewRequest(http.MethodGet, url, nil)
    req.Header.Set("X", "SUu5V7NPXQXzI8wCL95LYV9IkZdnzGfQ")

    w := httptest.NewRecorder()
    hfw.Router(w, req)

    t.Logf("%+v", w.Body)
}