package interview

import (
	"encoding/json"
	"fmt"
	"strings"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	hfwutil "gitlab.ifchange.com/bot/hfwkit/utils"
	"gitlab.ifchange.com/bot/logger"
	commonpb "gitlab.ifchange.com/bot/proto/common"
	pb "gitlab.ifchange.com/bot/proto/dhr_staff/staff"
	"xorm.io/builder"

	"ifchange/dhr/libraries"
	"ifchange/dhr/models"
)

// 员工需要做的试卷
type DataCollectDemandStaff struct {
	dhr_staff.Staff
	Leader                      Leader             `json:"leader"`
	LeaderIsEmpty               bool               `json:"leader_is_empty"`                 // leader是否为空
	CompletedConfigItemParams   []*ConfigItemParam `json:"completed_config_item_params"`    // 已完成的维度列表
	NoCompletedConfigItemParams []*ConfigItemParam `json:"no_completed_config_item_params"` // 未完成的维度列表（即需要采集的维度列表）
}

// 是否需要
func (s *DataCollectDemandStaff) IsCompleteDataCollect() bool {
	if s == nil {
		return true
	}
	return len(s.NoCompletedConfigItemParams) == 0
}

// 获取有采集需求的员工列表
func GetDataCollectDemandStaffs(companyId, projectId int, status []pb.Status) (extendedStaffs []*DataCollectDemandStaff, err error) {
	// 获取该项目详情
	projects, err := models.ProjectsModel.SearchOne(db.Cond{"is_deleted": 0, "company_id": companyId, "id": projectId})
	if err != nil {
		logger.Error(err)
		return
	}
	if projects == nil {
		logger.Warn("project is nil")
		return
	}

	// 获取该项目下员工列表并提取出员工 ID 列表
	projectsStaffs, err := models.ProjectsStaffsModel.Search(db.Cond{"is_deleted": 0, "project_id": projectId})
	if err != nil {
		logger.Error(err)
		return
	}
	if projectsStaffs == nil || len(projectsStaffs) == 0 {
		logger.Warn("projectsStaffs is nil or empty")
		return
	}
	staffIds := make([]int, 0, len(projectsStaffs))
	for _, v := range projectsStaffs {
		staffIds = append(staffIds, v.StaffId)
	}
	staffIds = hfwutil.FilterDuplicateAndZeroIntSlice(staffIds)

	// 远程获取该项目下所有员工详情
	staffs, err := dhr_staff.ListStaffByIds(nil, companyId, staffIds, true, status)
	if err != nil {
		logger.Error(err)
		return
	}
	if staffs == nil || len(staffs) == 0 {
		logger.Warn("staffs is nil or empty")
		return
	}

	// 获取该项目的测评配置
	projectsInterviewsConfigs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"is_deleted": 0,
		"project_id": projectId,
	})
	if err != nil {
		logger.Error(err)
		return
	}
	if projectsInterviewsConfigs == nil {
		logger.Warn("projectsInterviewsConfigs is nil")
		return
	}

	needInterviewConfigMapping := make(map[int]ConfigSubItemsIdGetter) // 该项目需要的测评与子维度的 Mapping
	needInterviewCompletedMapping := make(map[int]map[string]bool)     // 该项目需要的测评与子维度的完成情况 Mapping
	for _, config := range projectsInterviewsConfigs {
		items := ParseConfigSubItems(config.InterviewConfigs)
		needInterviewConfigMapping[config.InterviewId] = items
		needInterviewCompletedMapping[config.InterviewId] = make(map[string]bool)
		for _, staffId := range staffIds {
			switch interview.Type(config.InterviewId) { // 除素质、专业知识技能其它
			case interview.Personality,
				interview.Potential,
				interview.WorkValues,
				interview.KeyExp,
				interview.EmotionalIntelligence,
				interview.CriticalThinking,
				interview.PracticalIntelligence,
				interview.OccupationalPersonality,
				interview.PersonalityDisorder,
				interview.LeadershipStyle,
				interview.OrgCommitment,
				interview.ManagementQuality:
				needInterviewCompletedMapping[config.InterviewId][fmt.Sprintf("%d:0", staffId)] = false
			default: // 素质、专业知识技能
				if len(items) == 0 {
					logger.Errorf("interviewId: %d, config is nil", config.InterviewId)
					return
				}
				for _, item := range items { // 需要测评的子维度
					needInterviewCompletedMapping[config.InterviewId][fmt.Sprintf("%d:%d", staffId, item.Id)] = false
				}
			}
		}
	}

	logger.Debugf("GetDataCollectDemandStaffs needInterviewConfigMapping: %s", libraries.MustJSONMarshal(needInterviewConfigMapping))

	// 获取该项目的有效测评数据
	// TODO 可以把非当前项目的有效数据直接插入到当前项目中
	validStaffsInterviewDetails, err := newValidDetails(projectId).getValidStaffsInterviewDetails(staffIds, needInterviewConfigMapping)
	if err != nil {
		logger.Error(err)
		return
	}
	if validStaffsInterviewDetails == nil || len(validStaffsInterviewDetails) == 0 {
		logger.Warn("validStaffsInterviewDetails is nil or empty")
	}

	for _, detail := range validStaffsInterviewDetails {
		switch interview.Type(detail.InterviewId) {
		case interview.Personality,
			interview.Potential,
			interview.WorkValues,
			interview.KeyExp,
			interview.EmotionalIntelligence,
			interview.CriticalThinking,
			interview.PracticalIntelligence,
			interview.OccupationalPersonality,
			interview.PersonalityDisorder,
			interview.LeadershipStyle,
			interview.OrgCommitment,
			interview.ManagementQuality:
			// 处理新测评
			needInterviewCompletedMapping[detail.InterviewId][fmt.Sprintf("%d:0", detail.StaffId)] = true // 已经答题，不需要再采集
		default:
			needInterviewCompletedMapping[detail.InterviewId][fmt.Sprintf("%d:%d", detail.StaffId, detail.SubItem)] = true // // 已经答题，不需要再采集
		}
	}

	logger.Debugf("GetDataCollectDemandStaffs needInterviewCompletedMapping: %s", libraries.MustJSONMarshal(needInterviewCompletedMapping))

	// 处理已完成、未完成的测评数据
	completedStaffInterviewConfigMapping := make(map[int]map[int][]ConfigSubItem)   // 已完成的员工测评 Mapping, map[staffId]map[interviewId][]ConfigSubItem
	noCompletedStaffInterviewConfigMapping := make(map[int]map[int][]ConfigSubItem) // 未完成的员工测评 Mapping, map[staffId]map[interviewId][]ConfigSubItem
	for id, mapping := range needInterviewCompletedMapping {
		for key, completed := range mapping {
			split := strings.Split(key, ":")
			staffId := hfwutil.MustAtoi(split[0])
			subitemId := hfwutil.MustAtoi(split[1])

			if _, ok := completedStaffInterviewConfigMapping[staffId]; !ok {
				completedStaffInterviewConfigMapping[staffId] = make(map[int][]ConfigSubItem)
			}
			if _, ok := noCompletedStaffInterviewConfigMapping[staffId]; !ok {
				noCompletedStaffInterviewConfigMapping[staffId] = make(map[int][]ConfigSubItem)
			}

			switch interview.Type(id) {
			case interview.Personality,
				interview.Potential,
				interview.WorkValues,
				interview.KeyExp,
				interview.EmotionalIntelligence,
				interview.CriticalThinking,
				interview.PracticalIntelligence,
				interview.OccupationalPersonality,
				interview.PersonalityDisorder,
				interview.LeadershipStyle,
				interview.OrgCommitment,
				interview.ManagementQuality:
				if completed {
					if _, ok := completedStaffInterviewConfigMapping[staffId][id]; !ok {
						completedStaffInterviewConfigMapping[staffId][id] = make([]ConfigSubItem, 0)
					}
				} else {
					if _, ok := noCompletedStaffInterviewConfigMapping[staffId][id]; !ok {
						noCompletedStaffInterviewConfigMapping[staffId][id] = make([]ConfigSubItem, 0)
					}
				}
			default: // 素质、专业知识技能
				if completed {
					if _, ok := completedStaffInterviewConfigMapping[staffId][id]; !ok {
						completedStaffInterviewConfigMapping[staffId][id] = make([]ConfigSubItem, 0)
					}
					completedStaffInterviewConfigMapping[staffId][id] = append(completedStaffInterviewConfigMapping[staffId][id], ConfigSubItem{Id: subitemId})
				} else {
					if _, ok := noCompletedStaffInterviewConfigMapping[staffId][id]; !ok {
						noCompletedStaffInterviewConfigMapping[staffId][id] = make([]ConfigSubItem, 0)
					}
					noCompletedStaffInterviewConfigMapping[staffId][id] = append(noCompletedStaffInterviewConfigMapping[staffId][id], ConfigSubItem{Id: subitemId})
				}
			}
		}
	}

	logger.Debugf("GetDataCollectDemandStaffs completedStaffInterviewConfigMapping: %s", libraries.MustJSONMarshal(completedStaffInterviewConfigMapping))
	logger.Debugf("GetDataCollectDemandStaffs noCompletedStaffInterviewConfigMapping: %s", libraries.MustJSONMarshal(noCompletedStaffInterviewConfigMapping))

	// 构建返回对象
	for _, staff := range staffs {
		demandStaff := &DataCollectDemandStaff{
			Staff: *staff,
			Leader: Leader{
				ID:   staff.ParentId,
				Name: staff.ParentName,
			},
		}
		for id, config := range completedStaffInterviewConfigMapping[staff.Id] {
			demandStaff.CompletedConfigItemParams = append(demandStaff.CompletedConfigItemParams, &ConfigItemParam{
				Id:       id,
				SubItems: config,
			})
		}
		for id, config := range noCompletedStaffInterviewConfigMapping[staff.Id] {
			demandStaff.NoCompletedConfigItemParams = append(demandStaff.NoCompletedConfigItemParams, &ConfigItemParam{
				Id:       id,
				SubItems: config,
			})
		}
		extendedStaffs = append(extendedStaffs, demandStaff)
	}
	if len(extendedStaffs) == 0 {
		logger.Warn("extendedStaffs empty")
		return
	}

	// 远程获取该项目下所有员工的直属领导详情
	leadersIds := make([]int, 0, len(extendedStaffs))
	for _, v := range extendedStaffs {
		leadersIds = append(leadersIds, v.ParentId)
	}
	leadersIds = hfwutil.FilterDuplicateAndZeroIntSlice(leadersIds)
	if len(leadersIds) == 0 {
		logger.Warn("leadersIds empty")
		return
	}
	leaders, err := dhr_staff.ListStaffByIds(nil, companyId, leadersIds, false, nil)
	if err != nil {
		logger.Error(err)
		return
	}
	// if leaders == nil || len(leaders) == 0 {
	// 	logger.Warn("leaders is nil or empty")
	// 	return
	// }

	for idx, staff := range extendedStaffs {
		var isPic commonpb.Whether_Flag
		for _, leader := range leaders {
			if staff.Leader.ID == leader.Id {
				staff.Leader.Email = leader.Email
				isPic = commonpb.Whether_Flag(leader.IsPic)
			}
		}
		// 如果 leader 不是企业负责人同时 email 不存在，说明 leader 不存在了，则过滤该 leader 下的员工
		if staff.Leader.Email == "" && isPic == commonpb.Whether_Flag_NO {
			extendedStaffs[idx].CompletedConfigItemParams = staff.CompletedConfigItemParams[:0]
			extendedStaffs[idx].NoCompletedConfigItemParams = staff.NoCompletedConfigItemParams[:0]
			extendedStaffs[idx].LeaderIsEmpty = true // staff leader 为空
		}
	}

	return
}

func ParseConfigSubItems(str string) []ConfigSubItem {
	var cfg []ConfigSubItem
	_ = encoding.JSON.UnmarshalFromString(str, &cfg)
	return cfg
}

type ConfigSubItemsIdGetter []ConfigSubItem

func (c ConfigSubItemsIdGetter) GetId(i int) int {
	return c[i].Id
}

func (c ConfigSubItemsIdGetter) Len() int {
	return len(c)
}

// BEI维度初始化，
// BEI是否设置为完成
func beiFinished(configInterviewID int, projectID int) bool {
	finishedOldBei := true
	if configInterviewID == 1 && isModeTwoByProjectID(projectID) { // 模式2下，不需要测评老BEI
		finishedOldBei = true // 直接设置为完成
	} else if configInterviewID == 1 && isModeOneByProjectID(projectID) { // 模式1下，需要测评老BEI
		finishedOldBei = false // 默认为未完成
	}
	return finishedOldBei
}

// 获取项目所处BEI模式
func getProjectInterviewModeByID(projectID int) (mode int) {
	p, err := models.ProjectsModel.SearchOne(db.Cond{
		"id":         projectID,
		"is_deleted": 0,
	})
	if err != nil || p == nil {
		logger.Errorf("[GetProjectInterviewModeByID] search project %v by id %d, err: %v", p, projectID, p)
		return 0
	}
	return p.InterviewMode
}

// 判断该项目是否处于BEI模式1
func isModeOneByProjectID(projectID int) bool {
	mode := getProjectInterviewModeByID(projectID)
	if mode == 1 {
		return true
	}
	return false
}

// 判断该项目是否处于BEI模式2
// 缺省情况为模式2
func isModeTwoByProjectID(projectID int) bool {
	mode := getProjectInterviewModeByID(projectID)
	if mode == 1 {
		return false
	}
	return true
}

func newValidDetails(currentProjectID int) *validStaffsDetails {
	return &validStaffsDetails{
		CurrentProjectID: currentProjectID,
	}
}

type validStaffsDetails struct {
	CurrentProjectID int `json:"current_project_id"`
}

func (valid *validStaffsDetails) getValidStaffsInterviewDetails(staffIds []int, interviewConfigMapping map[int]ConfigSubItemsIdGetter) (
	result []*models.StaffsInterviewsDetails, err error) {
	where := builder.NewCond()

	for id, item := range interviewConfigMapping {
		switch interview.Type(id) {
		// 素质 1
		case interview.Bei:
			where = where.Or(
				builder.Eq{"interview_id": interview.Bei}.
					And(builder.In("sub_item", hfwutil.GetIds(item))).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Bei).BeforeTime())}),
			)
		// 性格 2，没有子维度，特殊处理
		case interview.Personality:
			where = where.Or(
				builder.Eq{"interview_id": interview.Personality}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Personality).BeforeTime())}),
			)
		// 专业技能 3
		case interview.Skill:
			where = where.Or(
				builder.Eq{"interview_id": interview.Skill}.
					And(builder.In("sub_item", hfwutil.GetIds(item))).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Skill).BeforeTime())}),
			)
		// 专业知识 4
		case interview.Knowledge:
			where = where.Or(
				builder.Eq{"interview_id": interview.Knowledge}.
					And(builder.In("sub_item", hfwutil.GetIds(item))).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Knowledge).BeforeTime())}),
			)
		// 潜力 5，没有子维度，特殊处理
		case interview.Potential:
			where = where.Or(
				builder.Eq{"interview_id": interview.Potential}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.Potential).BeforeTime())}),
			)
		// 工作选择价值观 6
		case interview.WorkValues:
			where = where.Or(
				builder.Eq{"interview_id": interview.WorkValues}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.WorkValues).BeforeTime())}),
			)
		// 关键经历 7
		case interview.KeyExp:
			where = where.Or(
				builder.Eq{"interview_id": interview.KeyExp}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.KeyExp).BeforeTime())}),
			)
		// 情绪智力 8，没有子维度，特殊处理
		case interview.EmotionalIntelligence:
			where = where.Or(
				builder.Eq{"interview_id": interview.EmotionalIntelligence}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.EmotionalIntelligence).BeforeTime())}),
			)
		// 批判思维 9，没有子维度，特殊处理
		case interview.CriticalThinking:
			where = where.Or(
				builder.Eq{"interview_id": interview.CriticalThinking}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.CriticalThinking).BeforeTime())}),
			)
		// 管理实践能力 10，没有子维度，特殊处理
		case interview.PracticalIntelligence:
			where = where.Or(
				builder.Eq{"interview_id": interview.PracticalIntelligence}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.PracticalIntelligence).BeforeTime())}),
			)
		// 职业人格 11，没有子维度，特殊处理
		case interview.OccupationalPersonality:
			where = where.Or(
				builder.Eq{"interview_id": interview.OccupationalPersonality}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.OccupationalPersonality).BeforeTime())}),
			)
		// 性格风险 12，没有子维度，特殊处理
		case interview.PersonalityDisorder:
			where = where.Or(
				builder.Eq{"interview_id": interview.PersonalityDisorder}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.PersonalityDisorder).BeforeTime())}),
			)
		// 领导风格 13，没有子维度，特殊处理
		case interview.LeadershipStyle:
			where = where.Or(
				builder.Eq{"interview_id": interview.LeadershipStyle}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.LeadershipStyle).BeforeTime())}),
			)
		// 组织忠诚 14，没有子维度，特殊处理
		case interview.OrgCommitment:
			where = where.Or(
				builder.Eq{"interview_id": interview.OrgCommitment}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.OrgCommitment).BeforeTime())}),
			)
			// 8维管理素质测验 21，没有子维度，特殊处理
		case interview.ManagementQuality:
			where = where.Or(
				builder.Eq{"interview_id": interview.ManagementQuality}.
					And(builder.Gt{"sub_item": 0}).
					And(builder.Gt{"updated_at": hfwutil.FormatDateTime(interview.GetPeriodDay(interview.ManagementQuality).BeforeTime())}),
			)
		}
	}

	staffsInterviewDetails, err := models.StaffsInterviewsDetailsModel.Search(db.Cond{
		"is_deleted":  0,
		"nolimit":     struct{}{},
		"staff_id in": staffIds,
		"status":      2,
		"where":       libraries.MustToBoundSQL(where),
		"orderby":     "updated_at DESC",
	})
	if err != nil {
		logger.Error(err)
		return
	}

	newStaffsInterviewDetails := valid.filterOldPAndO(staffsInterviewDetails)
	// 一级维度去重
	result = make([]*models.StaffsInterviewsDetails, 0, len(newStaffsInterviewDetails))
	tmp := make(map[string]struct{})
	for k, v := range newStaffsInterviewDetails {
		key := fmt.Sprintf("%d:%d:%d", v.StaffId, v.InterviewId, v.SubItem)
		if _, ok := tmp[key]; !ok {
			tmp[key] = struct{}{}
			result = append(result, newStaffsInterviewDetails[k])
		}
	}

	b, _ := json.Marshal(result)
	logger.Debugf("[getValidStaffsInterviewDetails] out param len: %d, data: %s", len(result), string(b))
	return
}

// 入参，为有效数据(包含BEI模式1和模式2，10、11号测评老的数据)
// 出参，为过滤后的数据
// 1、对10号测评(practical_intelligence)和11号测评(occupational_personality)是否完成进行过滤，
// 由于两个测评增加了新维度，
// 需要再次测评它们
// 2、对BEI不同模式下的数据进行过滤
func (valid *validStaffsDetails) filterOldPAndO(details []*models.StaffsInterviewsDetails) (newDetails []*models.StaffsInterviewsDetails) {
	b, _ := json.Marshal(details)
	logger.Debugf("[filterOldPAndO] in param len: %d, data: %s", len(details), string(b))

	// 10号测评和11号测评的结果可能不可信，
	// 先置为不可信，
	// 不可信的维度数据需要再次参加测评
	for k, v := range details {
		if v.InterviewId == 10 || v.InterviewId == 11 {
			details[k].IsDeleted = 1
		}
	}
	// 对满足条件的测评，
	// 重置为可信状态
	for _, v := range details {
		if (v.InterviewId == 10 && v.SubItem == 3 && v.SecondarySubItem == 4) ||
			v.InterviewId == 11 && v.SubItem == 3 && v.SecondarySubItem == 6 {
			for kk, vv := range details {
				if vv.StaffId == v.StaffId && vv.InterviewId == v.InterviewId {
					details[kk].IsDeleted = 0
				}
			}
		}
	}

	if isModeTwoByProjectID(valid.CurrentProjectID) {
		// 处于模式2时，对模式1下的BEI完成率进行过滤，
		// 模式1下的BEI数据在模式2下无效
		for k, v := range details {
			// v.ProjectId，历史测评数据是否是模式1下的
			// 如果为true，则需要过滤
			if v.InterviewId == 1 && isModeOneByProjectID(v.ProjectId) {
				details[k].IsDeleted = 1
			}
		}
	}

	// 过滤掉失信数据，
	// 构建新集合
	for _, v := range details {
		if v.IsDeleted == 0 {
			newDetails = append(newDetails, v)
		}
	}

	b, _ = json.Marshal(newDetails)
	logger.Debugf("[filterOldPAndO] out param len: %d, data: %s", len(newDetails), string(b))
	return newDetails
}
