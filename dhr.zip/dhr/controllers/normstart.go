package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/interview"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfwkit/api"

    "gitlab.ifchange.com/bot/hfw"
)

type NormStarService struct {
    core.Controller
}

/**
* @api {post} /norm_star/callback NormStart的回调接口
* @apiVersion 1.0.0
* @apiGroup NormStar
* @apiDescription NormStart的回调接口
*
* @apiParam {String} session    按照http://192.168.1.174/apidocs/apidoc/rule.html生成的session
* @apiParam {String} uuid 测评者唯一ID
* @apiParam {String} activityId 测评者所在活动ID
* @apiParam {String} totalScore 总分
* @apiParam {String} identityCard 身份证号
* @apiParam {String} reportUrl 报告下载地址
* @apiParam {Json} reportUrlJson 返回多个版本的报告下载地址
* @apiParam {Json} dimScore 所有指标的得分
* @apiParam {Json} dimScoreVo 带有指标结构的所有指标得分
* @apiParam {String} startLevel 星级
* @apiParam {String} levelExplain 测评者所在活动ID
* @apiParam {String} timeStamp 实时时间戳
*
* @apiParamExample {json} Request-Example:
* {
*	"session": "",
*	"uuid": ,
*	"activityId": "",
*	"totalScore": "",
*	"identityCard": "",
*	"reportUrl": "",
*	"reportUrlJson": "",
*	"dimScore": "",
*	"dimScoreVo": "",
*	"startLevel": "",
*	"levelExplain": "",
*	"timeStamp": "",
* }
* @apiSuccess {Object[]} results 返回结果
* @apiSuccess {String} results.succeed 是否成功
* @apiSuccess {String} results.code 失败的原因
* @apiSuccessExample {json} Success-Response:
* {
*	"succeed": true,
*	"code": ""
* }
 */
func (ctl *NormStarService) Callback(httpCtx *hfw.HTTPContext) {
    params := new(interview.NormStarCallbackServiceParams)
    err := api.RequestUnmarshal(httpCtx, &params)
    httpCtx.ThrowCheck(20304001, err)
    logger.Debugf("NormStarCallback params: %+v", params.NormStarCallbackParams)
    // httpCtx.ResponseWriter.Header().Set("Content-Type", "application/json; charset=utf-8")

    err = interview.NormStarCallback(params.NormStarCallbackParams)
    httpCtx.ThrowCheck(20304001, err)
    httpCtx.Results = true
}

// func (_ *NormStarService) Index(httpCtx *hfw.HTTPContext) {
//	logger.Info("OKOOKOOKOKOOKOKOK")
//	params := &struct {
//		ProjectID        int `json:"project_id"`
//		CompanyID        int `json:"company_id"`
//		DataCollectPland int `json:"data_collect_pland"`
//	}{}
//	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, params))
//	err := interview.Create(httpCtx, params.ProjectID, params.CompanyID, params.DataCollectPland)
//	//err := interview.Create(httpCtx, 1, 109, 3)
//
//	httpCtx.ThrowCheck(20305000, err)
//	httpCtx.Results = true
// }
