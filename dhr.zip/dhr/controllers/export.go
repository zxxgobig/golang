package controllers

import (
	"bytes"
	"fmt"
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/logger"
	"ifchange/dhr/core"
	"ifchange/dhr/logics/interview"
	"io/ioutil"
	"net/http"
	"strconv"
	"time"
)

type Export struct {
	core.Controller
}

type ExportGetParams struct {
	StaffId int `json:"staff_id"`
}

/**
 * @api {get} /export/download 下载个人报告
 * @apiVersion 1.0.0
 * @apiGroup Region
 * @apiDescription 获取个人报告
 *
 * @apiParam {String} session session信息
 * @apiParam {Number} project_id 项目id
 * @apiParam {Number} staff_id 员工id
 * @apiParam {String} staff_name 员工名字
 * @apiParam {String} file_type 文件类型

 * @apiParamExample {json} Request-Example:
   {
		"session": "",
		"project_id": 1,
		"staff_id" 1,
		"staff_name": ""
		"file_type": "docx" | "pdf",

   }
 * @apiSuccess {Object} results 返回结果

 *
*/

func (*Export) Download(httpCtx *hfw.HTTPContext) {
	params := httpCtx.Request.URL.Query()

	//session := params.Get("session")
	projectIdStr := params.Get("project_id")
	staffIdStr := params.Get("staff_id")
	staffName := params.Get("staff_name")
	fileType := params.Get("file_type")
	//if session == "" {
	//	httpCtx.ThrowCheck(20144001, "session or projectID not empty")
	//}
	//httpCtx.ThrowCheck(20144001, VerifyRequestSession(httpCtx, &Session{
	//	SessionID: session,
	//}))
	if staffIdStr == "" || projectIdStr == "" || staffName == ""{
		httpCtx.ThrowCheck(20304001, "参数错误")
	}
	if fileType != "docx" && fileType != "pdf" {
		httpCtx.ThrowCheck(20304001, "参数错误")
	}
	staffId, err := strconv.Atoi(staffIdStr)
	httpCtx.ThrowCheck(20305000, err)
	projectId, err := strconv.Atoi(projectIdStr)
	httpCtx.ThrowCheck(20305000, err)
	interviewFinished := &interview.InterviewFinishedParams{
		ProjectId: projectId,
		StaffId:   staffId,
	}
	result := &ExportPersonalResult{}
	errNo, err := result.Get(interviewFinished)
	logger.Debugf("^^^^^^^^^^^:%#v", result)
	httpCtx.ThrowCheck(errNo, err)
	bufferData, err := buffer(fileType, result)
	if fileType == "docx" {
		httpCtx.ReturnFileContent("application/vnd.openxmlformats-officedocument.wordprocessingml.document",
			fmt.Sprintf("%s_个人报告_%v.docx", staffName, time.Now().Format("200601021504")), bufferData)
	} else {
		httpCtx.ReturnFileContent("application/pdf", fmt.Sprintf("%s_个人报告_%v.pdf", staffName,
			time.Now().Format("200601021504")), bufferData)
	}

}

type ExportPersonalResult struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    string `json:"data"`
}

func (p *ExportPersonalResult) Get(interviewFinished *interview.InterviewFinishedParams) (errNo int64, err error) {
	data, err := interviewFinished.Search()
	if err != nil {
		return 20305000, err
	}
	if len(data.FinishedInterviews) == 0 {
		return core.NoCompletedTests, fmt.Errorf("没有已完成的测评")
	}
	dataByte, err := encoding.JSON.Marshal(data)
	if err != nil {
		return 20305000, err
	}
	body := bytes.NewBuffer(dataByte)
	resp, err := http.Post(config.AppConfig.Custom["DhrExport"]+"/export/personal", "application/json", body)
	if err != nil {
		return 20305000, err
	}

	defer resp.Body.Close()
	bodys, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 20305000, err
	}

	err = encoding.JSON.Unmarshal(bodys, p)
	return 20305000, err
}

func buffer(fileType string, result *ExportPersonalResult) (bufferData *bytes.Buffer, err error) {
	if fileType == "docx" {

		reportBytes, err := encoding.Base64Decode(result.Data)
		if err != nil {
			return bufferData, err
		}
		bufferData = bytes.NewBuffer(reportBytes)
		return bufferData, err
	} else {

		p := api.NewPost("", "aspose2PDF")
		p.P = &struct {
			Base64File string `json:"base64File"`
			Ext        string `json:"ext"`
		}{
			Base64File: result.Data,
			Ext:        "docx",
		}
		pdfRes := &struct {
			Base64PDF string `json:"base64PDF"`
			PdfSize   int    `json:"pdfSize"`
		}{}
		err := api.SimpleCurl(nil, config.AppConfig.Custom["Trans"], p, &pdfRes)
		if err != nil {
			return bufferData, err
		}
		pdfBytes, err := encoding.Base64Decode(pdfRes.Base64PDF)
		if err != nil {
			return bufferData, err
		}
		bufferData := bytes.NewBuffer(pdfBytes)
		return bufferData, err
	}
}

/**
 * @api {post} /export/status 个人报告完成状态
 * @apiVersion 1.0.0
 * @apiGroup Region
 * @apiDescription 个人报告完成状态
 *
 * @apiParam {String} session session信息
 * @apiParam {Number} project_id 项目id
 * @apiParam {Number} staff_id 员工id

 * @apiParamExample {json} Request-Example:
   {
		"session": "",
		"project_id": 1,
		"staff_id" 1,

   }
 * @apiSuccess {Object} results 返回结果
	{
    	true/false
	}
 *
*/

type InterviewFinishedParams struct {
	*Session
	ProjectId int `json:"project_id"`
	StaffId   int `json:"staff_id"`
}

func (*Export) Status(httpCtx *hfw.HTTPContext) {
	params := &InterviewFinishedParams{}
	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &params))
	interviewFinished := interview.InterviewFinishedParams{StaffId:params.StaffId, ProjectId:params.ProjectId}
	data, err := interviewFinished.Search()
	httpCtx.ThrowCheck(20304001, err)
	if len(data.FinishedInterviews) > 0 {
		httpCtx.Results = true
	} else {
		httpCtx.Results = false
	}
}
