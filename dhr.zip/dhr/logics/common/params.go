package common

type GetResultParams struct {
	Id          int    `json:"id"`
	Uuid        string `json:"uuid"`
	InterviewId int    `json:"interview_id"`
	ActivityId  int    `json:"activity_id"`
	ProductId   int    `json:"product_id"`
	UserId      int    `json:"user_id"`
}
