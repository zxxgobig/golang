package interview

import (
	"fmt"
	"time"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw"

	"ifchange/dhr/logics/writedb"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

// 测评编号，与数据表 interviews 中的 id 保持一致
const IntvBei = 1                      // 素质
const IntvNormstar = 2                 // 性格
const IntvSkill = 3                    // 专业技能
const IntvKnowlege = 4                 // 专业知识
const IntvPotential = 5                // 潜力
const IntvWorkValues = 6               // 工作选择价值观
const IntvKeyExp = 7                   // 关键经历
const IntvEmotionalIntelligence = 8    // 情绪智力
const IntvCriticalThinking = 9         // 批判思维
const IntvPracticalIntelligence = 10   // 管理实践能力
const IntvOccupationalPersonality = 11 // 职业人格
const IntvPersonalityDisorder = 12     // 性格风险
const IntvLeadershipStyle = 13         // 领导风格
const IntvOrgCommitment = 14           // 组织忠诚度
const ManagementQuality = 21           // 8维管理素质测验

// 测评完成的status，与 staffs_interviews_details 对应
const interviewDone = 2

var professionalSkill IInterviews

func Init() {
	professionalSkill = new(ProfessionalSkill)
}

type WaitWriteDbList struct {
	WaitWriteDbs []*WaitWriteDb
}
type WaitWriteDb struct {
	TableName   string
	UpdateData  db.Cond
	UpdateWhere db.Cond
}

func Create(httpCtx *hfw.HTTPContext, projectID, companyID, dataCollectPlanId int) (err error) {
	dataCollectPlansUsers, err := GetDataCollectDemandStaffs(companyID, projectID, nil)
	if err != nil {
		return err
	}
	if len(dataCollectPlansUsers) == 0 {
		return fmt.Errorf("dataCollectPlansUsers is nil")
	}
	// 素质 潜力 normstar
	writeList := &writedb.WaitWriteDbList{}
	for _, dataCollectPlansUser := range dataCollectPlansUsers {
		emailUuid := ""
		for _, configItemParam := range dataCollectPlansUser.NoCompletedConfigItemParams {
			configParams := &Config{
				HttpCtx:           httpCtx,
				ProjectID:         projectID,
				StaffID:           dataCollectPlansUser.Staff.Id,
				Name:              dataCollectPlansUser.Staff.Name,
				Sex:               dataCollectPlansUser.Staff.Sex,
				Uuid:              "",
				CompanyID:         companyID,
				DataCollectPlanId: dataCollectPlanId,
				TimeStamp:         time.Now(),
			}
			if configItemParam.Id == IntvBei {
				if emailUuid != "" {
					configParams.EmailUuid = emailUuid
				}
				configParams.InterviewID = IntvBei

			} else if configItemParam.Id == IntvPotential {
				if emailUuid != "" {
					configParams.EmailUuid = emailUuid
				}
				configParams.InterviewID = IntvPotential

			} else if configItemParam.Id == IntvNormstar {
				configParams.InterviewID = IntvNormstar

			} else if configItemParam.Id == IntvWorkValues {
				if emailUuid != "" {
					configParams.EmailUuid = emailUuid
				}
				configParams.InterviewID = IntvWorkValues

			} else if configItemParam.Id == IntvKeyExp {
				if emailUuid != "" {
					configParams.EmailUuid = emailUuid
				}
				configParams.InterviewID = IntvKeyExp

			} else if configItemParam.Id >= 8 && configItemParam.Id <= 14 || configItemParam.Id == 21 {
				if emailUuid != "" {
					configParams.EmailUuid = emailUuid
				}
				configParams.InterviewID = configItemParam.Id
			} else {
				continue
			}
			inter := CreateInterview(configItemParam.Id)
			err = inter.SetConfig(configParams)
			if err != nil {
				return err
			}
			_, err = inter.Create(configItemParam.SubItems)
			if err != nil {
				return err
			}
			// 增加一条记录
			cdata := &models.StaffsInterviews{
				EmailUuid:     configParams.EmailUuid,
				Uuid:          configParams.Uuid,
				CompanyId:     companyID,
				ProjectId:     configParams.ProjectID,
				DataCollectId: configParams.DataCollectPlanId,
				StaffIds:      []int{},
				StaffId:       configParams.StaffID,
				InterviewId:   configParams.InterviewID,
			}
			w := &writedb.WaitWriteDb{
				Type:       "insert",
				TableName:  "staffs_interviews",
				InsertData: cdata,
			}

			writeList.WaitWriteDbs = append(writeList.WaitWriteDbs, w)
			// 添加ProjectsStaffsInterviewsDetails
			if len(configItemParam.SubItems) > 0 && configParams.InterviewID == IntvBei && isModeOneByProjectID(projectID){
				for i := 0; i < len(configItemParam.SubItems); i++ {
					cdata := &models.StaffsInterviewsDetails{
						ProjectId:     configParams.ProjectID,
						DataCollectId: configParams.DataCollectPlanId,
						StaffId:       configParams.StaffID,
						InterviewId:   configParams.InterviewID,
						SubItem:       configItemParam.SubItems[i].Id,
					}
					w := &writedb.WaitWriteDb{
						Type:       "insert",
						TableName:  "staffs_interviews_details",
						InsertData: cdata,
					}
					writeList.WaitWriteDbs = append(writeList.WaitWriteDbs, w)

				}
			}

			if configItemParam.Id == IntvBei || configItemParam.Id == IntvPotential ||
				configItemParam.Id == IntvKeyExp || configItemParam.Id == IntvWorkValues ||
				(configItemParam.Id >= 7 && configItemParam.Id <= 14) || configItemParam.Id == ManagementQuality {
				emailUuid = configParams.EmailUuid
			}
		}

	}

	leaderMap := map[int][]*DataCollectDemandStaff{}
	leader2StaffId := map[int][]int{}
	// 专业技能 专业知识
	for _, dataCollectPlansUser := range dataCollectPlansUsers {
		for _, x := range dataCollectPlansUser.NoCompletedConfigItemParams {
			if x.Id == IntvKnowlege || x.Id == IntvSkill {
				if _, ok := leaderMap[dataCollectPlansUser.Leader.ID]; ok {
					flag := true
					for i := 0; i < len(leaderMap[dataCollectPlansUser.Leader.ID]); i++ {
						if leaderMap[dataCollectPlansUser.Leader.ID][i] == dataCollectPlansUser {
							flag = false
							break
						}
					}
					if flag {
						leaderMap[dataCollectPlansUser.Leader.ID] = append(leaderMap[dataCollectPlansUser.Leader.ID], dataCollectPlansUser)
					}
				} else {
					leaderMap[dataCollectPlansUser.Leader.ID] = []*DataCollectDemandStaff{dataCollectPlansUser}
				}
			}
		}
	}

	for _, dataCollectPlansUser := range dataCollectPlansUsers {
		for _, x := range dataCollectPlansUser.NoCompletedConfigItemParams {
			if x.Id == IntvKnowlege || x.Id == IntvSkill {
				leader2StaffId[dataCollectPlansUser.Leader.ID] = append(leader2StaffId[dataCollectPlansUser.Leader.ID], dataCollectPlansUser.Staff.Id)
			}
		}
	}

	for k, _ := range leaderMap {
		dataCollectPlansUsers := leaderMap[k]
		var professionalSkill IInterviews
		professionalSkill = new(ProfessionalSkill)
		if dataCollectPlansUsers[0].Leader.ID == 0 {
			continue
		}
		configParams := &Config{
			ProjectID:         projectID,
			StaffID:           dataCollectPlansUsers[0].Leader.ID,
			Name:              dataCollectPlansUsers[0].Leader.Name,
			Sex:               dataCollectPlansUsers[0].Leader.Sex,
			Uuid:              "",
			InterviewID:       IntvSkill,
			CompanyID:         companyID,
			DataCollectPlanId: dataCollectPlanId,
			TimeStamp:         time.Now(),
		}

		professionalSkillConfig := &ProfessionalSkillConfig{
			DataCollectPlansUsers: dataCollectPlansUsers,
			Config:                configParams,
		}

		err = professionalSkill.SetConfig(professionalSkillConfig)
		if err != nil {
			return err
		}
		_, err := professionalSkill.Create(nil)
		if err != nil {
			return err
		}
		if len(dataCollectPlansUsers) < 1 {
			continue
		}

		// 增加一条记录
		cdata := &models.StaffsInterviews{
			EmailUuid:     configParams.EmailUuid,
			Uuid:          configParams.Uuid,
			CompanyId:     companyID,
			ProjectId:     configParams.ProjectID,
			DataCollectId: configParams.DataCollectPlanId,
			StaffIds:      leader2StaffId[configParams.StaffID],
			StaffId:       configParams.StaffID,
			InterviewId:   configParams.InterviewID,
		}
		w := &writedb.WaitWriteDb{
			Type:       "insert",
			TableName:  "staffs_interviews",
			InsertData: cdata,
		}

		writeList.WaitWriteDbs = append(writeList.WaitWriteDbs, w)

		for i := 0; i < len(dataCollectPlansUsers); i++ {
			for n := 0; n < len(dataCollectPlansUsers[i].NoCompletedConfigItemParams); n++ {
				for k := 0; k < len(dataCollectPlansUsers[i].NoCompletedConfigItemParams[n].SubItems); k++ {
					interviewID := dataCollectPlansUsers[i].NoCompletedConfigItemParams[n].Id
					if interviewID == 3 || interviewID == 4 {
						cdata := &models.StaffsInterviewsDetails{
							ProjectId:     configParams.ProjectID,
							DataCollectId: configParams.DataCollectPlanId,
							StaffId:       dataCollectPlansUsers[i].Id,
							InterviewId:   interviewID,
							SubItem:       dataCollectPlansUsers[i].NoCompletedConfigItemParams[n].SubItems[k].Id,
						}
						w := &writedb.WaitWriteDb{
							Type:       "insert",
							TableName:  "staffs_interviews_details",
							InsertData: cdata,
						}
						writeList.WaitWriteDbs = append(writeList.WaitWriteDbs, w)
					}
				}
			}
		}

	}
	err = writeList.WriteDb()
	// 链接包含信息：uuid
	return err
}

// Leader
type Leader struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Sex   int    `json:"sex"`
	Email string `json:"email"`
}

// GetInterviewsConfigsByProjectID 通过项目id获取测评配置
func GetInterviewsConfigsByProjectID(projectID int) (
	interviewConfigs []*models.ProjectsInterviewsConfigs, err error) {

	interviewConfigs, err =
		models.ProjectsInterviewsConfigsModel.Search(db.Cond{
			"is_deleted": 0,
			"project_id": projectID,
			"is_show":    models.SHOW,
		})
	if err != nil {
		err = common.NewRespErr(20305000, err)
		logger.Warn(err)
		return
	}

	return
}

// 获取有效的项目
func GetValidProject(companyId int, projectId int) (
	project *models.Projects, err error) {

	project, err = models.ProjectsModel.SearchOne(db.Cond{
		"company_id": companyId,
		"id":         projectId,
		"is_deleted": 0,
	})
	if err != nil {
		logger.Warn(err)
		return
	}
	if project == nil {
		err = fmt.Errorf("project not found: %d", projectId)
		err = common.NewRespErr(20304026, err)
		logger.Warn(err)
		return

	}
	return
}
