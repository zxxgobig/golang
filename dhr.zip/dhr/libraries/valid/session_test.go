package valid

import "testing"

const sess = "eyJib3RfaWQiOiIzMCIsImNvbXBhbnlfaWQiOiIxMjI5NjYiLCJkYXRhX3Blcm1pc3Npb24iOjIsImV4cGlyZSI6IjE1NzE4MjA5NDI3MzUiLCJmcm9tIjoiQiIsInBob25lIjoiMTc3NDA1Njg5ODkiLCJyb2xlX3R5cGUiOjIsInNyY19pZCI6IjEiLCJ0b2tlbiI6Ij09QWhsZnlJc1M2VzdnOSt4akhXQkdhcFVEUGg4VUhkOGc1WVhya1RnMzE3TjM5VnFLakJXQXNPMmtsRVBwUGJHMnRIUHZYYktLeHVHaXdXMnJ0QVJFKzciLCJ1c2VyX2lkIjoiMzU4OTMwIn0="

func TestVerifyAuthority(t *testing.T) {
	isPass, err := VerifyAuthority(sess, "bot_public")
	if err != nil {
		t.Error(err)
		return
	}
	t.Logf("TestVerifyAuthority status is %v", isPass)
}
