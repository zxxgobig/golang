package controllers

import (
	"fmt"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/logger"
	"gitlab.ifchange.com/dhr/kit/session"
	"ifchange/dhr/logics/data_collect"
	"time"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/interview"
	"ifchange/dhr/logics/position"
	"ifchange/dhr/logics/project"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
)

type Projects struct {
	core.Controller
}

/**
 * @api {post} /projects/list 项目列表
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目列表
 *
 * @apiParam {String} session session
 * @apiParam {String} key 关键词
 * @apiParam {[]int} position_ids 岗位名称
 * @apiParam {String} page page
 * @apiParam {String} page_size page_size
 * @apiParam {String} [filter] 过滤
 *
 * @apiParamExample {json} Request-Example:
 {
	"session": "",
	"key": "关键词",
	"position_ids":[1, 2, 3],
	"page": 1,
	"page_size": 20,
	"filter":"data_collect"
 }
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.total 项目总的条数
 * @apiSuccess {[]Object} results.list 项目列表
 * @apiSuccess {Number} results.list.id 项目 id
 * @apiSuccess {String} results.list.name 项目名称
 * @apiSuccess {String} results.list.position 岗位
 * @apiSuccess {Number} results.list.interview_users_count 测评用户数量
 * @apiSuccess {[]Object} results.list.finished_status 采集计划完成度详情
 * @apiSuccess {Number} results.list.finished_status.id 采集计划 id
 * @apiSuccess {String} results.list.finished_status.name 采集计划名称
 * @apiSuccess {Number} results.list.finished_status.rate 采集计划完成度
 * @apiSuccess {Number} results.list.finished_status_rate 项目完成度
 * @apiSuccess {Number} results.list.scene_id 场景 id
 * @apiSuccess {String} results.list.goal_desc 目标描述
 * @apiSuccess {String} results.list.start_at 开始时间
 * @apiSuccess {String} results.list.owner_username 项目所属账号用户名
 * @apiSuccess {Number} results.list.is_owned 是否为当前账号的项目 1：是； 2 不是
 * @apiSuccess {Number} results.list.role_type 是否是超管，1：是，2：不是
 * @apiSuccess {Number} results.list.report_id 版本ID
 *
 * @apiSuccessExample {json} Response-Example:

 {
    "total":1,
    "list":[
          {
			"id": 1,
			"name": "项目名字",
			"scene_id": "场景id",
			"position": "岗位被删除",
			"interview_users_count": 1000,
			"finished_status": [
				{
					"id": 1,
					"name": "这是一次牛逼的采集",
					"rate": 0.13
				}
			],
			"finished_status_rate": 0.13,
			"goal_desc": "目标描述",
			"start_at": "1560999235",
			"owner_username": "秦皓",
			"is_owned": 1,
            "role_type": 1,
			"report_id": 3,
		}
    ]
 }
 *
*/

type ProjectListResult struct {
	Id                  int                       `json:"id"`
	SceneId             int                       `json:"scene_id"`
	Name                string                    `json:"name"`
	Position            string                    `json:"position"`
	InterviewUsersCount int                       `json:"interview_users_count"`
	FinishedStatus      []*project.FinishedStatus `json:"finished_status"`
	FinishedStatusRate  float64                   `json:"finished_status_rate"`
	GoalDesc            string                    `json:"goal_desc"`
	StartAt             time.Time                 `json:"start_at"`
}

type ProjectListParams struct {
	*Session
	Token       string `json:"token"`
	CompanyID   int    `json:"company_id"`
	Key         string `json:"key"`
	PositionIds []int  `json:"position_ids"`
	Page        int    `json:"page"`
	PageSize    int    `json:"page_size"`
	Filter      string `json:"filter"`
}

func (c *Projects) List(httpCtx *hfw.HTTPContext) {
	params := &ProjectListParams{}
	err := api.RequestUnmarshal(httpCtx, &params)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, validate(params))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	sess, ok := httpCtx.Ctx.Value("session").(*session.Session)
	if !ok {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("参数错误"))
	}
	projectListParams := &project.GetProjectListParams{
		Session:        params.GetSessionID(),
		CompanyId:      sess.CompanyID,
		UserId:         sess.UserID,
		Key:            params.Key,
		PositionIds:    params.PositionIds,
		Page:           params.Page,
		PageSize:       params.PageSize,
		RoleType:       sess.RoleType,
		DataPermission: sess.DataPermission,
		RoleIds:        sess.RoleIds,
	}
	result, total, err := project.GetProjectList(httpCtx, projectListParams, params.Filter)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = ListResult{
		Total: total,
		List:  result,
	}
}

/**
 * @api {post} /projects/simple_list 纯项目信息的项目列表
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 纯项目信息的项目列表
 *
 * @apiParam {Number} company_id 公司 ID
 * @apiParam {String} token 校验 token
 * @apiParam {String} page page
 * @apiParam {String} page_size page_size
 *
 * @apiParamExample {json} Request-Example:
 {
	"company_id":122927,
	"token":"5f29e2d689d97b0b66e360a90c555ade",
	"page":1,
	"page_size":20
 }
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Number} results.total 项目总的条数
 * @apiSuccess {[]Object} results.list 项目列表
 * @apiSuccess {Number} results.list.id 项目 id
 * @apiSuccess {String} results.list.name 项目名称
 * @apiSuccess {String} results.list.company_id 所属公司 id
 * @apiSuccess {String} results.list.position_id 岗位 id
 * @apiSuccess {Number} results.list.position_industry_id 行业 id
 * @apiSuccess {[]Object} results.list.position_industry_id 职级 id
 * @apiSuccess {Number} results.list.position_level_id 职级 Level id
 * @apiSuccess {String} results.list.is_manager_position 是否管理岗位
 * @apiSuccess {Number} results.list.interview_users_count 被收集认识
 * @apiSuccess {Number} results.list.finished_status_rate 项目完成度
 * @apiSuccess {Number} results.list.scene_id 场景 id
 * @apiSuccess {String} results.list.goal_desc 目标描述
 * @apiSuccess {String} results.list.start_at 开始时间
 * @apiSuccess {String} results.list.is_deleted 是否删除
 *
 * @apiSuccessExample {json} Response-Example:
{
    "total":3,
    "list":[
        {
            "id":600,
            "company_id":122927,
            "user_id":192,
            "name":"形成分层级能力标准Demo",
            "scene_id":4,
            "scene_template_id":0,
            "position_id":16,
            "position_industry_id":514,
            "position_function_id":61411,
            "position_level_id":2,
            "is_manager_position":0,
            "interview_users_count":45,
            "complate_rate":0,
            "goal_desc":"形成分层级能力标准",
            "desc":"",
            "start_at":1566874535,
            "is_deleted":0,
            "updated_at":1571124721,
            "created_at":1566874535
        },
        {
            "id":598,
            "company_id":122927,
            "user_id":122927,
            "name":"任用晋升策略Demo",
            "scene_id":2,
            "scene_template_id":0,
            "position_id":16,
            "position_industry_id":514,
            "position_function_id":61411,
            "position_level_id":2,
            "is_manager_position":0,
            "interview_users_count":45,
            "complate_rate":0,
            "goal_desc":"任用晋升策略",
            "desc":"",
            "start_at":1566874535,
            "is_deleted":0,
            "updated_at":1577348388,
            "created_at":1566874535
        },
        {
            "id":597,
            "company_id":122927,
            "user_id":122927,
            "name":"人才发展Demo",
            "scene_id":1,
            "scene_template_id":0,
            "position_id":16,
            "position_industry_id":514,
            "position_function_id":61411,
            "position_level_id":2,
            "is_manager_position":0,
            "interview_users_count":45,
            "complate_rate":0,
            "goal_desc":"人才发展",
            "desc":"",
            "start_at":1566874535,
            "is_deleted":0,
            "updated_at":1577348388,
            "created_at":1566874535
        }
    ]
}
 *
*/
func (c *Projects) SimpleList(httpCtx *hfw.HTTPContext) {
	params := &ProjectListParams{}
	err := api.RequestUnmarshal(httpCtx, &params)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(params))

	companyID, err := CheckToken2(*params, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	projectListParams := &project.GetProjectListParams{
		CompanyId: companyID,
		Key:       params.Key,
		Page:      params.Page,
		PageSize:  params.PageSize,
	}
	result, total, err := project.GetProjectSimpleList(projectListParams)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = ListResult{
		Total: total,
		List:  result,
	}
}

//func (c *Projects) List(httpCtx *hfw.HTTPContext) {
//	param := struct {
//		*Session
//		Key         string `json:"key"`
//		PositionIds []int  `json:"position_ids"`
//		Page        int    `json:"page"`
//		PageSize    int    `json:"page_size"`
//	}{}
//	err := api.RequestUnmarshal(httpCtx, &param)
//	httpCtx.ThrowCheck(20304001, err)
//
//	httpCtx.ThrowCheck(20304001, validate(param))
//	// 验证session
//	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))
//
//	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
//	httpCtx.ThrowCheck(20304001, err)
//
//	projectL := project.NewProjects()
//	result, total, err := projectL.List(curUser.CompanyId, param.Key, param.PositionIds, param.Page, param.PageSize)
//	httpCtx.ThrowCheck(20304001, err)
//
//	_result := make([]ProjectListResult, 0, len(result))
//	if len(result) > 0 {
//		positionIDs := []int{}
//		for _, p := range result {
//			positionIDs = append(positionIDs, p.PositionId)
//		}
//		positions, err := dhr_staff.SysListWithInvalidPositionByIds(nil, curUser.CompanyId, positionIDs, false)
//		httpCtx.ThrowCheck(20304001, err)
//
//		for _, item := range result {
//			finishedStatus, err := projectL.GetFinishedStatus(item.Id)
//			httpCtx.ThrowCheck(20304001, err)
//
//			_result = append(_result, ProjectListResult{
//				Id:                  item.GetId(),
//				Name:                item.GetName(),
//				SceneId:             item.GetSceneId(),
//				Position:            GetPositionName(positions, item.GetPositionId()),
//				InterviewUsersCount: item.GetInterviewUsersCount(),
//				FinishedStatus:      finishedStatus,
//				FinishedStatusRate:  projectL.GetFinishedStatusTotal(finishedStatus),
//				GoalDesc:            item.GoalDesc,
//				StartAt:             item.StartAt,
//			})
//		}
//	}
//
//	httpCtx.Results = ListResult{
//		Total: total,
//		List:  _result,
//	}
//}

func GetPositionName(positions []*dhr_staff.Position, id int) (name string) {
	name = "岗位被删除"
	for _, p := range positions {
		if p.Id == id {
			name = p.Name
			return
		}
	}
	return
}

/**
 * @api {post} /projects/create 项目创建
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目创建
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} scene_id 场景id
 * @apiParam {Number} position_id 岗位id
 * @apiParam {String} name 名称
 * @apiParam {Number[]} staff_ids 员工列表
 * @apiParam {Number} industry_id 行业id
 * @apiParam {Number} position_function_id 职能id
 * @apiParam {Number} is_manager_position 是否是管理岗
 * @apiParam {Number} position_level_id 层级
 * @apiParam {String} start_at 开始时间
 * @apiParam {String} desc 目标描述
 * @apiParam {Object[]} interview_config_item_params 维度
 * @apiParam {Number} interview_config_item_params.id 大维度id
 * @apiParam {String} interview_config_item_params.name 大维度名称
 * @apiParam {Number} interview_config_item_params.sub_items.id 子维度id
 * @apiParam {String} interview_config_item_params.sub_items.enname 子维度key
 * @apiParam {String} interview_config_item_params.sub_items.name 子维度中文名
 * @apiParam {Object} interviews_configs 关键经历 和 工作选择价值观 两个测评的维度
 * @apiParam {Object} interviews_configs.work_values 工作选择价值观的二级维度 id 列表
 * @apiParam {Object} interviews_configs.key_expr.manage_expr 关键经历的管理经历的二级维度 id 列表
 * @apiParam {Object} interviews_configs.key_expr.business_expr 关键经历的业务经历的二级维度 id 列表
 *
 * @apiParamExample {json} Request-Example:
 {
   "session": "",
   "scene_id": 1,
   "position_id": 1,
   "name": "nice pro",
   "staff_ids": [
 	   1,
 	   2
   ],
   "industry_id": 1,
   "position_function_id": 1,
   "is_manager_position": 1,
   "position_level_id": 1,
   "start_at": "2019-06-05 15:04:05",
   "desc": "12334",
   "interview_config_item_params": [
 	   {
 		   "id": 1,
 		   "name": "bei",
 		   "sub_items": [
 			   {
 				   "id": 1,
 				   "enname": "active",
 				   "name": "积极主动"
 			   }
 		   ]
 	   }
   ],
   "interviews_configs": {
	   "work_values": [1,2,3],
	   "key_expr": {
		   "manage_expr": [1,2,3],
		   "business_expr": [1,2,3]
	   }
   }
 }
 *
 * @apiSuccess {Object} result 返回结果
 *
 * @apiSuccessExample {json} Response-Example:
{}
 *
*/
func (c *Projects) Create(httpCtx *hfw.HTTPContext) {
	param := struct {
		*project.ProjectCreateRequestParam
		*Session
	}{}
	_, err := ValidateAndUnMarshal(httpCtx, &param)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)
	sess, ok := (httpCtx.Ctx.Value("session")).(*session.Session)
	if !ok {
		httpCtx.ThrowCheck(20304001, fmt.Errorf("参数错误"))
	}
	logger.Debugf("-------------------------:%+v", sess)
	// 验证项目名称的业务要求
	err = param.ProjectCreateRequestParam.Validate(sess.CompanyID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.ThrowCheck(20304001, project.NewProjects().Create(models.Projects{
		CompanyId:          sess.CompanyID,
		UserId:             sess.UserID,
		Name:               param.Name,
		SceneId:            param.SceneId,
		PositionId:         param.PositionId,
		PositionIndustryId: param.IndustryId,
		PositionFunctionId: param.PositionFunctionId,
		IsManagerPosition:  param.IsManagerPosition,
		Desc:               param.Desc,
		PositionLevelId:    param.PositionLevelId,
		ComplateRate:       0,
		StartAt:            param.StartAt,
	}, param.InterviewConfigItemParams, param.InterviewConfigs, param.StaffIds))
}

/**
 * @api {post} /projects/delete 删除项目
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目列表
 *
 * @apiParam {String} session session
 * @apiParam {Number[]} project_id 需要删除的项目id
 *
 * @apiParamExample {json} Request-Example:
 {
	"session": "",
	"project_id": 1
 }
 *
 * @apiSuccess {Object} results 空
 *
 * @apiSuccessExample {json} Response-Example:

 {
	 "results": {}
 }
 *
*/
func (c *Projects) Delete(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID int `json:"project_id" validate:"required"`
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)
	err = project.NewProjects().Delete(curUser.CompanyId,
		params.ProjectID)
	httpCtx.ThrowCheck(20305000, err)
}

/**
 * @api {post} /projects/edit 更新项目
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 更新项目，目前只支持重命名
 *
 * @apiParam {String} session session
 * @apiParam {Number} project_id 项目ID
 * @apiParam {String} name 新的项目名称
 *
 * @apiParamExample {json} Request-Example:
 {
	"session": "",
	"project_id": 1,
	"name": "xxx",
 }
 *
 * @apiSuccess {Object} results 操作成功则为空
 *
 * @apiSuccessExample {json} Response-Example:

 {
	 "results": {}
 }
 *
*/
func (c *Projects) Edit(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID int    `json:"project_id"`
		Name      string `json:"name"`
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)

	err = project.NewProjects().Edit(curUser.CompanyId,
		params.ProjectID, params.Name)

	httpCtx.ThrowCheck(20305000, err)
}

/**
 * @api {post} /projects/interview_config_items_recommend 推荐维度
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 推荐维度
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} position_function_id 职能id
 * @apiParam {Number} position_level_id 职位层级id
 * @apiParam {Number} scene_id 场景id
 *
 * @apiParamExample {json} Request-Example:
 {
	"session": "",
	"position_function_id": 1,
	"position_level_id": 1
	"scene_id": 1,
 }
 *
 * @apiSuccess {Object} results.id 大维度id
 * @apiSuccess {Object} results.name 大维度名称
 * @apiSuccess {Object} results.sub_items.id 子维度名称
 * @apiSuccess {Object} results.sub_items.enname 子维度名称
 * @apiSuccess {Object} results.sub_items.name 子维度名称
 * @apiSuccess {Object} results.sub_items.editable 是否可以编辑
 * @apiSuccess {Object} results.sub_items.is_must 是否必选
 * @apiSuccess {Object} results.sub_items.max_subitems 子维度的最大数量限制.如果是0, 表示不需要子维度.
 *
 * @apiSuccessExample {json} Response-Example:
[
    {
        "id":1,
        "name":"bei",
		"editable": 1,
		"max_subitems": 3,
		"is_must": 1,
        "sub_items":[
            {
                "id":1,
                "enname":"active",
                "name":"积极主动"
            }
        ]
    }
]
*/
func (c *Projects) InterviewConfigItemsRecommend(httpCtx *hfw.HTTPContext) { // 参数中有场景id，所以必须要返回1级维度是否必选
	param := struct {
		*Session
		PositionFunctionId int `json:"position_function_id" validate:"required"`
		PositionLevelId    int `json:"position_level_id" validate:"required"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &param)
	httpCtx.ThrowCheck(20304001, validate(param))
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.Results, err = interview.NewInterviews().
		ConfigItemsRecommend(param.PositionFunctionId, param.PositionLevelId)
	httpCtx.ThrowCheck(20304001, err)
	return
}

/**
* @api {post} /projects/interview_config_items 测评全维度列表
* @apiVersion 0.1.0
* @apiGroup Projects
* @apiDescription 测评全维度列表 ,
*
* @apiParam {String} session 身份认证 Session
* @apiParam {int} interview_id 维度编号 1:素质; 2:性格; 3:专业技能; 4:专业知识; 5:潜力; 6:工作选择价值观, 7: 关键经历） 不填写为全维度
*
* @apiParamExample {json} Request-Example:
{
	"session": "",
    "interview_id":1
}
*
* @apiSuccess {Object} results.id 大维度(测评)id
* @apiSuccess {Object} results.name 大维度(测评)名称
* @apiSuccess {Object} results.max_subitems 子维度的最大数量限制. 如果是0, 表示不需要子维度(该接口用不上)
* @apiSuccess {Object} results.editable 是否可以编辑, 1:可以; 0:不可以）
* @apiSuccess {Object} results.desc 维度描述信息
* @apiSuccess {Object} results.sub_items.id 子维度名称
* @apiSuccess {Object} results.sub_items.enname 子维度名称
* @apiSuccess {Object} results.sub_items.name 子维度名称
* @apiSuccess {Object} results.sub_items.class 子维度分类，1 标记为管理经理的子维度; 0 表示普通子维度
*
* @apiSuccessExample {json} Response-Example:
[
	{
		"id": 1,
		"name": "bei",
		"max_subitems" 1,
		"editable": 1,
		"desc": "•潜力是对于员工长期自我发展而言较为重要的核心特质和驱动力；<br>•E成认为潜力最核心的四大方面包括：“敏锐学习能力”、“跨界思考能力”、“人际感知能力”和“情感管理能力”",
		"sub_items": [
			{
				"id": 1,
                "enname": "active",
			    "name": "积极主动"
				"class": 0,
			}
		]
	}
]
*/

func (c *Projects) InterviewConfigItems(httpCtx *hfw.HTTPContext) {
	param := struct {
		*Session
		InterviewID int `json:"interview_id"`
	}{}

	curUser, err := ValidateAndUnMarshal(httpCtx, &param)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	httpCtx.Results, err = interview.NewInterviews().ConfigItems(curUser.CompanyId, param.InterviewID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
	return
}

/**
 * @api {post} /projects/detail 项目详情
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
 {
	 "session": ""
	 "project_id": 4
 }
 *
 * @apiSuccess {Number} results.id 项目id
 * @apiSuccess {Object} results.position 岗位信息
 * @apiSuccess {Object} results.position_industry 行业信息
 * @apiSuccess {Object} results.position_function 职能信息
 * @apiSuccess {Object} results.reports 报告
 * @apiSuccess {Object} results.goal_desc 目标
 * @apiSuccess {Object} results.desc 描述
 * @apiSuccess {Object} results.is_manager_position 是否是管理岗 0否 1是
 * @apiSuccess {Object} results.position_level 目标登记
 * @apiSuccess {Object} results.created_at 创建时间
 *
 * @apiSuccessExample {json} Response-Example:
{
	"id": 4,
	"position": {
		"id": 1,
		"company_id": 1,
		"name": "todo岗位",
		"is_deleted": 0,
		"created_at": "0001-01-01T00:00:00Z",
		"updated_at": "0001-01-01T00:00:00Z"
	},
	"position_industry": {
		"id": 2,
		"name": "互联网",
		"parent_id": 1,
		"depth": 2,
		"p1": 1,
		"p2": 0,
		"p3": 0,
		"p4": 0,
		"is_deleted": 0,
		"updated_at": "2019-06-05T14:58:45+08:00",
		"created_at": "2019-06-05T14:58:45+08:00"
	},
	"position_function": {
		"id": 61383,
		"function_id": 2200001,
		"name": "产品研发",
		"parent_id": 1200001,
		"depth": 2,
		"is_deleted": 0,
		"updated_at": "2019-06-05T14:47:51+08:00",
		"created_at": "2019-06-05T14:47:51+08:00"
	},
	"position_level": {
		"id": 1,
		"name": "总经理/权威",
		"is_deleted": 0,
		"updated_at": "2019-06-05T11:12:01+08:00",
		"created_at": "2019-06-05T11:12:02+08:00"
	},
	"goal_desc": "12334",
	"scene_id": 1,
	"is_manager_position": 1,
    "desc": "12334",
	"reports": [
		{
			"id": 2,
			"name": "采集计划特拉斯",
			"project_id": 4,
			"complate_users_count": 12,
			"high_efficienct_users_count": 13,
			"low_efficienct_users_count": 20,
			"is_deleted": 0,
			"updated_at": "2019-06-10T16:32:57+08:00",
			"created_at": "2019-06-04T13:12:47+08:00"
		},
		{
			"id": 0,
			"name": "nice pro最新采集计划",
			"project_id": 4,
			"complate_users_count": 0,
			"high_efficienct_users_count": 0,
			"low_efficienct_users_count": 0,
			"is_deleted": 0,
			"updated_at": "0001-01-01T00:00:00Z",
			"created_at": "0001-01-01T00:00:00Z"
		}
	],
	"created_at": "2019-06-10T15:18:53+08:00"
}
 *
*/
func (c *Projects) Detail(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectID int `json:"project_id" validate:"required"`
	}{}

	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	httpCtx.ThrowCheck(20304001, validate(param))

	p, err := project.NewProjects().Detail(param.ProjectID)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = p
}

/**
 * @api {post} /projects/proj_positions 项目下的岗位列表
 * @apiVersion 0.1.0
 * @apiGroup positions
 * @apiDescription 采集计划页面岗位列表
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} project_id 项目 ID
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_id": 1,
		}
	}
 *
 *
 * @apiSuccess {Object[]} result.list 岗位列表
 * @apiSuccess {Number} result.list.id 岗位 id
 * @apiSuccess {Number} result.list.company_id 公司 id
 * @apiSuccess {String} result.list.name 岗位名称
 * @apiSuccess {Number} result.list.is_deleted 是否删除
 * @apiSuccessExample {json} Response-Example:

{
	"results": {
		"list": [
			{
				"id": 1,
				"company_id": 1,
				"name": "前端开发工程师",
				"is_deleted": 0,
				"created_at" "2019-06-05T11:12:01+08:00",
				"updated_at" "2019-06-05T11:12:01+08:00",
			},{
				"id": 2,
				"company_id": 1,
				"name": "后端开发工程师",
				"is_deleted": 0,
				"created_at" "2019-06-05T11:12:01+08:00",
				"updated_at" "2019-06-05T11:12:01+08:00",
			}
		]
	}

}
 *
*/
func (c *Projects) ProjPositions(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID int `json:"project_id" validate:"required"`
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(20305000, err)

	ps, err := project.NewProjects().GetPositionsByCompanyID(
		curUser.CompanyId)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = map[string]interface{}{
		"list": ps,
	}
}

/**
 * @api {post} /projects/positions 公司所有项目的岗位列表
 * @apiVersion 0.1.0
 * @apiGroup positions
 * @apiDescription 盘点列表页面下，职位列表
 *
 * @apiParam {String} session 约定的 session
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
		}
	}
 *
 *
 * @apiSuccess {Object[]} result.list 岗位列表
 * @apiSuccess {Number} result.list.id 岗位 id
 * @apiSuccess {Number} result.list.company_id 公司 id
 * @apiSuccess {String} result.list.name 岗位名称
 * @apiSuccess {Number} result.list.is_deleted 是否删除
 * @apiSuccessExample {json} Response-Example:

{
	"results": {
		"list": [
			{
				"id": 1,
				"company_id": 1,
				"name": "前端开发工程师",
				"is_deleted": 0,
				"created_at" "1560999235",
				"updated_at" "1560999235",
			},{
				"id": 2,
				"company_id": 1,
				"name": "后端开发工程师",
				"is_deleted": 0,
				"created_at" "1560999235",
				"updated_at" "1560999235",
			}
		]
	}

}
 *
*/
func (c *Projects) Positions(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	ps, err := position.GetProjectsPositions(curUser.CompanyId)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = map[string]interface{}{
		"list": ps,
	}
}

/**
 * @api {post} /projects/list_by_staff 用户参与的盘点列表
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 用户的盘点列表
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} staff_id 员工id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"staff_id": 1
		}
	}
 *
 *
 * @apiSuccess {Object[]} result.list 岗位列表
 * @apiSuccess {Number} result.list.id 项目 id
 * @apiSuccess {Number} result.list.name 岗位名称
 * @apiSuccess {Number} result.list.created_at 创建时间
 * @apiSuccessExample {json} Response-Example:
 [
	{
		"id": 4,
		"company_id": 109,
		"user_id": 109,
		"name": "nice pro",
		"scene_id": 1,
		"position_id": 1,
		"position_industry_id": 2,
		"position_function_id": 2200001,
		"position_level_id": 1,
		"is_manager_position": 1,
		"interview_users_count": 2,
		"complate_rate": 0,
		"goal_desc": "12334",
		"start_at": "2019-06-05T15:04:05+08:00",
		"is_deleted": 0,
		"updated_at": "2019-06-10T15:18:53+08:00",
		"created_at": "2019-06-10T15:18:53+08:00"
	}
 ]
 *
*/
func (c *Projects) ListByStaff(httpCtx *hfw.HTTPContext) {
	param := struct {
		*Session
		StaffId  int `json:"staff_id"`
		Page     int `json:"page"`
		PageSize int `json:"page_size"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &param)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(param))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	result, total, err := project.NewProjects().ListByStaffId(curUser.CompanyId, param.StaffId, param.Page, param.PageSize)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.Results = ListResult{
		Total: total,
		List:  result,
	}
}

/**
 * @api {post} /projects/notice 项目提示信息
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目提示信息
 *
 * @apiParam {String} session 员工 session
 * @apiParam {Number} project_id 项目 id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_id": 1
		}
	}
 *
 *
 * @apiSuccess {Object[]} result 提示信息
 * @apiSuccess {Number} result.perform_staff_count 绩效员工总
 * @apiSuccess {Number} result.perform_staff_lack_count 缺少绩效员工数
 * @apiSuccess {Number} result.data_collect_staff_lack_count 缺少测评员工数
 * @apiSuccess {Object[]} result.data_collect_plans 采集计划列表
* @apiSuccess {Number} result.data_collect_plans.status 采集计划列表(1待采集，2采集中，3已完成，4暂停，5结束，6删除)

 * @apiSuccessExample {json} Response-Example:
 {
	"perform_staff_count": 100,
	"perform_staff_lack_count": 50,
	"data_collect_staff_lack_count": 40,
	"data_collect_plans": [
		{
			"id": 3,
			"project_id": 4,
			"name": "一次采集",
			"start_time": "0001-01-01T00:00:00+08:00",
			"end_time": "0001-01-01T00:00:00+08:00",
			"status": 1,
			"is_deleted": 0,
			"updated_at": "2019-06-11T19:22:50+08:00",
			"created_at": "2019-06-10T16:31:57+08:00"
		}
	]
}
 *
*/
func (c *Projects) Notice(httpCtx *hfw.HTTPContext) {

	param := struct {
		*Session
		ProjectId int `json:"project_id" validate:"required"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &param)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(param))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	result, err := project.NewProjects().GetNotice(curUser.CompanyId, param.ProjectId)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.Results = result

}

/**
 * @api {post} /projects/check  项目命名检查
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目命名合法性检查
 *
 * @apiParam {String} session 员工 session
 * @apiParam {String} project_name 项目名称
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
			"project_name": "测试项目1"
		}
	}
 *
 *
 * @apiSuccess {Object[]} result 结果
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results": {}
}
 *
*/
func (c *Projects) Check(httpCtx *hfw.HTTPContext) {
	params := struct {
		*Session
		ProjectName string `json:"project_name" validate:"required"`
	}{}

	curUser, err := ValidateAndUnMarshal(httpCtx, &params)
	httpCtx.ThrowCheck(core.RequestError, err)

	count, err := project.GetCountByProjectName(curUser.CompanyId, params.ProjectName)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	if count > 0 {
		err = fmt.Errorf("duplicate project name: <%+v>", params.ProjectName)
		httpCtx.ThrowCheck(core.ProjectNameDuplicate, err)
	} else {
		httpCtx.Results = nil
	}
}

/**
 * @api {post} /projects/workvalues  工作选择价值观维度获取
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 工作选择价值观维度获取
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} industry_id 行业 id
 * @apiParam {Number} position_function_id 职能 id
 * @apiParam {Number} position_level_id 职位层级id
 * @apiParam {Number} scene_id 场景 id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
		    "industry_id": 1,
		    "position_function_id": 1,
		    "position_level_id": 1,
		    "scene_id": 1,
		}
	}
 *
 *
 * @apiSuccess {Object[]} result 结果
 * @apiSuccess {Number} results.is_must 是否必填，1必填；0不必填
 * @apiSuccess {Number} results.sub_items 全量二级维度列表
 * @apiSuccess {Number} results.recommend_sub_items 推荐二级维度列表
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results": {
		 "is_must": 0,
		 "sub_items": [
		     {
                  "id": 1,
				  "enname": "",
				  "name": "",
			 }
		 ],
		 "recommend_sub_items": [
		     {
                  "id": 1,
				  "enname": "",
				  "name": "",
			 }
		 ]
	 }
}
 *
*/
func (ctl *Projects) WorkValues(httpCtx *hfw.HTTPContext) {
	params := struct {
		*Session
		IndustryID         int `json:"industry_id" validate:"required"`
		PositionFunctionID int `json:"position_function_id" validate:"required"`
		PositionLevelID    int `json:"position_level_id" validate:"required"`
		SceneID            int `json:"scene_id" validate:"required"`
	}{}

	_, err := ValidateAndUnMarshal(httpCtx, &params)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	workValues := interview.NewWorkValues()

	recommendSubItems, err := workValues.GetRecommendSubItems(
		params.IndustryID, params.PositionFunctionID,
		params.PositionLevelID, params.SceneID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	subItems, err := workValues.GetAllSubItems(
		params.IndustryID, params.PositionFunctionID,
		params.PositionLevelID, params.PositionFunctionID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	isMust := workValues.GetIsMust()

	httpCtx.Results = map[string]interface{}{
		"is_must":             isMust,
		"sub_items":           subItems,
		"recommend_sub_items": recommendSubItems,
	}
}

/**
 * @api {post} /projects/key_expr  关键经历
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 关键经历维度获取
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} industry_id 行业 id
 * @apiParam {Number} position_function_id 职能 id
 * @apiParam {Number} position_level_id 职位层级id
 * @apiParam {Number} scene_id 场景 id
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
		    "industry_id": 1,
		    "position_function_id": 1,
		    "position_level_id": 1,
		    "scene_id": 1,
		}
	}
 *
 *
 * @apiSuccess {Object[]} result 结果
 * @apiSuccess {Number} results.is_must 是否必填，1必填；0不必填
 * @apiSuccess {Number} results.sub_items 全量二级维度列表
 * @apiSuccess {Number} results.recommend_sub_items 推荐二级维度列表
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results": {
		 "is_must": 0,
		 "manage_expr": {
			 "is_must": 1,
			 "sub_items": [
				 {
					  "id": 1,
					  "enname": "",
					  "name": "",
				 }
			 ],
			 "recommend_sub_items": [
				 {
					  "id": 1,
					  "enname": "",
					  "name": "",
				 }
			 ]
		 },
		 "business_expr": {
			 "is_must": 0,
			 "sub_items": [
				 {
					  "id": 1,
					  "enname": "",
					  "name": "",
				 }
			 ],
			 "recommend_sub_items": [
				 {
					  "id": 1,
					  "enname": "",
					  "name": "",
				 }
			 ]
		 }
	 }
}
 *
*/
func (ctl *Projects) KeyExpr(httpCtx *hfw.HTTPContext) {
	params := struct {
		*Session
		IndustryID         int `json:"industry_id" validate:"required"`
		PositionFunctionID int `json:"position_function_id" validate:"required"`
		PositionLevelID    int `json:"position_level_id" validate:"required"`
		SceneID            int `json:"scene_id" validate:"required"`
	}{}

	_, err := ValidateAndUnMarshal(httpCtx, &params)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	keyExpr := &interview.KeyExp{}
	manageExpr, businessExpr, err := keyExpr.GetAllSubItems(params.IndustryID, params.PositionFunctionID,
		params.PositionLevelID, params.SceneID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = map[string]interface{}{
		"is_must":       0,
		"manage_expr":   manageExpr,
		"business_expr": businessExpr,
	}
}

/**
 * @api {post} /projects/get_inventory_data 获取测评盘点数据
 * @apiVersion 0.1.0
 * @apiGroup AutoHome
 * @apiDescription 获取测评盘点数据
 *
 * @apiParam {String} token 固定值(e成提供)
 * @apiParam {Number} project_id 项目ID
 * @apiParam {[]Number} interview_ids 测评ids
 * @apiParamExample {json} Request-Example:
 {
    "header":{
        "appid":43,
        "log_id":"",
        "uid":"",
        "uname":"",
        "provider":"dhr_autohome",
        "signid":"",
        "version":"",
        "ip":""
    },
    "request":{
        "p":{
                "token":"",
                "project_id":1,
                "interview_ids":[
                    6,
                    8,
                    14
                ]
        }
    }
}
 * @apiSuccess {Number} project_id 项目ID
 * @apiSuccess {String} project_name 项目名称
 * @apiSuccess {[]Object} inventories 测评列表
 * @apiSuccess {String} inventories.staff_no 员工工号
 * @apiSuccess {String} inventories.staff_name 员工姓名
 * @apiSuccess {Number} inventories.interview_id 测评ID
 * @apiSuccess {String} inventories.interview_name 测评名称
 * @apiSuccess {String} inventories.finish_time 完成时间
 * @apiSuccess {[]Object} inventories.first_list 一级纬度列表
 * @apiSuccess {String} inventories.first_list.name 一级名称
 * @apiSuccess {Number} inventories.first_list.score 一级得分(注意可能是小数)
 * @apiSuccess {String} inventories.first_list.explain 一级得分解读
 * @apiSuccess {String} inventories.first_list.self_explain 自定义说明
 * @apiSuccess {[]Object} inventories.first_list.second_list 二级纬度列表
 * @apiSuccess {String} inventories.first_list.second_list.name 名称
 * @apiSuccess {Number} inventories.first_list.second_list.score 得分(注意可能是小数)
 * @apiSuccess {String} inventories.first_list.second_list.explain 解读
 * @apiSuccessExample {json} Response-Example:
 {
    "header":{
        "appid":43,
        "log_id":"dev",
        "uid":"",
        "uname":"",
        "provider":"dhr_autohome",
        "signid":"",
        "version":"",
        "ip":""
    },
    "response":{
        "err_no":0,
        "err_msg":"",
        "results":{
            "project_id":1,
            "project_name":"",
            "inventories":[
                {
                    "interview_id":6,
                    "staff_no": "staffNo",
                    "staff_name":"张三",
                    "interview_name":"驱动力测评",
                    "finish_time":"2020-01-17 14:30:56",
                    "first_list":[
                        {
                            "name":"兴趣特长",
                            "explain":"这里是价值观：兴趣特长的解释说明"
                        },
                        {
                            "name":"自由独立",
                            "explain":"这里是价值观：自由独立的解释说明"
                        },
                        {
                            "name":"人际关系",
                            "explain":"这里是价值观：人际关系的解释说明"
                        },
                        {
                            "name":"组织需要",
                            "explain":"这里是价值观：组织需要的解释说明"
                        }
                    ]
                },
                {
                    "interview_id":7,
                    "staff_no": "staffNo",
                    "staff_name":"张三",
                    "interview_name":"关键经历测评",
                    "finish_time":"2020-01-17 14:30:56",
                    "first_list":[
                        {
                            "name":"团队主管经历",
                            "explain":"这里是官方解释",
                            "self_explain":"这里是员工自定义说明"
                        },
                        {
                            "name":"无管理经历",
                            "explain":"这里是官方解释",
                            "self_explain":"这里是员工自定义说明"
                        },
                        {
                            "name":"多业态管理",
                            "explain":"这里是官方解释",
                            "self_explain":"这里是员工自定义说明"
                        },
                        {
                            "name":"海外经历",
                            "explain":"这里是官方解释",
                            "self_explain":"这里是员工自定义说明"
                        }
                    ]
                },
                {
                    "interview_id":2,
                    "staff_no": "staffNo",
                    "staff_name":"张三",
                    "interview_name":"性格测评",
                    "finish_time":"2020-01-17 14:30:56",
                    "first_list":[
                        {
                            "name":"自觉自律",
                            "score":8,
                            "explain":"这里是得分解读"
                        },
                        {
                            "name":"创新精神",
                            "score":4,
                            "explain":"这里是得分解读"
                        },
                        {
                            "name":"关心他人",
                            "score":8,
                            "explain":"这里是得分解读"
                        },
                        {
                            "name":"沟通意识",
                            "score":7,
                            "explain":"这里是得分解读"
                        }
                    ]
                },
                {
                    "interview_id":8,
                    "staff_no": "staffNo",
                    "staff_name":"张三",
                    "interview_name":"情绪智力测评",
                    "finish_time":"2020-01-17 14:30:56",
                    "first_list":[
                        {
                            "name":"评价情绪",
                            "score":3,
                            "second_list":[
                                {
                                    "name": "评价他人的情绪",
                                    "score":5,
                                    "explain":"这里是得分解读"
                                },
                                {
                                    "name": "评价自己的情绪",
                                    "score":7,
                                    "explain":"这里是得分解读"
                                }
                            ]
                        },
                        {
                            "name":"觉知情绪",
                            "score":5,
                            "second_list":[
                                {
                                    "name": "觉知自己的情绪",
                                    "score":5,
                                    "explain":"这里是得分解读"
                                },
                                {
                                    "name": "人际洞察",
                                    "score":7,
                                    "explain":"这里是得分解读"
                                }
                            ]
                        }
                    ]
                },
                {
                    "interview_id":11,
                    "staff_no": "staffNo",
                    "staff_name":"张三",
                    "interview_name":"职业人格",
                    "finish_time":"2020-01-17 14:30:56",
                    "first_list":[
                        {
                            "name":"责任意识",
                            "score":3,
                            "second_list":[
                                {
                                    "name":"计划",
                                    "score": 3,
                                    "explain":"这里是得分解读"
                                },
                                {
                                    "name":"自律",
                                    "score": 6,
                                    "explain":"这里是得分解读"
                                },
                                {
                                    "name":"负责",
                                    "score": 7,
                                    "explain":"这里是得分解读"
                                }
                            ]
						}
                    ]
                },
                {
                    "interview_id":14,
                    "staff_no": "staffNo",
                    "staff_name":"张三",
                    "interview_name":"组织忠诚测评",
                    "finish_time":"2020-01-17 14:30:56",
                    "first_list":[
                        {
                            "name":"价值认同",
                            "score":7,
                            "explain":"这里是得分解读"
                        },
                        {
                            "name":"情感投入",
                            "score":9,
                            "explain":"这里是得分解读"
                        },
                        {
                            "name":"理想承诺",
                            "score":5,
                            "explain":"这里是得分解读"
                        },
                        {
                            "name":"敬业奉献",
                            "score":8,
                            "explain":"这里是得分解读"
                        }
                    ]
                }
            ]
        }
    }
}
 *
*/
func (ctl *Projects) GetInventoryData(httpCtx *hfw.HTTPContext) {
	params := struct {
		Token        string `json:"token"`
		ProjectId    int    `json:"project_id"`
		InterviewIds []int  `json:"interview_ids"`
	}{}

	err := api.RequestUnmarshal(httpCtx, &params)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	results, err := project.GetInventoryData(params.ProjectId, params.InterviewIds)
	httpCtx.ThrowCheck(core.SystemErrNo, err)
	httpCtx.Results = results
}

/**
 * @api {post} /projects/is_data_collect_completed 采集计划是否已经完成
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 采集计划是否已经完成
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} project_id 项目 id
 *
 * @apiParamExample {json} Request-Example:
	{
		"session":"",
		"project_id": 1
	}
 *
 *
 * @apiSuccess {Boolean} completed 已完成为 true，否则为 false
 * @apiSuccessExample {json} Response-Example:
	{
		"completed":true
	}
 *
*/
func (plan *Projects) IsDataCollectCompleted(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID int `json:"project_id"`
	}{}

	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, params))
	// 验证session
	httpCtx.ThrowCheck(20304001, validate(params))
	err := VerifyRequestSession(httpCtx, params)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	completed, err := data_collect.NewDataCollectPlan().IsCompleted(params.ProjectID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = map[string]interface{}{
		"completed": completed,
	}
}
