package controllers

import (
    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"

    "ifchange/dhr/core"
    v2_scene "ifchange/dhr/logics/v2/scene"
)

/**
 * @api {post} /v2_project/scene_list 基础数据 - 场景列表
 * @apiVersion 0.1.0
 * @apiGroup API_V2_Project
 * @apiDescription 场景列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": ""
	}
 *
 * @apiSuccess {Object} results 返回结果
 * @apiSuccess {Object[]} results.list 列表
 * @apiSuccess {Number} results.list.id 场景 ID
 * @apiSuccess {String} results.list.name 场景名称
 * @apiSuccess {String} results.list.desc 场景描述
 * @apiSuccess {String} results.list.goal 盘点目标
 * @apiSuccess {String} results.list.icon 场景图标
 * @apiSuccess {String} results.list.recommend 推荐维度
 * @apiSuccess {String} results.list.cover 场景配图
 * @apiSuccess {Object[]} results.list.templates 场景模版列表
 * @apiSuccess {Number} results.list.templates.id 场景模版 ID
 * @apiSuccess {String} results.list.templates.name 场景模版名称
 * @apiSuccess {String} results.list.templates.desc 场景模版描述
 * @apiSuccess {String} results.list.templates.icon 场景模版图标
 * @apiSuccess {String} results.list.templates.cover 场景模版配图
 * @apiSuccess {Number} results.list.templates.function_id 职能 ID
 * @apiSuccess {Number} results.list.templates.function_name 职能名称
 * @apiSuccess {Number} results.list.templates.level_id 层级 ID
 * @apiSuccess {Boolean} results.list.templates.is_manager 是否管理岗
 * @apiSuccess {Number} results.list.templates.scene_id 场景 ID
 *
 * @apiSuccessExample {json} Response-Example:
    {
        "list": [
            {
                "id": 1,
                "name": "人才发展建议",
                "desc": "为您找出员工群体和个人的关键能力缺口<br />使得您的培训与发展更有针对性",
                "goal": "通过对员工个人以及不同员工群体的能力长短板扫描，为您找出员工群体和个人的关键能力缺口，并相应提供丰富多样的群体和个人发展建议，包括个人反思、教练辅导、行动学习、书籍阅读和参与培训等方式，使得您的培训与发展更有针对性",
                "icon": "https://uimg.ifchange.com/toc/dhr_scene_1.png",
                "recommend": "必选：专业知识技能；素质；绩效 <br />\r\n可选：性格；潜力；关键经历； 工作选择价值观",
                "cover": "ttps://uimg.ifchange.com/toc/dhr_scene_cover_1.png",
                "templates": [
                    {
                        "id": 1,
                        "name": "店长人才盘点",
                        "desc": "通过对被盘点的店长岗位的人才分布结构的分析，以及基于人才九宫格的人才聚类分析，让您对各店长的综合能力及绩效结果一目了然，同时对店长岗位的人才梯队建设给出针对性的建议，为您排兵布阵提供重要的决策参考。",
                        "icon": "https://uimg.ifchange.com/toc/dhr_scene_template_4.png",
                        "cover": "https://uimg.ifchange.com/toc/dhr_scene_template_cover_4.png",
                        "function_id": 61409,
                        "function_name": "零售店长",
                        "level_id": 4,
                        "is_manager": 1,
                        "scene_id": 1
                    }
                ]
            },
            {
                "id": 2,
                "name": "人才结构扫描",
                "desc": "对团队人才的能力、绩效现状进行扫描，<br />为您团队的排兵布阵提供参考",
                "goal": "通过对被盘点的员工群体中人才分布结构的分析，以及基于人才九宫格的人才聚类分析，给出针对性建议，为您排兵布阵提供决策参考",
                "icon": "https://uimg.ifchange.com/toc/dhr_scene_2.png",
                "recommend": "必选：专业知识技能；素质；绩效 <br />\r\n可选：性格；潜力；关键经历； 工作选择价值观",
                "cover": "ttps://uimg.ifchange.com/toc/dhr_scene_cover_2.png"
            },
            {
                "id": 3,
                "name": "高潜人才识别",
                "desc": "帮助您找到组织中最具有发展潜力<br />和成长潜力的员工",
                "goal": "打开潜力的“黑匣子”，对潜力进行全面解构；并通过对员工潜力的全方位评估，结合绩效、能力等因素，为您找出员工群体中的高潜人才。",
                "icon": "https://uimg.ifchange.com/toc/dhr_scene_3.png",
                "recommend": "必选：专业知识技能；素质；绩效；潜力 <br />可选：性格；关键经历； 工作选择价值观",
                "cover": "ttps://uimg.ifchange.com/toc/dhr_scene_cover_3.png"
            },
            {
                "id": 4,
                "name": "人才能力分层",
                "desc": "帮助您将关键岗位上的大批量员工按照能力进行分层，<br />形成员工发展阶梯与分层能力标准",
                "goal": "通过对不同能力水平的员工分层，并进行人才聚类分析，萃取出被盘点的员工群体中能力突出、能力一般、能力待改进的员工各自具有哪些关键特征，形成人才发展阶梯与分层级能力标准",
                "icon": "https://uimg.ifchange.com/toc/dhr_scene_4.png",
                "recommend": "必选：专业知识技能；素质；绩效<br />\r\n可选：性格；潜力关键经历； 工作选择价值观",
                "cover": "ttps://uimg.ifchange.com/toc/dhr_scene_cover_4.png"
            }
        ]
    }
 *
*/
func (p *V2Project) SceneList(httpCtx *hfw.HTTPContext) {
    params := &struct {
        *Session
    }{}
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, api.RequestUnmarshal(httpCtx, &params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, validate(params))
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, VerifyRequestSession(httpCtx, params))
    //sess := httpCtx.Ctx.Value("session").(*session.Session)

    result, err := v2_scene.SceneLogic.ProjectCreateUsedList()
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = result
}
