package interview

import (
    "encoding/json"
    "testing"
)

func TestGetInterview(t *testing.T) {
    response, err := CreateInterview(6).Get("60ab797f-9887-360c-b67c-ce5f59f8613f", nil)
    if err != nil {
        t.Error(err)
        return
    }
    b, _ := json.Marshal(response)
    t.Log("TestGetInterview success ", string(b))
}
