package v2_industry

import (
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/common"

	"ifchange/dhr/models"
)

var IndustryLogic *Industry

func init() {
	IndustryLogic = new(Industry)
}

type (
	Industry struct {
	}

	IndustryTree struct {
		*IndustryModel
		Children []*IndustryTree `json:"children"`
	}

	IndustryModel struct {
		*models.PositionIndustries
		IsDeleted common.Omitempty `json:"is_deleted,omitempty"`
		CreatedAt common.Omitempty `json:"created_at,omitempty"`
		UpdatedAt common.Omitempty `json:"updated_at,omitempty"`
		P1        common.Omitempty `json:"p1,omitempty"`
		P2        common.Omitempty `json:"p2,omitempty"`
		P3        common.Omitempty `json:"p3,omitempty"`
		P4        common.Omitempty `json:"p4,omitempty"`
	}
)

func (f *Industry) ProjectCreateUsedList() (result *common.ListResult, err error) {
	industries, err := models.PositionIndustriesModel.Search(db.Cond{
		"is_deleted": 0,
		"depth in":   []int{1, 2},
		"orderby":    "id asc",
	})
	if err != nil {
		return nil, err
	}

	result = &common.ListResult{
		List: ConvertTree(ConvertIndustryModels(industries)),
	}

	return
}
