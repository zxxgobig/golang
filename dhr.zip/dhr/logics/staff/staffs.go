package staff

import (
	"errors"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	"gitlab.ifchange.com/bot/logger"
	"ifchange/dhr/models"
)

// CheckPositionByID 使用岗位 id 检查岗位有效性
func CheckPositionByID(companyID int, positionID int) (valid bool, err error) {
	positionIDs := []int{positionID}
	res, err := dhr_staff.CheckPositionByIDs(nil, companyID, positionIDs)
	if err != nil {
		return
	}
	if k, ok := res[positionID]; ok {
		if len(k) > 0 {
			logger.Warnf("check position false: <%+v>", res)
			return false, nil
		}
	}

	return true, nil
}

// CheckStaffs 使用员工 id 列表检查员工有效性
func CheckStaffs(companyID int, staffIds []int) (valid bool, err error) {
	res, err := dhr_staff.CheckStaffByIDs(nil, companyID, staffIds)
	if err != nil {
		return
	}
	for _, v := range res {
		if len(v) > 0 {
			logger.Warnf("check staffs false: <%+v>", res)
			return false, nil
		}
	}
	return true, nil
}

// 获取部门列表
func GetDepartments() ([]string, error) {
	departments, err := dhr_staff.SysListDepartment(nil)
	if err != nil {
		return nil, err
	}

	departmentNames := make([]string, 0, len(departments))
	for _, department := range departments {
		departmentNames = append(departmentNames, department.Name)
	}
	return departmentNames, nil
}

// 获取岗位列表
func GetPositions() ([]string, error) {
	positions, err := dhr_staff.SysListPosition(nil)
	if err != nil {
		return nil, err
	}

	positionNames := make([]string, 0, len(positions))
	for _, position := range positions {
		positionNames = append(positionNames, position.Name)
	}
	return positionNames, nil
}

// 获取人员列表
func GetStaffs() ([]string, error) {
	staffs, err := dhr_staff.SysListStaff(nil, "") // TODO: session here by zhangzhijing
	if err != nil {
		return nil, err
	}

	staffNames := make([]string, 0, len(staffs))
	for _, staff := range staffs {
		staffNames = append(staffNames, staff.Name)
	}
	return staffNames, nil
}

func GetLeaderInfo(companyId int, staffId int) (result *dhr_staff.Staff, err error) {
	staff, err := dhr_staff.GetStaffById(nil, companyId, staffId, true)
	if err != nil {
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetStaffById %d err:%v", staffId, err)
		return nil, err
	}
	if staff == nil {
		// staff leave
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetStaffById %d be leave", staffId)
		return nil, nil
	}

	leader, err := dhr_staff.GetStaffById(nil, companyId, staff.ParentId, true)
	if err != nil {
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetLeaderById %d err:%v", staff.ParentId, err)
		return nil, err
	}
	if leader == nil || leader.Status == 3 {
		// leader leave
		logger.Errorf("[getLeaderInfo] interviewId 3 or 4, GetLeaderById %d be leave", staff.ParentId)
		return nil, nil
	} else {
		return leader, nil
	}
}

func GetStaffIDsByProjectID(id int) (staffIDs []int, err error) {
	plan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"project_id": id,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}
	if plan == nil {
		return nil, errors.New("[GetStaffIDsByProjectID].DataCollectPlansModel.SearchOne is nil")
	}
	planStaffs, err := models.DataCollectPlanStaffsModel.Search(db.Cond{
		"plan_id":    plan.Id,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}
	if planStaffs == nil || len(planStaffs) == 0 {
		return nil, errors.New("[GetStaffIDsByProjectID].DataCollectPlanStaffsModel.Search is nil")
	}

	staffIDs = make([]int, 0)
	for _, v := range planStaffs {
		staffIDs = append(staffIDs, v.StaffId)
	}

	return staffIDs, nil
}
