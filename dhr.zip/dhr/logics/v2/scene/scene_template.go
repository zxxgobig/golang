package v2_scene

import (
    "gitlab.ifchange.com/bot/hfwkit/common"

    "ifchange/dhr/models"
)

type (
    SceneTemplateModel struct {
        *models.ProjectsScenesTemplate
        IsDeleted common.Omitempty `json:"is_deleted,omitempty"`
        CreatedAt common.Omitempty `json:"created_at,omitempty"`
        UpdatedAt common.Omitempty `json:"updated_at,omitempty"`
    }
)
