package v2_industry

import (
    "ifchange/dhr/models"
)

func ConvertTree(list []*IndustryModel) (tree []*IndustryTree) {
    return recursiveTree(list, 0)
}

func recursiveTree(list []*IndustryModel, pid int) (tree []*IndustryTree) {
    for _, v := range list {
        tmp := v
        if pid == v.ParentId {
            root := &IndustryTree{
                IndustryModel: tmp,
                Children:      recursiveTree(list, v.Id),
            }
            tree = append(tree, root)
        }
    }
    return
}

func ConvertIndustryModels(src []*models.PositionIndustries) []*IndustryModel {
    if len(src) == 0 {
        return nil
    }

    dst := make([]*IndustryModel, 0, len(src))

    for _, v := range src {
        dst = append(dst, &IndustryModel{
            PositionIndustries: v,
        })
    }

    return dst
}
