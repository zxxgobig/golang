package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/position_functions", &PositionFunctions{})
}

/*
go test ./controllers -run TestPositionFunctionsList -e local -v
*/
func TestPositionFunctionsList(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    params := &struct {
        *Session
        Page     int `json:"page"`
        PageSize int `json:"page_size"`
    }{
        Session: &Session{
            SessionID: session,
        },
    }

    rsp := test.Do(t, "/position_functions/list", params)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/position_functions/list results: <%+s>", b)
}
