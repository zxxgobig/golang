package stat

import (
	"sort"

	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

type Dimension struct {
	ID            int     `json:"id"`
	Name          string  `json:"name"`
	Score         float64 `json:"score"`
	Desc          string  `json:"desc,omitempty"`
	ExcellentDesc string  `json:"excellent_desc,omitempty"`
	Selected      bool    `json:"selected"`
	Max           int     `json:"max"`
}

type Measurement struct {
	Count     []int     `json:"count,omitempty"`
	Score     []float64 `json:"score,omitempty"`
	AVG       []int     `json:"avg,omitempty"`
	Benchmark []int     `json:"benchmark,omitempty"`
	Total     []int     `json:"total,omitempty"`
	Freq      []int     `json:"freq"`
}

type Option struct {
	InterviewID int

	StatCount     bool `json:"stat_count"`
	StatScore     bool `json:"stat_score"`
	StatAVG       bool `json:"stat_avg"`
	StatExcellent bool `json:"stat_excellent"`
	StatBenchmark bool `json:"stat_benchmark"`
	StatTotal     bool `json:"stat_total"`
	StatFreq      bool `json:"stat_freq"`

	ExcellentScore float64 `json:"excellent_score"`
}

func (o *Option) ShowExcellent() bool {
	return o.StatExcellent && o.ExcellentScore > 0.0
}

type Data struct {
	Legend      string      `json:"legend"`
	Measurement Measurement `json:"measurement"`
}

type ResponseData struct {
	Dimension       []Dimension       `json:"dimension"`
	ShowMeasurement []string          `json:"show_measurement"`
	Data            []*Data           `json:"data"`
	Unit            map[string]string `json:"unit"`
	Rule            string            `json:"rule"`
	TopFreq         []string          `json:"top_freq"` // freq 最高的部分
	DimensionFreqs  []*DimensionFreq  `json:"dimension_freqs"`
}

// 领导风格特有需求
type DimensionFreq struct {
	ID     int    `json:"id"`     // 维度ID
	Name   string `json:"name"`   // 维度名称
	Number int    `json:"number"` // 人数
}

type FreqObj struct {
	ID   int
	Freq int
}

var Freq2Name = map[int]string{
	1: "命令式",
	2: "教练式",
	3: "支持式",
	4: "授权式",
}

func getStatFormResponseDataStaff(legend string, dirty []*pb.Axis, option *Option) *ResponseData {
	dimensions := make([]Dimension, 0)
	scores := make([]float64, 0)
	avgScores := make([]float64, 0)
	excellentScores := make([]float64, 0)

	freqs := make([]int, 0)
	freqObjs := make([]*FreqObj, 0)
	for _, a := range dirty {
		dimensions = append(dimensions, Dimension{
			ID:            int(a.Id),
			Name:          a.Name,
			Selected:      true,
			Max:           10,
			Score:         a.Score,
			Desc:          getDesc(option.InterviewID, int(a.Id), a.Score),
			ExcellentDesc: getDesc(option.InterviewID, int(a.Id), a.ExcellentScore),
		})

		scores = append(scores, a.Score)
		avgScores = append(avgScores, a.Avg)
		excellentScores = append(excellentScores, a.ExcellentScore)

		if option.StatFreq {
			freqs = append(freqs, int(a.Frequency))
			freqObjs = append(freqObjs, &FreqObj{
				ID:   int(a.Id),
				Freq: int(a.Frequency),
			})
		}
	}

	data := []*Data{
		{
			Legend: legend,
			Measurement: Measurement{
				Score: scores,
			},
		},
	}

	topFreq := make([]string, 0, 4)
	if option.StatFreq {
		data[0].Measurement.Freq = freqs
		topFreq, _ = GetTopFreq(freqObjs)
	}

	if option.StatAVG {
		data = append(data, &Data{
			Legend: "平均得分",
			Measurement: Measurement{
				Score: avgScores,
			},
		})
	}

	if option.ShowExcellent() {
		data = append(data, &Data{
			Legend: "绩优者得分",
			Measurement: Measurement{
				Score: excellentScores,
			},
		})
	}

	return &ResponseData{
		Dimension:       dimensions,
		Data:            data,
		ShowMeasurement: []string{"score"},
		TopFreq:         topFreq,
	}
}

func pbAxesToEvalAxes(axes []*pb.Axis) EvalAxes {
	evalAxes := make(EvalAxes, 0)
	for _, d := range axes {
		evalAxes = append(evalAxes, EvalAxis{
			ID:    int(d.Id),
			Name:  d.Name,
			Score: d.Score,
			Total: 5,
			Desc:  getDesc(5, int(d.Id), d.Score),
		})
	}

	return evalAxes
}

func getStatFormResponseData(dirty EvalAxes, option *Option) *ResponseData {
	dimensions := make([]Dimension, 0)
	scores := make([]float64, 0)
	excellentScores := make([]float64, 0)
	freqs := make([]int, 0)
	for _, axis := range dirty {
		dimensions = append(dimensions, Dimension{
			ID:            axis.ID,
			Name:          axis.Name,
			Selected:      true,
			Max:           axis.Total,
			Desc:          getDesc(option.InterviewID, axis.ID, axis.Score),
			ExcellentDesc: getDesc(option.InterviewID, axis.ID, axis.ExcellentScore),
		})

		scores = append(scores, axis.Score)
		excellentScores = append(excellentScores, axis.ExcellentScore)

		if option.StatFreq {
			freqs = append(freqs, int(axis.Freq))
		}
	}

	data := []*Data{
		{
			Legend: "员工平均得分",
			Measurement: Measurement{
				Score: scores,
			},
		},
	}
	if option.ExcellentScore > 0 {
		data = append(data, &Data{
			Legend: "绩优者得分",
			Measurement: Measurement{
				Score: excellentScores,
			},
		})
	}

	if len(freqs) > 0 {
		data[0].Measurement.Freq = freqs
	}

	return &ResponseData{
		Dimension:       dimensions,
		Data:            data,
		ShowMeasurement: []string{"score"},
	}
}

func GetTopFreq(freqObjs []*FreqObj) (topFreq []string, topID []int) {
	sort.Slice(freqObjs, func(i, j int) bool { // 从大到小
		return freqObjs[i].Freq > freqObjs[j].Freq
	})

	topFreq = append(topFreq, Freq2Name[freqObjs[0].ID])
	topID = append(topID, freqObjs[0].ID)
	if freqObjs[0].Freq == freqObjs[1].Freq {
		topFreq = append(topFreq, Freq2Name[freqObjs[1].ID])
		topID = append(topID, freqObjs[1].ID)
	}
	if freqObjs[0].Freq == freqObjs[2].Freq {
		topFreq = append(topFreq, Freq2Name[freqObjs[2].ID])
		topID = append(topID, freqObjs[2].ID)
	}
	if freqObjs[0].Freq == freqObjs[3].Freq {
		topFreq = append(topFreq, Freq2Name[freqObjs[3].ID])
		topID = append(topID, freqObjs[3].ID)
	}

	return topFreq, topID
}
