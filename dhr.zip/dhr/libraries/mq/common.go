package mq

import (
    "gitlab.ifchange.com/bot/hfwkit/config"
)

var (
    mqServers []string
)

func init() {
    mqServers = config.GetServers().BotNsqLookupds
    if len(mqServers) < 1 {
        panic("nsq config is nil")
    }
}
