package interview

import (
	"fmt"
	logicsCommon "ifchange/dhr/logics/common"
	"ifchange/dhr/models"
	"strings"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

const (
	// 性格测试产品ID
	PersonalityEvalProductID = 11
	// Aits的src_id
	AitsSrcID = 2
	// 当前产品状态完成 0未完成1已完成且可推送2已推送3已完成但不可推送
	UserProductDone = 3
)

type NormStarDimensionParams struct {
	FunctionID        int  `json:"function_id"`
	IsManagerPosition bool `json:"is_manager_position"`
}

type NormStarDimensionResult struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

var normstarManagerIndex = []map[string]interface{}{
	{"id": 18, "name": "民主精神"},
	{"id": 19, "name": "率先垂范"},
	{"id": 12, "name": "精力水平"},
}

type NormStarCallbackParams struct {
	StaffID       int    `json:"staff_id"`
	Uuid          string `json:"uuid"`
	ActivityID    string `json:"activityId"`
	TotalScore    string `json:"totalScore"`
	IdentityCard  string `json:"identityCard"`
	ReportUrl     string `json:"reportUrl"`
	ReportUrlJson string `json:"reportUrlJson"`
	DimScore      string `json:"dimScore"`
	DimScoreVo    string `json:"dimScoreVo"`
	StartLevel    string `json:"startLevel"`
	LevelExplain  string `json:"levelExplain"`
	TimeStamp     string `json:"timeStamp"`
}

type NormStarCallbackResults struct {
	Succeed bool   `json:"succeed"`
	Code    string `json:"code"`
}

type NormStarCallbackServiceParams struct {
	*NormStarCallbackParams
}

func NormStarCallback(param *NormStarCallbackParams) (err error) {
	if param == nil || param.Uuid == "" {
		return fmt.Errorf("nil params")
	}
	emailUuid := strings.Split(param.Uuid, "|")[1]
	interviewResult, err := logicsCommon.GetInterviewByStaffID(param.StaffID, IntvNormstar, emailUuid)
	if err != nil {
		return err
	}

	err = ResultCommit(interviewResult.InterviewId, interviewResult.EmailUuid, param.DimScore)
	return err
}

func NormStarDimension(param *NormStarDimensionParams) (result []*NormStarDimensionResult, err error) {
	result = make([]*NormStarDimensionResult, 0, 0)
	if param.FunctionID == 0 {
		return result, fmt.Errorf("function id is be 0")
	}
	list, err := models.PositionFunctionNormstarRecommendModel.Search(db.Cond{
		"function_id": param.FunctionID,
		"is_deleted":  0,
	})
	if err != nil {
		logger.Error(err)
		return
	}
	if list == nil || len(list) == 0 {
		list, err = models.PositionFunctionNormstarRecommendModel.Search(db.Cond{
			"function_id": 2200050,
			"is_deleted":  0,
		})
		if err != nil {
			logger.Error(err)
			return
		}
	}
	for _, p := range list {
		result = append(result, &NormStarDimensionResult{ID: p.NormstarId, Name: p.NormstarName})
	}
	if param.IsManagerPosition {
		for _, m := range normstarManagerIndex {
			mID, _ := m["id"]
			mName, _ := m["name"]
			var exists = false
			for _, obj := range result {
				if obj.ID == mID.(int) {
					exists = true
					break
				}
			}
			if !exists {
				result = append(result, &NormStarDimensionResult{ID: mID.(int), Name: mName.(string)})
			}
		}
	}
	return
}
