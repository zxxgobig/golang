package v2_interview

import (
	kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

	"ifchange/dhr/models"
)

type (
	// PersonalityDisorderRecommend ..
	PersonalityDisorderRecommend struct {
		Name     string `json:"name"`
		Desc     string `json:"desc"`
		Index    int    `json:"index"`
		IsAdvice bool   `json:"is_advice"`
		IsMust   bool   `json:"is_must"`
	}
)

// ProcessPersonalityDisorderRecommend ..
func ProcessPersonalityDisorderRecommend(
	sceneID, sceneTemplateID int,
	interviewsM map[kitinterview.Type]*models.Interviews,
) *PersonalityDisorderRecommend {

	interview, ok := interviewsM[kitinterview.PersonalityDisorder]
	if !ok {
		return nil
	}

	return &PersonalityDisorderRecommend{
		Name:     interview.Name,
		Desc:     interview.Desc,
		Index:    GetIndex(kitinterview.PersonalityDisorder),
		IsAdvice: GetIsAdvice(kitinterview.PersonalityDisorder, sceneTemplateID),
		IsMust:   GetIsMust(kitinterview.PersonalityDisorder, sceneID, sceneTemplateID),
	}
}
