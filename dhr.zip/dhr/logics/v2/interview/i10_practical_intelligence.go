package v2_interview

import (
	kitbei "gitlab.ifchange.com/bot/hfwkit/bei"
	kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

	"ifchange/dhr/models"
)

type (
	// PracticalIntelligenceRecommend ..
	PracticalIntelligenceRecommend struct {
		Name     string `json:"name"`
		Desc     string `json:"desc"`
		Index    int    `json:"index"`
		IsAdvice bool   `json:"is_advice"`
		IsMust   bool   `json:"is_must"`
	}
)

// ProcessPracticalIntelligenceRecommend ..
func ProcessPracticalIntelligenceRecommend(
	sceneID, sceneTemplateID int,
	interviewsM map[kitinterview.Type]*models.Interviews,
	useNewBEIMode bool,
	beiRecommend *BeiRecommend,
) *PracticalIntelligenceRecommend {

	interview, ok := interviewsM[kitinterview.PracticalIntelligence]
	if !ok {
		return nil
	}
	var (
		isAdvice = GetIsAdvice(kitinterview.PracticalIntelligence, sceneTemplateID)
	)
	if useNewBEIMode {
		for _, subitem := range beiRecommend.SubItems {
			if _, ok := kitbei.BeiSubitem2InterviewSubitems[subitem.Id]; ok {
				isAdvice = true
				break
			}
		}
	}

	return &PracticalIntelligenceRecommend{
		Name:     interview.Name,
		Desc:     interview.Desc,
		Index:    GetIndex(kitinterview.PracticalIntelligence),
		IsAdvice: isAdvice,
		IsMust:   GetIsMust(kitinterview.PracticalIntelligence, sceneID, sceneTemplateID),
	}
}
