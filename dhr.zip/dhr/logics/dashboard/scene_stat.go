package dashboard

import (
    "gitlab.ifchange.com/bot/hfw/encoding"
    "gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
    pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

type (
    SceneStatResult struct {
        List []*SceneStatItem `json:"list"`
    }
    SceneStatItem struct {
        Scene          *SceneStatScene `json:"scene"`
        ProjectCount   int             `json:"project_count"`
        CompletionRate float64         `json:"completion_rate"`
    }
    SceneStatScene struct {
        Id   int    `json:"id"`
        Name string `json:"name"`
        Desc string `json:"desc"`
    }
)

func SceneStat(companyId int) (result *SceneStatResult, err error) {
    result = new(SceneStatResult)

    data, err := client.GetSceneStat(nil, &pb.SceneStatRequest{
        CompanyId: int64(companyId),
    })
    if err != nil {
        return
    }
    if data == nil {
        return
    }

    err = encoding.JSON.Unmarshal(data, &result)
    if err != nil {
        return
    }

    return
}
