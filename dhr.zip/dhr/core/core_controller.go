package core

import (
	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"

	"ifchange/dhr/libraries/valid"
)

// Controller ..
type Controller struct {
	hfw.Controller
}

// Before ..
func (ctl *Controller) Before(httpCtx *hfw.HTTPContext) {
	httpCtx.IsJSON = true
	httpCtx.HasHeader = true
	httpCtx.Header = api.DefaultHeader

	if valid.IsFromB(httpCtx.Path) {
		// 先验证 token存在
		type Req struct {
			Token string `json:"token"`
		}
		req := new(Req)
		httpCtx.ThrowCheck(PermissionLimited, api.RequestUnmarshal(httpCtx, &req))
		if req.Token != "" {
			return
		}

		// 获取 session 和 resource_key
		type BeforeReq struct {
			Session     string `json:"session"`
			ResourceKey string `json:"resource_key"`
		}
		params := new(BeforeReq)
		httpCtx.ThrowCheck(PermissionLimited, api.RequestUnmarshal(httpCtx, &params))
		// 校验resource_key
		errNo, err := valid.VerifyAuthority(params.Session, params.ResourceKey)
		if errNo == 401 || errNo == 20000001 {
			httpCtx.ThrowCheck(SessionError, err)
		}
		httpCtx.ThrowCheck(PermissionLimited, err)
	}
}

const (
	_                  = iota + 20233999
	PermissionLimited  // 4000没有权限
	RequestError       // 4001参数错误
	SessionError       // 4002session错误
	Completed          // 4009已完成
	SubmitAgain        // 请勿重复提交
	NoQuestionsStarted // 未开始答题
	NoCompletedTests   // no completed tests

)

const (
	_ = iota + 20303999
	_ // 4000系统错误
	InvalidParamsErrNo
)

const (
	_           = iota + 20304999
	SystemErrNo // 5000系统错误
)

const (
	_                                     = iota + 20305500
	DbTransactionInitError                // 数据库事物初始化失败
	DbTransactionBeginError               // 数据库事物Begin失败
	DbTransactionCommitError              // 数据库事物Commit失败
	DbQueryNotExist                       // 数据不存在
	BeiError                              // 请求Bei错误
	PotentialResultsRequestError          // 潜力结果请求错误
	PersonalityEvalServiceError           // 性格
	ProfessionalSkillsResultsRequestError // 知识技能请求错误
	ProjectNameDuplicate                  // 项目重名
	ForbiddenErrNo
	RequestTimeOut // 请求超时

	InputDataError // 请求参数错误
)

var em = map[int64]string{
	// 前端错误码列表
	InvalidParamsErrNo: "参数错误",
	20304999:           "参数验证失败",
	20304998:           "参数验证未知错误",
	20304021:           "表头被更改",
	20304020:           "解析错误",
	20304026:           "项目不存在",
	20304028:           "没有符合条件数据",
	20304029:           "缺失要插入数据库的内容",
	20304030:           "查询不存在",
	20304031:           "文件大小限制10M",
	20304032:           "excel表不符合要求",
	20304033:           "标准等级只有高，中，低",
	20304034:           "级别对应关系不匹配",
	20304035:           "更新数据库失败",
	20304036:           "部分员工没有找到直属上级，请核对您的员工信息",
	20304037:           "采集计划起止时间有误",
	20304038:           "采集计划至少7天",
	20304039:           "今天已提醒",
	20304040:           "今天已发送过测评链接",
	20304041:           "表格内容不能为空",
	20304042:           "该采集计划名称已存在",
	20304043:           "盘点记录名称已存在",
	20304044:           "请补充起止时间",
	20304045:           "请补充采集计划名称",
	20304046:           "项目（采集计划）不属于当前账号",

	20304047: "岗位数据已失效",
	20304048: "行业数据已失效",
	20304049: "职能数据已失效",
	20304050: "层级数据已失效",
	20304051: "员工数据已失效",
	20304052: "采集计划不存在",
	20304053: "场景模版数据已失效",
	20304054: "项目名称不得超过20个字",
	20304055: "没有须要采集的员工",

	SubmitAgain:        "请勿重复提交",
	NoQuestionsStarted: "未开始答题",
	NoCompletedTests:   "没有已完成的测评",

	// 后端错误码列表
	20305000: "系统错误",
	20305001: "系统错误",             // 调用staff信息错误
	20305002: "员工信息不存在",          // 没有符合要求的staff信息
	20305003: "系统错误",             // interview create err
	20305004: "系统错误",             // 填写excel内容错误
	20305005: "系统错误",             // 调用采集所需staff信息错误
	20305006: "系统错误",             // 调用人才分布报告失败
	20305007: "系统错误",             // 调用人才分布报告无数据
	20305008: "系统错误",             // 获取模板失败
	20305009: "系统错误",             // 人才盘点数据生成时错误
	20305010: "系统错误",             // 项目没有须要评价绩效的人员
	20305011: "上传Excel处理失败，稍后再试", // 未能将excel成功存入DFS
	20305012: "系统错误",             // 创建采集计划时调用邮件系统错误
	20305013: "系统错误",             // 获取DFS上的历史excel失败
	20305014: "系统错误",             // Base64解码失败
	20305015: "系统错误",             // 获取DFS上的内容为空
	//20305016: "系统错误",             // 请求Activity失败   代码里使用该错误码不可删除
	20305016: "系统错误", //调用collectPlan.Users失败

	20305022: "系统错误", // 读取表格内容错误
	20305023: "系统错误", // 获取cell内容失败
	20305024: "系统错误", // 查数据库失败
	20305025: "系统错误", // 插入数据库失败
	20305027: "系统错误", // 更新数据库失败
	20305028: "系统错误", // 调用JAVA account/getAccountInfo接口报错
	20306004: "采集任务暂停",
	20306005: "采集任务结束",
	20306006: "采集任务删除",

	DbTransactionInitError:                "系统错误", // 数据库事物初始化失败
	DbTransactionBeginError:               "系统错误", // 数据库事物Begin失败
	DbTransactionCommitError:              "系统错误", // 数据库事物Commit失败
	DbQueryNotExist:                       "系统错误", // 数据不存在
	BeiError:                              "系统错误", // 请求Bei错误
	PotentialResultsRequestError:          "系统错误", // 潜力结果请求错误
	PersonalityEvalServiceError:           "系统错误", // 性格
	ProfessionalSkillsResultsRequestError: "系统错误", // 知识技能请求错误
	ProjectNameDuplicate:                  "项目重名",
	ForbiddenErrNo:                        "拒绝请求",
	RequestTimeOut:                        "网络有点延迟，请重新选择下。",
}

func init() {
	hfw.SetErrorMap(em)
}

func IsValidToken(token string) bool {
	if token == config.AppConfig.Custom["Token"] {
		return true
	}
	return false
}
