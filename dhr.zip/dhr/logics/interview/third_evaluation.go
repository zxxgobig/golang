package interview

import (
	"encoding/json"
	"fmt"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/utils"
	"gitlab.ifchange.com/bot/logger"
	"ifchange/dhr/core"
	logicsCommon "ifchange/dhr/logics/common"
	"strings"
)

type ThirdEvaluation struct {
	Config *Config
}

type ThirdEvaluationCreateParam struct {
	Uuid        string `json:"uuid"`
	InterviewId int    `json:"interview_id"`
	UserId      int    `json:"user_id"`
	UserName    string `json:"user_name"`
	Gender      int    `json:"gender"`
}

type ThirdEvaluationCommitParam struct {
	InterviewId         int               `json:"interview_id"`
	Uuid                string            `json:"uuid"`
	AnswerId            int               `json:"answer_id"`
	QuestionnaireId     int               `json:"questionnaire_id"`
	DeltaElapsedMinutes int               `json:"delta_elapsed_minutes"`
	FinishQuestionnaire bool              `json:"finish_questionnaire"`
	FinishTest          bool              `json:"finish_test"`
	AnswerSheets        map[string]string `json:"answer_sheets"`
}

type ThirdEvaluationSaveVoice struct {
	InterviewID int    `json:"interview_id"`
	Stage       string `json:"stage"`
	Voice       []byte `json:"voice"`
}

// 创建
func (b *ThirdEvaluation) Create(configSubItems []ConfigSubItem) (result interface{}, err error) {
	params := ThirdEvaluationCreateParam{
		Uuid:        b.Config.Uuid,
		InterviewId: b.Config.InterviewID,
		UserId:      b.Config.StaffID,
		UserName:    b.Config.Name,
		Gender:      b.Config.Sex,
	}

	p := api.NewPost("", "")
	p.P = params
	thirdEvaluationResult := &struct {
		Success bool `json:"success"`
	}{}
	err = api.SimpleCurl(nil, config.AppConfig.Custom["ThirdEvaluation"]+"create_activity", p, &thirdEvaluationResult)
	if err != nil {
		return
	}
	logger.Debugf("$$$$$:%#v", err)
	return nil, err
}

func (b *ThirdEvaluation) SetConfig(config interface{}) (err error) {
	var ok bool
	b.Config, ok = config.(*Config)
	if !ok {
		b.Config = nil
	}
	b.Config.Uuid, err = utils.CreateUuid(b.Config)
	if err != nil {
		return err
	}
	if b.Config.EmailUuid == "" {
		b.Config.EmailUuid, err = utils.CreateUuid(b.Config)
		if err != nil {
			return err
		}
	}
	return err
}

type ThirdEvaluationGetParam struct {
	Uuid string `json:"uuid"`
}

// 获取下一题
func (b *ThirdEvaluation) Get(uuid string, param interface{}) (t interface{}, err error) {

	p := api.NewPost("", "")
	pp := &ThirdEvaluationGetParam{}
	pp.Uuid = uuid
	p.P = pp

	var ThirdEvaluationResult json.RawMessage
	err = api.SimpleCurl(nil, config.AppConfig.Custom["ThirdEvaluation"]+"init_answer_sheet", p, &ThirdEvaluationResult)
	if err != nil {
		return
	}

	return ThirdEvaluationResult, nil
}

// 提交答案 返回是否完成
func (b *ThirdEvaluation) Commit(uuid string, param interface{}) (t interface{}, err error) {

	if param == nil {
		err = fmt.Errorf("param can't be nil")
		return
	}
	p := api.NewPost("", "")
	// p.P = param
	data, err := encoding.JSON.Marshal(param)
	if err != nil {
		return t, err
	}
	pp := &ThirdEvaluationCommitParam{}
	err = encoding.JSON.Unmarshal(data, pp)
	if err != nil {
		return t, err
	}
	pp.Uuid = uuid
	p.P = pp
	var ThirdEvaluationCommitResult json.RawMessage
	err = api.SimpleCurl(nil, config.AppConfig.Custom["ThirdEvaluation"]+"save_answer_sheet", p, &ThirdEvaluationCommitResult)
	logger.Infof("call third_evaluation return:%v and err:%v", ThirdEvaluationCommitResult, err)
	if err != nil {
		if strings.Contains(err.Error(), "200408") || strings.Contains(fmt.Sprintf("%v", err), "200408") {
			return t, common.NewRespErr(core.RequestTimeOut, "网络有点延迟，请重新选择下。")
		}
		return
	}
	return ThirdEvaluationCommitResult, nil
}

type ThirdEvaluationCommitResult struct {
	IsFinished int `json:"is_finished"`
}

func (b *ThirdEvaluation) ResultCommit(interviewID int, emailUuid string, param interface{}) (err error) {
	logger.Debugf("*************:ThirdEvaluationResultCommit")
	paramBytes, err := json.Marshal(param)
	if err != nil {
		return common.NewRespErr(core.SystemErrNo, err)
	}
	logger.Errorf("*************: %#v", param)
	if param == nil {
		return fmt.Errorf("ThirdEvaluation param is nil")
	}
	err = logicsCommon.UpdateStaffsInterview(emailUuid, string(paramBytes), param, interviewID)
	if err != nil {
		return err
	}
	return
}

func (b *ThirdEvaluation) CheckFinished(response interface{}) (isFinished bool, err error) {
	return isFinished, nil
}

func (b *ThirdEvaluation) SaveVoice(param interface{}) (err error) {
	return nil
}
