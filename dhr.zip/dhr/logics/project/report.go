package project

import (
	"fmt"
	"time"

	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/common"
	"ifchange/dhr/logics/lambda"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
)

type SubInterviewId = int
type Score = float64

type ProgressResult struct {
	Total                    int     `json:"total"`  // 盘点总人数
	Finish                   int     `json:"finish"` // 完成人数
	FinishRate               float64 `json:"finish_rate"`
	FinishLastAdd            int     `json:"finish_last_add"` // 最近7日新增人数
	StarStaff                int     `json:"star_staff"`
	StarStaffLastAdd         int     `json:"star_staff_last_add"`
	InefficiencyStaff        int     `json:"inefficiency_staff"`
	InefficiencyStaffLastAdd int     `json:"inefficiency_staff_last_add"`
}

type (
	_InventoryDistributionResult struct {
		AxisX                int                           `json:"axis_x"`
		AxisY                int                           `json:"axis_y"`
		Name                 string                        `json:"name"`
		Count                int                           `json:"count"`
		Percent              int                           `json:"percent"`
		DevelopmentAdvice    []string                      `json:"development_advice"`
		PromotionAdvice      string                        `json:"promotion_advice"`
		Staffs               []_InventoryDistributionStaff `json:"staffs"`
		AxisP                int                           `json:"-"`
		AxisClass            int                           `json:"-"`
		QualitySubItemScores map[SubInterviewId][]Score    `json:"-"`
	}

	_InventoryDistributionStaff struct {
		ID        int    `json:"id"`
		Name      string `json:"name"`
		AvatarURL string `json:"avatar_url"`
		Result    string `json:"-"`
	}

	_InventoryDistributionListResult struct {
		ID                          int          `json:"id"`
		Name                        string       `json:"name"`
		Status                      int          `json:"status"`
		Department                  string       `json:"department"`
		Position                    string       `json:"position"`
		GridP                       int          `json:"grid_p"`
		Result                      string       `json:"result"`
		ProfessionalSkillsScore     float64      `json:"professional_skills_score"`
		ProfessionalSkillsScoreDesc string       `json:"professional_skills_score_desc"`
		PotentialScore              float64      `json:"potential_score"`
		PotentialScoreDesc          string       `json:"potential_score_desc"`
		QualityScore                float64      `json:"quality_score"`
		QualityScoreDesc            string       `json:"quality_score_desc"`
		PerformanceLevel            string       `json:"performance_level"`
		PerformanceLevelStandard    lambda.Level `json:"performance_level_standard"`
		Personalities               []string     `json:"personalities"`
		PerformanceUploadAt         time.Time    `json:"-"`
	}
)

type DayDumpCountResult struct {
	ProjectName string `json:"project_name"`
	Count       int    `json:"count"`
}

func DayDumpCount(projectID int) (*DayDumpCountResult, error) {
	proj, err := models.ProjectsModel.SearchOne(db.Cond{
		"is_deleted": 0,
		"id":         projectID,
	})
	if err != nil {
		return nil, fmt.Errorf("DayDumpCount models.ProjectsModel.SearchOne error: %v", err)
	}
	if proj == nil {
		return nil, fmt.Errorf("no such project id: %d", projectID)
	}

	reports, err := models.ProjectsDistributionsModel.Search(db.Cond{
		"is_deleted": 0,
		"project_id": projectID,
		"where":      fmt.Sprintf(" updated_at > '%s' ", libraries.FormatDateTime(today())),
	})

	return &DayDumpCountResult{
		ProjectName: proj.Name,
		Count:       len(reports),
	}, nil
}

func today() time.Time {
	return libraries.DayStartTime(time.Now())
}

type ProjectsReportListResult struct {
	ID        int       `json:"id"`
	SceneID   int       `json:"scene_id"`
	Name      string    `json:"name"`
	CanAdjust bool      `json:"can_adjust"`
	CreatedAt time.Time `json:"created_at"`
}

func ProjectsDistributionsList(companyID, projectID int) ([]*ProjectsReportListResult, error) {
	result := make([]*ProjectsReportListResult, 0)

	proj, err := GetValidProject(companyID, projectID)
	if err != nil {
		logger.Error(err)
		return nil, fmt.Errorf("ProjectsDistributionsList GetValidProject error: %v", err)
	}

	rs, err := models.ProjectsDistributionsModel.Search(db.Cond{
		"is_deleted": 0,
		"project_id": projectID,
		"orderby":    "created_at desc",
	})

	if err != nil {
		return nil, fmt.Errorf("ProjectsReportList models.ProjectsDistributionsModel.Search error: %v", err)
	}

	for _, r := range rs {
		result = append(result, &ProjectsReportListResult{
			ID:        r.Id,
			Name:      r.Name,
			SceneID:   r.SceneId,
			CreatedAt: r.CreatedAt,
		})
	}

	result = append(result, &ProjectsReportListResult{
		ID:        0,
		Name:      proj.Name,
		SceneID:   proj.SceneId,
		CreatedAt: common.GetPlanByProjectID(projectID, common.CollectionCompleted).UpdatedAt,
	})

	if len(rs) != 0 {
		result[0].CanAdjust = true // 最新记录可调整
	} else {
		result[0].CanAdjust = true // 没有历史调整记录，可调整实时数据
	}

	return result, nil

}
