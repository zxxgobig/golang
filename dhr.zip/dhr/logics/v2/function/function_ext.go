package v2_function

import (
    "ifchange/dhr/models"
)

func ConvertTree(list []*FunctionModel) (tree []*FunctionTree) {
    return recursiveTree(list, 0)
}

func recursiveTree(list []*FunctionModel, pid int) (tree []*FunctionTree) {
    for _, v := range list {
        tmp := v
        if pid == v.ParentId {
            root := &FunctionTree{
                FunctionModel: tmp,
                Children:      recursiveTree(list, v.FunctionId),
            }
            tree = append(tree, root)
        }
    }
    return
}

func ConvertFunctionModels(src []*models.PositionFunctions) []*FunctionModel {
    if len(src) == 0 {
        return nil
    }

    dst := make([]*FunctionModel, 0, len(src))

    for _, v := range src {
        dst = append(dst, &FunctionModel{
            PositionFunctions: v,
        })
    }

    return dst
}
