# DHR 
[![coverage report](https://gitlab.ifchange.com/bot/dhr/badges/master/coverage.svg)](http://192.168.6.233:8080/dhr/)

### 文档
* http://xorm.io/docs http://www.xorm.io/docs/ 
* https://github.com/go-playground/validator
* https://github.com/go-playground/validator/blob/v9/_examples/simple/main.go
* http://apidocjs.com
* xorm.ORM().ShowSQL(true) 
* http://192.168.1.174/apidocs/dhr/
* bot.testing2.ifchange.com/api/dhr/ testing2.bot.rpc/api/dhr/  