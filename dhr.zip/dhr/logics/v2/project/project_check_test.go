package v2_project

import "testing"

func TestGetLatestReportID(t *testing.T) {
	reportID, err := ProjectLogic.GetLatestReportID(1)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(reportID)
}
