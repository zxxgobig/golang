package controllers

import (
	"fmt"
	"ifchange/dhr/libraries"
	"ifchange/dhr/logics/project/permission"
	"ifchange/dhr/models"
	"time"

	"gitlab.ifchange.com/bot/hfw/db"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/data_collect"
	"ifchange/dhr/logics/position"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
)

type DataCollectPlan struct {
	core.Controller
}

/**
* @api {post} /data_collect_plan/create 创建采集计划
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 创建采集计划
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} project_id 项目ID
* @apiParam {String} name 采集任务名称
* @apiParam {Number} start_time 采集任务开始时间 (十位时间戳)
* @apiParam {Number} end_time 采集任务结束时间(十位时间戳)
*
* @apiParamExample {json} Request-Example:

{
    "session":"",
    "project_id":1,
    "name":"产品信息采集",
    "start_time":1561046400,
    "end_time":1561824000
}
*
* @apiSuccess {Number} plan_id 采集计划ID
* @apiSuccessExample {json} Response-Example:

{
    "plan_id":1
}
*
*/
func (plan *DataCollectPlan) Create(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectID int    `json:"project_id" validate:"required"`
		Name      string `json:"name" validate:"required"`
		StartTime int    `json:"start_time" validate:"required"`
		EndTime   int    `json:"end_time" validate:"required"`
	}{}
	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, param))
	// 验证session
	// httpCtx.ThrowCheck(20304001, validate(param))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	collectPlan := data_collect.NewDataCollectPlan()
	// 判断参数
	if param.StartTime == 0 || param.EndTime == 0 {
		httpCtx.ThrowCheck(20304044, "请补充起止时间")
	}
	starTime := time.Unix(int64(param.StartTime), 0)
	httpCtx.ThrowCheck(20305000, err)
	endTime := time.Unix(int64(param.EndTime), 0)
	if param.Name == "" {
		httpCtx.ThrowCheck(20304045, "请补充采集计划名称")
	}
	planID, err := collectPlan.CreateCollectPlan(httpCtx, param.ProjectID, curUser.CompanyId, param.Name, starTime, endTime)
	httpCtx.ThrowCheck(20305000, err)
	httpCtx.Results = planID
}

/**
* @api {post} /data_collect_plan/list 计划列表/筛选
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 计划列表/筛选
*
* @apiParam {String} session 身份认证 Session
* @apiParam {String} plan_name 采集计划名称关键字（可选互斥检索条件）
* @apiParam {Number} position_ids 岗位ID（可选互斥检索条件）
* @apiParam {Number} status 采集状态（可选互斥检索条件）
* @apiParam {Number} page 页数
* @apiParam {Number} page_size 每页条数
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_name":"产品",
    "position_ids":[
        1,
        2
    ],
    "status":[
        1,
        2
    ],
    "page":1,
    "page_size":20
}
*
* @apiSuccess {Number} id 采集计划ID
* @apiSuccess {String} plan_name 采集计划名称
* @apiSuccess {String} position_name 岗位名
* @apiSuccess {String} project_name 关联项目名
* @apiSuccess {String} start_time 采集开始时间，10位时间戳
* @apiSuccess {String} end_time 采集结束时间，10位时间戳
* @apiSuccess {Number} total_count 总采集人数
* @apiSuccess {Number} completed_count 已采集人数
* @apiSuccess {Number} status 采集状态(待采集:1, 采集中:2, 完成:3, 暂停:4, 结束:5, 删除:6)
* @apiSuccess {Number} is_eval_link 今天是否发送过测评链接(未发送:0, 已发送:1)
* @apiSuccess {String} owner_username 采集计划所属项目所属账号的用户名
* @apiSuccess {Boolean} is_owned 是否为当前账号所属项目下创建的采集计划 true：是； false 不是
* @apiSuccess {Boolean} super_admin 是否是超级管理员
*
* @apiSuccessExample {json} Response-Example:

{
    "total":1,
    "list":[
        {
            "id":1,
            "plan_name":"产品经理信息采集",
            "position_name":"产品经理",
            "project_name":"产品经理",
            "start_time":"1560999235",
            "end_time":"1560999235",
            "total_count":100,
            "completed_count":20,
            "status":1,
			"is_eval_link":1,
			"owner_username": "秦皓",
			"is_owned": true
			"super_admin":true
        }
    ]
}
*
*/
type PlanListPespParam struct {
	Id             int       `json:"id"`
	PlanName       string    `json:"plan_name"`
	PositionName   string    `json:"position_name"`
	ProjectName    string    `json:"project_name"`
	StartTime      time.Time `json:"start_time"`
	EndTime        time.Time `json:"end_time"`
	TotalCount     int64     `json:"total_count"`
	CompletedCount int64     `json:"completed_count"`
	Status         int       `json:"status"`
	IsEvalLink     int       `json:"is_eval_link"`
	OwnerUsername  string    `json:"owner_username"`
	IsOwned        bool      `json:"is_owned"`
	SuperAdmin     bool      `json:"super_admin"`
}

type projectUserIDName struct {
	projectID int
	OwnerID   int
	OwnerName string
}

// 通过projectId获取userId，从而匹配出名字
func getUserInfoByProjectIDList(httpCtx *hfw.HTTPContext, companyID int, projectIDs []int) (data map[int]*projectUserIDName, err error) {
	projs, err := models.ProjectsModel.Search(db.Cond{
		"id in": projectIDs,
		//"is_deleted": 0,
	})
	if err != nil {
		return
	}

	projectUserIDMapping := make(map[int]int)
	userIDs := make([]int, 0)
	for _, v := range projs {
		projectUserIDMapping[v.Id] = v.UserId
		userIDs = append(userIDs, v.UserId)
	}
	//去 java 中台得到用户的名字
	params := libraries.GetUserInfoParams{
		CompanyId: companyID,
		Ids:       userIDs,
	}
	userIDNameMapping, err := libraries.GetUserInfo(httpCtx, &params)
	if err != nil {
		return
	}

	data = make(map[int]*projectUserIDName)
	for projectID, userID := range projectUserIDMapping {
		data[projectID] = &projectUserIDName{
			projectID: projectID,
			OwnerID:   userID,
			OwnerName: userIDNameMapping[userID].UserName,
		}
	}

	return data, nil
}

func getCreatorNameByProjectID(data map[int]*projectUserIDName, projectID int) string {
	d, exist := data[projectID]
	if !exist {
		return ""
	}
	return d.OwnerName
}
func judgeOwner(data map[int]*projectUserIDName, projectID int, sessionUserId int) bool {

	if owner, ok := data[projectID]; ok {
		if owner.OwnerID == sessionUserId {
			return true
		}
	}
	return false
}
func judgeSuperAdmin(roleType int) bool {
	if roleType == 1 {
		return true
	}
	return false
}

func (plan *DataCollectPlan) List(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		ResourceKey string `json:"resource_key"`
		PlanName    string `json:"plan_name"`
		PositionIDS []int  `json:"position_ids"`
		Status      []int  `json:"status"`
		Page        int    `json:"page"`
		PageSize    int    `json:"page_size"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, reqParam))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	collectPlan := data_collect.NewDataCollectPlan()
	collectPlanStaff := data_collect.NewDataCollectPlanStaffs()

	total, planL, err := collectPlan.List(reqParam.PlanName, reqParam.PositionIDS, reqParam.Status, curUser.CompanyId,
		reqParam.Page, reqParam.PageSize, curUser.Id, curUser.RoleType, curUser.RoleIds, reqParam.GetSessionID())
	httpCtx.ThrowCheck(20304001, err)

	if planL == nil || len(planL) == 0 {
		httpCtx.Results = make([]interface{}, 0)
		return
	}

	// 所有的项目ID
	var projectIds []int
	for _, cp := range planL {
		projectIds = append(projectIds, cp.ProjectId)
	}

	// 获取采集计划对应项目的创建者名字
	projectOwnerIDNames, err := getUserInfoByProjectIDList(httpCtx, curUser.CompanyId, projectIds)

	projectL, err := collectPlan.GetProjectNameByIds(data_collect.RemoveRepeatedElement(projectIds))
	httpCtx.ThrowCheck(20304001, err)

	// 获取项目中的岗位详情
	var positionL = make([]*dhr_staff.Position, 0)
	for _, project := range projectL {
		positionDetailL, err := position.GetPositionsByIDs(project.CompanyId, []int{project.PositionId})
		if err != nil {
			httpCtx.ThrowCheck(20304001, err)
		}
		positionL = append(positionL, positionDetailL...)
	}

	planListRespL := make([]*PlanListPespParam, 0)
	noticeLog := data_collect.NewDataCollectNoticeLog()
	for _, plan := range planL {
		planListResp := &PlanListPespParam{}
		planListResp.OwnerUsername = getCreatorNameByProjectID(projectOwnerIDNames, plan.ProjectId)
		planListResp.IsOwned = judgeOwner(projectOwnerIDNames, plan.ProjectId, curUser.Id)
		planListResp.SuperAdmin = judgeSuperAdmin(curUser.RoleType)
		planListResp.Id = plan.Id
		planListResp.PlanName = plan.Name
		planListResp.StartTime = plan.StartTime
		planListResp.EndTime = plan.EndTime
		planListResp.Status = plan.Status
		bool, err := noticeLog.TodayIsEvalLink(plan.Id)
		if err != nil {
			httpCtx.ThrowCheck(20304001, err)
		}
		if bool {
			planListResp.IsEvalLink = 1
		} else {
			planListResp.IsEvalLink = 0
		}

		for _, position := range positionL {
			if position.Id == plan.PositionId {
				planListResp.PositionName = position.Name
			}
		}
		for _, project := range projectL {
			if project.Id == plan.ProjectId {
				planListResp.ProjectName = project.Name
			}
		}

		totalCount, err := collectPlanStaff.GetCollectPlanTotalCountByPlanId(plan.Id)
		httpCtx.ThrowCheck(20304001, err)
		planListResp.TotalCount = totalCount

		completedCount, err := collectPlanStaff.GetCollectPlanCompletedCountByPlanId(plan.Id)
		httpCtx.ThrowCheck(20304001, err)
		planListResp.CompletedCount = completedCount
		planListRespL = append(planListRespL, planListResp)
	}

	httpCtx.Results = ListResult{
		Total: total,
		List:  planListRespL,
	}
}

/**
* @api {post} /data_collect_plan/list_by_staff 用户参与的采集记录列表
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 用户参与的采集记录列表
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} staff_id 员工id
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "staff_id": 1,
    "page":1,
    "page_size":20
}
*
* @apiSuccess {Number} id 采集计划ID
* @apiSuccess {String} plan_name 采集计划名称
* @apiSuccess {String} position 岗位
* @apiSuccess {String} project_name 关联项目
* @apiSuccess {String} start_time 采集开始时间
* @apiSuccess {String} end_time 采集结束时间
* @apiSuccess {Number} total_count 总采集人数
* @apiSuccess {Number} completed_count 已采集人数
* @apiSuccess {Number} status 采集状态(待采集:1, 采集中:2, 完成:3, 暂停:4, 结束:5, 删除:6)
*
* @apiSuccessExample {json} Response-Example:

{
    "total":1,
    "list":[
        {
            "id":1,
            "project_id": 1,
            "name":"产品经理",
            "start_time":"1560999235",
            "end_time":"1560999235",
            "status": 1,
            "is_deleted": 0,
		    "updated_at": "2019-06-10T15:18:53+08:00",
		    "created_at": "2019-06-10T15:18:53+08:00"
        }
    ]
}
*
*/
func (plan *DataCollectPlan) ListByStaff(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		StaffId  int `json:"staff_id"`
		Page     int `json:"page"`
		PageSize int `json:"page_size"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, reqParam))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	collectPlan := data_collect.NewDataCollectPlan()
	listResp, total, err := collectPlan.ListByStaffId(curUser.CompanyId, reqParam.StaffId, reqParam.Page, reqParam.PageSize)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.Results = ListResult{
		Total: total,
		List:  listResp,
	}
}

/**
* @api {post} /data_collect_plan/time_edit 采集计划时间修改
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 采集计划时间修改
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} plan_id 采集计划ID
* @apiParam {String} start_time 开始时间
* @apiParam {String} end_time 结束时间
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1,
    "start_time":"1560999235",
    "end_time":"1560999235"
}
*
* @apiSuccess {Number} plan_id 采集计划ID
* @apiSuccess {String} start_time 开始时间
* @apiSuccess {String} end_time 结束时间
*
* @apiSuccessExample {json} Response-Example:

{
    "plan_id":1,
    "start_time":"2019-07-01 00:00:00",
    "end_time":"2019-08-01 00:00:00"
}
*
*/
func (plan *DataCollectPlan) TimeEdit(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		PlanID    int       `json:"plan_id"`
		StartTime time.Time `json:"start_time"`
		EndTime   time.Time `json:"end_time"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(20304001, err)
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, reqParam))

	collectPlan := data_collect.NewDataCollectPlan()
	planID, startTimeResp, endTimeResp, err := collectPlan.TimeEdit(reqParam.PlanID, reqParam.StartTime, reqParam.EndTime)
	httpCtx.ThrowCheck(20304001, err)

	respParam := struct {
		PlanID    int       `json:"plan_id"`
		StartTime time.Time `json:"start_time"`
		EndTime   time.Time `json:"end_time"`
	}{
		PlanID:    planID,
		StartTime: startTimeResp,
		EndTime:   endTimeResp,
	}
	httpCtx.Results = respParam
}

/**
* @api {post} /data_collect_plan/status_operate 计划状态操作
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 计划状态操作
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} plan_id 采集计划ID
* @apiParam {Number} status 采集状态(待采集:1, 采集中:2, 完成:3, 暂停:4, 结束:5, 删除:6)
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1,
    "status":2
}
*
*
* @apiSuccess {Number} plan_id 采集计划ID
* @apiSuccess {Number} status 采集状态
* @apiSuccessExample {json} Response-Example:

{
    "plan_id":1,
    "status":2
}
*
*/
func (plan *DataCollectPlan) StatusOperate(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		PlanID int `json:"plan_id"`
		Status int `json:"status"`
	}{}

	curUser, err := ValidateAndUnMarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)

	if curUser.RoleType != 1 {
		// check data permission
		_, err = permission.IsCollectionPlanOwnedByUser(curUser.Id, reqParam.PlanID)
		httpCtx.ThrowCheck(20305001, err)
	}

	collectPlan := data_collect.NewDataCollectPlan()
	planIdResp, statusResp, err := collectPlan.StatusOperate(reqParam.PlanID, reqParam.Status)
	httpCtx.ThrowCheck(20144033, err)

	respParam := struct {
		PlanID int `json:"plan_id"`
		Status int `json:"status"`
	}{
		PlanID: planIdResp,
		Status: statusResp,
	}
	httpCtx.Results = respParam
}

/**
* @api {post} /data_collect_plan/detail 计划详情
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 计划详情
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} plan_id 采集计划ID
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1
}
*
*
* @apiSuccess {Number} id 采集计划ID
* @apiSuccess {String} plan_name 采集计划名称
* @apiSuccess {String} project_name 关联项目
* @apiSuccess {Date} start_time 开始时间
* @apiSuccess {Date} end_time 结束时间
* @apiSuccess {Number} total_count 总采集人数
* @apiSuccess {Number} completed_count 已采集人数
* @apiSuccess {Number} status 采集状态(待采集:1, 采集中:2, 完成:3, 暂停:4, 结束:5, 删除:6)
* @apiSuccess {Number} is_notice 今天是否已经提醒(未提醒:0, 已提醒:1)
* @apiSuccess {Number} is_eval_link 今天是否发送过测评链接(未发送:0, 已发送:1)
* @apiSuccess {Number} remaining_days 采集剩余天数
* @apiSuccess {String} dimension 维度名称
* @apiSuccess {String} is_need_collect 此维度是否需要采集(不需要采集:0, 需要采集:1)
*
* @apiSuccessExample {json} Response-Example:

{
    "id":1,
    "plan_name":"",
    "project_name":"",
    "start_time":"1560999235",
    "end_time":"1560999235",
    "total_count":100,
    "completed_count":70,
    "status":1,
    "is_notice":1,
	"remaining_days":10,
    "dimension_detail":[
        {
            "id":3,
            "dimension_cn":"技能测评",
            "dimension":"skill",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":0
        },
        {
            "id":4,
            "dimension_cn":"知识测评",
            "dimension":"knowledge",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":1,
            "dimension_cn":"素质测评",
            "dimension":"bei",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":5,
            "dimension_cn":"潜力测评",
            "dimension":"potential",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":2,
            "dimension_cn":"性格测评",
            "dimension":"normstar",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":7,
            "dimension_cn":"关键经历",
            "dimension":"key_expr",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":6,
            "dimension_cn":"工作选择价值观",
            "dimension":"work_values",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":8,
            "dimension_cn":"情绪智力",
            "dimension":"emotionalIntelligence",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":9,
            "dimension_cn":"批判思维",
            "dimension":"criticalThinking",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":10,
            "dimension_cn":"管理实践能力",
            "dimension":"practicalIntelligence",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":11,
            "dimension_cn":"职业人格",
            "dimension":"occupationalPersonality",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":12,
            "dimension_cn":"性格风险",
            "dimension":"personalityDisorder",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":13,
            "dimension_cn":"领导风格",
            "dimension":"leadershipStyle",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        },
        {
            "id":14,
            "dimension_cn":"组织忠诚度",
            "dimension":"orgCommitment",
            "total_count":100,
            "completed_count":20,
			"is_need_collect":1
        }
    ]
}
*
*/
type DetailParamResp struct {
	ID              int                `json:"id"`
	PlanName        string             `json:"plan_name"`
	ProjectName     string             `json:"project_name"`
	StartTime       time.Time          `json:"start_time"`
	EndTime         time.Time          `json:"end_time"`
	TotalCount      int64              `json:"total_count"`
	CompletedCount  int64              `json:"completed_count"`
	Status          int                `json:"status"`
	IsNotice        int                `json:"is_notice"`
	IsEvalLink      int                `json:"is_eval_link"`
	RemainingDays   int                `json:"remaining_days"`
	DimensionDetail []*DimensionDetail `json:"dimension_detail"`
}

type DimensionDetail struct {
	ID             int    `json:"id"`
	Dimension      string `json:"dimension"`
	DimensionCN    string `json:"dimension_cn"`
	TotalCount     int64  `json:"total_count"`
	CompletedCount int64  `json:"completed_count"`
	IsNeedCollect  int    `json:"is_need_collect"`
}

func (plan *DataCollectPlan) Detail(httpCtx *hfw.HTTPContext) {
	reqParam := struct {
		*Session
		PlanID int `json:"plan_id"`
	}{}
	_, err := ValidateAndUnMarshal(httpCtx, &reqParam)
	httpCtx.ThrowCheck(20304001, err)

	collectPlan := data_collect.NewDataCollectPlan()
	collectPlanStaff := data_collect.NewDataCollectPlanStaffs()
	planDetail, err := collectPlan.PlanDetailByPlanId(reqParam.PlanID)
	httpCtx.ThrowCheck(20304001, err)

	if planDetail == nil {
		httpCtx.ThrowCheck(20304028, fmt.Errorf("collect plan is null by planId: %d", reqParam.PlanID))
	}
	resp := &DetailParamResp{}
	resp.ID = planDetail.Id
	resp.PlanName = planDetail.Name
	resp.StartTime = planDetail.StartTime
	resp.EndTime = planDetail.EndTime
	resp.Status = planDetail.Status

	totalCount, err := collectPlanStaff.GetCollectPlanTotalCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	if totalCount == 0 {
		httpCtx.Results = struct{}{}
		return
	}
	resp.TotalCount = totalCount
	completedCount, err := collectPlanStaff.GetCollectPlanCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	resp.CompletedCount = completedCount

	noticeLog := data_collect.NewDataCollectNoticeLog()
	bool, err := noticeLog.TodayIsNotice(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	if bool {
		resp.IsNotice = 1
	} else {
		resp.IsNotice = 0
	}
	bool, err = noticeLog.TodayIsEvalLink(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	if bool {
		resp.IsEvalLink = 1
	} else {
		resp.IsEvalLink = 0
	}

	skillCount, err := collectPlanStaff.GetCollectPlanSkillCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	knowledgeCount, err := collectPlanStaff.GetCollectPlanKnowledgeCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	beiCount, err := collectPlanStaff.GetCollectPlanBeiCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	potentialCount, err := collectPlanStaff.GetCollectPlanPotentialCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	normstarCount, err := collectPlanStaff.GetCollectPlanNormstarCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	emotionalIntelligenceCount, err := collectPlanStaff.GetCollectPlanEmotionalIntelligenceCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	criticalThinkingCount, err := collectPlanStaff.GetCollectPlanCriticalThinkingCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	practicalIntelligenceCount, err := collectPlanStaff.GetCollectPlanPracticalIntelligenceCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	occupationalPersonalityCount, err := collectPlanStaff.GetCollectPlanOccupationalPersonalityCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	personalityDisorderCount, err := collectPlanStaff.GetCollectPlanPersonalityDisorderCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	leadershipStyleCount, err := collectPlanStaff.GetCollectPlanLeadershipStyleCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	orgCommitmentCount, err := collectPlanStaff.GetCollectPlanOrgCommitmentCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	// TODO logical problems roll back
	keyExprCount, err := collectPlanStaff.GetCollectPlanKeyExprCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	workValuesCount, err := collectPlanStaff.GetCollectPlanWorkValuesCompletedCountByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)
	notCollectDimension, err := collectPlanStaff.NotCollectDimensionsByPlanId(planDetail.Id)
	httpCtx.ThrowCheck(20304001, err)

	dimensionDetailL := make([]*DimensionDetail, 0)
	skill := &DimensionDetail{}
	knowledge := &DimensionDetail{}
	knowledge.CompletedCount = knowledgeCount
	knowledge.TotalCount = totalCount
	knowledge.Dimension = "knowledge"
	knowledge.ID = 4
	knowledge.DimensionCN = "知识测评"
	if _, ok := notCollectDimension["knowledge"]; ok {
		knowledge.IsNeedCollect = 0
	} else {
		knowledge.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, knowledge)
	skill.CompletedCount = skillCount
	skill.TotalCount = totalCount
	skill.Dimension = "skill"
	skill.ID = 3
	skill.DimensionCN = "技能测评"
	if _, ok := notCollectDimension["skill"]; ok {
		skill.IsNeedCollect = 0 // 不需要采集状态
	} else {
		skill.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, skill)
	bei := &DimensionDetail{}
	bei.CompletedCount = beiCount
	bei.TotalCount = totalCount
	bei.Dimension = "bei"
	bei.ID = 1
	bei.DimensionCN = "素质测评"
	if _, ok := notCollectDimension["bei"]; ok {
		bei.IsNeedCollect = 0
	} else {
		bei.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, bei)
	potential := &DimensionDetail{}
	potential.CompletedCount = potentialCount
	potential.TotalCount = totalCount
	potential.Dimension = "potential"
	potential.ID = 5
	potential.DimensionCN = "潜力测评"
	if _, ok := notCollectDimension["potential"]; ok {
		potential.IsNeedCollect = 0
	} else {
		potential.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, potential)
	normstar := &DimensionDetail{}
	normstar.CompletedCount = normstarCount
	normstar.TotalCount = totalCount
	normstar.Dimension = "normstar"
	normstar.ID = 2
	normstar.DimensionCN = "性格测评"
	if _, ok := notCollectDimension["normstar"]; ok {
		normstar.IsNeedCollect = 0
	} else {
		normstar.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, normstar)

	// TODO logical problems roll back
	keyExpr := &DimensionDetail{}
	keyExpr.CompletedCount = keyExprCount
	keyExpr.TotalCount = totalCount
	keyExpr.Dimension = "key_expr"
	keyExpr.ID = 7
	keyExpr.DimensionCN = "关键经历"
	if _, ok := notCollectDimension["key_expr"]; ok {
		keyExpr.IsNeedCollect = 0
	} else {
		keyExpr.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, keyExpr)
	workValues := &DimensionDetail{}
	workValues.CompletedCount = workValuesCount
	workValues.TotalCount = totalCount
	workValues.Dimension = "work_values"
	workValues.ID = 6
	workValues.DimensionCN = "工作选择价值观"
	if _, ok := notCollectDimension["work_values"]; ok {
		workValues.IsNeedCollect = 0
	} else {
		workValues.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, workValues)

	emotionalIntelligence := &DimensionDetail{}
	emotionalIntelligence.CompletedCount = emotionalIntelligenceCount
	emotionalIntelligence.TotalCount = totalCount
	emotionalIntelligence.Dimension = "emotionalIntelligence"
	emotionalIntelligence.ID = 8
	emotionalIntelligence.DimensionCN = "情绪智力"
	if _, ok := notCollectDimension["emotional_intelligence"]; ok {
		emotionalIntelligence.IsNeedCollect = 0
	} else {
		emotionalIntelligence.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, emotionalIntelligence)
	criticalThinking := &DimensionDetail{}
	criticalThinking.CompletedCount = criticalThinkingCount
	criticalThinking.TotalCount = totalCount
	criticalThinking.Dimension = "criticalThinking"
	criticalThinking.ID = 9
	criticalThinking.DimensionCN = "批判思维"
	if _, ok := notCollectDimension["critical_thinking"]; ok {
		criticalThinking.IsNeedCollect = 0
	} else {
		criticalThinking.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, criticalThinking)
	practicalIntelligence := &DimensionDetail{}
	practicalIntelligence.CompletedCount = practicalIntelligenceCount
	practicalIntelligence.TotalCount = totalCount
	practicalIntelligence.Dimension = "practicalIntelligence"
	practicalIntelligence.ID = 10
	practicalIntelligence.DimensionCN = "管理实践能力"
	if _, ok := notCollectDimension["practical_intelligence"]; ok {
		practicalIntelligence.IsNeedCollect = 0
	} else {
		practicalIntelligence.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, practicalIntelligence)
	occupationalPersonality := &DimensionDetail{}
	occupationalPersonality.CompletedCount = occupationalPersonalityCount
	occupationalPersonality.TotalCount = totalCount
	occupationalPersonality.Dimension = "occupationalPersonality"
	occupationalPersonality.ID = 11
	occupationalPersonality.DimensionCN = "职业人格"
	if _, ok := notCollectDimension["occupational_personality"]; ok {
		occupationalPersonality.IsNeedCollect = 0
	} else {
		occupationalPersonality.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, occupationalPersonality)
	personalityDisorder := &DimensionDetail{}
	personalityDisorder.CompletedCount = personalityDisorderCount
	personalityDisorder.TotalCount = totalCount
	personalityDisorder.Dimension = "personalityDisorder"
	personalityDisorder.ID = 12
	personalityDisorder.DimensionCN = "性格风险"
	if _, ok := notCollectDimension["personality_disorder"]; ok {
		personalityDisorder.IsNeedCollect = 0
	} else {
		personalityDisorder.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, personalityDisorder)
	leadershipStyle := &DimensionDetail{}
	leadershipStyle.CompletedCount = leadershipStyleCount
	leadershipStyle.TotalCount = totalCount
	leadershipStyle.Dimension = "leadershipStyle"
	leadershipStyle.ID = 13
	leadershipStyle.DimensionCN = "领导风格"
	if _, ok := notCollectDimension["leadership_style"]; ok {
		leadershipStyle.IsNeedCollect = 0
	} else {
		leadershipStyle.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, leadershipStyle)
	orgCommitment := &DimensionDetail{}
	orgCommitment.CompletedCount = orgCommitmentCount
	orgCommitment.TotalCount = totalCount
	orgCommitment.Dimension = "orgCommitment"
	orgCommitment.ID = 14
	orgCommitment.DimensionCN = "组织忠诚度"
	if _, ok := notCollectDimension["org_commitment"]; ok {
		orgCommitment.IsNeedCollect = 0
	} else {
		orgCommitment.IsNeedCollect = 1
	}
	dimensionDetailL = append(dimensionDetailL, orgCommitment)
	resp.DimensionDetail = dimensionDetailL

	remainDays := collectPlan.RemainingDays(planDetail.Status, planDetail.StartTime, planDetail.EndTime, planDetail.UpdatedAt)
	resp.RemainingDays = remainDays
	httpCtx.Results = resp
}

/**
* @api {post} /data_collect_plan/users 计划对象详情列表
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 计划对象列表
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} plan_id 采集计划ID
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1
}
* @apiSuccess {[]String} hide 隐藏维度列表
* @apiSuccess {int} status 采集状态(1待采集，2采集中，3已完成，4暂停，5结束，6删除)
* @apiSuccess {[]Object} list 员工信息列表
* @apiSuccess {String} list.staff_name 员工姓名
* @apiSuccess {Number} list.status 员工状态 1. 试用期；2. 在职；3. 离职
* @apiSuccess {Number} list.leader_status leader状态 1. 试用期；2. 在职；3. 离职
* @apiSuccess {String} list.department 部门
* @apiSuccess {String} list.position 岗位
* @apiSuccess {Number} list.skill 专业技能(1:未完成，2：已完成)
* @apiSuccess {Number} list.knowledge 专业知识(1:未完成，2：已完成)
* @apiSuccess {Number} list.bei 素质(1:未完成，2：已完成)
* @apiSuccess {Number} list.potential 潜力(1:未完成，2：已完成)
* @apiSuccess {Number} list.normstar 性格(1:未完成，2：已完成)
* @apiSuccess {Number} list.emotional_intelligence 情绪智力(1:未完成，2：已完成)
* @apiSuccess {Number} list.critical_thinking 批判思维(1:未完成，2：已完成)
* @apiSuccess {Number} list.practical_intelligence 管理实践能力(1:未完成，2：已完成)
* @apiSuccess {Number} list.occupational_personality 职业人格(1:未完成，2：已完成)
* @apiSuccess {Number} list.personality_disorder 性格风险(1:未完成，2：已完成)
* @apiSuccess {Number} list.leadership_style 领导风格(1:未完成，2：已完成)
* @apiSuccess {Number} list.org_commitment 组织忠诚度(1:未完成，2：已完成)
*
* @apiSuccessExample {json} Response-Example:

{
    "total":2,
    "project_id":12,
    "report_id":1,
	"hide":["bei","normstar","emotional_intelligence"],
	"status":1,
    "list":[
        {
            "staff_name":"张三",
            "status": 2,
            "leader_status": 1,
            "department":"产品部",
            "position":"产品经理",
            "skill":1,
            "knowledge":1,
            "bei":3,
            "potential":2,
            "normstar":3,
            "emotional_intelligence":1,
            "critical_thinking":1,
            "practical_intelligence":1,
            "occupational_personality":1,
            "personality_disorder":1,
            "leadership_style":1,
            "org_commitment":1
        },
        {
            "staff_name":"李四",
            "status": 2,
            "leader_status": 1,
            "department":"产品部",
            "position":"产品经理",
            "skill":1,
            "knowledge":1,
            "bei":3,
            "potential":2,
            "normstar":3,
            "emotional_intelligence":1,
            "critical_thinking":1,
            "practical_intelligence":1,
            "occupational_personality":1,
            "personality_disorder":1,
            "leadership_style":1,
            "org_commitment":1
        }
    ]
}
*
*/
func (plan *DataCollectPlan) Users(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		PlanID int `json:"plan_id" validate:"required"`
	}{}
	httpCtx.ThrowCheck(20305000, api.RequestUnmarshal(httpCtx, param))
	// 验证session
	httpCtx.ThrowCheck(20304001, validate(param))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	collectPlan := data_collect.NewDataCollectPlan()
	result, err := collectPlan.Users(curUser.CompanyId, param.PlanID)
	httpCtx.ThrowCheck(20305000, err)
	if result == nil {
		httpCtx.Results = struct{}{}
	} else {
		httpCtx.Results = result
	}
}

/**
* @api {post} /data_collect_plan/progress 计划进度列表
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 计划进度列表
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} plan_id 采集计划ID
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
    "plan_id":1
}
*
*
* @apiSuccess {String} dimension 维度名称
* @apiSuccess {Number} total_count 总采集人数
* @apiSuccess {Number} completed_count 已采集人数
*
* @apiSuccessExample {json} Response-Example:

{
    "total":5,
    "list":[
        {
            "dimension":"skill",
            "total_count":100,
            "completed_count":20
        },
        {
            "dimension":"knowledge",
            "total_count":100,
            "completed_count":20
        },
        {
            "dimension":"bei",
            "total_count":100,
            "completed_count":20
        },
        {
            "dimension":"potential",
            "total_count":100,
            "completed_count":20
        },
        {
            "dimension":"normstar",
            "total_count":100,
            "completed_count":20
        }
    ]
}
*
*/
func (plan *DataCollectPlan) Progress(httpCtx *hfw.HTTPContext) {

}

/**
 * @api {post} /data_collect_plan/positions 公司所有盘点计划的岗位列表
 * @apiVersion 0.1.0
 * @apiGroup positions
 * @apiDescription 盘点计划的岗位列表
 *
 * @apiParam {String} session 约定的 session
 *
 * @apiParamExample {json} Request-Example:
	{
		"p": {
			"session": "",
		}
	}
 *
 *
 * @apiSuccess {Object[]} result.list 岗位列表
 * @apiSuccess {Number} result.list.id 岗位 id
 * @apiSuccess {Number} result.list.company_id 公司 id
 * @apiSuccess {String} result.list.name 岗位名称
 * @apiSuccess {Number} result.list.is_deleted 是否删除
 * @apiSuccessExample {json} Response-Example:

{
	"results": {
		"list": [
			{
				"id": 1,
				"company_id": 1,
				"name": "前端开发工程师",
				"is_deleted": 0,
				"created_at" "1560999235",
				"updated_at" "1560999235",
			},{
				"id": 2,
				"company_id": 1,
				"name": "后端开发工程师",
				"is_deleted": 0,
				"created_at" "1560999235",
				"updated_at" "1560999235",
			}
		]
	}

}
 *
*/
func (plan *DataCollectPlan) Positions(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	ps, err := position.GetPlansPositions(curUser.CompanyId)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = map[string]interface{}{
		"list": ps,
	}
}

/**
 * @api {post} /data_collect_plan/progress_analysis 采集计划进度分析接口
 * @apiVersion 0.1.0
 * @apiGroup CollectionPlan
 * @apiDescription 获取采集计划进度分析
 *
 * @apiParam {String} session 约定的 session
 * @apiParam {Number} plan_id 需要获取数据的计划id
 * @apiParam {Number} interview_id 需要获取数据的项目下的某项测评的 id
 *
 * @apiParamExample {json} Request-Example:
	{
		"session": "",
		"plan_id": 1,
		"interview_id": 2,
	}
 *
 *
 * @apiSuccess {Number} result.total_nums 测评总人数
 * @apiSuccess {Object[]} result.list 采集位进度数据列表
 * @apiSuccess {Number} result.list.date 日期
 * @apiSuccess {Number} result.list.completion_rate 累计完成率
 * @apiSuccess {String} result.list.complete_nums 完成测评的人数
 * @apiSuccessExample {json} Response-Example:

{
	"total_nums": 10000
	"list": [
		{
			"date": 1560999234,
			"completion_rate": 0.8720,
			"complete_nums": 8720
		},{
			"date": 1560999235,
			"completion_rate": 0.8723,
			"complete_nums": 8723
		}
	]
}
 *
*/
func (plan *DataCollectPlan) ProgressAnalysis(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		PlanID      int `json:"id"`
		InterviewID int `json:"interview_id"`
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	totalNums, list, err := data_collect.NewDataCollectPlan().ProgressAnalysis(
		curUser.CompanyId, params.PlanID, params.InterviewID)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = map[string]interface{}{
		"total_nums": totalNums,
		"list":       list,
	}
}

/**
* @api {post} /data_collect_plan/recent_list 首页获取近期采集计划列表
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 首页获取近期的采集计划列表(近七天和进行中的)
*
* @apiParam {String} session 身份认证 Session
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
}
*
* @apiSuccess {Number} id 采集计划ID
* @apiSuccess {String} plan_name 采集计划名称
* @apiSuccess {String} position_name 岗位名
* @apiSuccess {String} project_name 关联项目名
* @apiSuccess {Object} interviews 采集计划下的测评信息列表
*
* @apiSuccessExample {json} Response-Example:

{
    "total":1,
    "list":[
        {
            "id":1,
            "plan_name":"产品经理信息采集",
			"project_id": 1,
            "project_name":"项目名称",
			"interviews": [
				{"id": 1, "name": "素质"},
				{"id": 2, "name": "性格"},
				{"id": 3, "name": "专业技能"},
				{"id": 4, "name": "专业知识"},
				{"id": 5, "name": "潜力"},
				{"id": 6, "name": "工作选择价值观"},
				{"id": 7, "name": "关键经历"}
			]
        }
    ]
}
*
*/
func (plan *DataCollectPlan) RecentList(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	planInfos, err := data_collect.NewDataCollectPlan().GetRecentList(curUser.CompanyId)
	httpCtx.ThrowCheck(core.SystemErrNo, err)

	httpCtx.Results = map[string]interface{}{
		"total": len(planInfos),
		"list":  planInfos,
	}
}

/**
* @api {post} /data_collect_plan/send_mail 发送采集邮件
* @apiVersion 0.1.0
* @apiGroup CollectionPlan
* @apiDescription 发送采集邮件
*
* @apiParam {String} session 身份认证 Session
*
* @apiParamExample {json} Request-Example:
{
    "session":"",
}
*
* @apiSuccess {Number} affected 发送人数
*
* @apiSuccessExample {json} Response-Example:

{
}
*
*/
func (plan *DataCollectPlan) SendMail(httpCtx *hfw.HTTPContext) {
	reqParam := &struct {
		*Session
	}{}
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, reqParam))

	// send mail
	err := data_collect.NewDataCollectNoticeLog().NoticeMailWhenTiming()
	httpCtx.ThrowCheck(20305000, err)

	// set completed
	affected, err := data_collect.NewDataCollectPlan().CompletedPlans()
	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = fmt.Sprintf("CompletedPlans affected %d", affected)
}
