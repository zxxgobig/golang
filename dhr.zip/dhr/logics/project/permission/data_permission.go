package permission

import (
	"fmt"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"

	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
)

const (
	resourceTypeProject = iota + 1
	resourceTypeCollectionPlan
)

const (
	permissionWrite = iota + 1
	permissionRead
	permissionOther
)

type Permission struct {
	ResourceKey string `json:"resource_key"`
	Permission  int    `json:"permission"`
}

func AllPermission() ([]Permission, error) {
	perms, err := models.ProjectsDataPermissionsModel.Search(db.Cond{
		"project_type": 1,
		"is_deleted":   0,
	})
	if err != nil {
		return nil, err
	}

	data := make([]Permission, 0)
	for _, p := range perms {
		if p.Permission == permissionRead {
			continue
		}
		data = append(data, Permission{
			ResourceKey: p.ResourceKey,
			Permission:  1,
		})
	}

	return data, nil
}

func DataPermission(accountID, resourceType, resourceID int) ([]Permission, error) {
	if resourceType == resourceTypeProject {
		return getProjectDataPermission(accountID, resourceID)
	} else if resourceType == resourceTypeCollectionPlan {
		return getCollectionPlanDataPermission(accountID, resourceID)
	}

	return nil, common.NewRespErr(20304001, fmt.Sprintf("unknown resource type %d", resourceType))
}

func getProjectDataPermission(accountID, projectID int) ([]Permission, error) {
	proj, err := models.ProjectsModel.SearchOne(db.Cond{
		"id":         projectID,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}

	if proj == nil {
		return nil, common.NewRespErr(20304026, fmt.Sprintf("no such project[id=%d]", projectID))
	}

	if proj.UserId == accountID {
		return getDataPermissionFromDB(1, 1)
	}
	return getDataPermissionFromDB(2, 1)
}

func getCollectionPlanDataPermission(accountID, collectionPlanID int) ([]Permission, error) {
	collectionPlan, err := models.DataCollectPlansModel.SearchOne(db.Cond{
		"id":         collectionPlanID,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}
	if collectionPlan == nil {
		return nil, common.NewRespErr(20304030, fmt.Sprintf("no such data collection plan[id=%d]", collectionPlanID))
	}

	proj, err := models.ProjectsModel.SearchOne(db.Cond{
		"id":         collectionPlan.ProjectId,
		"is_deleted": 0,
	})
	if err != nil {
		return nil, err
	}

	if proj == nil {
		return nil, common.NewRespErr(20304026, fmt.Sprintf("no such project[id=%d]", collectionPlan.ProjectId))
	}

	if proj.UserId == accountID {
		return getDataPermissionFromDB(1, 2)
	}
	return getDataPermissionFromDB(2, 2)
}

func getDataPermissionFromDB(projectType, resourceType int) ([]Permission, error) {
	perms, err := models.ProjectsDataPermissionsModel.Search(db.Cond{
		"project_type":  projectType,
		"resource_type": resourceType,
		"is_deleted":    0,
	})
	if err != nil {
		return nil, err
	}

	data := make([]Permission, 0)
	for _, p := range perms {
		if p.Permission == permissionRead {
			continue
		}
		data = append(data, Permission{
			ResourceKey: p.ResourceKey,
			Permission:  p.Permission,
		})
	}

	return data, nil
}

// 获取下级是B端用户列表
type UserListPermission struct {
	UserID   int               `json:"user_id"`   // 用户id
	UserList []*UserPermission `json:"user_list"` // 下属B端用户列表
}

type UserPermission struct {
	EmpNo     string `json:"emp_no"`
	UserId    int    `json:"user_id"` // 员工user_id
	StaffId   int    `json:"staff_id"`
	StaffName string `json:"staff_name"`
}

func GetPermissionUserList(session string) (*UserListPermission, error) {
	p := api.NewPost("", "")
	p.P = &struct {
		Session string `json:"session"`
	}{
		Session: session,
	}

	result := new(UserListPermission)
	err := api.SimpleCurl(nil, config.AppConfig.Custom["DhrStaff"]+"staffs/user_list_permission", p, &result)
	if err != nil {
		return nil, err
	}

	return result, nil
}

type JudgeDataPermissionReq struct {
	RoleIds   []int  `json:"role_ids"`
	CompanyID int    `json:"company_id"`
	ModuleKey string `json:"module_key"`
}

func JudgeResourceDataPermission(params *JudgeDataPermissionReq) (int, error) {
	p := api.NewPost("resource", "dataPermission")
	p.P = params

	result := &struct {
		Results int `json:"results"`
	}{}

	err := api.SimpleCurl(nil, config.AppConfig.Custom["RBACAccountURL"]+"resource/dataPermission", p, &result.Results)
	if err != nil {
		return 0, err
	}

	return result.Results, nil
}
