package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/project"

    "gitlab.ifchange.com/bot/hfw"
)

type ProjectsScenes struct {
    core.Controller
}

/**
 * @api {post} /projects_scenes/list 项目场景列表
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目场景列表
 *
 * @apiParamExample {json} Request-Example:
 {
	 "p": {
		 "session": "xx"
	 }
 }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.id 场景 id
 * @apiSuccess {String} result.name 场景名称
 * @apiSuccess {String} result.desc 场景描述
 * @apiSuccess {String} result.goal 盘点目标
 * @apiSuccess {String} result.icon 图标
 * @apiSuccess {String} result.recommend 推荐维度
 * @apiSuccess {Boolean} result.is_selected 是否已选择，1已选择，0未选择
 * @apiSuccess {Number} result.is_deleted 1删除，0未删除
 * @apiSuccess {String} result.created_at 创建时间
 * @apiSuccess {String} result.updated_at 更新时间
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results" : {
		 "list": [
			{
				"id": 1,
				"name": "识别高潜人才",
				"desc": "详情介绍文案，详情介绍文案",
				"goal": "盘点目标, 盘点目标",
				"icon": "https://xxxx.png",
				"recommend": "推荐维度",
				"is_selected": 1,
				"is_deleted": 0,
				"updated_at":"1560999235",
				"created_at":"1560999235"
			},
			{
				"id":2,
				"name": "识别高潜人才",
				"desc": "详情介绍文案，详情介绍文案",
				"goal": "盘点目标, 盘点目标",
				"icon": "https://xxxx.png",
				"recommend": "推荐维度",
				"is_selected": 0,
				"is_deleted": 0,
				"updated_at":"1560999235",
				"created_at":"1560999235"
			}
		 ]
	 }
 }
 *
*/
func (c *ProjectsScenes) List(httpCtx *hfw.HTTPContext) {
    params := &struct {
        *Session
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, params)
    httpCtx.ThrowCheck(core.RequestError, err)

    scenes, err := project.NewProjectsScenes().List(
        curUser.CompanyId, 0)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = map[string]interface{}{
        "list": scenes,
    }
}

/**
 * @api {post} /projects_scenes/select_list 项目场景列表(选择)
 * @apiVersion 0.1.0
 * @apiGroup Projects
 * @apiDescription 项目场景列表
 *
 * @apiParam {String} session session
 * @apiParam {Number} project_id 项目id
 *
 * @apiParamExample {json} Request-Example:
 {
	 "p": {
		 "session": "xx"
		 "project_id": 1,
	 }
 }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.id 场景 id
 * @apiSuccess {String} result.name 场景名称
 * @apiSuccess {String} result.desc 场景描述
 * @apiSuccess {String} result.goal 盘点目标
 * @apiSuccess {String} result.icon 图标
 * @apiSuccess {String} result.recommend 推荐维度
 * @apiSuccess {String} result.enable true 可选，false 不可选
 * @apiSuccess {Number} result.is_deleted 1删除，0未删除
 * @apiSuccess {String} result.created_at 创建时间
 * @apiSuccess {String} result.updated_at 更新时间
 *
 * @apiSuccessExample {json} Response-Example:
 {
	 "results" : {
		 "list": [
			{
				"id": 1,
				"name": "识别高潜人才",
				"desc": "详情介绍文案，详情介绍文案",
				"goal": "盘点目标, 盘点目标",
				"icon": "https://xxxx.png",
				"recommend": "推荐维度",
				"enable": true,
				"is_deleted": 0,
				"updated_at":"2019-06-05T14:47:51+08:00",
				"created_at":"2019-06-05T14:47:51+08:00"
			},
			{
				"id":2,
				"name": "识别高潜人才",
				"desc": "详情介绍文案，详情介绍文案",
				"goal": "盘点目标, 盘点目标",
				"icon": "https://xxxx.png",
				"recommend": "推荐维度",
				"enable": false,
				"is_deleted": 0,
				"updated_at":"2019-06-05T14:47:51+08:00",
				"created_at":"2019-06-05T14:47:51+08:00"
			}
		 ]
	 }
 }
 *
*/
func (c *ProjectsScenes) SelectList(httpCtx *hfw.HTTPContext) {
    params := &struct {
        *Session
        ProjectID int `json:"project_id" validate:"required"`
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, params)
    httpCtx.ThrowCheck(core.RequestError, err)

    scenes, err := project.NewProjectsScenes().List(
        curUser.CompanyId, params.ProjectID)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = map[string]interface{}{
        "list": scenes,
    }
}
