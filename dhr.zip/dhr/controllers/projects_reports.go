package controllers

import (
	"ifchange/dhr/core"
	"ifchange/dhr/logics/project"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfwkit/api"

	"gitlab.ifchange.com/bot/hfw"
)

type ProjectsReport struct {
	core.Controller
}

/**
 * @api {post} /projects_reports/list 项目详情-报告列表
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-报告列表
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Objects[]} inventories 盘点记录列表
 * @apiSuccess {Number} result.inventories.id 盘点记录 ID
 * @apiSuccess {Number} result.inventories.scene_id 场景 ID
 * @apiSuccess {String} result.inventories.name 盘点记录名称
 * @apiSuccess {Boolean} result.inventories.can_adjust 是否可以调整九宫格
 * @apiSuccess {String} result.inventories.created_at 盘点记录创建时间
 *
 * @apiSuccessExample {json} Response-Example:
 *		{
 *			"inventories": [{
 *					"id": 1,
 *					"scene_id": 1,
 *					"name": "盘点记录1",
 *					"can_adjust": false,
 *					"created_at": "1560999235"
 *				},{
 *					"id": 2,
 *					"scene_id": 1,
 *					"name": "盘点记录2",
 *					"can_adjust": false,
 *					"created_at": "1560999235"
 *				},{
 *					"id": 3,
 *					"scene_id": 1,
 *					"name": "盘点记录3",
 *					"can_adjust": false,
 *					"created_at": "1560999235"
 *				},
 *			]
 *		}
 *
 */

func (c *ProjectsReport) List(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID int `json:"project_id" validate:"required"`
	}{}
	curUser, err := ValidateAndUnMarshal(httpCtx, params)
	httpCtx.ThrowCheck(20304001, err)

	rs, err := project.ProjectsDistributionsList(curUser.CompanyId, params.ProjectID)
	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = map[string]interface{}{
		"inventories": rs,
	}
}

/**
* @api {post} /projects_reports/dump 项目详情-保存报告
* @apiVersion 0.1.0
* @apiGroup ProjectsReport
* @apiDescription 项目详情-保存报告
*
* @apiParam {String} session 身份认证 Session
* @apiParam {Number} project_id 项目 ID
* @apiParam {Number} scene_id 场景 ID
* @apiParam {Number} name 盘点记录名称
* @apiParam {Object[]} adjust_staffs 要调整的员工列表
* @apiParam {Number} adjust_staffs.id 员工 ID
* @apiParam {Number} adjust_staffs.original 初始位置（0-8）
* @apiParam {Number} adjust_staffs.target 目标位置（0-8）
*
* @apiParamExample {json} Request-Example:
* {
*     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
*	   "project_id": 3,
*	   "scene_id": 1,
*	   "name": "hahah",
*	   "adjust_staffs": [{
*			"id": 23,
*			"original": 0,
*			"target": 8,
*		},{
*			"id": 43,
*			"original": 3,
*			"target": 8,
*		}]
* }
*
* @apiSuccess {Object} result 返回结果
* @apiSuccess {Boolean} success 是否保存成功
* @apiSuccess {Boolean} is_first_dump 是否为项目的第一次保存
*
* @apiSuccessExample {json} Response-Example:
*		{
*			"success": true,
*			"is_first_dump": true
*		}
*
 */
func (c *ProjectsReport) Dump(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectID    int                    `json:"project_id" validate:"required"`
		SceneID      int                    `json:"scene_id" validate:"required"`
		Name         string                 `json:"name" validate:"required"`
		AdjustStaffs []*project.AdjustStaff `json:"adjust_staffs" validate:"required"`
	}{}

	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	httpCtx.ThrowCheck(20304001, validate(param))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	err = project.Dump(curUser.CompanyId, param.ProjectID, param.SceneID, param.Name, param.AdjustStaffs)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = &struct {
		Success bool `json:"success"`
	}{true}
}

/**
 * @api {post} /projects_reports/edit 项目报告编辑
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目报告编辑（版本编辑-目前只支持重命名）
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} id 报告
 * @apiParam {String} name 名称
 *
 * @apiParamExample {json} Request-Example:
 {
	"session": "",
	"project_id":4,
	"id":1,
	"name":"酷"
 }
 *
 * @apiSuccess {Object} result 空
 *
 * @apiSuccessExample {json} Response-Example:
{
	 "results": {}
}
 *
*/
func (c *ProjectsReport) Edit(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectId int    `json:"project_id" validate:"required"`
		Id        int    `json:"id"`
		Name      string `json:"name" validate:"required"`
	}{}

	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	httpCtx.ThrowCheck(20304001, validate(param))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20305000, project.Rename(curUser.CompanyId, models.ProjectsReports{
		Id:        param.Id,
		ProjectId: param.ProjectId,
		Name:      param.Name,
	}))

	httpCtx.Results = nil
}

/**
 * @api {post} /projects_reports/export 项目详情-导出报告
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-导出报告
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 2
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Boolean} success 是否导出成功
 *
 * @apiSuccessExample {json} Response-Example:
 *		{
 *			"success": true
 *		}
 *
 */
func (c *ProjectsReport) Export(httpCtx *hfw.HTTPContext) {

}

/**
 * @api {post} /projects_reports/delete 项目详情-删除报告
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-删除报告
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 报告 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Boolean} success 是否保存成功
 *
 * @apiSuccessExample {json} Response-Example:
 *		{
 *			"success": true
 *		}
 *
 */
func (c *ProjectsReport) Delete(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectId int `json:"project_id" validate:"required"`
		ReportID  int `json:"report_id" validate:"required"`
	}{}

	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	httpCtx.ThrowCheck(20304001, validate(param))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20305000, project.Delete(curUser.CompanyId, param.ProjectId, param.ReportID))

	httpCtx.Results = nil
}

/**
 * @api {post} /projects_reports/distribution_interview_list 项目详情-盘点分布 Y 轴（能力）列表
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-盘点分布 Y 轴（能力）列表
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3
 * }
 *
 * @apiSuccess {Object[]} result 返回结果，为列表
 * @apiSuccess {Number} result.interview_id 测评类型 ID
 * @apiSuccess {String} result.name 测评名称
 *
 * @apiSuccessExample {json} Response-Example:
 *		[{
 *			"interview_id": 0,
 *			"name": "综合能力"
 *		},{
 *			"interview_id": 1,
 *			"name": "专业知识技能"
 *		},{
 *			"interview_id": 3,
 *			"name": "素质"
 *		},{
 *			"interview_id": 5,
 *			"name": "潜力"
 *		}]
 *
 */
func (c *ProjectsReport) DistributionInterviewList(httpCtx *hfw.HTTPContext) {
	param := &struct {
		*Session
		ProjectId int `json:"project_id" validate:"required"`
	}{}

	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, &param))

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, param))

	httpCtx.ThrowCheck(20304001, validate(param))

	items, err := project.GetInterviewItems(param.ProjectId)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = items
}

/**
 * @api {post} /projects_reports/day_dump_count 项目详情-获取当日已保存次数
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-获取当日已保存次数
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {String} result.name 项目名称
 * @apiSuccess {Number} result.count 单日保存次数
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *		"name": “项目1”,
 *		"count": 1
 *   }
 *
 */
func (c *ProjectsReport) DayDumpCount(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session

	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	result, err := project.DayDumpCount(req.ProjectID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/is_report_name_exist 项目详情-查询报告名称是否已经存在
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-查询报告名称是否已经存在
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} name 要查询的项目名称
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 1",
 *	   "name": "报告2222"
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.is_exist true 为存在，false 不存在
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *		"is_exist": false
 *   }
 *
 */
func (c *ProjectsReport) IsReportNameExist(httpCtx *hfw.HTTPContext) {
	req := &struct {
		*Session
		ProjectID int    `json:"project_id" validate:"required"`
		Name      string `json:"name" validate:"required"`
	}{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	result, err := project.IsReportNameExist(req.ProjectID, req.Name)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}
