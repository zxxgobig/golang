package libraries

import (
    "time"
)

const (
    DateFormat     = "2006-01-02"
    TimeFormat     = "15:04:05"
    DateTimeFormat = "2006-01-02 15:04:05"
)

func FormatDate(t time.Time) string {
    return t.Format(DateFormat)
}

func FormatTime(t time.Time) string {
    return t.Format(TimeFormat)
}

func FormatDateTime(t time.Time) string {
    return t.Format(DateTimeFormat)
}

func MustParse(format string, str string) time.Time {
    parse, _ := time.Parse(format, str)
    return parse
}

func MustParseDate(str string) time.Time {
    return MustParse(DateFormat, str)
}

func MustParseTime(str string) time.Time {
    return MustParse(TimeFormat, str)
}

func MustParseDateTime(str string) time.Time {
    return MustParse(DateTimeFormat, str)
}

func DayStartTime(t time.Time) time.Time {
    return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
}

func DayEndTime(t time.Time) time.Time {
    return DayStartTime(t).Add(24*time.Hour - time.Nanosecond)
}

func TodayStartTime() time.Time {
    return DayStartTime(time.Now())
}

func TodayEndTime() time.Time {
    return DayEndTime(time.Now())
}
