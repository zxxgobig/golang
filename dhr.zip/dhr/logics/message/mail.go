package message

import (
    "encoding/json"

    mqKit "gitlab.ifchange.com/bot/commonkit/mq"
)

type MailData struct {
    Subject string   `json:"subject"`
    Email   []string `json:"email"`
    Content string   `json:"content"`
}

func SendMail(mqPub mqKit.Pub, data MailData) (err error) {

    err = mqPub.Init("email")
    if err != nil {
        return
    }

    content, err := json.Marshal(data)
    if err != nil {
        return
    }
    message := &mqKit.Message{
        Content: content,
    }
    err = mqPub.Publish(message)
    return
}
