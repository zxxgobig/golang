package lambda

import (
    "strings"
)

// 通过name返回一级纬度ID
func GetInterviewIdByName(name string) int {
    if name == "" {
        return InterviewNotFound
    }

    for i, v := range InterviewItemNames {
        if strings.Contains(v, name) {
            return i
        }
    }

    // 素质
    for _, axis := range QualityAxes {
        if strings.Contains(axis.Name, name) {
            return InterviewBEI
        }
    }

    // 性格
    for _, axis := range PersonalityAxes {
        if strings.Contains(axis.Name, name) {
            return InterviewPersonalityEval
        }
    }

    // 潜力
    for _, axis := range PotentialAxes {
        if strings.Contains(axis.Name, name) {
            return InterviewPotential
        }
    }

    return InterviewNotFound
}
