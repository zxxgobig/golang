package position

import (
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"
)

type PositionIndustries struct {
}

func NewPositionIndustries() *PositionIndustries {
	return new(PositionIndustries)
}

type PositionIndustriesModel struct {
}

type PositionIndustiesModel struct {
	Item     *models.PositionIndustries   `json:"item"`
	SubItems []*models.PositionIndustries `json:"sub_items"`
}

func (p *PositionIndustries) List(page, pageSize int) (_models []*PositionIndustiesModel, total int64, err error) {

	cond := db.Cond{
		"is_deleted": 0,
		"page":       page,
		"pagesize":   pageSize,
		"depth":      1,
	}

	total = 0
	positionIndustries, err := models.PositionIndustriesModel.Search(cond)
	if err != nil {
		return nil, 0, err
	}

	for _, positionIndustry := range positionIndustries {
		_positionIndustiesModel := &PositionIndustiesModel{
			Item:     positionIndustry,
			SubItems: []*models.PositionIndustries{},
		}
		cond["depth"] = 2
		cond["parent_id"] = positionIndustry.Id
		_positionIndustiesModel.SubItems, err = models.PositionIndustriesModel.Search(cond)
		if err != nil {
			return nil, 0, err
		}

		_models = append(_models, _positionIndustiesModel)
	}

	return
}
