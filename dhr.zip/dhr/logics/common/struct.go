package common

type (
	ListResult struct {
		List      interface{} `json:"list"`
		CanAdjust bool        `json:"can_adjust,omitempty"`
	}

	PageResult struct {
		Total int64       `json:"total"`
		List  interface{} `json:"list"`
	}
)

// 项目详情-关键经历
type KeyExperience struct {
	Type         string              `json:"type"`          // 管理经历 or 业务经历
	ManageList   []*SubKeyExperience `json:"manage_list"`   // 管理经历
	BusinessList []*SubKeyExperience `json:"business_list"` // 业务经历
}

type SubKeyExperience struct {
	Id       int64   `json:"id"`       // 子纬度ID
	Name     string  `json:"name"`     // 子纬度名称
	Number   int     `json:"number"`   //
	Focus    bool    `json:"focus"`    // 重点关注经历 - true；其它 - false
	Fraction float64 `json:"fraction"` // 百分比，占总测评人数
}

// 项目详情-工作选择价值观
type JobChoiceValue struct {
	List []*SubJobChoiceValue `json:"list"`
}

type SubJobChoiceValue struct {
	Id        int64   `json:"id"`         // 子纬度ID
	Name      string  `json:"name"`       // 子纬度名称
	Number    int     `json:"number"`     //
	Focus     bool    `json:"focus"`      // 是否重点关注
	Fraction  float64 `json:"fraction"`   // 人数占比
	AreaRatio float64 `json:"area_ratio"` // 面积占比
}

// 员工详情-标签
type StaffLabels struct {
	StaffId              int      `json:"staff_id"`
	JobChoiceValueLabels []string `json:"job_choice_value_labels"`
	KeyExperienceLabels  []string `json:"key_experience_labels"`
	Labels               []string `json:"labels"`
}
