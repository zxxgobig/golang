package interview

import (
    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/encoding"
    "ifchange/dhr/logics/lambda"
    "testing"
)

func TestNormStart(t *testing.T) {
    paramStr := `{"领导支配":5,"工作个性":3.29,"情绪控制":3,"亲和力":2,"个性":3.29,"掩饰性":3,"内归因":4,"客户导向":5,"合作精":2,"辅助指标":3,"坚韧不拔":2}`
    paramsMap := make(map[string]float64)
    err := encoding.JSON.Unmarshal([]byte(paramStr), &paramsMap)
    if err != nil {
        t.Error(err)
    }
    paramsIntMap := make(map[int]float64)
    for k, v := range paramsMap {
        if lambda.GetPersonalityAxisID(k) > 0 {
            paramsIntMap[lambda.GetPersonalityAxisID(k)] = v
        }
    }
    logger.Debugf("%+v", paramsIntMap)
}
