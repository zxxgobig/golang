package v2_interview

import (
    "gitlab.ifchange.com/bot/hfw/db"
    "gitlab.ifchange.com/bot/hfwkit/common"
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    SubitemListParam struct {
        CompanyId   int `json:"company_id" validate:"required"`
        InterviewId int `json:"interview_id" validate:"required"`
    }
)

func (i *Interview) SubitemList(params *SubitemListParam) (result *common.ListResult, err error) {
    cond := db.Cond{
        "is_deleted": 0,
        "orderby":    "id ASC",
    }

    if params.InterviewId > 0 {
        cond["id"] = params.InterviewId
    }

    interviews, err := models.InterviewsModel.Search(cond)
    if err != nil {
        return
    }
    if len(interviews) == 0 {
        return
    }

    interviewsM := ConvertInterviews2Map(interviews)

    switch kitinterview.Type(params.InterviewId) {
    case kitinterview.Skill:
        result = ProcessSkillSubItem(params.CompanyId, interviewsM)
    case kitinterview.Knowledge:
        result = ProcessKnowledgeSubItem(params.CompanyId, interviewsM)
    }

    return
}

func (c *SubitemListParam) Validate() error {
    return nil
}
