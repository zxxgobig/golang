package controllers

import (
    "testing"
    "time"

    "gitlab.ifchange.com/bot/hfw"

    "github.com/json-iterator/go/extra"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    extra.RegisterTimeAsInt64Codec(time.Second)
    _ = hfw.Handler("/staffs_view", &StaffsView{})
}

// TODO
func TestStaffViewCreate(t *testing.T) {}

// TODO
func TestStaffViewList(t *testing.T) {}

func TestStaffsViewPerformance(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID: 38,
    }

    rsp := test.Do(t, "/staffs_view/performance", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/performance results: <%+s>", b)

}

func TestStaffsViewInventoryDistribution(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   136,
        ProjectID: 84,
    }

    rsp := test.Do(t, "/staffs_view/inventory_distribution", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/inventory_distribution results: <%+s>", b)

}

func TestStaffsViewPotential(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   38,
        ProjectID: 17,
    }

    rsp := test.Do(t, "/staffs_view/potential", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/potential results: <%+s>", b)

}

func TestStaffsViewProfessionalSkills(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   38,
        ProjectID: 17,
    }

    rsp := test.Do(t, "/staffs_view/professional_skills", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/professional_skills results: <%+s>", b)

}

func TestStaffsViewQuality(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   1,
        ProjectID: 54,
    }

    rsp := test.Do(t, "/staffs_view/quality", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/quality results: <%+s>", b)

}

func TestStaffsViewPersonalityEval(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   1,
        ProjectID: 54,
    }

    rsp := test.Do(t, "/staffs_view/personality_eval", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/personality_eval results: <%+s>", b)

}

func TestStaffsViewCollectionPlanList(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   14,
        ProjectID: 38,
    }

    rsp := test.Do(t, "/staffs_view/collection_plan_list", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/collection_plan_list results: <%+s>", b)

}

func TestStaffsViewReportList(t *testing.T) {

    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := StaffViewRequest{
        Session: &Session{
            SessionID: session,
        },
        StaffID:   1,
        ProjectID: 50,
    }

    rsp := test.Do(t, "/staffs_view/inventory_list", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/staffs_view/inventory_list results: <%+s>", b)

}
