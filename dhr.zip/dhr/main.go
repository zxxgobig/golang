package main

import (
	"time"

	"github.com/json-iterator/go/extra"
	"gitlab.ifchange.com/bot/hfw"

	"ifchange/dhr/controllers"
	_ "ifchange/dhr/cron"
	// _ "ifchange/dhr/logics/data_transfer"
)

func main() {
	extra.RegisterTimeAsInt64Codec(time.Second)

	_ = hfw.Handler("/data_collect_plan", &controllers.DataCollectPlan{})
	_ = hfw.Handler("/interviews", &controllers.Interviews{})
	_ = hfw.Handler("/interviews_configs", &controllers.InterviewsConfigs{})
	_ = hfw.Handler("/position_functions", &controllers.PositionFunctions{})
	_ = hfw.Handler("/position_industries", &controllers.PositionIndustries{})
	_ = hfw.Handler("/position_levels", &controllers.PositionLevels{})
	_ = hfw.Handler("/projects_reports", &controllers.ProjectsReport{})
	_ = hfw.Handler("/projects_scenes", &controllers.ProjectsScenes{})
	_ = hfw.Handler("/projects_staffs", &controllers.ProjectsStaffs{})
	_ = hfw.Handler("/projects_staffs_perform", &controllers.ProjectsUsersPerform{})
	_ = hfw.Handler("/projects", &controllers.Projects{})
	_ = hfw.Handler("/staffs_view", &controllers.StaffsView{})
	_ = hfw.Handler("/talent_excel", &controllers.TalentExcelDownload{})
	_ = hfw.Handler("/norm_star", &controllers.NormStarService{})
	_ = hfw.Handler("/create", &controllers.Create{})
	_ = hfw.Handler("/sas", &controllers.Sas{})
	_ = hfw.Handler("/dashboard", &controllers.Dashboard{})
	_ = hfw.Handler("/external", &controllers.External{})
	_ = hfw.Handler("/permission", &controllers.Permission{})
	_ = hfw.Handler("/test_reports", &controllers.TestReports{})
	_ = hfw.Handler("/v2_project", &controllers.V2Project{})
	_ = hfw.Handler("/push", &controllers.Push{})
	_ = hfw.Handler("/update", &controllers.Update{})
	_ = hfw.Handler("/region", &controllers.Region{})
	_ = hfw.Handler("/export", &controllers.Export{})
	_ = hfw.Handler("/company_configs", &controllers.CompanyConfigs{})
	_ = hfw.Handler("/sync", &controllers.Sync{})
	_ = hfw.Run()

}
