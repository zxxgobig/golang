package cron

import (
    "ifchange/dhr/logics/project"
    "ifchange/dhr/models"
    "time"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/db"
    "github.com/robfig/cron"
)

var retryInterval = 5 * time.Minute

func init() {
    c := cron.New()
    c.AddFunc("0 0 30 * * *", func() { // 每天 0:30
        for i := 0; i < 3; i++ {
            projects, err := models.ProjectsModel.Search(db.Cond{
                "is_deleted": 0,
            })
            if err != nil {
                logger.Errorf("cron error: %v", err)
                time.Sleep(retryInterval)
                continue
            }

            projectsDailyReports := make([]*models.ProjectsDailyReports, 0)
            for _, p := range projects {
                result, err := project.GetCurrentProgress(p.CompanyId, p.Id)
                if err != nil {
                    logger.Errorf("project.GetCurrentProgress error: %v", err)
                    continue
                }
                if result != nil {
                    projectsDailyReports = append(projectsDailyReports, &models.ProjectsDailyReports{
                        ProjectId:                p.Id,
                        ComplateUsersCount:       result.Finish,
                        LowEfficienctUsersCount:  result.InefficiencyStaffLastAdd,
                        HighEfficienctUsersCount: result.StarStaff,
                        Date:                     time.Now().Format("2006-01-02"), // TODO:
                    })
                }
            }

            if len(projectsDailyReports) > 0 {
                _, err = models.ProjectsDailyReportsModel.Insert(projectsDailyReports...)
                logger.Errorf("project.GetCurrentProgress error: %v", err)
            }

            break
        }
    })
}
