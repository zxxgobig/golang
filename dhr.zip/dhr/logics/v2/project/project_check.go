package v2_project

import (
	"bytes"
	"crypto/tls"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"time"
	"unicode/utf8"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/encoding"

	kitbei "gitlab.ifchange.com/bot/hfwkit/bei"
	"gitlab.ifchange.com/bot/hfwkit/config"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"
	hfwutils "gitlab.ifchange.com/bot/hfwkit/utils"
	commonpb "gitlab.ifchange.com/bot/proto/common"
	"google.golang.org/grpc"

	"ifchange/dhr/core"
	"ifchange/dhr/models"

	"gitlab.ifchange.com/bot/hfw/db"

	"context"
	"encoding/json"

	hfwcommon "gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/grpc/client"
	"gitlab.ifchange.com/bot/logger"
	pbcommon "gitlab.ifchange.com/bot/proto/common"
	"gitlab.ifchange.com/bot/proto/dhr_staff/staff"
	pb "gitlab.ifchange.com/bot/proto/dhr_staff/staff"
	pbskill "gitlab.ifchange.com/bot/proto/professional_skills"
)

type (
	subItem struct {
		ID int `json:"id"`
	}
	//CheckBeiOpenInterviewsReq ..
	CheckBeiOpenInterviewsReq struct {
		// SubItems ..
		SubItems []*subItem `json:"subitems"`
	}

	CheckBeiOpenInterviewIsCheck struct {
		IsCheck bool `json:"is_check"`
	}
	// CheckBeiOpenInterviewRes ..
	CheckBeiOpenInterviewRes struct {
		PracticalIntelligence   *CheckBeiOpenInterviewIsCheck `json:"practical_intelligence"`
		OccupationalPersonality *CheckBeiOpenInterviewIsCheck `json:"occupational_personality"`
		CriticalThinking        *CheckBeiOpenInterviewIsCheck `json:"critical_thinking"`
	}
)

// CheckBeiOpenInterviews ..
func (f *Project) CheckBeiOpenInterviews(subItems []*subItem) (res *CheckBeiOpenInterviewRes, err error) {
	if subItems == nil {
		return nil, common.NewRespErr(core.InputDataError, "参数为空")
	}

	res = &CheckBeiOpenInterviewRes{
		PracticalIntelligence:   &CheckBeiOpenInterviewIsCheck{IsCheck: false},
		OccupationalPersonality: &CheckBeiOpenInterviewIsCheck{IsCheck: false},
		CriticalThinking:        &CheckBeiOpenInterviewIsCheck{IsCheck: false},
	}
	// save checked interviews
	checkedInterviewM := make(map[int]struct{})
	for _, subItem := range subItems {
		if hitInterviewSubItem, ok := kitbei.BeiSubitem2InterviewSubitems[subItem.ID]; ok {
			if _, ok := checkedInterviewM[hitInterviewSubItem.InterviewID]; ok {
				continue
			}
			switch hitInterviewSubItem.InterviewID {
			case kitbei.CriticalThinkingInterviewID:
				res.CriticalThinking.IsCheck = true
			case kitbei.PracticalIntelligenceInterviewID:
				res.PracticalIntelligence.IsCheck = true
			case kitbei.OccupationalPersonalityInterviewID:
				res.OccupationalPersonality.IsCheck = true
			}
			checkedInterviewM[hitInterviewSubItem.InterviewID] = struct{}{}
		}
	}
	return
}

// PreCheck ..
func (f *Project) PreCheck(companyID int, name string) (err error) {
	return CheckProjectName(companyID, name)
}

// CheckProjectName ..
func CheckProjectName(companyID int, name string) (err error) {
	if utf8.RuneCountInString(name) > ProjectNameLengthLimit {
		return hfwcommon.NewRespErr(20304054, "项目名称不得超过20个字")
	}

	total, err := models.ProjectsModel.Count(db.Cond{
		"is_deleted": 0,
		"company_id": companyID,
		"name":       name,
	})
	if err != nil {
		err = hfwcommon.NewRespErr(core.SystemErrNo, "exec models.ProjectsModel.Count error")
		return
	}

	if total > 0 {
		err = hfwcommon.NewRespErr(core.ProjectNameDuplicate, "project name duplicate")
		return
	}

	return
}

// NeedInterViewResult ..
type NeedInterViewResult struct {
	Id   int    `json:"id"`
	Name string `json:"name"`
}

// GetNeedInterviews ..
func (f *Project) GetNeedInterviews(projectID int) (needInterViewResult []*NeedInterViewResult, err error) {
	// 获取该项目的测评配置
	interviews, err := models.InterviewsModel.Search(db.Cond{})
	if err != nil {
		logger.Error(err)
		return
	}
	if interviews == nil {
		logger.Warn("interviews is nil")
		return
	}
	var interviewsMap = make(map[int]string)
	for _, interview := range interviews {
		if interview.Id == 3 || interview.Id == 4 {
			interviewsMap[interview.Id] = "专业知识技能"
		} else {
			interviewsMap[interview.Id] = interview.Name
		}

	}
	// 获取该项目的测评配置
	projectsInterviewsConfigs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"is_deleted": 0,
		"project_id": projectID,
		"orderby":    "interview_id asc",
		"is_show":    models.SHOW,
	})
	if err != nil {
		logger.Error(err)
		return
	}
	if projectsInterviewsConfigs == nil {
		logger.Warn("projectsInterviewsConfigs is nil")
		return
	}

	addCount := 0 //3和4合并为3
	for _, config := range projectsInterviewsConfigs {
		name := ""
		if _, ok := interviewsMap[config.InterviewId]; ok {
			name = interviewsMap[config.InterviewId]
		}
		if config.InterviewId == 4 {
			config.InterviewId = 3
		}
		if addCount > 0 && config.InterviewId == 3 {
			continue
		}
		if config.InterviewId == 3 {
			addCount = 1
		}
		needInterViewResult = append(needInterViewResult, &NeedInterViewResult{
			Id:   config.InterviewId,
			Name: name,
		})
	}
	needInterViewResult = append(needInterViewResult, &NeedInterViewResult{
		Id:   10000, //一个特殊的标志，标志前端图表是否展示
		Name: "绩效",
	})
	return
}

func (f *Project) UploadPicture(content, format string) (url string, err error) {
	//picstore.NewImage(content).Upload("." + format)
	resp, err := uploadPic(&MultimediaUploadReq{
		Content: content,
		Ext:     format,
	})
	return resp.Data, err
}

type MultimediaUploadReq struct {
	Content string `json:"content"`
	Ext     string `json:"ext"`
}

type MultimediaUploadResp struct {
	Code int    `json:"code"`
	Msg  string `json:"ext"`
	Data string `json:"data"`
}

func uploadPic(req *MultimediaUploadReq) (resp *MultimediaUploadResp, err error) {
	data, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	logger.Debugf("uploadPic req: %s", string(data))

	tr := &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true}}
	client := &http.Client{Transport: tr}

	r, err := client.Post(config.AppConfig.Custom["CsiServeURL"]+"/multimedia/upload", "application/json;charset=UTF-8", bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer r.Body.Close()

	respData, err := ioutil.ReadAll(r.Body)
	if err != nil {
		return nil, err
	}
	logger.Debugf("uploadPic respData: %s", string(respData))

	resp = new(MultimediaUploadResp)
	err = encoding.JSON.Unmarshal(respData, &resp)
	if err != nil {
		logger.Errorf("uploadPic err:%v", err)
		return nil, common.NewRespErr(20305017, "请求CsiServeURL错误："+err.Error())
	}
	if resp.Code != 0 {
		err = errors.New(resp.Msg)
	}
	return
}

type SubItem struct {
	Name  string `json:"name"`
	Score int    `json:"score,omitempty"`
}
type SubTitle struct {
	Name    string     `json:"name"`
	SubItem []*SubItem `json:"sub_item"`
}
type InterviewConfig struct {
	Id      int        `json:"id,omitempty"`
	Name    string     `json:"name"`
	SubItem []*SubItem `json:"sub_item"`
}
type CustomInterviewConfig struct {
	Id       int         `json:"id,omitempty"`
	Name     string      `json:"name"`
	SubTitle []*SubTitle `json:"sub_title"`
}

type ProjectInfo struct {
	Name                    string                   `json:"name"`
	Desc                    string                   `json:"desc"`
	SceneName               string                   `json:"scene_name"`
	StartAt                 time.Time                `json:"start_at"`
	PositionName            string                   `json:"position_name"`
	IndustryName            string                   `json:"industry_name"`
	LevelName               string                   `json:"level_name"`
	FunctionName            string                   `json:"function_name"`
	IsManager               int                      `json:"is_manager"`
	InterviewsConfigs       []*InterviewConfig       `json:"interviews_config"`
	CustomInterviewsConfigs []*CustomInterviewConfig `json:"custom_interviews_config"`
	Staffs                  []*dhr_staff.Staff       `json:"staffs"`
}
type IndbInterviewSubitemConfig struct {
	Id    int    `json:"id"`
	Name  string `json:"name"`
	Class int    `json:"class,omitempty"`
	Score int    `json:"score,omitempty"`
}

type NormalStarConfigSelected struct {
	NormstarName string `json:"normstar_name"`
}
type NormalStarConfig struct {
	Selected []*NormalStarConfigSelected `json:"Selected"`
}

// GetInfo 获取项目的配置信息
func (f *Project) GetInfo(companyId int, projectId int) (result ProjectInfo, err error) {
	// 获取该项目的测评配置
	project, err := models.ProjectsModel.SearchOne(db.Cond{"is_deleted": 0, "id": projectId, "company_id": companyId})
	if err != nil {
		logger.Error(err)
		return
	}
	if project == nil {
		logger.Warn("project is nil")
		return
	}
	result.Name = project.Name
	result.Desc = project.Desc
	result.StartAt = project.StartAt
	result.IsManager = project.IsManagerPosition
	// 获取该项目的职位名称
	position, err := dhr_staff.SysGetWithInvalidPositionById(nil, project.CompanyId, project.PositionId, false)
	if err != nil {
		return
	}
	if position == nil {
		return result, fmt.Errorf("position not found:%d", project.Id)
	}
	result.PositionName = position.Name
	// 获取该项目的场景名称
	projectScene, err := models.ProjectsScenesModel.SearchOne(db.Cond{"is_deleted": 0, "id": project.SceneId})
	if err != nil {
		logger.Error(err)
		return
	}
	if projectScene == nil {
		logger.Warn("projectScene is nil")
		return
	}
	result.SceneName = projectScene.Name
	// 获取该项目的职能名称
	positionFunction, err := models.PositionFunctionsModel.SearchOne(db.Cond{"is_deleted": 0, "id": project.PositionFunctionId})
	if err != nil {
		logger.Error(err)
		return
	}
	if positionFunction == nil {
		logger.Warn("positionFunction is nil")
		return
	}
	result.FunctionName = positionFunction.Name
	// 获取该项目的行业名称
	PositionIndusty, err := models.PositionIndustriesModel.SearchOne(db.Cond{
		"is_deleted": 0,
		"id":         project.PositionIndustryId,
	})
	if err != nil {
		logger.Error(err)
		return
	}
	if PositionIndusty == nil {
		logger.Warn("PositionIndusty is nil")
		return
	}
	result.IndustryName = PositionIndusty.Name
	// 获取该项目的层级名称
	PositionLevel, err := models.PositionLevelsModel.SearchOne(db.Cond{"is_deleted": 0, "id": project.PositionLevelId})
	if err != nil {
		logger.Error(err)
		return
	}
	if PositionLevel == nil {
		logger.Warn("PositionLevel is nil")
		return
	}
	result.LevelName = PositionLevel.Name
	// 获取现在的所有的测评的二级维度
	interviewsDb, err := models.InterviewsModel.Search(db.Cond{"is_deleted": 0, "orderby": "id asc"})
	if err != nil {
		logger.Error(err)
		return
	}
	if interviewsDb == nil {
		logger.Warn("interviews is nil")
		return
	}
	var interviewsIdToName = make(map[int]string)
	var interviewsCustom = make(map[string]IndbInterviewSubitemConfig)
	var interviewsStand = make(map[int][]*SubItem)
	for _, interviewsItem := range interviewsDb {
		interviewsIdToName[interviewsItem.Id] = interviewsItem.Name
		var indbInterviewSubitemConfig []IndbInterviewSubitemConfig
		err = json.Unmarshal([]byte(interviewsItem.Config), &indbInterviewSubitemConfig)
		if err != nil {
			logger.Error(err)
			return
		}
		for _, indbInterviewSubitemConfigItem := range indbInterviewSubitemConfig {
			switch interviewsItem.Id {
			case 1, 2, 3, 4, 6, 7:
				key := fmt.Sprintf("%d-%d", interviewsItem.Id, indbInterviewSubitemConfigItem.Id)
				interviewsCustom[key] = indbInterviewSubitemConfigItem
			case 5, 8, 9, 10, 11, 12, 13, 14:
				interviewsStand[interviewsItem.Id] = append(interviewsStand[interviewsItem.Id], &SubItem{
					Name: indbInterviewSubitemConfigItem.Name,
				})
			default:
			}
		}
	}
	// 获取该项目的测评配置
	projectsInterviewsConfigs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"is_deleted": 0,
		"project_id": projectId,
		"orderby":    "interview_id asc",
		"is_show":    models.SHOW,
	})
	if err != nil {
		logger.Error(err)
		return
	}
	if projectsInterviewsConfigs == nil {
		logger.Warn("projectsInterviewsConfigs is nil")
		return
	}
	for _, projectInterviewConfig := range projectsInterviewsConfigs {
		customInterviewConfig := &CustomInterviewConfig{}
		customInterviewConfig.Id = projectInterviewConfig.InterviewId
		customInterviewConfig.Name = interviewsIdToName[projectInterviewConfig.InterviewId]
		interviewConfig := &InterviewConfig{}
		interviewConfig.Id = projectInterviewConfig.InterviewId
		interviewConfig.Name = interviewsIdToName[projectInterviewConfig.InterviewId]
		switch projectInterviewConfig.InterviewId {
		case 3, 4:
			var indbInterviewSubitemConfig []IndbInterviewSubitemConfig
			err = json.Unmarshal([]byte(projectInterviewConfig.InterviewConfigs), &indbInterviewSubitemConfig)
			if err != nil {
				logger.Error(err)
				continue
			}
			values := []string{}
			for _, indbInterviewSubitemConfigItem := range indbInterviewSubitemConfig {
				values = append(values, strconv.Itoa(indbInterviewSubitemConfigItem.Id))
			}
			cond := &pbcommon.CondValuesParam{Key: "id", Values: values}
			req := &pbskill.EvaluateSkillListRequest{}
			req.Cond = append(req.Cond, cond)
			resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
				res, err := pbskill.NewEvaluateClient(conn).SkillsList(ctx, req)
				if err != nil {
					return nil, err
				}
				if res.GetErrNo() != 0 {
					return nil, hfwcommon.NewRespErr(res.GetErrNo(), res.GetErrMsg())
				}
				return res.GetResults(), nil
			}, time.Duration(10)*time.Second)
			if err != nil {
				logger.Error(err)
				continue
			}
			response := resp.(*pbskill.EvaluateSkillsListResult)
			skillSubItems := make(map[int]string)
			for _, x := range response.List {
				skillSubItems[int(x.Id)] = x.Name
			}
			subItem := []*SubItem{}
			for _, indbInterviewSubitemConfigItem := range indbInterviewSubitemConfig {
				if _, ok := skillSubItems[indbInterviewSubitemConfigItem.Id]; !ok {
					continue
				}
				subItem = append(subItem, &SubItem{
					Name: skillSubItems[indbInterviewSubitemConfigItem.Id],
				})
			}
			interviewConfig.SubItem = subItem
			result.InterviewsConfigs = append(result.InterviewsConfigs, interviewConfig)
		case 2:
			var normalStarConfig NormalStarConfig
			err = json.Unmarshal([]byte(projectInterviewConfig.InterviewConfigs), &normalStarConfig)
			if err != nil {
				logger.Error(err)
				continue
			}
			subItem := []*SubItem{}
			for _, normalStarConfigItem := range normalStarConfig.Selected {
				subItem = append(subItem, &SubItem{
					Name: normalStarConfigItem.NormstarName,
				})
			}
			interviewConfig.SubItem = subItem
			result.InterviewsConfigs = append(result.InterviewsConfigs, interviewConfig)
		case 1, 6:
			var indbInterviewSubitemConfig []IndbInterviewSubitemConfig
			err = json.Unmarshal([]byte(projectInterviewConfig.InterviewConfigs), &indbInterviewSubitemConfig)
			if err != nil {
				logger.Error(err)
				continue
			}
			subItem := []*SubItem{}
			for _, indbInterviewSubitemConfigItem := range indbInterviewSubitemConfig {
				key := fmt.Sprintf("%d-%d", projectInterviewConfig.InterviewId, indbInterviewSubitemConfigItem.Id)
				if _, ok := interviewsCustom[key]; !ok {
					continue
				}
				subItem = append(subItem, &SubItem{
					Name:  interviewsCustom[key].Name,
					Score: indbInterviewSubitemConfigItem.Score,
				})
			}
			interviewConfig.SubItem = subItem
			result.InterviewsConfigs = append(result.InterviewsConfigs, interviewConfig)
		case 7:
			var indbInterviewSubitemConfig []IndbInterviewSubitemConfig
			err = json.Unmarshal([]byte(projectInterviewConfig.InterviewConfigs), &indbInterviewSubitemConfig)
			if err != nil {
				logger.Error(err)
				continue
			}
			var subItemZero, subItemOne []*SubItem
			for _, indbInterviewSubitemConfigItem := range indbInterviewSubitemConfig {
				key := fmt.Sprintf("%d-%d", projectInterviewConfig.InterviewId, indbInterviewSubitemConfigItem.Id)
				if _, ok := interviewsCustom[key]; !ok {
					continue
				}
				if interviewsCustom[key].Class == 0 {
					subItemZero = append(subItemZero, &SubItem{
						Name: interviewsCustom[key].Name,
					})
				} else {
					subItemOne = append(subItemOne, &SubItem{
						Name: interviewsCustom[key].Name,
					})
				}
			}
			customInterviewConfig.SubTitle = append(customInterviewConfig.SubTitle, &SubTitle{
				Name:    "业务经历",
				SubItem: subItemZero,
			})
			customInterviewConfig.SubTitle = append(customInterviewConfig.SubTitle, &SubTitle{
				Name:    "管理经历",
				SubItem: subItemOne,
			})
			result.CustomInterviewsConfigs = append(result.CustomInterviewsConfigs, customInterviewConfig)
		case 5, 8, 9, 10, 11, 12, 13, 14:
			interviewConfig.SubItem = interviewsStand[projectInterviewConfig.InterviewId]
			result.InterviewsConfigs = append(result.InterviewsConfigs, interviewConfig)
		default:
			continue
		}
	}
	// 获取项目下的盘点staff_ids
	projectStaffs, err := models.ProjectsStaffsModel.Search(db.Cond{"is_deleted": 0, "project_id": projectId, "orderby": "created_at asc"})
	if err != nil {
		logger.Error(err)
		return
	}
	if projectStaffs == nil {
		logger.Warn("projectsStaffsDb is nil")
		return
	}
	staffIds := []int{}
	for _, projectStaff := range projectStaffs {
		staffIds = append(staffIds, projectStaff.StaffId)
	}
	// 调用dhr_staff接口获取项目下的盘点人员详情
	req := &pb.BatchDetailRequest{
		CompanyId: int64(project.CompanyId),
		Full:      true,
		Cond: &commonpb.CondValuesParam{
			Key:    "id",
			Values: hfwutils.IntSlice2StringSlice(staffIds),
		},
		Status: []staff.Status{staff.Status_DIMISSION},
	}
	logger.Debugf("GRPC Staff Do Staff.BatchDetail params: [%+v]", req)
	resp, err := client.Do(nil, config.GetGrpcServers().DhrStaff,
		func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
			ret, err := pb.NewStaffServiceClient(conn).BatchDetail(ctx, req)
			if err != nil {
				return nil, err
			}
			if ret.GetErrNo() != 0 {
				return nil, hfwcommon.NewRespErr(ret.GetErrNo(), ret.GetErrMsg())
			}
			return ret.GetResults(), nil
		}, time.Duration(10)*time.Second)
	logger.Debugf("GRPC Staff Do Staff.BatchDetail result: [%+v]", resp)

	if convert, ok := resp.(*pb.BatchDetailResult); ok {
		result.Staffs = make([]*dhr_staff.Staff, 0, len(convert.List))
		for _, v := range convert.GetList() {
			tmp := v
			result.Staffs = append(result.Staffs, dhr_staff.BatchPbStaff2modelStaff(tmp)...)
		}
	}
	return result, nil
}

func (_ *Project) GetLatestVersionID(projectID int) (versionID int, err error) {
	d, err := models.ProjectsDistributionsModel.SearchOne(db.Cond{
		"project_id": projectID,
		"orderby":    "id desc",
		"is_deleted": 0,
	})
	if err != nil {
		return 0, err
	}
	if d == nil {
		return 0, nil
	}
	return d.Id, nil
}
