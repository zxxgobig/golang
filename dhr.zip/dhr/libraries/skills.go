package libraries

import (
    "context"
    "errors"
    "fmt"
    "sync"
    "time"

    "gitlab.ifchange.com/bot/hfw/common"
    "gitlab.ifchange.com/bot/hfwkit/config"
    "gitlab.ifchange.com/bot/hfwkit/grpc/client"
    pb "gitlab.ifchange.com/bot/proto/professional_skills"
    "google.golang.org/grpc"
)

var (
    professionalNamesByID   = new(sync.Map)
    professionalNamesByName = new(sync.Map)
)

func GetProfessionalSkillName(companyID, skillID int) (name string, err error) {
    if companyID == 0 && skillID == 0 {
        return name, errors.New("company_id and skill id is both 0")
    }

    if bc, ok := professionalNamesByID.Load(getSkillNameCacheKey(skillID)); ok {
        return bc.(string), nil
    }

    data, err := fetchSkillList(companyID, 0)
    if err != nil {
        return name, fmt.Errorf("GetProfessionalSkillName fetchSkillList error: %v for company id: %d", err, companyID)
    }
    for _, v := range data {
        professionalNamesByID.Store(getSkillNameCacheKey(v.Id), v.Name)
        if v.Id == skillID {
            name = v.Name
        }
    }

    return name, nil
}

func GetProfessionalSkillID(companyID int, name string) (id int, err error) {
    if companyID == 0 && name == "" {
        return id, errors.New("company_id and skill id is both 0")
    }

    if bc, ok := professionalNamesByID.Load(getSkiillIDCacheKey(name)); ok {
        return bc.(int), nil
    }

    data, err := fetchSkillList(companyID, 0)
    if err != nil {
        return id, fmt.Errorf("GetProfessionalSkillName fetchSkillList error: %v for company id: %d", err, companyID)
    }
    for _, v := range data {
        professionalNamesByID.Store(getSkiillIDCacheKey(v.Name), v.Id)
        if v.Name == name {
            id = v.Id
        }
    }

    return id, nil
}

func getSkillNameCacheKey(skillID int) string {
    return fmt.Sprintf("skillID-%d", skillID)
}

func getSkiillIDCacheKey(skillName string) string {
    return fmt.Sprintf("skillName-%s", skillName)
}

// 子维度 如bei下的积极性测评等
type ConfigSubItem struct {
    Id     int    `json:"id"`
    EnName string `json:"enname"`
    Name   string `json:"name"`
}

var (
    expireTime time.Duration = time.Duration(5) * time.Second
)

//  更新缓存：1知识  2技能, 0全部
func fetchSkillList(companyId, typeId int) (configSubItemList []ConfigSubItem, err error) {
    params := pb.EvaluateSkillListRequest{
        CompanyId: int64(companyId),
        Type:      pb.SkillType(typeId),
        PageSize:  100000,
    }
    resp, err := client.Do(nil, config.GetGrpcServers().ProfessionalSkills, func(ctx context.Context, conn *grpc.ClientConn) (interface{}, error) {
        res, err := pb.NewEvaluateClient(conn).SkillsList(ctx, &params)
        if err != nil {
            return nil, err
        }
        if res.GetErrNo() != 0 {
            return nil, common.NewRespErr(int64(res.GetErrNo()), res.GetErrMsg())
        }
        return res.GetResults(), nil
    }, expireTime)
    if err != nil {
        return
    }
    result := resp.(*pb.EvaluateSkillsListResult)
    configSubItemList = []ConfigSubItem{}
    for _, x := range result.List {
        configSubItemList = append(configSubItemList, ConfigSubItem{
            Id:   int(x.Id),
            Name: x.Name,
        })
    }

    return
}
