package models

import (
	"database/sql"
	"encoding/gob"
	"errors"
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
	hfw "gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfw/configs"
	"gitlab.ifchange.com/bot/hfw/db"
	logger "gitlab.ifchange.com/bot/logger"
)

var StaffsReportsModel = &StaffsReports{}

func init() {
	var err error
	StaffsReportsModel.Dao, err = db.NewXormDao(hfw.Config, hfw.Config.Db)
	if err != nil {
		logger.Fatal(err)
		panic(err)
	}
	StaffsReportsModel.Dao.EnableCache(StaffsReportsModel)
	//StaffsReportsModel.Dao.DisableCache(StaffsReportsModel)
	//gob: type not registered for interface
	gob.Register(StaffsReportsModel)
}

type StaffsReports struct {
	Dao *db.XormDao `json:"-" xorm:"-"`

	Id                         int       `json:"id" xorm:"not null pk autoincr comment('自增id') INT(11)"`
	ProjectReportId            int       `json:"project_report_id" xorm:"not null default 0 comment('盘点记录名') INT(11)"`
	StaffId                    int       `json:"staff_id" xorm:"not null default 0 comment('员工 id') INT(11)"`
	Distributions              string    `json:"distributions" xorm:"not null comment('盘点结果内容') TEXT"`
	ProfessionalSkills         string    `json:"professional_skills" xorm:"not null comment('专业技能') TEXT"`
	Potential                  string    `json:"potential" xorm:"not null comment('潜力') TEXT"`
	Quality                    string    `json:"quality" xorm:"not null comment('素质') TEXT"`
	Performance                string    `json:"performance" xorm:"not null comment('绩效') TEXT"`
	PersonalityEval            string    `json:"personality_eval" xorm:"not null comment('性格测评') TEXT"`
	EmotionalIntelligence      string    `json:"emotional_intelligence" xorm:"not null comment('情绪智力测评') TEXT"`
	CriticalThinking           string    `json:"critical_thinking" xorm:"not null comment('批判思维测评') TEXT"`
	PracticalIntelligence      string    `json:"practical_intelligence" xorm:"not null comment('管理实践能力测评') TEXT"`
	OccupationalPersonality    string    `json:"occupational_personality" xorm:"not null comment('职业人格测评') TEXT"`
	PersonalityDisorder        string    `json:"personality_disorder" xorm:"not null comment('偏离因素测评') TEXT"`
	LeadershipStyle            string    `json:"leadership_style" xorm:"not null comment('领导风格测评') TEXT"`
	OrgCommitment              string    `json:"org_commitment" xorm:"not null comment('组织忠诚度测评') TEXT"`
	Result                     string    `json:"result" xorm:"not null comment('盘点结果') VARCHAR(32)"`
	ProfessionalSkillsAvgScore float64   `json:"professional_skills_avg_score" xorm:"not null comment('专业知识技能平均分') DOUBLE(11,2)"`
	PotentialAvgScore          float64   `json:"potential_avg_score" xorm:"not null comment('潜力平均分') DOUBLE(11,2)"`
	QualityAvgScore            float64   `json:"quality_avg_score" xorm:"not null comment('素质平均分') DOUBLE(11,2)"`
	PerformanceLevelStandard   string    `json:"performance_level_standard" xorm:"not null comment('绩效得分字母等级') VARCHAR(32)"`
	Personalities              string    `json:"personalities" xorm:"not null comment('突出性格') VARCHAR(256)"`
	IsDeleted                  int       `json:"is_deleted" xorm:"not null default 0 comment('是否已删除') INT(1)"`
	CreatedAt                  time.Time `json:"created_at" xorm:"not null default 'CURRENT_TIMESTAMP' created TIMESTAMP"`
	UpdatedAt                  time.Time `json:"updated_at" xorm:"not null default 'CURRENT_TIMESTAMP' updated TIMESTAMP"`
}

func (m *StaffsReports) GetId() (val int) {
	if m == nil {
		return
	}
	return m.Id
}

func (m *StaffsReports) GetProjectReportId() (val int) {
	if m == nil {
		return
	}
	return m.ProjectReportId
}

func (m *StaffsReports) GetStaffId() (val int) {
	if m == nil {
		return
	}
	return m.StaffId
}

func (m *StaffsReports) GetDistributions() (val string) {
	if m == nil {
		return
	}
	return m.Distributions
}

func (m *StaffsReports) GetProfessionalSkills() (val string) {
	if m == nil {
		return
	}
	return m.ProfessionalSkills
}

func (m *StaffsReports) GetPotential() (val string) {
	if m == nil {
		return
	}
	return m.Potential
}

func (m *StaffsReports) GetQuality() (val string) {
	if m == nil {
		return
	}
	return m.Quality
}

func (m *StaffsReports) GetPerformance() (val string) {
	if m == nil {
		return
	}
	return m.Performance
}

func (m *StaffsReports) GetPersonalityEval() (val string) {
	if m == nil {
		return
	}
	return m.PersonalityEval
}

func (m *StaffsReports) GetEmotionalIntelligence() (val string) {
	if m == nil {
		return
	}
	return m.EmotionalIntelligence
}

func (m *StaffsReports) GetCriticalThinking() (val string) {
	if m == nil {
		return
	}
	return m.CriticalThinking
}

func (m *StaffsReports) GetPracticalIntelligence() (val string) {
	if m == nil {
		return
	}
	return m.PracticalIntelligence
}

func (m *StaffsReports) GetOccupationalPersonality() (val string) {
	if m == nil {
		return
	}
	return m.OccupationalPersonality
}

func (m *StaffsReports) GetPersonalityDisorder() (val string) {
	if m == nil {
		return
	}
	return m.PersonalityDisorder
}

func (m *StaffsReports) GetLeadershipStyle() (val string) {
	if m == nil {
		return
	}
	return m.LeadershipStyle
}

func (m *StaffsReports) GetOrgCommitment() (val string) {
	if m == nil {
		return
	}
	return m.OrgCommitment
}

func (m *StaffsReports) GetResult() (val string) {
	if m == nil {
		return
	}
	return m.Result
}

func (m *StaffsReports) GetProfessionalSkillsAvgScore() (val float64) {
	if m == nil {
		return
	}
	return m.ProfessionalSkillsAvgScore
}

func (m *StaffsReports) GetPotentialAvgScore() (val float64) {
	if m == nil {
		return
	}
	return m.PotentialAvgScore
}

func (m *StaffsReports) GetQualityAvgScore() (val float64) {
	if m == nil {
		return
	}
	return m.QualityAvgScore
}

func (m *StaffsReports) GetPerformanceLevelStandard() (val string) {
	if m == nil {
		return
	}
	return m.PerformanceLevelStandard
}

func (m *StaffsReports) GetPersonalities() (val string) {
	if m == nil {
		return
	}
	return m.Personalities
}

func (m *StaffsReports) GetIsDeleted() (val int) {
	if m == nil {
		return
	}
	return m.IsDeleted
}

func (m *StaffsReports) GetCreatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.CreatedAt
}

func (m *StaffsReports) GetUpdatedAt() (val time.Time) {
	if m == nil {
		return
	}
	return m.UpdatedAt
}

func (m *StaffsReports) String() string {
	return fmt.Sprintf("%#v", m)
}

func (m *StaffsReports) TableName() string {
	return "staffs_reports"
}

func (m *StaffsReports) Save(t ...*StaffsReports) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *StaffsReports
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		if i.Id > 0 {
			return m.Dao.UpdateById(i)
		} else {
			return m.Dao.Insert(i)
		}
	}
}

func (m *StaffsReports) Saves(t []*StaffsReports) (affected int64, err error) {
	return m.Dao.Insert(t)
}

func (m *StaffsReports) Insert(t ...*StaffsReports) (affected int64, err error) {
	if len(t) > 1 {
		return m.Dao.Insert(t)
	} else {
		var i *StaffsReports
		if len(t) == 0 {
			if m.Dao == nil {
				panic("dao not init")
			}
			i = m
		} else if len(t) == 1 {
			i = t[0]
		}
		return m.Dao.Insert(i)
	}
}

func (m *StaffsReports) Update(params db.Cond,
	where db.Cond) (affected int64, err error) {
	return m.Dao.UpdateByWhere(m, params, where)
}

func (m *StaffsReports) SearchOne(cond db.Cond) (t *StaffsReports, err error) {
	if cond == nil {
		cond = db.Cond{}
	}
	cond["page"] = 1
	cond["pagesize"] = 1

	rs, err := m.Search(cond)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}

	return
}

func (m *StaffsReports) Search(cond db.Cond) (t []*StaffsReports, err error) {
	err = m.Dao.Search(&t, cond)
	return
}

func (m *StaffsReports) SearchAndCount(cond db.Cond) (t []*StaffsReports, total int64, err error) {
	total, err = m.Dao.SearchAndCount(&t, cond)
	return
}

func (m *StaffsReports) Rows(cond db.Cond) (rows *xorm.Rows, err error) {
	return m.Dao.Rows(m, cond)
}

func (m *StaffsReports) Iterate(cond db.Cond, f xorm.IterFunc) (err error) {
	return m.Dao.Iterate(m, cond, f)
}

func (m *StaffsReports) Count(cond db.Cond) (total int64, err error) {
	return m.Dao.Count(m, cond)
}

func (m *StaffsReports) GetMulti(ids ...interface{}) (t []*StaffsReports, err error) {
	err = m.Dao.GetMulti(&t, ids...)
	return
}

func (m *StaffsReports) GetByIds(ids ...interface{}) (t []*StaffsReports, err error) {
	return m.GetMulti(ids...)
}

func (m *StaffsReports) GetById(id interface{}) (t *StaffsReports, err error) {
	rs, err := m.GetMulti(id)
	if err != nil {
		return
	}
	if len(rs) > 0 {
		t = rs[0]
	}
	return
}

func (m *StaffsReports) Replace(cond db.Cond) (int64, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Replace(fmt.Sprintf("REPLACE `%s` SET ", m.TableName()), cond)
}

func (m *StaffsReports) Exec(sqlState string, args ...interface{}) (sql.Result, error) {
	defer m.Dao.ClearCache(m)
	return m.Dao.Exec(sqlState, args...)
}

func (m *StaffsReports) Query(args ...interface{}) ([]map[string][]byte, error) {
	return m.Dao.Query(args...)
}

func (m *StaffsReports) QueryString(args ...interface{}) ([]map[string]string, error) {
	return m.Dao.QueryString(args...)
}

func (m *StaffsReports) QueryInterface(args ...interface{}) ([]map[string]interface{}, error) {
	return m.Dao.QueryInterface(args...)
}

//以下用于事务，注意同个实例不能在多个goroutine同时使用
//使用完毕需要执行Close()，当Close的时候如果没有commit，会自动rollback
//参数只能是0-1个，可以是
//  configs.DbConfig    新生成dao
//  *db.XormDao         使用现有的dao
//  空                  使用默认的数据库配置
func NewStaffsReports(c ...interface{}) (m *StaffsReports, err error) {
	m = &StaffsReports{}
	var dbConfig configs.DbConfig
	if len(c) == 0 {
		dbConfig = hfw.Config.Db
	} else if len(c) == 1 {
		switch c[0].(type) {
		case configs.DbConfig:
			dbConfig = c[0].(configs.DbConfig)
		case *db.XormDao:
			m.Dao = c[0].(*db.XormDao)
			if m.Dao == nil {
				return nil, errors.New("nil dao")
			}
			return
		default:
			return nil, errors.New("error configs")
		}
	} else {
		return nil, errors.New("too many configs")
	}

	m.Dao, err = db.NewXormDao(hfw.Config, dbConfig)
	if err != nil {
		return nil, err
	}
	m.Dao.NewSession()

	return
}

func (m *StaffsReports) Close() {
	m.Dao.Close()
}

func (m *StaffsReports) Begin() error {
	return m.Dao.Begin()
}

func (m *StaffsReports) Rollback() error {
	return m.Dao.Rollback()
}

func (m *StaffsReports) Commit() error {
	return m.Dao.Commit()
}
