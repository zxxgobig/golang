package controllers

import (
    "ifchange/dhr/logics/project"
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/projects_reports", &ProjectsReport{})
}

const (
    projectID = 60
)

func TestProjectsReportsPotential(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
    }
    rsp := test.Do(t, "/projects_reports/potential", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/potential results: <%+s>", b)

}

func TestProjectsReportsQuality(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
    }
    rsp := test.Do(t, "/projects_reports/quality", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/quality results: <%+s>", b)

}

func TestProjectsReportsProfessionalSkills(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
    }
    rsp := test.Do(t, "/projects_reports/professional_skills", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/professional_skills results: <%+s>", b)

}

func TestProjectsReportsPersonalityEval(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
    }
    rsp := test.Do(t, "/projects_reports/personality_eval", param)

    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/personality_eval results: <%+s>", b)

}

func TestProjectsReportsResult(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
        SceneID   int `json:"scene_id,omitempty"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: 60,
        SceneID:   2,
    }
    rsp := test.Do(t, "/projects_reports/result", param)
    t.Logf("respone: %v", string(rsp.Results))
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/result results: <%+s>", string(b))

}

func TestProjectsReportsExcellentCharacter(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: 60,
    }
    rsp := test.Do(t, "/projects_reports/excellent_character", param)
    t.Logf("respone: %#v", rsp)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/excellent_character results: <%+s>", b)

}

func TestProjectsReportsPerformance(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
    }
    rsp := test.Do(t, "/projects_reports/performance", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/performance results: <%+s>", b)

}

func TestProjectsReportsInventoryProgress(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID int `json:"project_id"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
    }
    rsp := test.Do(t, "/projects_reports/inventory_progress", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/inventory_progress results: <%+s>", b)

}

func TestProjectsReportsDump(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }
    param := struct {
        *Session
        ProjectID    int                   `json:"project_id" validate:"required"`
        Name         string                `json:"name" validate:"required"`
        AdjustStaffs []project.AdjustStaff `json:"adjust_staffs" validate:"required"`
    }{
        Session: &Session{
            SessionID: session,
        },
        ProjectID: projectID,
        Name:      "hahah",
        AdjustStaffs: []project.AdjustStaff{
            {
                ID:       4,
                Original: 5,
                Target:   4,
            },
        },
    }
    rsp := test.Do(t, "/projects_reports/dump", param)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/projects_reports/dump results: <%+s>", b)

}
