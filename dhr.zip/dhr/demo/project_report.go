package demo

import (
    "encoding/json"

    "ifchange/dhr/logics/common"
    "ifchange/dhr/logics/lambda"
    "ifchange/dhr/logics/stat"

    "gitlab.ifchange.com/bot/hfw"
)

func in(num int, list []int) bool {
    //if hfw.GetEnv() != hfw.PROD {
    //	return false
    //}
    for _, i := range list {
        if i == num {
            return true
        }
    }

    return false
}

var demoProjectIDList []int
var prodDemoProjectIDList = []int{25, 26, 27, 28}
var devDemoProjectIDList = []int{57, 58, 59, 60, 269, 270}

func init() {
    if hfw.GetEnv() == hfw.PROD {
        demoProjectIDList = prodDemoProjectIDList
        return
    }

    demoProjectIDList = devDemoProjectIDList
}

func GetResult(projectID, sceneID int) interface{} {
    if !in(projectID, demoProjectIDList) {
        return nil
    }
    if sceneID == 0 { // fix demo data pdf export
        sceneID = 1
    }

    var result []stat.InventoryResultItem
    switch sceneID {
    case lambda.SceneDevelopmentPersonnel: // 团队发展建议
        err := json.Unmarshal(r1, &result)
        if err != nil {
            panic(err)
        }
    case lambda.ScenePromotion: // 人才结构扫描
        err := json.Unmarshal(r2, &result)
        if err != nil {
            panic(err)
        }
    case lambda.ScenePotential: // 团队潜力发展建议
        err := json.Unmarshal(r3, &result)
        if err != nil {
            panic(err)
        }
    case lambda.SceneHierarchy: // 形成分层级能力标准
        err := json.Unmarshal(r4, &result)
        if err != nil {
            panic(err)
        }
    }

    return result
}

func GetPerformance(projectID int) interface{} {
    if !in(projectID, demoProjectIDList) {
        return nil
    }

    var result *stat.GroupPerformanceResult
    err := json.Unmarshal(performance, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetExcellent(projectID int) interface{} {
    if !in(projectID, demoProjectIDList) {
        return nil
    }

    var result *stat.ExcellentCharacterResult
    err := json.Unmarshal(excellent, &result)
    if err != nil {
        panic(err)
    }

    return result
}

// 项目详情-工作选择价值观 6
func GetJobChoiceValue(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *common.JobChoiceValue
    err := json.Unmarshal(JobChoiceValue, &result)
    if err != nil {
        panic(err)
    }

    return result
}

// 项目详情-关键经历 7
func GetKeyExperience(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *common.KeyExperience
    err := json.Unmarshal(KeyExperience, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetLeadershipStyle(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(LeadershipStyle, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetEmotionalIntelligence(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(EmotionalIntelligence, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetOrgCommitment(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(OrgCommitment, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetPracticalIntelligence(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(PracticalIntelligence, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetOccupationalPersonality(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(OccupationalPersonality, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetCriticalThinking(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(CriticalThinking, &result)
    if err != nil {
        panic(err)
    }

    return result
}

func GetPersonalityDisorder(projectId int) interface{} {
    if !in(projectId, demoProjectIDList) {
        return nil
    }

    var result *stat.InterviewResult
    err := json.Unmarshal(PersonalityDisorder, &result)
    if err != nil {
        panic(err)
    }

    return result
}
