package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/test"
)

func init() {
    _ = hfw.Handler("/interviews_configs", &InterviewsConfigs{})
}

// go test ./controllers -run TestInterviewsConfigsAddSkill -e local -v

func TestInterviewsConfigsAddSkill(t *testing.T) {
    session, _ := GetSession()

    params := &struct {
        *Session
        InterviewId int    `json:"interview_id"`
        Name        string `json:"name"`
    }{
        Session: &Session{
            SessionID: session,
        },
        InterviewId: 3,
        Name:        "新技能",
    }
    rsp := test.Do(t, "/interviews_configs/addskill", &params)
    b, _ := rsp.Results.MarshalJSON()
    t.Logf("/interviews_configs/addskill res: <%+v>", b)
}
