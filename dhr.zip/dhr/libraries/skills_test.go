package libraries

import "testing"

func TestGetProfessionalSkillName(t *testing.T) {
    type args struct {
        companyID int
        skillID   int
    }
    tests := []struct {
        name     string
        args     args
        wantName string
        wantErr  bool
    }{
        {name: "skillID=1", args: args{companyID: 1, skillID: 1}, wantName: "统计学知识", wantErr: false},
        {name: "skillID=2", args: args{companyID: 1, skillID: 2}, wantName: "电气工程知识", wantErr: false},
        {name: "skillID=3", args: args{companyID: 1, skillID: 3}, wantName: "供应链管理知识", wantErr: false},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            gotName, err := GetProfessionalSkillName(tt.args.companyID, tt.args.skillID)
            if (err != nil) != tt.wantErr {
                t.Errorf("GetProfessionalSkillName() error = %v, wantErr %v", err, tt.wantErr)
                return
            }
            if gotName != tt.wantName {
                t.Errorf("GetProfessionalSkillName() = %v, want %v", gotName, tt.wantName)
            }
        })
    }
}
