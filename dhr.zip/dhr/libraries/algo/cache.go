package algo

import (
    "encoding/json"
    "fmt"
    "sort"
    "time"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfw/encoding"
    "gitlab.ifchange.com/bot/hfw/redis"
    "gitlab.ifchange.com/bot/hfwkit/config"
)

var expiredIn = 7 * 24 * time.Hour

func GetCache(req *FeatureImportanceRequest) (*FeatureImportanceResponse, error) {
    key, err := getCacheKey(req)
    if err != nil {
        return nil, err
    }

    logger.Debugf("algo-cache: get cache key: %v", key)

    data, err := redis.Get(key)
    if err != nil {
        return nil, fmt.Errorf("GetCache from redis error: %v", err)
    }

    if data == nil {
        logger.Debugf("algo-cache: no cached data")
        return nil, nil
    }

    d := data.(string)
    response := &FeatureImportanceResponse{}
    err = json.Unmarshal([]byte(d), &response)
    if err != nil {
        return nil, fmt.Errorf("GetCache json.Unmarshal error: %v", err)
    }

    logger.Debugf("algo-cache: cached response: %#v", *response)

    return response, nil
}

func SetCache(req *FeatureImportanceRequest, response *FeatureImportanceResponse) error {
    data, err := json.Marshal(&response)
    if err != nil {
        return fmt.Errorf("set cache json.Marshal error: %v", err)
    }

    key, err := getCacheKey(req)
    if err != nil {
        return err
    }

    logger.Debugf("algo-cache: set cache key: %v", key)

    err = redis.SetEx(key, string(data), int(expiredIn.Seconds()))
    if err != nil {
        return fmt.Errorf("set to redis error: %v", err)
    }
    return nil
}

func getCacheKey(req *FeatureImportanceRequest) (string, error) {

    len1 := len(req.SkillIds)
    len2 := len(req.Data)
    length := fmt.Sprintf("%d-%d", len1, len2)
    sort.Slice(req.Data, func(i, j int) bool {
        return req.Data[i].StaffID < req.Data[j].StaffID
    })
    for _, d := range req.Data {
        length += fmt.Sprintf("%d-%d-%d-%d-%s-%s",
            len(d.Potential),
            len(d.PersonalityEval),
            len(d.ProfessionalSkills),
            len(d.Quality),
            d.StandardLevel,
            d.Level)
    }

    return fmt.Sprintf("%s-%s-fix2", config.AppConfig.Redis.Prefix, encoding.Base64Encode([]byte(length))), nil
}
