package v2_interview

import (
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    OrgCommitmentRecommend struct {
        Name     string `json:"name"`
        Desc     string `json:"desc"`
        Index    int    `json:"index"`
        IsAdvice bool   `json:"is_advice"`
        IsMust   bool   `json:"is_must"`
    }
)

func ProcessOrgCommitmentRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *OrgCommitmentRecommend {
    interview, ok := interviewsM[kitinterview.OrgCommitment]
    if !ok {
        return nil
    }

    return &OrgCommitmentRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.OrgCommitment),
        IsAdvice: GetIsAdvice(kitinterview.OrgCommitment, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.OrgCommitment, sceneId, sceneTemplateId),
    }
}
