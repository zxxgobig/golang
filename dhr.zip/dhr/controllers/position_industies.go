package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/position"

    "gitlab.ifchange.com/bot/hfwkit/api"

    "gitlab.ifchange.com/bot/hfw"
)

type PositionIndustries struct {
    core.Controller
}

/**
 * @api {post} /position_industries/list 行业列表
 * @apiVersion 0.1.0
 * @apiGroup Position
 * @apiDescription 行业列表
 *
 * @apiParam {String} session session
 *
 * @apiParamExample {json} Request-Example:
 {
	"session":""
 }
 *
 * @apiSuccess {Number} results.total 总数
 * @apiSuccess {Object[]} results.list 列表
 * @apiSuccess {Object} results.list.item 一级职级
 * @apiSuccess {Object} results.list.sub_items 子职级
 *
 * @apiSuccessExample {json} Response-Example:
 [
	{
		"item": {
			"id": 536,
			"name": "零售",
			"parent_id": 0,
			"depth": 1,
			"p1": 0,
			"p2": 0,
			"p3": 0,
			"p4": 0,
			"is_deleted": 0,
			"updated_at": "1560999235",
			"created_at": "1560999235"
		},
		"sub_items": [
			{
				"id": 832,
				"name": "花卉服务",
				"parent_id": 536,
				"depth": 2,
				"p1": 536,
				"p2": 0,
				"p3": 0,
				"p4": 0,
				"is_deleted": 0,
				"updated_at": "1560999235",
				"created_at": "1560999235"
			}
		]
 	}
]
 *
*/

func (c *PositionIndustries) List(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        Page     int `json:"page"`
        PageSize int `json:"page_size"`
    }{}
    err := api.RequestUnmarshal(httpCtx, &param)
    httpCtx.ThrowCheck(20304001, err)
    result, total, err := position.NewPositionIndustries().List(param.Page, param.PageSize)
    httpCtx.ThrowCheck(20304001, err)

    httpCtx.Results = ListResult{
        Total: total,
        List:  result,
    }
}
