package controllers

import (
    "testing"

    "gitlab.ifchange.com/bot/hfwkit/test"
)

/*
go test ./controllers -run TestPositionFunctions -e local -v
*/
func TestPositionFunctions(t *testing.T) {
    session, err := GetSession()
    if err != nil {
        t.Fatal(err)
    }

    params := &struct {
        *Session
        Page     int `json:"page"`
        PageSize int `json:"page_size"`
    }{
        Session: &Session{
            SessionID: session,
        },
        Page:     0,
        PageSize: 0,
    }

    rsp := test.Do(t, "/position_functions/list", &params)
    b, err := rsp.Results.MarshalJSON()
    if err != nil {
        t.Fatal(err)
    }
    t.Logf("/position_functions/list results: <%+s>", b)
}
