package controllers

import (
    "ifchange/dhr/core"
    "ifchange/dhr/logics/project/permission"

    "gitlab.ifchange.com/bot/hfw"
)

type Permission struct {
    core.Controller
}

/**
* @api {post} /permission/shared_mapping_data 分享项目的操作权限
* @apiVersion 1.0.0
* @apiGroup Permission
* @apiDescription 分享项目的操作权限
*
* @apiParam {String} session Session
* @apiParam {String} type 资源类型：1，项目；2，采集计划
* @apiParam {String} id 资源 id：若 type 为 1， 填项目 id；若 type 为 2，填采集计划 id
*
* @apiParamExample {json} Request-Example:
* {
*	"session": "",
*   "type": 1,
*	"id": 2
* }
* @apiSuccess {Object} results 返回结果
* @apiSuccess {Object[]} results.data 权限资源
* @apiSuccess {String} results.data.resource_key 资源名称
* @apiSuccess {Number} results.data.permission 权限等级，1， write；2，read；3，hidden

* @apiSuccessExample {json} Success-Response:
 		{
            "data": [
                {
                    "resource_key": "bot_collection_notice",
                    "permission": 2
                },
                {
                    "resource_key": "bot_collection_link",
                    "permission": 2
                },
                {
                    "resource_key": "bot_collection_operate",
                    "permission": 2
                },
                {
                    "resource_key": "bot_collection_create",
                    "permission": 2
                }
            ]
        }
*/

func (Permission) SharedMappingData(httpCtx *hfw.HTTPContext) {
    param := struct {
        *Session
        Type int `json:"type"`
        ID   int `json:"id"`
    }{}

    curUser, err := ValidateAndUnMarshal(httpCtx, &param)
    httpCtx.ThrowCheck(core.InvalidParamsErrNo, err)
    if curUser.RoleType == 1 {
        data, err := permission.AllPermission()
        httpCtx.ThrowCheck(core.SystemErrNo, err)
        httpCtx.Results = &struct {
            Data interface{} `json:"data"`
        }{data}
        
        return
    }

    data, err := permission.DataPermission(curUser.Id, param.Type, param.ID)
    httpCtx.ThrowCheck(core.SystemErrNo, err)

    httpCtx.Results = &struct {
        Data interface{} `json:"data"`
    }{data}

    return
}
