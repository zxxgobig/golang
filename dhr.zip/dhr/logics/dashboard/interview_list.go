package dashboard

import (
	"sort"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"

	"ifchange/dhr/core"
	"ifchange/dhr/logics/lambda"
	"ifchange/dhr/models"
)

type (
	InterviewListResult struct {
		List []*InterviewListResultItem `json:"list"`
	}
	InterviewListResultItem struct {
		Id   int    `json:"id"`
		Name string `json:"name"`
	}
)

func InterviewList(companyId, sceneId int) (result *InterviewListResult, err error) {
	projects, err := models.ProjectsModel.Search(db.Cond{
		"is_deleted": 0,
		"company_id": companyId,
		"scene_id":   sceneId,
	})
	if err != nil {
		return nil, common.NewRespErr(core.SystemErrNo, err)
	}
	if projects == nil {
		return
	}

	projectIds := make([]int, 0, len(projects))
	for _, v := range projects {
		projectIds = append(projectIds, v.Id)
	}

	projectsInterviewsConfigs, err := models.ProjectsInterviewsConfigsModel.Search(db.Cond{
		"is_deleted":    0,
		"project_id in": projectIds,
		"is_show":       models.SHOW,
	})
	if err != nil {
		return nil, common.NewRespErr(core.SystemErrNo, err)
	}
	if projectsInterviewsConfigs == nil {
		return
	}

	result = &InterviewListResult{List: make([]*InterviewListResultItem, 0, 7)}
	result.List = append(result.List, &InterviewListResultItem{
		Id:   0,
		Name: lambda.InterviewItemNames[0],
	})

	interviewIdM := make(map[int]struct{})
	for _, v := range projectsInterviewsConfigs {
		switch v.InterviewId {
		case lambda.InterviewPersonalityEval, lambda.InterviewKnowledge, lambda.InterviewWorkValues, lambda.InterviewKeyExperience:
			goto FILTER
		}
		if _, ok := interviewIdM[v.InterviewId]; !ok {
			interviewIdM[v.InterviewId] = struct{}{}
			result.List = append(result.List, &InterviewListResultItem{
				Id:   v.InterviewId,
				Name: lambda.InterviewItemNames[v.InterviewId],
			})
		}
	FILTER:
	}

	sort.Slice(result.List, func(i, j int) bool {
		return result.List[i].Id < result.List[j].Id
	})

	return
}
