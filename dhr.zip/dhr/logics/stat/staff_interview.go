package stat

import (
	"gitlab.ifchange.com/bot/hfwkit/dhr/interview"
	"gitlab.ifchange.com/bot/hfwkit/dhr/stat/client"
	pb "gitlab.ifchange.com/bot/proto/dhr/stat"
)

func GetStaffInterviewData(companyID, projectID, staffID, reportID int, interviewType interview.Type) (*InterviewResult, error) {
	statType, id := parseStatTypeAndID(companyID, projectID)

	result, err := client.GetStaffInterviewData(nil, &pb.StaffInterviewDataRequest{
		CompanyId:   int64(companyID),
		StatType:    statType,
		Id:          int64(id),
		StaffId:     int64(staffID),
		InterviewId: int64(interviewType),
	})
	if err != nil {
		return nil, err
	}
	if result == nil {
		return nil, nil
	}

	return &InterviewResult{
		StaffID: staffID,
		Data:    getStatFormResponseDataStaff("此员工得分", result.Axes, getStatOption(interviewType, result.ExcellentScore)),
	}, nil
}

func getStatOption(interviewType interview.Type, excellentScore float64) *Option {
	if interviewType == interview.LeadershipStyle {
		return &Option{
			InterviewID:    int(interviewType),
			StatScore:      false,
			StatFreq:       true,
			ExcellentScore: excellentScore,
		}
	}
	return &Option{
		InterviewID:    int(interviewType),
		StatScore:      true,
		StatAVG:        true,
		StatExcellent:  true,
		ExcellentScore: excellentScore,
	}
}

func parseStatTypeAndID(companyID, projectID int) (statType pb.StatType, id int) {
	if projectID == 0 {
		return pb.StatType_COMPANY, companyID
	}

	return pb.StatType_PROJECT, projectID
}
