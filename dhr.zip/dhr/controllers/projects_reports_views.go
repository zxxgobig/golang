package controllers

import (
	"ifchange/dhr/demo"
	"ifchange/dhr/logics/project"
	"ifchange/dhr/logics/stat"

	"gitlab.ifchange.com/bot/hfw"
	"gitlab.ifchange.com/bot/hfwkit/api"
)

type ProjectsReportRequest struct {
	*Session
	Token     string `json:"token,omitempty"`
	CompanyId int    `json:"company_id,omitempty"`
	ProjectID int    `json:"project_id"`
	ReportID  int    `json:"report_id"`
	SceneID   int    `json:"scene_id,omitempty"`
}

/**
 * @api {post} /projects_reports/inventory_progress 项目详情-盘点进度
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-盘点进度
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 3
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.total 项目总人数
 * @apiSuccess {Number} result.finish 完成人数
 * @apiSuccess {Number} result.finish_rate 完成人数 rate
 * @apiSuccess {Number} result.finish_last_add 最近七天增加的完成人数
 * @apiSuccess {Number} result.star_staff 明星员工人数
 * @apiSuccess {Number} result.star_staff_last_add 最近七天增加的明星员工人数
 * @apiSuccess {Number} result.inefficiency_staff 低效员工人数
 * @apiSuccess {Number} result.inefficiency_staff_last_add 最近七天增加的低效员工人数
 *
 * @apiSuccessExample {json} Response-Example:
 *		{
 *			"total": 1000,
 *			"finish": 800,
 *			"finish_rate": 0.8,
 *			"finish_last_add": +2,
 *			"star_staff": 23,
 *			"star_staff_last_add": 0,
 *			"inefficiency_staff": 98,
 *			"inefficiency_staff_last_add": -5
 *		}
 *
 */
func (c *ProjectsReport) InventoryProgress(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	progress, err := project.InventoryProgress(curUser.CompanyId, req.ProjectID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = progress
}

/**
 * @api {post} /projects_reports/result 项目详情-盘点结果和建议
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-盘点结果和建议
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 * @apiParam {Number} scene_id 目标（场景） ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 3,
 *	   "scene_id": 1
 * }
 *
 * @apiSuccess {Object[]} result 返回结果，为列表
 * @apiSuccess {String} result.name 名称
 * @apiSuccess {String[]} result.list 描述文字列表
 * @apiSuccess {String[]} result.position_levels 团队发展建议
 * @apiSuccess {Object[]} result.position_levels 岗位层级列表
 * @apiSuccess {Number} result.position_levels.name 岗位层级名称
 * @apiSuccess {Number} result.position_levels.count 岗位层级人员个数
 * @apiSuccess {String[]} result.position_levels.desc 岗位层级描述
 * @apiSuccess {Object[]} result.position_levels.staff_list 岗位层级员工列表
 * @apiSuccess {Number} result.position_levels.staff_list.id 岗位层级员工 ID
 * @apiSuccess {Number} result.position_levels.staff_list.distribution_id 岗位层级员工所在九宫格位置 ID
 * @apiSuccess {String} result.position_levels.staff_list.name 岗位层级员工名称
 * @apiSuccess {String} result.position_levels.staff_list.department 岗位层级员工部门
 * @apiSuccess {Number} result.position_levels.staff_list.status 岗位层级员工状态
 *
 * @apiSuccessExample {json} Response-Example:
 *	[
 *	    {
 *	        "name": "团队优势",
 *	        "list": [
 *	            "Golang",
 *	            "Java"
 *	        ]
 *	    },
 *	    {
 *	        "name": "团队劣势",
 *	        "list": [
 *	            "关系建立",
 *	            "沟通影响"
 *	        ]
 *	    },
 *	    {
 *	        "name": "团队发展建议",
 *	        "list": [
 *	            "建议未来对于公司业务进行更为深入的思考",
 *	            "理解业务的关键成功要素和痛点",
 *	            "找到自身工作与业务的深度结合点，使得组织工作的种种创新举措可以对业务和公司产生更为深刻的影响。"
 *	        ]
 *	    },
 *	    {
 *	        "name": "团队任用/晋升建议",
 *	        "list": [
 *	            "1条，字数大致100字左右。"
 *	        ]
 *	    },
 *	    {
 *	        "name": "形成层级划分与能力标准",
 *	        "list": [
 *	            "根据综合能力水平，可以将员工分为初级XXX（岗位名称）、中级XXX（岗位名称）、高级XXX（岗位名称）"
 *	        ],
 *	        "position_levels": [
 *	            {
 *	                "name": "初级XXX（岗位名称）",
 *	                "count": 42,
 *	                "staff_list": [{
 *	                  "id": 2,
 *	                  "distribution_id": 1,
 *	                  "name": "秦皓",
 *	                  "department": "开发部",
 *	                  "status": 1
 *	                },{
 *	                  "id": 12,
 *	                  "distribution_id": 2,
 *	                  "name": "秦皓皓",
 *	                  "department": "开发部",
 *	                  "status": 3
 *	                }],
 *	                "desc": [
 *	                    "基本掌握公司产品知识、销售话术，能够在工作中应用，正常履行工作职责。",
 *	                    "具有较强的客户导向，能够主动征求客户意见，并付诸行动、进行改进",
 *	                    "具有较强的业绩意识，为自己或自己的团队设定高水准而又切合实际的目标，以提高业绩"
 *	                ]
 *	            },
 *	            {
 *	                "name": "中级XXX（岗位名称）",
 *	                "count": 18,
 *	                "staff_list": [{
 *	                  "id": 2,
 *	                  "distribution_id": 4,
 *	                  "name": "秦皓",
 *	                  "department": "开发部",
 *	                  "status": 1
 *	                },{
 *	                  "id": 12,
 *	                  "distribution_id": 9,
 *	                  "name": "秦皓皓",
 *	                  "department": "开发部",
 *	                  "status": 3
 *	                }],
 *	                "desc": [
 *	                    "基本掌握公司产品知识、销售话术，能够在工作中应用，正常履行工作职责。",
 *	                    "具有较强的客户导向，能够主动征求客户意见，并付诸行动、进行改进",
 *	                    "具有较强的业绩意识，为自己或自己的团队设定高水准而又切合实际的目标，以提高业绩"
 *	                ]
 *	            },
 *	            {
 *	                "name": "高级XXX（岗位名称）",
 *	                "count": 0,
 *	                "desc": [
 *	                    "基本掌握公司产品知识、销售话术，能够在工作中应用，正常履行工作职责。",
 *	                    "具有较强的客户导向，能够主动征求客户意见，并付诸行动、进行改进",
 *	                    " 具有较强的业绩意识，为自己或自己的团队设定高水准而又切合实际的目标，以提高业绩"
 *	                ]
 *	            }
 *	        ]
 *	    }
 *	]
 */
func (c *ProjectsReport) Result(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}

	if req.ReportID == 0 {
		result = demo.GetResult(req.ProjectID, req.SceneID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}

	result, err = stat.Result(curUser.CompanyId, req.ProjectID, req.SceneID)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/excellent_character 项目详情-绩优者特征
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-绩优者特征
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 3
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {String} result.main_desc 主描述
 * @apiSuccess {String} result.extra_desc 附加描述
 * @apiSuccess {Object[]} result.axes 绩优者维度信息列表
 * @apiSuccess {Number} result.axes.id 维度 ID
 * @apiSuccess {String} result.axes.name 维度名称
 * @apiSuccess {String} result.axes.desc 维度描述
 * @apiSuccess {Object[]} result.characters 绩优者特征列表
 * @apiSuccess {Number} result.characters.id 绩优者特征 ID
 * @apiSuccess {Number} result.characters.type 绩优者特征类型，1 高亮； 2 普通
 * @apiSuccess {String} result.characters.name 绩优者特征名称
 * @apiSuccess {Number} [result.characters.excellent_score] 绩优者得分，高亮类型才有这个字段
 * @apiSuccess {Number} [result.characters.avg_score] 平均得分，高亮类型才有这个字段
 *
 * @apiSuccessExample {json} Response-Example:
 *		{
 *			"main_desc": "唯家置业顾问岗位上绩效表现优秀的员工呈现出一些共同的特征",
 *			"axes": [{
 *						"id": 1,
 *						"name": "专业知识",
 *						"desc": "他们通常熟知区域内楼盘相关知识，精通房地产销售话术与技巧"
 *					},{
 *						"id": 1,
 *						"name": "素质",
 *						"desc": "他们通常熟知区域内楼盘相关知识，精通房地产销售话术与技巧"
 *					},{
 *						"id": 1,
 *						"name": "性格",
 *						"desc": "唯家置业顾问岗位上绩效表现优秀的员工呈现出一些共同的特征。他们通常熟知区域内楼盘相关知识，精通房地产销售话术与技巧"
 *					},{
 *						"id": 1,
 *						"name": "潜力",
 *						"desc": "。他们通常熟知区域内楼盘相关知识，精通房地产销售话术与技巧"
 *					}
 *			 ],
 *			"extra_desc": "唯家置业顾问岗位上绩效表现优秀的员工呈现出一些共同的特征",
 *			"characters": [{
 *					"id": 1,
 *					"name": "潜力巨大",
 *					"type": 1,
 *					"excellent_score": 3,
 *					"avg_score": 2
 *				},{
 *					"id": 3,
 *					"type": 1,
 *					"name": "上进",
 *					"excellent_score": 3,
 *					"avg_score": 2
 *				},{
 *					"id": 3,
 *					"type": 2
 *					"name": "自律"
 *				}{
 *					"id": 3,
 *					"type": 2
 *					"name": "冷静"
 *				}
 *			]
 *		}
 *
 */
func (c *ProjectsReport) ExcellentCharacter(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, req))

	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}

	if req.ReportID == 0 {
		result = demo.GetExcellent(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}

	result, err = stat.ExcellentCharacter(curUser.CompanyId, req.ProjectID)

	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/inventory_over_view 项目详情-盘点结果概览
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-盘点结果概览
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 3,
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {String} result.interview_id 0代表综合能力，5代表潜力
 * @apiSuccess {String} result.data 具体数据
 *
 * @apiSuccessExample {json} Response-Example:
 * {
		"interview_id":0,
        "data":{
			"inventory_over_view_synthetic": {
               "0": {
                   "count": 1,
                   "percent": 0.333,
                   "name": "重点晋升"
               },
               "1": {
                   "name": "持续贡献",
                   "count": 0,
                   "percent": 0
               },
               "2": {
                   "name": "需要提升",
                   "count": 2,
                   "percent": 0.667
               },
               "3": {
                   "name": "亟待关注",
                   "count": 0,
                   "percent": 0
               }
           },
           "inventory_over_view_potential": {
               "num": 0,
               "count": 0,
               "percent": 0
           },
           "top": [
               {
					"status": 1,
					"name": "卢一浩",
					"department_name": "素质验证部",
					"position_name": "设计岗位",
					"id": 496,
					"no": "753951789"
				},
				{
					"status": 3,
					"name": "小娟娟",
					"department_name": "",
					"position_name": "",
					"id": 8818,
					"no": "xjj001"
				},
				{
					"department_name": "陈赐测试部门",
					"position_name": "1111",
					"id": 8874,
					"no": "N0000120",
					"status": 1,
					"name": "测试陈赐"
				}
           ],
           "last": [
               {
					"id": 8874,
					"no": "N0000120",
					"status": 1,
					"name": "测试陈赐",
					"department_name": "陈赐测试部门",
					"position_name": "1111"
				},
				{
					"department_name": "",
					"position_name": "",
					"id": 8818,
					"no": "xjj001",
					"status": 3,
					"name": "小娟娟"
				},
				{
					"name": "卢一浩",
					"department_name": "素质验证部",
					"position_name": "设计岗位",
					"id": 496,
					"no": "753951789",
					"status": 1
				}
           ]
       }
 * }
 *
*/
func (c *ProjectsReport) InventoryOverView(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID int `json:"project_id" validate:"gte=1"`
		ReportID  int `json:"report_id" validate:"gte=0"`
	}{}
	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(20304001, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	result, err := stat.GroupInventoryOverView(curUser.CompanyId, params.ProjectID, params.ReportID)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/inventory_distribution 项目详情-人才盘点分布
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-人才盘点分布
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 * @apiParam {Number} interview_id 测评 id; 0 表示【综合能力】
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 3,
 *	   "interview_id": 0
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object[]} result.list 九宫格分布列表
 * @apiSuccess {Number} result.list.axis_x 分布位置坐标 x 轴
 * @apiSuccess {Number} result.list.axis_y 分布位置坐标 y 轴
 * @apiSuccess {Number} result.list.name 分布位置名称
 * @apiSuccess {Number} result.list.count 人数
 * @apiSuccess {Number} result.list.percent 占比，单位 %
 * @apiSuccess {String[]} result.list.development_advice 团队发展建议
 * @apiSuccess {String} result.list.promotion_advice 团队任用/晋升建议
 * @apiSuccess {Object[]} result.list.staffs 员工列表
 * @apiSuccess {Number} result.list.staffs.id 员工 ID
 * @apiSuccess {Number} result.list.staffs.no 员工工号
 * @apiSuccess {Number} result.list.staffs.status 员工状态
 * @apiSuccess {String} result.list.staffs.name 员工姓名
 * @apiSuccess {String} result.list.staffs.avatar_url 员工头像链接
 * @apiSuccess {String} result.list.staffs.department_name 部门名称
 *
 * @apiSuccessExample {json} Response-Example:
 *		{
 *			"list": [{
 *				"axis_x": 1,
 *				"axis_y": 3,
 *				"name": "潜力员工",
 *				"count": 2,
 *				"percent": 16,
 *				"promotion_advice": "建议xxxx",
 *				"development_advice": ["建议1","建议2","建议3"],
 *				"staffs": [{
 *					"id": 1001,
 *					"no": "NO001",
 *					"status": 1,
 *					"name": "秦皓皓",
 *					"avatar_url": "http://xxx.png"
 *					"department_name": "部门啊"
 *				},{
 *					"id": 1002,
 *					"no": "NO002",
 *					"status": 2,
 *					"name": "泽明",
 *					"avatar_url": "http://yyyy.png"
 *					"department_name": "部门啊"
 *				}]
 *			},{
 *				"axis_x": 2,
 *				"axis_y": 3,
 *				"name": "高成长员工",
 *				"count": 3,
 *				"percent": 24,
 *				"promotion_advice": "建议xxxx",
 *				"development_advice": ["建议1","建议2","建议3"],
 *				"staffs": [{
 *					"id": 1003,
 *					"no": "NO003",
 *					"status": 1,
 *					"name": "秦皓",
 *					"avatar_url": "http://zzz.png"
 *					"department_name": "部门啊"
 *				},{
 *					"id": 1004,
 *					"no": "NO004",
 *					"status": 2,
 *					"name": "秦某某",
 *					"avatar_url": "http://xyz.png"
 *					"department_name": "部门啊"
 *				}]
 *			}]
 *		}
 *
 */
func (c *ProjectsReport) InventoryDistribution(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID   int `json:"project_id" validate:"gte=1"`
		ReportID    int `json:"report_id" validate:"gte=0"`
		InterviewID int `json:"interview_id" validate:"gte=0"`
	}{}
	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(20304001, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	result, err := stat.GroupInventoryDistribution(curUser.CompanyId, params.ProjectID, params.ReportID, params.InterviewID)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/inventory_distribution_list 项目详情-人才盘点分布列表
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-人才盘点分布列表，只返回综合能力的结果
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} interview_id interview_id
 * @apiParam {Number} report_id 盘点记录 ID
 * @apiParam {String} [search] 搜索（搜索范围：员工名、部门、岗位）
 * @apiParam {Object} [order] 排序，不传默认员工 ID 排序
 * @apiParam {String} order.key 字段名（支持的排序的字段：result(由上到下1-9),professional_skills_score,potential_score,quality_score,performance_level）
 * @apiParam {Number} order.order 排序，0: 升序，1: 降序
 * @apiParam {Object[]} [filter] 筛选
 * @apiParam {String} filter.key 字段名（支持的筛选的字段：result,professional_skills_score,potential_score,quality_score,performance_level）
 * @apiParam {String[]} filter.values Value 列表
 * @apiParam {Number} [page=1] 页码
 * @apiParam {Number} [page_size=10] 分页大小
 *
 * @apiParamExample {json} Request-Example:
 *
	{
		"session":"eyJmcm9tIjoiQiIsInNyY19pZCI6MSwibWFuYWdlcl9pZCI6ODQsImNvbXBhbnlfaWQiOjg0LCJ1c2VyX2lkIjo4NCwiZXhwaXJlIjoxNTY1NjA5NTcwLCJzaWduYXR1cmUiOiJmZTEwNTdjNzY2YjhhZDI0Y2FkYTYyZGIzNGVlZDkwMTIwM2M3ZjNlIiwidXNlcl90eXBlIjoxfQ==",
		"project_id":3,
		"report_id":3,
		"search":"",
		"order":{
			"key":"professional_skills_score",
			"order":1
		},
		"filter":[
			{
				"key":"result",
				"values":[
					1
				]
			}
		],
		"page":1,
		"page_size":10
	}
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object} result.filter 筛选条件
 * @apiSuccess {Object[]} result.filter.result 盘点结果列表
 * @apiSuccess {Object[]} result.filter.professional_skills_score 专业知识/技能列表
 * @apiSuccess {Object[]} result.filter.potential_score 潜力列表
 * @apiSuccess {Object[]} result.filter.quality_score 素质列表
 * @apiSuccess {Object[]} result.filter.performance_level 绩效列表
 * @apiSuccess {Object[]} result.filter.personalities 突出性格列表
 * @apiSuccess {Number} result.total 总数
 * @apiSuccess {Object[]} result.list 员工列表
 * @apiSuccess {Number} result.list.id 员工 ID
 * @apiSuccess {String} result.list.name 员工名字
 * @apiSuccess {String} result.list.sex 员工性别（1男 2女）
 * @apiSuccess {Number} result.list.staffs.status 员工状态
 * @apiSuccess {String} result.list.department 员工所在部门
 * @apiSuccess {String} result.list.position 员工岗位
 * @apiSuccess {String} result.list.result 盘点结果
 * @apiSuccess {Number} result.list.professional_skills_score 员工专业知识/技能得分
 * @apiSuccess {String} result.list.professional_skills_score_desc 员工专业知识/技能得分描述
 * @apiSuccess {Number} result.list.potential_score 员工潜力得分
 * @apiSuccess {String} result.list.potential_score_desc 员工潜力得分描述
 * @apiSuccess {Number} result.list.quality_score 员工素质得分
 * @apiSuccess {String} result.list.quality_score_desc 员工素质得分描述
 * @apiSuccess {String} result.list.performance_level 员工绩效等级（S A B C）
 * @apiSuccess {String} result.list.performance_level_standard 员工标准绩效等级（1: 高 2: 中 3: 低）
 * @apiSuccess {String[]} result.list.personalities 员工性格列表
 *
 * @apiSuccessExample {json} Response-Example:
	{
		"filter":{
			"result":[
				{
					"key":"3",
					"value":"明星员工",
					"desc":""
				},
				{
					"key":"2",
					"value":"未来之星",
					"desc":""
				},
				{
					"key":"9",
					"value":"高产员工",
					"desc":""
				},
				{
					"key":"1",
					"value":"待发展者",
					"desc":""
				},
				{
					"key":"8",
					"value":"合格员工",
					"desc":""
				},
				{
					"key":"4",
					"value":"待观察者",
					"desc":""
				},
				{
					"key":"7",
					"value":"低效员工",
					"desc":""
				}
			],
			"professional_skills_score":[
				{
					"key":"4",
					"value":"4分",
					"desc":"专业精深"
				},
				{
					"key":"2",
					"value":"2分",
					"desc":"专业一般"
				},
				{
					"key":"1",
					"value":"1分",
					"desc":"专业薄弱"
				}
			],
			"potential_score":[
				{
					"key":"4",
					"value":"4分",
					"desc":"潜力十足"
				},
				{
					"key":"3",
					"value":"3分",
					"desc":"潜力较高"
				},
				{
					"key":"1",
					"value":"1分",
					"desc":"潜力有限"
				}
			],
			"quality_score":[
				{
					"key":"4",
					"value":"4分",
					"desc":"融会贯通"
				},
				{
					"key":"3",
					"value":"3分",
					"desc":"得心应手"
				},
				{
					"key":"2",
					"value":"2分",
					"desc":"中规中矩"
				},
				{
					"key":"1",
					"value":"1分",
					"desc":"力有不逮"
				}
			],
			"performance_level":[
				{
					"key":"1",
					"value":"A",
					"desc":"高级"
				},
				{
					"key":"1",
					"value":"S",
					"desc":"高级"
				},
				{
					"key":"2",
					"value":"B",
					"desc":"中级"
				},
				{
					"key":"3",
					"value":"C",
					"desc":"低级"
				}
			],
			"personalities":[

			]
		},
		"total":6,
		"list":[
			{
				"id":180,
				"name":"陈向飞",
				"sex":1,
				"status": 1,
				"department":"义橙",
				"position":"测试岗位",
				"result":"低效员工",
				"professional_skills_score":1,
				"professional_skills_score_desc":"专业薄弱",
				"potential_score":1,
				"potential_score_desc":"潜力有限",
				"quality_score":1,
				"quality_score_desc":"力有不逮",
				"performance_level":"C",
				"performance_level_standard":3,
				"personalities":[
					"民主精神",
					"品质意识"
				]
			},
			{
				"id":178,
				"name":"丁羽",
				"sex":1,
				"status": 1,
				"department":"义橙",
				"position":"测试岗位",
				"result":"低效员工",
				"professional_skills_score":1,
				"professional_skills_score_desc":"专业薄弱",
				"potential_score":1,
				"potential_score_desc":"潜力有限",
				"quality_score":1,
				"quality_score_desc":"力有不逮",
				"performance_level":"C",
				"performance_level_standard":3,
				"personalities":[
					"民主精神",
					"精力水平"
				]
			},
			{
				"id":151,
				"name":"王豪",
				"sex":1,
				"status": 2,
				"department":"义橙",
				"position":"测试岗位",
				"result":"未来之星",
				"professional_skills_score":4,
				"professional_skills_score_desc":"专业精深",
				"potential_score":4,
				"potential_score_desc":"潜力十足",
				"quality_score":4,
				"quality_score_desc":"融会贯通",
				"performance_level":"B",
				"performance_level_standard":2,
				"personalities":[
					"创新精神",
					"率先垂范"
				]
			},
			{
				"id":150,
				"name":"王永杰",
				"sex":1,
				"status": 3,
				"department":"义橙",
				"position":"测试岗位",
				"result":"未来之星",
				"professional_skills_score":4,
				"professional_skills_score_desc":"专业精深",
				"potential_score":4,
				"potential_score_desc":"潜力十足",
				"quality_score":4,
				"quality_score_desc":"融会贯通",
				"performance_level":"B",
				"performance_level_standard":2,
				"personalities":[
					"品质意识",
					"创新精神"
				]
			},
			{
				"id":149,
				"name":"魏超",
				"sex":1,
				"status": 1,
				"department":"义橙",
				"position":"测试岗位",
				"result":"未来之星",
				"professional_skills_score":4,
				"professional_skills_score_desc":"专业精深",
				"potential_score":4,
				"potential_score_desc":"潜力十足",
				"quality_score":4,
				"quality_score_desc":"融会贯通",
				"performance_level":"B",
				"performance_level_standard":2,
				"personalities":[
					"品质意识",
					"创新精神"
				]
			},
			{
				"id":148,
				"name":"文玲玲",
				"sex":2,
				"status": 2,
				"department":"义橙",
				"position":"测试岗位",
				"result":"未来之星",
				"professional_skills_score":4,
				"professional_skills_score_desc":"专业精深",
				"potential_score":4,
				"potential_score_desc":"潜力十足",
				"quality_score":4,
				"quality_score_desc":"融会贯通",
				"performance_level":"B",
				"performance_level_standard":2,
				"personalities":[
					"率先垂范",
					"民主精神"
				]
			}
		]
		}
*/
func (c *ProjectsReport) InventoryDistributionList(httpCtx *hfw.HTTPContext) {
	params := &struct {
		*Session
		ProjectID   int                    `json:"project_id" validate:"gte=1"`
		InterviewID int                    `json:"interview_id"`
		ReportID    int                    `json:"report_id" validate:"gte=0"`
		Order       *stat.OrderByParams    `json:"order"`
		Filter      []*stat.FilterByParams `json:"filter"`
		Search      string                 `json:"search" validate:"gte=0"`
		Page        int                    `json:"page" validate:"gte=0"`
		PageSize    int                    `json:"page_size" validate:"gte=0,lte=200"`
	}{}
	httpCtx.ThrowCheck(20304001, api.RequestUnmarshal(httpCtx, params))
	httpCtx.ThrowCheck(20304001, VerifyRequestSession(httpCtx, params))
	httpCtx.ThrowCheck(20304001, validate(params))
	curUser, err := GetCurUser(httpCtx.Ctx.Value("session"))
	httpCtx.ThrowCheck(20304001, err)

	result, err := stat.InventoryDistributionList(curUser.CompanyId, params.ProjectID, params.InterviewID, params.ReportID,
		params.Order, params.Filter, params.Search, params.Page, params.PageSize)

	httpCtx.ThrowCheck(20305000, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/professional_skills 项目详情-专业知识技能
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-专业知识技能
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object} result.professional_skills 员工专业技能结果
 * @apiSuccess {Object[]} result.professional_skills.dimension 统计的维度列表
 * @apiSuccess {String} result.professional_skills.dimension.name 统计的维度名称
 * @apiSuccess {String} result.professional_skills.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.professional_skills.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.professional_skills.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.professional_skills.rule 统计规则
 * @apiSuccess {Object[]} result.professional_skills.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.professional_skills.data 统计数据
 * @apiSuccess {String} result.professional_skills.data.legend 图例
 * @apiSuccess {Object} result.professional_skills.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *		"quality": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "各项平均分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) ProfessionalSkills(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	result, err := stat.ProjectProfessionalSkills(companyID, req.ProjectID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/potential 项目详情-潜力
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-潜力
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object[]} result.potential 潜力关键项列表
 * @apiSuccess {String} result.potential.id 潜力项目 id
 * @apiSuccess {String} result.potential.name 潜力项目名称
 * @apiSuccess {String} result.potential.score 潜力项目得分
 * @apiSuccess {String} result.potential.total 潜力项目总分
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *		"potential": [{
 *			"id": 1,
 *			"name": "好奇心和优秀的自我学习能力",
 *			"score": 8,
 *			"total": 24
 *		},
 *		{
 *			"id": 11,
 *			"name": "跨领域的思考能力",
 *			"score": 23,
 *			"total": 24
 *		}]
 *   }
 *
 */
func (c *ProjectsReport) Potential(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)
	result, err := stat.ProjectPotential(companyID, req.ProjectID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/quality 项目详情-素质
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-素质
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object} result.quality 专业技能结果
 * @apiSuccess {Object[]} result.quality.dimension 统计的维度列表
 * @apiSuccess {String} result.quality.dimension.name 统计的维度名称
 * @apiSuccess {String} result.quality.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.quality.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.quality.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.quality.rule 统计规则
 * @apiSuccess {Object[]} result.quality.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.quality.data 统计数据
 * @apiSuccess {String} result.quality.data.legend 图例
 * @apiSuccess {Object} result.quality.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
 *   {
 *		"quality": {
 *          "dimension": [{
 *              "id": 1,
 *              "name": "素质1",
 *				"desc": "xxx",
 * 				"excellent_desc": "yyyy",
 *              "selected": true
 *          }, {
 *              "id": 2,
 *              "name": "素质2",
 *				"desc": "xxx",
 * 				"excellent_desc": "yyyy",
 *              "selected": true
 *          }, {
 *              "id": 3,
 *              "name": "素质3",
 *				"desc": "xxx",
 * 				"excellent_desc": "yyyy",
 *              "selected": true
 *          }, {
 *              "id": 20,
 *              "name": "激励",
 *				"desc": "xxx",
 * 				"excellent_desc": "yyyy",
 *              "selected": true
 *          }, {
 *              "id": 4,
 *              "name": "素质4",
 *				"desc": "xxx",
 * 				"excellent_desc": "yyyy",
 *              "selected": true
 *          }, {
 *              "id": 5,
 *              "name": "素质5",
 *				"desc": "xxx",
 * 				"excellent_desc": "yyyy",
 *              "selected": true
 *          }],
 *          "show_measurement": ["score"],
 *          "rule": "",
 *          "unit": {
 *              "score": "分"
 *          },
 *          "data": [{
 *                  "legend": "各项平均分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  },{
 *                  "legend": "绩优者得分",
 *                  "measurement": {
 *                      "score": [75,55,70,65,61,50]
 *                  }
 *              }
 *          ]
 *      }
 *   }
 *
 */
func (c *ProjectsReport) Quality(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)
	result, err := stat.ProjectQuality(companyID, req.ProjectID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/performance 项目详情-绩效
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-绩效
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Object} result.performance 员工绩效列表
 * @apiSuccess {Object[]} result.performance.props 标准绩效占比列表
 * @apiSuccess {String} result.performance.props.level 绩效评级名字
 * @apiSuccess {Number} result.performance.props.percent 标准绩效评级占比
 * @apiSuccess {String[]} result.performance.props.labels 标签列表
 * @apiSuccess {Number} result.performance.props.number 当前绩效人数
 * @apiSuccess {[]Object} result.performance.props.label_result
 * @apiSuccess {String} result.performance.props.label_result.title 标题
 * @apiSuccess {String[]} result.performance.props.label_result.list 标签列表
 *
 * @apiSuccessExample {json} Response-Example:
    {
 	"performance": {
 		"props": [
		{
 		 	"level": "S",
 			"percent": 12,
 			 "label_result": [
				{
					"title": "正向",
					"list": ["标签1"，"标签2"，"标签3"]
				},
				{
					"title": "负向",
					"list": ["标签1"，"标签2"，"标签3"]
				}
			]
 		},
		{
 			"level": "A",
 			"percent": 25,
 			"label_result": [
				{
					"title": "正向",
					"list": ["标签1"，"标签2"，"标签3"]
				},
				{
					"title": "负向",
					"list": ["标签1"，"标签2"，"标签3"]
				}
			]
		},
		{
 			"level": "B",
 			"percent": 45,
 			"label_result": [
				{
					"title": "正向",
					"list": ["标签1"，"标签2"，"标签3"]
				},
				{
					"title": "负向",
					"list": ["标签1"，"标签2"，"标签3"]
				}
			]
		},
		{
 			"level": "C",
 			"percent": 18,
 			"label_result": [
				{
					"title": "正向",
					"list": ["标签1"，"标签2"，"标签3"]
				},
				{
					"title": "负向",
					"list": ["标签1"，"标签2"，"标签3"]
				}
			]
		}
		]
 	}
    }
 *
*/
func (c *ProjectsReport) Performance(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result1 interface{}

	if req.ReportID == 0 {
		result1 = demo.GetPerformance(req.ProjectID)
		if result1 != nil {
			httpCtx.Results = result1
			return
		}
	}

	result, err := stat.ProjectPerformance(companyID, req.ProjectID, req.ReportID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/personality_eval 项目详情-性格
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-性格
 *
 * @apiParam {String} session 身份认证 Session
 * @apiParam {Number} project_id 项目 ID
 * @apiParam {Number} report_id 盘点记录 ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *     "session": "eyJGcm9tIjoiQiIsInNyY19pZCI6MCwibWFuYWdlcl9pZCI6NCwidXNlcl9pZCI6MCwiZXhwaXJlIjoiMjAxODExMTMxODU4NDUiLCJzaWduYXR1cmUiOiJjOGU5ZmU1NjI3YzdmODJlZjFhZTdlMDAzMjU3ZGZiNWIyOTQ1YjNkIn0=",
 *	   "project_id": 3,
 *	   "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {Number} result.avg 平均分
 * @apiSuccess {Object} result.data 组织忠诚度
 * @apiSuccess {Object[]} result.data.dimension 统计的维度列表
 * @apiSuccess {String} result.data.dimension.name 统计的维度名称
 * @apiSuccess {String} result.data.dimension.desc 统计的维度描述
 * @apiSuccess {Boolean} result.data.dimension.selected 是否为被选中的维度
 * @apiSuccess {String[]} result.data.show_measurement 需要展示的统计数据项目
 * @apiSuccess {String} result.data.rule 统计规则
 * @apiSuccess {Object[]} result.data.unit 统计项目单位，具体对象格式视统计项目而定
 * @apiSuccess {Object[]} result.data.data 统计数据
 * @apiSuccess {String} result.data.data.legend 图例
 * @apiSuccess {Object} result.data.data measurement 统计规则，具体对象格式视统计项目而定
 *
 * @apiSuccessExample {json} Response-Example:
{
    "dimension": [
        {
            "id": 1,
            "name": "性格1",
            "selected": true
        },
        {
            "id": 2,
            "name": "性格2",
            "selected": true
        },
        {
            "id": 3,
            "name": "性格3",
            "selected": true
        },
        {
            "id": 4,
            "name": "性格4",
            "selected": true
        }
    ],
    "show_measurement": [
        "score"
    ],
    "rule": "",
    "unit": {
        "score": "分"
    },
    "data": [
        {
            "legend": "0~3分 (表现不足)",
            "measurement": [
                {
                    "stack": "team",
                    "value": [
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        }
                    ]
                },
                {
                    "stack": "excellent",
                    "value": [
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        }
                    ]
                }
            ]
        },
        {
            "legend": "4~6分 (表现一般)",
            "measurement": [
                {
                    "stack": "team",
                    "value": [
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        }
                    ]
                },
                {
                    "stack": "excellent",
                    "value": [
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        }
                    ]
                }
            ]
        },
        {
            "legend": "7~9分 (表现优秀)",
            "measurement": [
                {
                    "stack": "team",
                    "value": [
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        }
                    ]
                },
                {
                    "stack": "excellent",
                    "value": [
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        },
                        {
                            "num": 12,
                            "percent": 10
                        }
                    ]
                }
            ]
        }
    ]
}
*/
func (c *ProjectsReport) PersonalityEval(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)
	result, err := stat.ProjectPersonalityEval(companyID, req.ProjectID)
	httpCtx.ThrowCheck(20305001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/key_experience 项目详情-关键经历
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-关键经历
 *
 * @apiParam {String} session 身份认证 session
 * @apiParam {Number} project_id 项目ID
 * @apiParam {Number} report_id 盘点记录ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *      "session": "eyJGcm9tIjoiQiIs=",
 *      "project_id": 3,
 *      "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果
 * @apiSuccess {String} result.type 默认展示管理还是业务
 * @apiSuccess {Object[]} result.manage_list 管理经历列表
 * @apiSuccess {String} result.manage_list.name 纬度名称
 * @apiSuccess {Number} result.manage_list.number 命中人数
 * @apiSuccess {Boolean} result.manage_list.focus 是否重点关注 true 命中， false 未命中
 * @apiSuccess {Number} result.manage_list.fraction 百分比
 * @apiSuccess {Object[]} result.business_list 业务经历列表
 * @apiSuccess {String} result.business_list.name 纬度名称
 * @apiSuccess {Number} result.business_list.number 命中人数
 * @apiSuccess {Boolean} result.business_list.focus 是否重点关注 true 命中， false 未命中
 * @apiSuccess {Number} result.business_list.fraction 百分比
 * @apiSuccessExample {json} Response-Example:
 {
      "results": {
          "type": "manage_list",
          "manage_list": [
              {
                  "name": "多经营单元负责人管理经历",
                  "number": 300,
                  "focus": false,
                  "fraction": 0.34
             },
             {
                  "name": "多部门分管领导经历",
                  "number": 280,
                  "focus": true,
                  "fraction": 0.25
             },
             {
                  "name": "无管理经历",
                  "number": 340,
                  "focus": false,
                  "fraction": 0.12
             }
         ],
         "business_list": [
             {
                 "name": "组建团队",
                 "number": 500,
                 "focus": true,
                 "fraction": 0.25
             },
             {
                 "name": "市场开拓",
                 "number": 280,
                 "focus": false,
                 "fraction": 0.25
             },
             {
                 "name": "技术/专业",
                 "number": 340,
                 "focus": true,
                 "fraction": 0.25
             }
         ]
     }
}
*
*/
func (c *ProjectsReport) KeyExperience(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))
	// 验证session
	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetKeyExperience(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}

	result, err = stat.KeyExperience(int64(companyID), int64(req.ProjectID))
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.Results = result
}

/**
 * @api {post} /projects_reports/job_choice_value 项目详情-工作选择价值观
 * @apiVersion 0.1.0
 * @apiGroup ProjectsReport
 * @apiDescription 项目详情-工作选择价值观
 *
 * @apiParam {String} session 身份认证 session
 * @apiParam {Number} project_id 项目ID
 * @apiParam {Number} report_id 盘点记录ID
 *
 * @apiParamExample {json} Request-Example:
 * {
 *      "session": "sesshiahidfhfa=",
 *      "project_id": 3,
 *      "report_id": 1
 * }
 *
 * @apiSuccess {Object} result 返回结果slice
 * @apiSuccess {Object[]} result.list 工作选择价值观列表
 * @apiSuccess {String} result.list.name 工作选择价值观名称
 * @apiSuccess {Number} result.list.number 工作选择价值观人数
 * @apiSuccess {Boolean} result.list.focus 是否重点关注 true 命中， false 未命中
 * @apiSuccess {Number} result.list.fraction 人数百分比
 * @apiSuccess {Number} result.list.area_ratio 面积占比
 * @apiSuccessExample {json} Response-Example:
  {
      "results": {
          "list": [
              {
                  "name": "兴趣特长",
                  "number": 340,
                  "focus": true,
                  "fraction": 0.12,
                  "area_ratio": 0.2
              },
              {
                  "name": "自我实现",
                  "number": 340,
                  "focus": false,
                  "fraction": 0.15,
                  "area_ratio": 0.2
              },
              {
                  "name": "人际关系",
                  "number": 340,
                  "focus": true,
                  "fraction": 0.35,
                  "area_ratio": 0.2
              },
              {
                  "name": "收入与财富",
                  "number": 240,
                  "focus": false,
                  "fraction": 0.16,
                  "area_ratio": 0.2
              }
          ]
      }
 }
*
*/
func (c *ProjectsReport) JobChoiceValue(httpCtx *hfw.HTTPContext) {
	req := &ProjectsReportRequest{}
	err := api.RequestUnmarshal(httpCtx, &req)
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.ThrowCheck(20304001, validate(req))

	companyID, err := CheckToken(*req, httpCtx)
	httpCtx.ThrowCheck(20304001, err)

	var result interface{}
	if req.ReportID == 0 {
		result = demo.GetJobChoiceValue(req.ProjectID)
		if result != nil {
			httpCtx.Results = result
			return
		}
	}

	result, err = stat.JobChoiceValue(int64(companyID), int64(req.ProjectID))
	httpCtx.ThrowCheck(20304001, err)

	httpCtx.Results = result
}
