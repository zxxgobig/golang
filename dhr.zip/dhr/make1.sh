#!/bin/bash
#git tag -d v201810101009
#git push origin :refs/tags/v201810101009
#git checkout master
git pull
appName=$(basename $(pwd))
dockerName=bot_${appName}
isNewDocker=0
isNewTag=0
if [ -z "$1" ];then
    isNewDocker=1
    #发布新版本
    VERSION=v`date "+%Y%m%d%H%M"` && \
        git tag $VERSION
    isNewTag=1
elif [ "$1" == "master" ];then
    isNewDocker=1
    #测试当前代码
    VERSION=v`date "+%Y%m%d%H%M"` && \
        git checkout "$1"
else
    #回滚，把latest变成指定版本，用于测试环境
    VERSION="$1" && \
        git checkout "$1"
fi

if [ $isNewDocker -eq 1 ];then
    time CGO_ENABLED=0 go build -a -v -ldflags '-s -w' && \
        time upx -9 $appName && \
        sed -i "s#^ENV V.*#ENV VERSION $VERSION#g" dockerfile && \
        docker build -t hub.ifchange.com/bot/$dockerName:$VERSION -f dockerfile . && \
        docker tag hub.ifchange.com/bot/$dockerName:$VERSION hub.ifchange.com/bot/$dockerName:latest && \
        docker push hub.ifchange.com/bot/$dockerName:$VERSION && \
        docker push hub.ifchange.com/bot/$dockerName:latest && \
        rm $appName
    if [ $? == 0 ];then
        if [ $isNewTag -eq 1 ];then
            git push origin --tags
        fi
    fi
else
    docker tag hub.ifchange.com/bot/$dockerName:$VERSION hub.ifchange.com/bot/$dockerName:latest && \
    docker push hub.ifchange.com/bot/$dockerName:latest
fi
