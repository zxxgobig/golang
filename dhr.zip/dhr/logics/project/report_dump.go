package project

func Dump(companyID, projectID, sceneID int, name string, adjustStaffs []*AdjustStaff) (err error) {
	return nil
}

