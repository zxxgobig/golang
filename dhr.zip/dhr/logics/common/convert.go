package common

/*
 0 1 2
 3 4 5
 6 7 8
*/

func ConvertXY2P(X, Y int) int {
	switch X {
	case 1:
		switch Y {
		case 1:
			return 7
		case 2:
			return 4
		case 3:
			return 1
		}
	case 2:
		switch Y {
		case 1:
			return 8
		case 2:
			return 5
		case 3:
			return 2
		}
	case 3:
		switch Y {
		case 1:
			return 9
		case 2:
			return 6
		case 3:
			return 3
		}
	}
	return 0
}

func ConvertP2XY(P int) (X, Y int) {
	switch P {
	case 1:
		return 1, 3
	case 2:
		return 2, 3
	case 3:
		return 3, 3
	case 4:
		return 1, 2
	case 5:
		return 2, 2
	case 6:
		return 3, 2
	case 7:
		return 1, 1
	case 8:
		return 2, 1
	case 9:
		return 3, 1
	}

	return 0, 0
}
