package algo

import (
    "sort"

    "gitlab.ifchange.com/bot/hfw"
    "gitlab.ifchange.com/bot/hfwkit/api"
)

type FeatureImportanceRequest struct {
    SkillIds []string        `json:"skill_ids"`
    Data     []StaffEvalData `json:"data"`
}

type StaffEvalData struct {
    StaffID            int             `json:"staff_id"`
    Level              string          `json:"level"`          // 原始等级
    StandardLevel      string          `json:"standard_level"` // 标准等级
    PersonalityEval    map[int]float64 `json:"personality_eval"`
    Quality            map[int]float64 `json:"quality"`
    Potential          map[int]float64 `json:"potential"`
    ProfessionalSkills map[int]float64 `json:"professional_skills"`
}

type FeatureImportanceResponse struct {
    Features []Feature `json:"features"`
}

type Feature struct {
    Axis   string  `json:"axis"`
    Label  string  `json:"label"`
    Weight float64 `json:"weight"`
}

func FeatureImportance(req *FeatureImportanceRequest) (res *FeatureImportanceResponse, err error) {
    p := api.NewPost("", "")
    p.P = req
    err = api.SimpleCurl(nil, hfw.Config.Custom["AlgoFeatureImportanceURL"], p, &res)

    return
}

func SortFeaturesByWeightDesc(features []Feature) {
    if features == nil {
        return
    }

    sort.Slice(features, func(i, j int) bool { return features[i].Weight > features[j].Weight })
}
