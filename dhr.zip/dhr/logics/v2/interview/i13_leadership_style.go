package v2_interview

import (
    kitinterview "gitlab.ifchange.com/bot/hfwkit/dhr/interview"

    "ifchange/dhr/models"
)

type (
    LeadershipStyleRecommend struct {
        Name     string `json:"name"`
        Desc     string `json:"desc"`
        Index    int    `json:"index"`
        IsAdvice bool   `json:"is_advice"`
        IsMust   bool   `json:"is_must"`
    }
)

func ProcessLeadershipStyleRecommend(sceneId, sceneTemplateId int, interviewsM map[kitinterview.Type]*models.Interviews) *LeadershipStyleRecommend {
    interview, ok := interviewsM[kitinterview.LeadershipStyle]
    if !ok {
        return nil
    }

    return &LeadershipStyleRecommend{
        Name:     interview.Name,
        Desc:     interview.Desc,
        Index:    GetIndex(kitinterview.LeadershipStyle),
        IsAdvice: GetIsAdvice(kitinterview.LeadershipStyle, sceneTemplateId),
        IsMust:   GetIsMust(kitinterview.LeadershipStyle, sceneId, sceneTemplateId),
    }
}
