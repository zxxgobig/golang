package interview

import (
	"fmt"

	"gitlab.ifchange.com/bot/hfw/encoding"
	"gitlab.ifchange.com/bot/hfwkit/dhr_staff"

	common2 "ifchange/dhr/logics/common"
	"ifchange/dhr/models"

	"ifchange/dhr/core"

	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfw/db"
	"gitlab.ifchange.com/bot/logger"
	pbstaff "gitlab.ifchange.com/bot/proto/dhr_staff/staff"
	pb "gitlab.ifchange.com/bot/proto/professional_skills"
)

// dhr读取题目
func Get(emailUuid string, interviewId int, param interface{}) (result *FinishStatus, err error) {
lab:
	result = new(FinishStatus)
	allStaffsInterviews, err := GetStaffsInterviewsByEmailUuid(emailUuid)

	if err != nil {
		return
	}

	result.setInterviewsInfo(allStaffsInterviews)

	if len(allStaffsInterviews) == 0 {
		err = fmt.Errorf("no record found")
		return
	}

	CurStaffsInterviews, err := models.StaffsInterviewsModel.Search(db.Cond{
		"email_uuid":   emailUuid,
		"interview_id": interviewId,
		"is_deleted":   0,
	})

	if err != nil {
		return result, common.NewRespErr(core.RequestError, "请求错误")
	}
	if len(CurStaffsInterviews) == 0 {
		return result, common.NewRespErr(core.Completed, "测评不存在")
	}
	logger.Debugf("^^^^^^^^^:%#v", CurStaffsInterviews[0])
	//var CurStaffsInterviews []*models.StaffsInterviews
	//finishFlag := true
	//for _, x := range allStaffsInterviews {
	//	if x.Status < 2 {
	//		finishFlag = false
	//		break
	//	}
	//}
	//// 全部完成
	//if finishFlag == true {
	//	return result, nil
	//}

	//// 正在进行的题目
	//for _, x := range allStaffsInterviews {
	//	if x.Status == 1 || x.Status == 0{
	//		CurStaffsInterviews = append(CurStaffsInterviews, x)
	//	}
	//}
	//
	//// 多道题正在进行中
	////if len(CurStaffsInterviews) > 1 {
	////    err = fmt.Errorf("expect 1 staffsInterview %d", len(CurStaffsInterviews))
	////    return
	////}
	//
	//// 获取需要做的题目
	//if len(CurStaffsInterviews) == 0 {
	//	for _, x := range allStaffsInterviews {
	//		if x.InterviewId == interviewId {
	//			CurStaffsInterviews = append(CurStaffsInterviews, x)
	//		}
	//	}
	//	//if len(CurStaffsInterviews) != 1 {
	//	//	err = fmt.Errorf("expect 1 staffsInterview %d", len(CurStaffsInterviews))
	//	//	return
	//	//}
	//}
	//// 当前的答题
	//if len(CurStaffsInterviews) == 0 {
	//	return result, common.NewRespErr(core.Completed, "测评已完成或不存在")
	//}
	//CurStaffsInterviewsMap := make(map[int]*models.StaffsInterviews)
	//if len(CurStaffsInterviews) == 0 {
	//	for i := 0; i < len(CurStaffsInterviews); i++ {
	//		CurStaffsInterviewsMap[CurStaffsInterviews[i].InterviewId] = CurStaffsInterviews[i]
	//	}
	//}

	//staffsInterview := CurStaffsInterviewsMap[interviewId]

	// 当前的答题
	staffsInterview := CurStaffsInterviews[0]
	result.CurInterviewId = staffsInterview.InterviewId
	result.CurInterviewUuid = staffsInterview.Uuid

	if staffsInterview.InterviewId != interviewId {
		err = fmt.Errorf("interviewId not equal ")
		return
	}

	plan, err := common2.GetPlanById(staffsInterview.DataCollectId)
	if err != nil {
		return
	}
	if plan == nil {
		err = fmt.Errorf("plan not exist: <%+v>", staffsInterview.DataCollectId)
		logger.Warn(err)
		return
	}
	// 题目状态异常
	if plan.Status >= 4 {
		err = common.NewRespErr(int64(20306000+plan.Status), "plan status unvalid")
		return
	}
	if staffsInterview.Status == 2 {
		return result, nil
	} else if staffsInterview.Status == 0 {
		_, err = models.StaffsInterviewsModel.Update(db.Cond{
			"status": 1,
		}, db.Cond{
			"id": staffsInterview.Id,
		})
		if err != nil {
			return
		}
	} else if staffsInterview.Status != 1 {
		err = common.NewRespErr(6001, "staffs interview status unvalid")
		return
	}
	// norstar 跳转
	if staffsInterview.InterviewId == IntvNormstar {
		return
	}
	var response interface{}
	if staffsInterview.InterviewId == IntvPotential {
		response, err = CreateInterview(staffsInterview.InterviewId).Commit(staffsInterview.Uuid, nil)
	} else {
		response, err = CreateInterview(staffsInterview.InterviewId).Get(staffsInterview.Uuid, param)
		if staffsInterview.InterviewId > 7 {
			result.Data = response
			return result, err
		}
		// 格式化专业技能
		if err == nil && (staffsInterview.InterviewId == IntvSkill || staffsInterview.InterviewId == IntvKnowlege) {
			evaluateGetResult := response.(*pb.EvaluateGetResult)
			userIds := []int{}
			for _, x := range evaluateGetResult.List {
				userIds = append(userIds, int(x.UserId))
			}
			_result := _EvaluateGetResult{}
			_result.EvaluateGetResult = evaluateGetResult
			var users []*dhr_staff.Staff
			users, err = dhr_staff.ListStaffByIds(nil, staffsInterview.CompanyId, userIds, true, []pbstaff.Status{pbstaff.Status_DIMISSION})
			if err != nil {
				return
			}
			for _, x := range users {

				_result.Users = append(_result.Users, _EvaluateGetResultUser{
					Id:   x.Id,
					Name: x.Name,
					No:   x.No,
				})
			}
			response = _result
		}
		data, err := encoding.JSON.Marshal(response)
		if err != nil {
			return nil, err
		}
		isFinish := &struct {
			ISFinish bool `json:"is_finish"`
		}{}
		err = encoding.JSON.Unmarshal(data, isFinish)
		if err != nil {
			return nil, err
		}
		if isFinish.ISFinish == true {
			err = common2.UpdateStaffsInterviewStatus(emailUuid, interviewId, 2)
			if err != nil {
				return nil, err
			}
			goto lab
		}
	}
	if err != nil {
		return
	}

	result.Data = response
	return result, nil
}

// 获取试题
func GetStaffsInterviews(emailUuid string, interviewId int) (staffsInterviews []*models.StaffsInterviews, err error) {
	return models.StaffsInterviewsModel.Search(db.Cond{
		"interview_id": interviewId,
		"email_uuid":   emailUuid,
		"is_deleted":   0,
	})
}

// 获取试题
func GetStaffsInterviewsByEmailUuid(emailUuid string) (staffsInterviews []*models.StaffsInterviews, err error) {
	return models.StaffsInterviewsModel.Search(db.Cond{
		"email_uuid": emailUuid,
		"is_deleted": 0,
	})
}
