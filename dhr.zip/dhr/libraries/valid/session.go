package valid

import (
	"strings"

	"github.com/pkg/errors"
	"gitlab.ifchange.com/bot/hfw/common"
	"gitlab.ifchange.com/bot/hfwkit/api"
	"gitlab.ifchange.com/bot/hfwkit/config"
)

func IsFromB(uri string) bool {
	// these uri from 'C' platform

	if strings.Contains(uri, "interviews/list_statff_interviews") ||
		strings.Contains(uri, "interviews/get") ||
		strings.Contains(uri, "interviews/commit") ||
		strings.Contains(uri, "interviews/feed_back") ||
		strings.Contains(uri, "norm_star/callback") ||
		strings.Contains(uri, "talent_excel/download") ||
		strings.Contains(uri, "projects_staffs_perform/download") ||
		strings.Contains(uri, "projects_staffs_perform/download_template") ||
		strings.Contains(uri, "external/excellent_characters") ||
		strings.Contains(uri, "sas/get_answer") ||
		strings.Contains(uri, "sas/project_by_name") ||
		strings.Contains(uri, "sas/interview_id_by_name") ||
		strings.Contains(uri, "sas/name_list") ||
		strings.Contains(uri, "test_reports/download") ||
		strings.Contains(uri, "push") ||
		strings.Contains(uri, "update") ||
		strings.Contains(uri, "v2_project/get_need_interviews_for_project") ||
		strings.Contains(uri, "interviews/qrcode") ||
		strings.Contains(uri, "talent_excel/users_download") ||
		strings.Contains(uri, "export/download") ||
		strings.Contains(uri, "sync/company_info") ||
		strings.Contains(uri, "interviews/finished") ||
		strings.Contains(uri, "projects/get_inventory_data") ||
		strings.Contains(uri, "projects/inventory_over_view") ||
		strings.Contains(uri, "projects/is_data_collect_completed") ||
		strings.Contains(uri, "v2_project/upload_picture") ||
		strings.Contains(uri, "projects_staffs/drop_list") ||
		strings.Contains(uri, "v2_project/latest_report_id") {
		return false
	}
	// other uri form 'B' platform
	return true
}

// 验证resource_key 的权限
func VerifyAuthority(sess, resourceKey string) (int64, error) {
	p := api.NewPost("", "")
	p.P = &struct {
		Session     string `json:"session"`
		ResourceKey string `json:"resource_key"`
	}{
		Session:     sess,
		ResourceKey: resourceKey,
	}

	result := &struct {
		Results bool `json:"results"`
	}{}

	var errNo int64
	err := api.SimpleCurl(nil, config.AppConfig.Custom["RBACAccountURL"]+"account/verifyResourceKey", p, &result.Results)
	if err != nil {
		if e, ok := err.(*common.RespErr); ok {
			errNo = e.ErrNo()
		}
		return errNo, errors.Wrap(err, "request Java's account verifyResourceKey failed.")
	}

	// TODO: add data permission verify ??
	return 0, nil
}
