package external

import (
    "fmt"

    "ifchange/dhr/logics/project"
    "ifchange/dhr/logics/stat"

    "gitlab.ifchange.com/bot/logger"
    "gitlab.ifchange.com/bot/hfwkit/api"
    "gitlab.ifchange.com/bot/hfwkit/config"
    "gitlab.ifchange.com/bot/hfwkit/dhr_staff"
    pb "gitlab.ifchange.com/bot/proto/dhr_staff/staff"
)

const (
    commercialValueCoefficient = 2400
)

type Data struct {
    ComID           int      `json:"com_id"`
    CommercialValue int64    `json:"commercial_value"`
    Labels          []string `json:"labels"`
}

func ExcellentCharacters() ([]Data, error) {
    // get all accounts
    companies, err := getAllCompanyAccounts()
    if err != nil {
        return nil, err
    }

    if len(companies) == 0 {
        return nil, fmt.Errorf("no data")
    }

    counts, err := getAllCompanyStaffCounts()
    if err != nil {
        return nil, fmt.Errorf("getAllCompanyStaffCounts error: %v", err)
    }

    type labels map[string]struct{}
    // get company projects mapping ship
    companyLabels := make(map[int]labels)
    for _, c := range companies {
        companyLabels[c.ID] = make(labels)
    }

    projects, err := project.GetProjects()
    if err != nil {
        return nil, fmt.Errorf("project.GetProjects error:%v", err)
    }

    // get each project's data
    for _, p := range projects {
        ec, err := stat.ExcellentCharacter(p.CompanyId, p.Id)
        if err != nil {
            logger.Errorf("stat.ExcellentCharacter error for company id: %d, project id: %d", p.CompanyId, p.Id)
            continue
        }

        if ec == nil || len(ec.Characters) == 0 {
            continue
        }

        ls := companyLabels[p.CompanyId]
        for _, c := range ec.Characters {
            ls[c.Name] = struct{}{}
        }
        companyLabels[p.CompanyId] = ls
    }

    // wrap all data
    data := make([]Data, 0)
    for cid, cl := range companyLabels {
        ls := make([]string, 0)
        for k := range cl {
            ls = append(ls, k)
        }

        data = append(data, Data{
            ComID:           cid,
            CommercialValue: counts[cid] * commercialValueCoefficient,
            Labels:          ls,
        })
    }

    return data, nil
}

type Company struct {
    ID   int    `json:"id"`
    Name string `json:"name"`
}

func getAllCompanyAccounts() (companies []Company, err error) {
    p := api.NewPost("companies", "search")
    p.P = map[string]int{"pagesize": 100}

    result := &struct {
        Total   int       `json:"total"`
        Results []Company `json:"results"`
    }{}
    err = api.SimpleCurl(nil, config.GetServers().BotDhrAdmin, p, &result)
    if err != nil {
        return nil, fmt.Errorf("getAllCompanyAccounts call botAdminServer faild:%s", err)
    }

    return result.Results, nil
}

func getAllCompanyStaffCounts() (counts map[int]int64, err error) {
    data, err := dhr_staff.GetCompanyStaffCount(nil, &pb.CompanyStaffCountRequest{})
    if err != nil {
        return nil, fmt.Errorf(" dhr_staff.GetCompanyStaffCount error:%s", err)
    }

    counts = make(map[int]int64)
    for _, d := range data {
        counts[int(d.CompanyId)] = d.Count
    }

    return counts, nil
}
