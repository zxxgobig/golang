package data_collect

import (
	"ifchange/dhr/models"
	"testing"
	"time"
)

func TestDataCollectPlanEndPlans(t *testing.T) {
	newPlan := NewDataCollectPlan()
	affected, err := newPlan.CompletedPlans()
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(affected)
}

func TestDataCollectPlanGetPlanById(t *testing.T) {
	newPlan := NewDataCollectPlan()
	plan, err := newPlan.GetCollectPlanById(1)
	if err != nil {
		t.Errorf("TestDataCollectPlanGetPlanById GetCollectPlanById err: %v ", err)
		return
	}
	endTime := time.Date(plan.EndTime.Year(), plan.EndTime.Month(), plan.EndTime.Day(), 10, 0, 0, 0, time.Local)
	t.Log(endTime.Format("2006年01月02日15点"))
}

func TestDataCollectPlanGetProcessRate(t *testing.T) {
	newPlan := NewDataCollectPlan()
	f, err := newPlan.GetProcessRate(1)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(f)
}

/*
go test ./logics/data_collect -run TestGetRecentList -v -count=1
*/
func TestGetRecentList(t *testing.T) {
	cp := NewDataCollectPlan()
	pls, err := cp.GetRecentList(109)
	if err != nil {
		t.Fatal(err)
	}
	for _, p := range pls {
		t.Log(p)
	}
}

/*
go test ./logics/data_collect -run TestProgressAnalysis -v -count=1
*/
func TestProgressAnalysis(t *testing.T) {
	companyID := 109
	planID := 96
	interviewID := 1
	cp := NewDataCollectPlan()
	total, planProgressList, err := cp.ProgressAnalysis(companyID, planID, interviewID)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(total)
	t.Log(planProgressList)
}
func TestDataCollectPlan_List(t *testing.T) {
	cp := NewDataCollectPlan()
	total, planL, err := cp.List("", nil, nil, 109, 19, 19, 1, 2, []int{1, 2}, "")
	if err != nil {
		t.Fatal(err)
	}
	t.Log(total)
	t.Log(planL)
}
func TestDataCollectPlan_GetUserNamesByUserIds(t *testing.T) {
	cp := NewDataCollectPlan()
	projectids := make([]int, 0)
	projectids = append(projectids, 600)
	pl, err := cp.GetProjectNameByIds(projectids)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(pl)
}

func TestDataCollectCreateInsert(t *testing.T) {
	insertData := &models.DataCollectPlans{
		ProjectId:   1,
		PositionId:  1,
		Name:        "测试",
		Status:      1,
		VerifyPhone: 1,
		IsDeleted:   1,
	}
	_, err := models.DataCollectPlansModel.Insert(insertData)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(insertData.Id)
}
